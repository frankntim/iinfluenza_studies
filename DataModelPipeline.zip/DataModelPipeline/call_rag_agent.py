# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------

# MAGIC %pip install networkx

# COMMAND ----------

# MAGIC %pip install langgraph==0.3.4 langchain-openai==0.3.0 langchain-experimental==0.3.4 databricks-langchain  databricks-agents databricks-sql-connector sqlalchemy  pydantic tabulate
# MAGIC
# MAGIC %restart_python dbutils.library.restartPython()
# MAGIC

# COMMAND ----------

from rag_agent import call_rag_agent #workflow, summarize_final_output

# COMMAND ----------

joined$VISITCD <- factor(joined$VISITCD, levels = c("SCR",

                                        "C1D1PRE", "C1D1HR6","C1D1HR16","C1D2",

                                        "C1D8PRE", "C1D8HR6","C1D9",

                                        "C1D15PRE", "C1D15HR6", "C1D16",

                                        "C1D22PRE", "C1D22HR6","C1D23",

                                        "C2D1PRE", "C2D15PRE","C3D1PRE",

                                        "C3D15PRE","C3D29","C4D1PRE","C4D15","C4D29",

                                        "C5D1PRE","C5D15PRE","C5D29","C6D1PRE","C6D15",

                                        "EOT","SFU","LFUMONTH3","LTFU","UNK",

                                        "UNSCH"))

 
Thursday 1:54 PM Meeting ended: 20m 58s 

 

# COMMAND ----------

prompt_input =  "How many cohorts are there and for each how many subjects in study AMG160"
prompt_input = "Provide the distribution of subjects with adverse event flags indicating Y in AMG160?"


prompt_input = "Arrange these distinct visit  codes in correct priorities: C1D1PRE,SCR,UNSCH, C1D1HR6,C1D1HR16?"
model_name = "project-115-Precision_Medicine_AI_Agent-2"
inference,result_df,sql_query = call_rag_agent(prompt_input,model_name)

# COMMAND ----------

inference

# COMMAND ----------

print(sql_query)

# COMMAND ----------

result_df

# COMMAND ----------

