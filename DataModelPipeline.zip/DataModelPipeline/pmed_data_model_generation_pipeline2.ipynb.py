# Databricks notebook source
##Install OpenAI library
%pip install openai

# COMMAND ----------

import os
from openai import OpenAI
from databricks.connect import DatabricksSession

# Set the Databricks host and user token
os.environ["DATABRICKS_HOST"] = "https://amgen-ai-dev.cloud.databricks.com/"
os.environ["DATABRICKS_TOKEN"] = "dapi09f0df7c995c9e37c8a40f7b681a26d4"

# COMMAND ----------

from pyspark.sql.functions import sha2, concat_ws

# Read the source table into a DataFrame
result_df = spark.read.table("edl_dev.cbd_sandbox.pdm_data_intermediate_prod")
display(result_df)

# COMMAND ----------

import json

VISITCD_LEVELS = ("SCR",
"C1D1PRE", "C1D1HR6","C1D1HR16","C1D2",
"C1D8PRE", "C1D8HR6","C1D9",
"C1D15PRE", "C1D15HR6", "C1D16",
"C1D22PRE", "C1D22HR6","C1D23",
"C2D1PRE", "C2D15PRE","C3D1PRE",
"C3D15PRE","C3D29","C4D1PRE","C4D15","C4D29",
"C5D1PRE","C5D15PRE","C5D29","C6D1PRE","C6D15",
"EOT","SFU","LFUMONTH3","LTFU","UNK",
"UNSCH")
VISIT_ORDER = {visit: idx for idx, visit in enumerate(VISITCD_LEVELS)}
VISIT_ORDER_str  = json.dumps(VISIT_ORDER)
VISIT_ORDER_str

# COMMAND ----------

import json


from pyspark.sql.functions import when, lit

result_dff = result_df.withColumn(
    "column_order_priorities",
    when(result_df["column_name"] == "VISITCD", lit(VISIT_ORDER_str)).otherwise(lit("N/A"))
)

display(result_dff)

# COMMAND ----------

result_dff.count()

# COMMAND ----------

result_df.columns

# COMMAND ----------

result_dff = result_dff[['table_name',
 'table_description',
 'table_details',
 'column_name',
 'column_data_type',
 'column_description',
 'column_details',
 'column_order_priorities',
 'embedded_text'
 ]]

# COMMAND ----------

display(result_dff)

# COMMAND ----------

display(result_dff[result_dff['column_name']=='VISITCD'])

# COMMAND ----------

# MAGIC %md
# MAGIC **Add id to the dataframe**

# COMMAND ----------

# Add an id column with a unique hash produced from the table_name & column_name
result_df_with_id = result_dff.withColumn("id", sha2(concat_ws("_", "table_name", "column_name"), 256))

# COMMAND ----------

#display(result_df_with_id)
display(result_df_with_id[result_df_with_id['column_name']=='VISITCD'])

# COMMAND ----------

# Write the resulting DataFrame with the id column to the specified table
result_df_with_id.write.mode("overwrite").saveAsTable("edl_dev.cbd_sandbox.pdm_data_intermediate_prod_index_v2")


# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE edl_dev.cbd_sandbox.pdm_data_intermediate_prod_index_v2
# MAGIC SET TBLPROPERTIES (
# MAGIC   delta.enableChangeDataFeed = true
# MAGIC )

# COMMAND ----------

# MAGIC %md
# MAGIC **Create Vector Index**

# COMMAND ----------

# MAGIC %pip install databricks-vectorsearch
# MAGIC dbutils.library.restartPython()
# MAGIC %restart_python

# COMMAND ----------

#create vector 
from databricks.vector_search.client import VectorSearchClient

vs_client = VectorSearchClient()

index_name = "edl_dev.cbd_sandbox.pmed_prod_ddm_vector_index_v4"

vs_client.create_delta_sync_index(
    endpoint_name="aiwb-shared-endpoint-1",
    source_table_name="edl_dev.cbd_sandbox.pdm_data_intermediate_prod_index_v2",
    index_name=index_name,
    pipeline_type="TRIGGERED",
    primary_key="id",
    embedding_source_column="embedded_text",
    embedding_model_endpoint_name="project-115-Precision_Medicine_AI_Agent-1"
)
