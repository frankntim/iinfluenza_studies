# Databricks notebook source

#keepalive
import time
import os

while True:
    print('hello')
    time.sleep(1)
    os.system('clear')

# COMMAND ----------

##Install OpenAI library
%pip install openai


# COMMAND ----------

# MAGIC %restart_python or dbutils.library.restartPython()

# COMMAND ----------

from openai import OpenAI

# COMMAND ----------

# MAGIC %md
# MAGIC ## ALL Table Listing Enumeration

# COMMAND ----------

import os
from databricks.connect import DatabricksSession

# Set the Databricks host and user token
os.environ["DATABRICKS_HOST"] = "https://amgen-ai-dev.cloud.databricks.com/"
os.environ["DATABRICKS_TOKEN"] = "dapi09f0df7c995c9e37c8a40f7b681a26d4"

# Create a new Spark session using Databricks Connect with the supplied token
spark = DatabricksSession.builder.getOrCreate()

tables_df = spark.sql("SHOW TABLES IN edl_prd.cdh_bite_prd_publish").select("tableName")
display(tables_df)

# Filter tables to only include those that can be accessed and are not 'user_access'
accessible_tables = []
for row in tables_df.collect():
    table = row["tableName"]
    if table == "user_access":
        continue
    try:
        # Try to access the table
        spark.table(f"edl_prd.cdh_bite_prd_publish.{table}").limit(1).collect()
        #print(table)
        accessible_tables.append((table))
    except:
        # Skip tables that cannot be accessed
        continue

# Create a DataFrame of accessible tables
accessible_tables_df = spark.createDataFrame(accessible_tables, ["table_name"])

# COMMAND ----------

# MAGIC %md
# MAGIC **Step 1: Accessible Tables Under Clinical Trial Studies**

# COMMAND ----------

# Get the list of tables in the database
tables_df = spark.sql("SHOW TABLES IN edl_prd.cdh_bite_prd_publish").select("tableName")

# Filter tables to only include those that can be accessed and are not 'user_access'
accessible_tables = []
for row in tables_df.collect():
    table = row["tableName"]
    if table == "user_access":
        continue
    try:
        # Try to access the table
        spark.table(f"edl_prd.cdh_bite_prd_publish.{table}").limit(1).collect()
        #print(table)
        accessible_tables.append((table))
    except:
        # Skip tables that cannot be accessed
        continue

# Create a DataFrame of accessible tables
accessible_tables_df = spark.createDataFrame(accessible_tables, ["table_name"])

# Display the DataFrame of accessible tables
display(accessible_tables_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Schema Walk

# COMMAND ----------

# Get the list of tables in the database
#tables_df = spark.sql("SHOW TABLES IN edl_prd.cdh_bite_prd_publish").select("tableName")

# Filter tables to only include those that can be accessed and are not 'user_access'
accessible_tables = []
for row in accessible_tables_df.collect():
    table = row["table_name"]
    if table == "user_access":
        continue
    try:
        # Try to access the table
        spark.table(f"edl_prd.cdh_bite_prd_publish.{table}").limit(1).collect()
        accessible_tables.append((table,))
    except:
        # Skip tables that cannot be accessed
        continue

# Create a DataFrame of accessible tables
accessible_tables_df = spark.createDataFrame(accessible_tables, ["table_name"])

# Extract table name, column name, and column data type for all tables
data = []
for row in accessible_tables_df.collect():
    table = row["table_name"]
    schema = spark.table(f"edl_prd.cdh_bite_prd_publish.{table}").schema
    data.extend([(f"edl_prd.cdh_bite_prd_publish.{table}", field.name, field.dataType.simpleString()) for field in schema])

# Create a DataFrame
df = spark.createDataFrame(data, ["table_name", "column_name", "column_data_type"])

# Display the DataFrame
display(df)

# COMMAND ----------

df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Generate Source Data Model Table

# COMMAND ----------

raw_source_table = "edl_dev.cbd_sandbox.pdm_data_dict_prod_raw_3"

df.write.mode("append").format("delta").saveAsTable(raw_source_table)

# COMMAND ----------

#Improve Data Model Inference



# COMMAND ----------

spark.conf.set("spark.databricks.streaming.realTimeMode.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC ## PDM Data Model Class

# COMMAND ----------

import yaml

# Load the prompt from YAML only once
with open("/Workspace/Users/rswens01@amgen.com/Agent Approaches/datamodeling/production/properties/pmed_ddm_assist.yaml", "r") as f:
    prompt_yaml = yaml.safe_load(f)
prompt = prompt_yaml["prompt"]

# Example YAML file representation (pmed_ddm_assist.yaml):
# prompt: |
#   Provide a brief description of the table and a brief description of the columns. The format of the returned response should be in a CSV format of table_name, table_description, column_name, column_description, and column_data_type. For the table descriptions please keep the description very brief, using 2 to 3 words maximum. Do not modify the input table_name or any column_name in any way. The table_names must be inputted and returned in exactly the same form: edl_prd.cdh_bite_prd_publish_amgXXX_YYYYMMDD_ne_domain. For example edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_adsl is correct. Returning only amg160_20180101_ne_adsl is insufficient and unacceptable.  Also please follow these rules: when a table has _adsl in the name, assign subjects data, when a table has _ae in the name assign adverse events, when _ex, assign exposures, when _cm, assign concomittment medications, when _cb assign biomarkers, when ngs assign gene variants, when rna assign transcriptomics, and when protein, assign protein data.
#   Please also consider the following definitions, and do not leave any unknown or as N/A. Instead arrive at a definition.
#   
#     PRODUCT:The product name, STUDYID:The study identifier, SUBJID:The subject identifier, TRTSTDTC:The treatment start date, PLNCYDUR:Planned cycle duration, COHRTARM:Cohort arm, DOSETARN:Dose target, DOSESEQP:Dose sequence, DOSEFIRA:First dose amount, DOSE2A:Second dose amount, DOSE3A:Third dose amount, DOSE4A:fouth dose amount, DOSEMAXA:Maximum dose amount, DOSETARP:Dose target percentage, ETHNIC:ethnicity, AGE:subject age, SEX:subject gender, PROPHYL:Prophylaxis indicator, IP2DAY:IP2 day, adj_premed:Adjusted premedication, COHORT:Cohort, SBJTYPE:Subject Type, DMSPART:DMS part, COHRTTYP:Cohort type, DMTRTGRP:DM treatment group, dose:Dosse, phase:Phase, treatment_free_interval_days:Treatment-free interval in days, PRIORPD:Prior PD, PRIORPDDTC:Prior PD date, COUNTRY:Country,COUNTRYL:Country Label, REGION1:Region, ACTARM:Actual Arm
#     TRTDURD:Treatment duration in days, PDSTEPOC:PD step, PLCIVDUR:Planned cycle duration, DCUTDT:Data cut-off date, ACOHORT:Actual cohort, SAFFL:Safety Flag, RECLEVFL:Recurrent event flag, RECCEVFL:Recurrent event confirmation flag, PSAEVCFL:PSA event confirmation flag, ECOGBL:ECOG baseline, NHXACTHR:NHX activity,
#     TNMSTGBL:TNM stage baseline, AFIBFL:Atrial fibrillation flag, AFIBMXDT:Atrial fibrillation maximum date
#     AFIBMXGR:Atrial fibrillation maximum grade, CRSFL:CRS flag, CRSFIRGR:CRS first grade
#     CRSFIRDT:CRS first date, CRSMXDTC:CRS maximum date, CRSMXGRD:CRS maximum grade, SCD:SCD
#     SCDCRSFL:SCD CRS flag, SCDCRSMX:SCD CRS maximum, SCDFL:SCD flag, SCDMXDTC:SCD maximum date
#     SCDMXGRD:SCD maximum grade, SCD_CRS:SCD CRS, SCRSMDTC:SCD CRS date, TTCRSDY:Time to CRS in days
#     TTCRSHR: Time to CRS in hours, NEUROFL:Neuro flag, NEUROMDT:Neuro maximum date, NEUROMGR:Neuro maximum grade,
#     NEUTROFL:Neutropenia flag, NPMGRDTC:Neutropenia maximum date, NPMAXGRD:Neutropenia maximum grade
#     EXQTY_C:Ex quantity, LSTIPDTC:Last IP date, TRTDURDY:Treatment duration in days,MEANDOSE:Mean dose,
#     DOSENUMT:Dose number, BASESLD:Baseline SLD, BESTSLDP:Best SLD percentage, FADTC:FA date, primary_tumor_type:Primary tumor type, HX:History, HXHLGT:History high-level group term
#     HXHLT:History high-level term, HXLLT:History low-level term, HXPT:History preferred term,
#     HXSOC:History system organ class, HXSTAT:History status

# COMMAND ----------

import pandas as pd

class ProdDataModel:
    def __init__(self):
        """Initialization"""
        self.DATABRICKS_HOST = "https://amgen-ai-dev.cloud.databricks.com/"
        self.DATABRICKS_TOKEN = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
        self.base_url = self.DATABRICKS_HOST + 'serving-endpoints'
        self.api_key = "dapi09f0df7c995c9e37c8a40f7b681a26d4"
        self.model_name = "project-115-Precision_Medicine_AI_Agent-2"
        self.response_data = []
    
    def processRequest(self, inputDF):
        client = OpenAI(api_key=self.api_key, base_url=self.base_url)
        
        # Convert DataFrame to list of dictionaries
        input_data = inputDF.collect()
        # prompt = """Provide a brief description of the table and a brief description of the columns. The format of the returned response should be in a CSV format of table_name, table_description, column_name, column_description, and column_data_type. For the table descriptions please keep the description very brief, using 2 to 3 words maximum. Do not modify the input table_name or any column_name in any way. The table_names must be inputted and returned in exactly the same form: edl_prd.cdh_bite_prd_publish_amgXXX_YYYYMMDD_ne_domain. For example edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_adsl is correct. Returning only amg160_20180101_ne_adsl is insufficient and unacceptable.  Also please follow these rules: when a table has _adsl in the name, assign subjects data, when a table has _ae in the name assign adverse events, when _ex, assign exposures, when _cm, assign concomittment medications, when _cb assign biomarkers, when ngs assign gene variants, when rna assign transcriptomics, and when protein, assign protein data.\n Please also consider the following definitions, and do not leave any unknown or as N/A. Instead arrive at a definition. \n
        
        # PRODUCT:The product name, STUDYID:The study identifier, SUBJID:The subject identifier, TRTSTDTC:The treatment start date, PLNCYDUR:Planned cycle duration, COHRTARM:Cohort arm, DOSETARN:Dose target, DOSESEQP:Dose sequence, DOSEFIRA:First dose amount, DOSE2A:Second dose amount, DOSE3A:Third dose amount, DOSE4A:fouth dose amount, DOSEMAXA:Maximum dose amount, DOSETARP:Dose target percentage, ETHNIC:ethnicity, AGE:subject age, SEX:subject gender, PROPHYL:Prophylaxis indicator, IP2DAY:IP2 day, adj_premed:Adjusted premedication, COHORT:Cohort, SBJTYPE:Subject Type, DMSPART:DMS part, COHRTTYP:Cohort type, DMTRTGRP:DM treatment group, dose:Dosse, phase:Phase, treatment_free_interval_days:Treatment-free interval in days, PRIORPD:Prior PD, PRIORPDDTC:Prior PD date, COUNTRY:Country,COUNTRYL:Country Label, REGION1:Region, ACTARM:Actual Arm
        # TRTDURD:Treatment duration in days, PDSTEPOC:PD step, PLCIVDUR:Planned cycle duration, DCUTDT:Data cut-off date, ACOHORT:Actual cohort, SAFFL:Safety Flag, RECLEVFL:Recurrent event flag, RECCEVFL:Recurrent event confirmation flag, PSAEVCFL:PSA event confirmation flag, ECOGBL:ECOG baseline, NHXACTHR:NHX activity, 
        # TNMSTGBL:TNM stage baseline, AFIBFL:Atrial fibrillation flag, AFIBMXDT:Atrial fibrillation maximum date
        # AFIBMXGR:Atrial fibrillation maximum grade, CRSFL:CRS flag, CRSFIRGR:CRS first grade
        # CRSFIRDT:CRS first date, CRSMXDTC:CRS maximum date, CRSMXGRD:CRS maximum grade, SCD:SCD
        # SCDCRSFL:SCD CRS flag, SCDCRSMX:SCD CRS maximum, SCDFL:SCD flag, SCDMXDTC:SCD maximum date
        # SCDMXGRD:SCD maximum grade, SCD_CRS:SCD CRS, SCRSMDTC:SCD CRS date, TTCRSDY:Time to CRS in days
        # TTCRSHR: Time to CRS in hours, NEUROFL:Neuro flag, NEUROMDT:Neuro maximum date, NEUROMGR:Neuro maximum grade, 
        # NEUTROFL:Neutropenia flag, NPMGRDTC:Neutropenia maximum date, NPMAXGRD:Neutropenia maximum grade
        # EXQTY_C:Ex quantity, LSTIPDTC:Last IP date, TRTDURDY:Treatment duration in days,MEANDOSE:Mean dose, 
        # DOSENUMT:Dose number, BASESLD:Baseline SLD, BESTSLDP:Best SLD percentage, FADTC:FA date, primary_tumor_type:Primary tumor type, HX:History, HXHLGT:History high-level group term
        # HXHLT:History high-level term, HXLLT:History low-level term, HXPT:History preferred term, 
        # HXSOC:History system organ class, HXSTAT:History status"""

        messages = [{"role": "system", "content": prompt}]
        for row in input_data:
             messages.append({
                "role": "user",
                "content": f"Table: {row['table_name']}, Column: {row['column_name']}, Type: {row['column_data_type']}"
            })
        
        response = client.chat.completions.create(
            model=self.model_name,
            messages=messages,
            max_tokens=16384
        )
        
        # Parse the CSV response wrapped in JSON
        csv_content = response.choices[0].message.content.strip()
        csv_lines = csv_content.split('\n')
        
        for line in csv_lines:
            parts = line.split(',')
            if len(parts) == 5:
                table_name, table_description, column_name, column_description, column_data_type = parts
                # Skip header line by checking if it matches the header labels
                if (table_name.strip().lower() == 'table_name' and
                    table_description.strip().lower() == 'table_description' and
                    column_name.strip().lower() == 'column_name' and
                    column_description.strip().lower() == 'column_description' and
                    column_data_type.strip().lower() == 'column_data_type'):
                    continue
                self.response_data.append({
                    'table_name': table_name.strip(),
                    'table_description': table_description.strip(),
                    'column_name': column_name.strip(),
                    'column_data_type': column_data_type.strip(),
                    'column_description': column_description.strip()
                })
            else:
                # Handle the case where the line does not have exactly 5 parts
                print("empty or irrelevant line")
    
    def get_response(self):
        return pd.DataFrame(self.response_data)

# COMMAND ----------

# MAGIC %md
# MAGIC # CORRECT Final Population Code

# COMMAND ----------

input_dir = "/Volumes/edl_dev/cbd_sandbox/data_model/input"
print(input_dir)
output_catalog = "edl_dev.cbd_sandbox" #databricks warehouse & catalog
print(output_catalog)
db_table = "pdm_data_dict_prod_3"
dbpath = output_catalog + "." + db_table

# Initialize the ProdDataModel instance
pdm = ProdDataModel()

# Read the table into a DataFrame
df = spark.read.table("edl_dev.cbd_sandbox.pdm_data_dict_prod_raw_3")
df.createOrReplaceTempView("pdm_data_dict_prod_raw_3")
spark.sql("""
          CREATE OR REPLACE TEMP VIEW pdm_data_dict_prod_raw_chunked AS
          SELECT *,
                 FLOOR((ROW_NUMBER() OVER (ORDER by table_name, column_name) -1) / 25) +1 AS chunk_id
          FROM pdm_data_dict_prod_raw_3""")

total_chunks = (df.count() + 24) // 25  # Calculate total chunks based on row count

for i in range(1, total_chunks + 1):
    df_chunk = spark.sql(f"""SELECT table_name, column_name, column_data_type FROM pdm_data_dict_prod_raw_chunked WHERE chunk_id = {i}""")

    display(df_chunk)
    print(df_chunk.count())
    print(f"Processing chunk {i}")
    pdm.processRequest(df_chunk)
    response_df = pdm.get_response()
    # Filter out rows with 'N/A' values to avoid appending extra rows
    response_df_filtered = response_df[response_df['table_name'] != 'N/A']
    # Convert pandas DataFrame to Spark DataFrame
    spark_df = spark.createDataFrame(response_df_filtered)
    # Write or append the data to the table
    spark_df.write.mode("append").saveAsTable(dbpath)
    # Clear response data to avoid duplication in the next chunk
    pdm.response_data.clear()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Produce Table Instructions 

# COMMAND ----------

# Load the table into a DataFrame
df_dict_prod = spark.read.table("edl_dev.cbd_sandbox.pdm_data_dict_prod_3")

# Load the CSV into another DataFrame
df_csv = spark.read.csv("dbfs:/Volumes/edl_dev/cbd_sandbox/data_model/csvs/data_modelv3_table_instructions.csv", header=True)

# Create temporary views for SQL queries
df_dict_prod.createOrReplaceTempView("pdm_data_dict_prod")
df_csv.createOrReplaceTempView("csv_data_model")

# SQL query to assign table_details based on table_type in table_name
result_df = spark.sql("""
    SELECT 
        dict.table_name,
        csv.table_details
    FROM 
        pdm_data_dict_prod dict
    LEFT JOIN 
        csv_data_model csv
    ON 
        dict.table_name LIKE CONCAT('%', csv.table_type, '%')
""")

# Ensure the result has exactly 14400 rows
result_df = result_df.limit(14400)

# Write the new DataFrame to the specified table
result_df.write.mode("overwrite").saveAsTable("edl_dev.cbd_sandbox.pdm_data_instructions_prod_3")

# COMMAND ----------

df_csv = spark.read.csv("dbfs:/Volumes/edl_dev/cbd_sandbox/data_model/csvs/data_modelv3_table_instructions.csv", header=True)
dff = df_csv.toPandas()
dff.head(10)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Produce Column Meta Details

# COMMAND ----------

# Load the table into a DataFrame
df_dict_prod = spark.read.table("edl_dev.cbd_sandbox.pdm_data_dict_prod_3")

# Load the CSV into another DataFrame
df_column_details = spark.read.csv("/Volumes/edl_dev/cbd_sandbox/data_model/csvs/data_modelv3_column_details.csv", header=True)

# Create temporary views for SQL queries
df_dict_prod.createOrReplaceTempView("pdm_data_dict_prod")
df_column_details.createOrReplaceTempView("column_details_csv")

# SQL query to join tables based on table_name containing table_type and matching column_name
result_df = spark.sql("""
    SELECT 
        dict.table_name,
        col.column_name,
        col.column_details
    FROM 
        pdm_data_dict_prod dict
    LEFT JOIN 
        column_details_csv col
    ON 
        dict.table_name LIKE CONCAT('%', col.table_type, '%') AND
        dict.column_name = col.column_name
    WHERE 
        col.column_details IS NOT NULL
""")

# Write the resulting DataFrame to the specified table
result_df.write.mode("overwrite").saveAsTable("edl_dev.cbd_sandbox.pdm_data_meta_prod_3")

# COMMAND ----------

# Column ordering
import json

VISITCD_LEVELS = ("SCR",
"C1D1PRE", "C1D1HR6","C1D1HR16","C1D2",
"C1D8PRE", "C1D8HR6","C1D9",
"C1D15PRE", "C1D15HR6", "C1D16",
"C1D22PRE", "C1D22HR6","C1D23",
"C2D1PRE", "C2D15PRE","C3D1PRE",
"C3D15PRE","C3D29","C4D1PRE","C4D15","C4D29",
"C5D1PRE","C5D15PRE","C5D29","C6D1PRE","C6D15",
"EOT","SFU","LFUMONTH3","LTFU","UNK",
"UNSCH")
VISIT_ORDER = {visit: idx for idx, visit in enumerate(VISITCD_LEVELS)}
VISIT_ORDER_str  = json.dumps(VISIT_ORDER)
VISIT_ORDER_str

# COMMAND ----------

import json


from pyspark.sql.functions import when, lit
# Load the table into a DataFrame
df_dict_prod = spark.read.table("edl_dev.cbd_sandbox.pdm_data_dict_prod_3")
#df_dict_prod_df  = df_dict_prod.toPandas()


df_dict_prod = df_dict_prod.withColumn(
    "column_order_priorities",
    when(df_dict_prod["column_name"] == "VISITCD", lit(VISIT_ORDER_str)).otherwise(lit("N/A"))
)
df_dict_prod_df  = df_dict_prod.toPandas()
display(df_dict_prod_df)

# Save this as prod_4
df_dict_prod.write.mode("overwrite").saveAsTable("edl_dev.cbd_sandbox.pdm_data_dict_prod_4")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Final Intermmediate Table ready for vectorization

# COMMAND ----------

# Read the tables into DataFrames
df_dict_prod = spark.read.table("edl_dev.cbd_sandbox.pdm_data_dict_prod_3")
df_meta_prod = spark.read.table("edl_dev.cbd_sandbox.pdm_data_meta_prod_3")
df_instructions_prod = spark.read.table("edl_dev.cbd_sandbox.pdm_data_instructions_prod_3")

# Create temporary views for SQL queries
df_dict_prod.createOrReplaceTempView("pdm_data_dict_prod")
df_meta_prod.createOrReplaceTempView("pdm_data_meta_prod")
df_instructions_prod.createOrReplaceTempView("pdm_data_instructions_prod")

# SQL query to join tables and get the required information with embedded_text as JSON
result_df = spark.sql("""
    SELECT 
        dict.table_name,
        dict.table_description,
        instr.table_details,
        dict.column_name,
        dict.column_data_type,
        dict.column_description,
        dict.column_order_priorities,
        meta.column_details,
        to_json(named_struct(
            'table_name', dict.table_name,
            'table_description', dict.table_description,
            'table_details', instr.table_details,
            'column_name', dict.column_name,
            'column_data_type', dict.column_data_type,
            'column_description', dict.column_description,
            'column_order_priorities', dict.column_order_priorities,
            'column_details', meta.column_details
        )) AS embedded_text
    FROM 
        pdm_data_dict_prod dict
    LEFT JOIN 
        pdm_data_instructions_prod instr
    ON 
        dict.table_name = instr.table_name
    LEFT JOIN 
        pdm_data_meta_prod meta
    ON 
        dict.table_name = meta.table_name AND dict.column_name = meta.column_name
    GROUP BY
        dict.table_name,
        dict.table_description,
        instr.table_details,
        dict.column_name,
        dict.column_data_type,
        dict.column_description,
        meta.column_details
""")

# Write the resulting DataFrame to the specified table
result_df.write.mode("overwrite").saveAsTable("edl_dev.cbd_sandbox.pdm_data_intermediate_prod")

display(result_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE edl_dev.cbd_sandbox.pdm_data_intermediate_prod_index
# MAGIC SET TBLPROPERTIES (delta.enableChangeDataFeed = true)

# COMMAND ----------

from pyspark.sql.functions import sha2, concat_ws

# Read the source table into a DataFrame
result_df = spark.read.table("edl_dev.cbd_sandbox.pdm_data_intermediate_prod")

# Add an id column with a unique hash produced from the table_name & column_name
result_df_with_id = result_df.withColumn("id", sha2(concat_ws("_", "table_name", "column_name"), 256))

# Write the resulting DataFrame with the id column to the specified table
result_df_with_id.write.mode("overwrite").saveAsTable("edl_dev.cbd_sandbox.pdm_data_intermediate_prod_index")

display(result_df_with_id)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Vector Index

# COMMAND ----------

# MAGIC %pip install databricks-vectorsearch
# MAGIC dbutils.library.restartPython()
# MAGIC %restart_python

# COMMAND ----------

#Create Vector Index 
from databricks.vector_search.client import VectorSearchClient

client = VectorSearchClient(disable_notice=True)

client.create_endpoint(
    name="pmed_prod_metadata",
    endpoint_type = "STANDARD"
)

# COMMAND ----------

#create vector 
from databricks.vector_search.client import VectorSearchClient

vs_client = VectorSearchClient()

index_name = "edl_dev.cbd_sandbox.pmed_prod_ddm_vector_index_3"

vs_client.create_delta_sync_index(
    endpoint_name="pmed_prod_metadata",
    source_table_name="edl_dev.cbd_sandbox.pdm_data_intermediate_prod_index",
    index_name=index_name,
    pipeline_type="TRIGGERED",
    primary_key="id",
    embedding_source_column="embedded_text",
    embedding_model_endpoint_name="project-115-Precision_Medicine_AI_Agent-1"
)


# COMMAND ----------

# MAGIC %md
# MAGIC #### Todo: Rearrange the above code around the basis of per user to vectorize the data model per user. Also when a user has less than the complete total number of tables, figure out how many studies that represents, and present a message or part of a response message to the user that their query will pertain to only X % of studies and has access to X number of tables out of Y tables. 

# COMMAND ----------

# Read the user entitlements table into a DataFrame
df_user_entitlements = spark.read.table("edl_prd.cdh_bite_prd_publish.user_access")

# Create a temporary view for SQL queries (session-scoped in memory logical construct, not persisted)
df_user_entitlements.createOrReplaceTempView("user_entitlements")

# SQL query to list users and their entitlements to tables in edl_prd.cdh_bite_prd_publish
result_df = spark.sql("""
    SELECT 
        username,
        study_id,
        program_id
    FROM 
        user_entitlements
    WHERE 
        program_id LIKE 'AMG%'
    ORDER BY 
        username, study_id
""")

display(result_df)

# COMMAND ----------

result_df[result_df['username'] =='rswens01'].head(100)

# COMMAND ----------

from pyspark.sql.functions import lower, concat_ws, lit, col, explode, array

table_suffixes = ["ngs", "ae", "ex", "rna", "protein", "cb", "cm", "adsl"]

df_with_lower = result_df.withColumn("program_id", lower(col("program_id")))

df_with_prefix = df_with_lower.withColumn(
    "prefix", concat_ws("_", col("program_id"), col("study_id"), lit("ne_"))
)

df_exploded = df_with_prefix.withColumn(
    "table_name",
    explode(array([concat_ws("", col("prefix"), lit(suffix)) for suffix in table_suffixes]))
)

user_entitlements = df_exploded.select(
    "username", "study_id", "program_id", "table_name"
)

display(user_entitlements)

# COMMAND ----------

##This code run with a service account & super user of PMED warehouse and catalog would enumerate all exisitng tables, and allow us to proceed to collect meta-data for those which exists and be cross-ed referenced with the user entitlements to produce per-User vector indexes. This will also feed some metrics and other details into the vector index which informs the user that in total there are Y studies, in which they are permitted to X studies, what those studies are, and that their queries will only be answereed or served on the basis of what studies they they access to. The concern is less a security one, then it is in returning more information for inference to confuse the model in generating SQLs which will fail for the specific user given that under their access, they will not be able to include or query other studies that they cannot access. 

# Get the list of tables in the database
tables_df = spark.sql("SHOW TABLES IN edl_prd.cdh_bite_prd_publish").select("tableName")

# Filter tables to only include those that can be accessed and are not 'user_access'
accessible_tables = []
for row in tables_df.collect():
    table = row["tableName"]
    if table == "user_access":
        continue
    try:
        # Try to access the table
        spark.table(f"edl_prd.cdh_bite_prd_publish.{table}").limit(1).collect()
        accessible_tables.append((table,))
    except:
        # Skip tables that cannot be accessed
        continue

# Create a DataFrame of accessible tables
accessible_tables_df = spark.createDataFrame(accessible_tables, ["table_name"])

## Filter and group tables based on the uniqueness in the portion of the tablename: "amgXXX_YYYYMMDD_"
#import re
#from collections import defaultdict

#pattern = re.compile(r"(amg\d+_\d+_)")
#grouped_tables = defaultdict(list)

#for row in accessible_tables_df.collect():
  #  table_name = row["table_name"]
 #   match = pattern.match(table_name)
 #   if match:
 #       key = match.group(1)
 #       grouped_tables[key].append(table_name)

# Output the parquet files to the specified directory
#output_dir = "/Workspace/Users/rswens01@amgen.com/datamodeling/production/parquets"

#for key, tables in grouped_tables.items():
#    df = spark.createDataFrame([(table,) for table in tables], ["table_name"])
#    df.write.mode("overwrite").parquet(f"{output_dir}/{key}tables.parquet")

# Display the DataFrame of accessible tables
display(accessible_tables_df)

# COMMAND ----------



# COMMAND ----------

from databricks.vector_search.client import VectorSearchClient
from datetime import datetime, timezone

client = VectorSearchClient()

ENDPOINT = "pmed_prod_metadata"
INDEX = "edl_dev.cbd_sandbox.pmed_prod_ddm_vector_index_3"

idx = client.get_index(
    endpoint_name=ENDPOINT,
    index_name=INDEX,
)
info = idx.describe()

created = (info.get("created_timestamp"))
ts_ms = ((info.get("delta_sync_status") or {}).get("last_processed_timestamp_ms")
         or info.get("last_processed_timestampe_ms")
)

if ts_ms is not None:
    ts_iso = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc).isoformat()
    print("Last processed time: ", ts_iso)
else:
    print(info)

# COMMAND ----------

#python
# Query the table
df = spark.read.table("edl_dev.cbd_sandbox.pdm_data_intermediate_prod_index")

# Write to CSV
df_pd = df.toPandas()
df_pd.to_csv("/Volumes/edl_dev/cbd_sandbox/data_model/csvs/pmed_prod_ddm_vector_index.csv", index=False)