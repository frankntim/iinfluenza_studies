# Databricks notebook source
import pandas as pd

# COMMAND ----------

# Fix: Remove ace_tools and use display() for Databricks notebooks
import pandas as pd
import ast

column_definitions = pd.read_csv("pmed_prod_ddm_vector_index.csv")

adsl_tables = [
    "edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_adsl",
    "edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_adsl",
    "edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_adsl",
    "edl_prd.cdh_bite_prd_publish.amg673_20160377_ne_adsl",
    "edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl"
]

adsl_definitions = column_definitions[
    column_definitions['table_name'].isin(adsl_tables)
]

comparison = (
    adsl_definitions.groupby(['column_name', 'table_name'])
    .size()
    .unstack(fill_value=0)
    .applymap(lambda x: "Yes" if x > 0 else "")
)

comparison = comparison.assign(
    tables_present_in=comparison.apply(
        lambda row: [col for col in comparison.columns if row[col] == "Yes"],
        axis=1
    )
)

different_columns = comparison[
    comparison['tables_present_in'].map(len) != len(adsl_tables)
]
different_columns = different_columns.reset_index()
display(different_columns)

# COMMAND ----------

# MAGIC %md
# MAGIC **ADSL**

# COMMAND ----------

# Fix: Remove ace_tools and use display() for Databricks notebooks
import pandas as pd
import ast

column_definitions = pd.read_csv("pmed_prod_ddm_vector_index.csv")

adsl_tables = [
    "edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_adsl",
    "edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_adsl",
    "edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_adsl",
    "edl_prd.cdh_bite_prd_publish.amg673_20160377_ne_adsl",
    "edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl"
]

adsl_definitions = column_definitions[
    column_definitions['table_name'].isin(adsl_tables)
]

comparison = (
    adsl_definitions.groupby(['column_name', 'table_name'])
    .size()
    .unstack(fill_value=0)
    .applymap(lambda x: "Yes" if x > 0 else "")
)

comparison = comparison.assign(
    tables_present_in=comparison.apply(
        lambda row: [col for col in comparison.columns if row[col] == "Yes"],
        axis=1
    )
)

different_columns = comparison[
    comparison['tables_present_in'].map(len) != len(adsl_tables)
]

#display(different_columns)
different_columns = different_columns.reset_index()
display(different_columns)

# COMMAND ----------

# MAGIC %md
# MAGIC **Molecule AMG160**

# COMMAND ----------

adsl_tables =['edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_adsl', 
'edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_cb', 
'edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_ae', 
'edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_cm', 
'edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_ex', 
'edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_ngs', 
'edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_protein', 
'edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_rna']

column_definitions = pd.read_csv("pmed_prod_ddm_vector_index.csv")

adsl_definitions = column_definitions[
    column_definitions['table_name'].isin(adsl_tables)
]

comparison = (
    adsl_definitions.groupby(['column_name', 'table_name'])
    .size()
    .unstack(fill_value=0)
    .applymap(lambda x: "Yes" if x > 0 else "")
)

comparison = comparison.assign(
    tables_present_in=comparison.apply(
        lambda row: [col for col in comparison.columns if row[col] == "Yes"],
        axis=1
    )
)

different_columns = comparison[
    comparison['tables_present_in'].map(len) != len(adsl_tables)
]

#display(different_columns)
different_columns = different_columns.reset_index()
display(different_columns)

# COMMAND ----------

# MAGIC %md
# MAGIC **AMG330**

# COMMAND ----------

amg330_tables =['edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_adsl',
                'edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb',
                'edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_ae',
                'edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cm',
                'edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_ex',
                'edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_ngs'
               ]

column_definitions = pd.read_csv("pmed_prod_ddm_vector_index.csv")

amg330_definitions = column_definitions[
    column_definitions['table_name'].isin(amg330_tables)
]

comparison = (
    amg330_definitions.groupby(['column_name', 'table_name'])
    .size()
    .unstack(fill_value=0)
    .applymap(lambda x: "Yes" if x > 0 else "")
)

comparison = comparison.assign(
    tables_present_in=comparison.apply(
        lambda row: [col for col in comparison.columns if row[col] == "Yes"],
        axis=1
    )
)

different_columns = comparison[
    comparison['tables_present_in'].map(len) != len(amg330_tables)
]

#display(different_columns)
different_columns = different_columns.reset_index()
display(different_columns)

# COMMAND ----------

import pandas as pd
#import ace_tools as tools

# Define example schema sets (from Databricks query results)
schemas = {
    "amg160_20180101_ne_adsl": ["PRODUCT", "STUDYID", "SUBJID", "TRTSTDTC", "AGE", "SEX", "COHORT", "DOSETARP", "ACTARM", "best_response", "snap_date"],
    "amg160_20180101_ne_cb": ["PRODUCT", "STUDYID", "SUBJID", "ASSAY", "ANALYTE", "STRESN", "VISITCD", "VISITDTC", "snap_date"],
    "amg160_20180101_ne_ae": ["PRODUCT", "STUDYID", "SUBJID", "AEPT", "AETOXGR", "AESTDTC", "AEENDTC", "NEUROMGR", "CRSFL", "snap_date"],
    "amg160_20180101_ne_cm": ["PRODUCT", "STUDYID", "SUBJID", "CMTRT", "CMDOSE", "CMSTDTC", "CMENDTC", "EPOCH", "snap_date"],
    "amg160_20180101_ne_ex": ["PRODUCT", "STUDYID", "SUBJID", "VISITCD", "VISITDTC", "IPNAME", "EXSEQ", "PLNCYDUR", "snap_date"],
    "amg160_20180101_ne_ngs": ["SUBJID", "SAMPLE", "ASSAY", "CHROM", "POS", "gene", "AA_CHANGE", "TYPE", "AF", "snap_date"],
    "amg160_20180101_ne_protein": ["SUBJID", "VISITCD", "ASSAY", "ANALYTE", "STRESN", "TSTNAM", "snap_date"],
    "amg160_20180101_ne_rna": ["SUBJID", "SAMPLEID", "ENSEMBL_GENE", "HGNC_SYMBOL", "COUNT", "FPKM", "TPM", "ASSAY", "snap_date"]
}

# Build a wide matrix showing column presence
all_columns = sorted(set(sum(schemas.values(), [])))
df = pd.DataFrame(index=all_columns, columns=schemas.keys())

for table, cols in schemas.items():
    df[table] = df.index.to_series().isin(cols).map({True: "✓", False: ""})

# Add a helper column counting presence across tables
#df["count_present_in"] = (df == "✓").sum(axis=1)
#df = df.sort_values("count_present_in", ascending=False)

# Display in ChatGPT UI
#tools.display_dataframe_to_user("AMG160 Full Schema Comparison Matrix", df)

df = df.reset_index()
display(df)

# COMMAND ----------

column_definitions = pd.read_csv("pmed_prod_ddm_vector_index.csv")
adsl_ = column_definitions[
    column_definitions['table_name'].isin(['edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_adsl'])
]['column_name'].values
cb_ = column_definitions[
    column_definitions['table_name'].isin(['edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_cb'])
]['column_name'].values
ae_ = column_definitions[
    column_definitions['table_name'].isin(['edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_ae'])
]['column_name'].values
cm_ = column_definitions[
    column_definitions['table_name'].isin(['edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_cm'])
]['column_name'].values
ex_ = column_definitions[
    column_definitions['table_name'].isin(['edl_prd.cdh_bite_prd_publish.amg160_201101_ne_ex'])
]['column_name'].values
ngs_ = column_definitions[
    column_definitions['table_name'].isin(['edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_ngs'])
]['column_name'].values 
 
protein_ = column_definitions[
    column_definitions['table_name'].isin(['edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_protein'])
]['column_name'].values 
rna_ = column_definitions[
    column_definitions['table_name'].isin(['edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_rna'])
]['column_name'].values

schemas = {
    "amg160_20180101_ne_adsl": list(adsl_),
    "amg160_20180101_ne_cb": list(cb_),
    "amg160_20180101_ne_ae": list(ae_),
    "amg160_20180101_ne_cm": list(cm_),
    "amg160_20180101_ne_ex": list(ex_),
    "amg160_20180101_ne_ngs": list(ngs_),
    "amg160_20180101_ne_protein": list(protein_),
    "amg160_20180101_ne_rna": list(rna_)
}

# Build a wide matrix showing column presence
all_columns = sorted(set(sum(schemas.values(), [])))
df = pd.DataFrame(index=all_columns, columns=schemas.keys())

for table, cols in schemas.items():
    df[table] = df.index.to_series().isin(cols).map({True: "✓", False: ""})

# COMMAND ----------

selected_indices = ["PRODUCT", "STUDYID", "SUBJID", "TRTSTDTC", "AGE", "SEX", "COHORT", "DOSETARP", "ACTARM", "best_response", "snap_date"]
df_selected = df.filter(items=selected_indices, axis=0)
df_selected = df_selected.reset_index()
display(df_selected)