# Databricks notebook source
  import requests
  import time

  DATABRICKS_HOST = "https://amgen-ai-dev.cloud.databricks.com"
  DATABRICKS_TOKEN = "dapi710b60b9cba1b7627629bd7a1328cd70"
  SQL_WAREHOUSE_ID = "792838787cf72ed7"

  query = """
  SELECT
    grantee,
    table_schema,
    table_name,
    privilege_type as table_privileges
  FROM
    edl_prd.information_schema.table_privileges
  ORDER BY grantee, table_schema, table_name, privilege_type
  """

  url = f"{DATABRICKS_HOST}/api/2.0/sql/statements"
  headers = {
      "Authorization": f"Bearer {DATABRICKS_TOKEN}",
      "Content-Type": "application/json"
  }

  payload = {
      "warehouse_id": SQL_WAREHOUSE_ID,
      "statement": query
  }

  response = requests.post(url, headers=headers, json=payload)
  data = response.json()

  statement_id = data.get("statement_id")
  if not statement_id:
      raise Exception(f"Error executing query: {data.get('error', {}).get('message', data)}")

  status_url = f"{DATABRICKS_HOST}/api/2.0/sql/statements/{statement_id}"
  while True:
      r = requests.get(status_url, headers=headers)
      result = r.json()
      state = result.get('status', {}).get("state")
      if state == "SUCCEEDED":
          break
      elif state in ("FAILED", "CANCELLED"):
          raise Exception(f"Error executing query: {result['status'].get('state_message', 'Unknown error')}")
      time.sleep(1)

  rows = result["result"]["data_array"]
  for row in rows:
      print(row)

# COMMAND ----------

pip install databricks-cli

# COMMAND ----------

!databricks configure --token --profile default --host https://amgen-ai-dev.cloud.databricks.com/

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

!databricks secrets create-scope --scope rjws-scope

# COMMAND ----------

!databricks configure --token

# COMMAND ----------

# Use the specified personal access token instead of the notebook user's token
spark.conf.set("spark.databricks.token", "dapi710b60b9cba1b7627629bd7a1328cd70")

display(spark.sql("""
SELECT 
  grantor, 
  grantee, 
  table_catalog, 
  table_name, 
  privilege_type
FROM 
  edl_prd.information_schema.table_privileges
"""))