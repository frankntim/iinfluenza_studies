import streamlit as st
from rag_pubmed import rag_medical_explanation
import pathlib

def inject_css(file_path):
    with open(file_path) as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

inject_css("styles/style.css")

st.title("🧠 Clinical Trials Assistant")

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

user_avatar = "🧑‍⚕️"
assistant_avatar = "🧬"

#st.markdown('<div id="main-container"><div id="chat-area">', unsafe_allow_html=True)
for msg in st.session_state.chat_history:
    with st.chat_message("user", avatar=user_avatar):
        st.markdown(msg["query"])
    with st.chat_message("assistant", avatar=assistant_avatar):
        if "**References**:" in msg["response"]:
            main, refs = msg["response"].split("**References**:")
            st.markdown(main.strip(), unsafe_allow_html=True)
            st.markdown('<div class="reference-section"><strong>References</strong><br>' +
                        refs.strip().replace("\n","<br>") + '</div>', unsafe_allow_html=True)
        else:
            st.markdown(msg["response"], unsafe_allow_html=True)
st.markdown('</div></div>', unsafe_allow_html=True)

user_input = st.chat_input("Ask a medical question…")
if user_input:
    with st.chat_message("user", avatar=user_avatar):
        st.markdown(user_input)
    with st.spinner("🔍 Searching…"):
        resp = rag_medical_explanation(user_input)
        st.session_state.chat_history.append({"query": user_input, "response": resp})
        with st.chat_message("assistant", avatar=assistant_avatar):
            if "**References**:" in resp:
                main, refs = resp.split("**References**:")
                st.markdown(main.strip(), unsafe_allow_html=True)
                st.markdown('<div class="reference-section"><strong>References</strong><br>' +
                            refs.strip().replace("\n","<br>") + '</div>', unsafe_allow_html=True)
            else:
                st.markdown(resp, unsafe_allow_html=True)
