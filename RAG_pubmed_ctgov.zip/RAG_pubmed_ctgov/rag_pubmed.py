# rag_pubmed.py

import os, hashlib, json
from typing import List, Dict
from langchain.schema import Document
from langchain.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from langchain.tools.tavily_search import TavilySearchResults

# Set API keys here or via environment variables
TAVILY_API_KEY = ""
OPENAI_API_KEY = ""
os.environ["TAVILY_API_KEY"] = TAVILY_API_KEY
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

CACHE_FILE = "pubmed_clinical_cache.json"

def load_cache() -> Dict:
    if os.path.exists(CACHE_FILE):
        return json.load(open(CACHE_FILE))
    return {}

def save_cache(cache: Dict):
    with open(CACHE_FILE, "w") as f:
        json.dump(cache, f)

def cache_key(query: str, k: int):
    return hashlib.md5(f"{query}_{k}".encode()).hexdigest()

def keyword_dual_search(query: str, k: int) -> List[Document]:
    """Search both PubMed and ClinicalTrials.gov using Tavily keyword search."""
    tool = TavilySearchResults()
    sources = ["site:pubmed.ncbi.nlm.nih.gov", "site:clinicaltrials.gov"]

    docs = []
    for src in sources:
        results = tool.run(f"{query} {src}")
        for r in results[:k]:
            docs.append(Document(
                page_content=r["content"],
                metadata={"source": r["url"], "title": r.get("title", "")}
            ))
    return docs

PROMPT = PromptTemplate(
    input_variables=["question","context"],
    template=(
        "You are a medical research assistant. Based on the following search results, "
        "provide a clear and concise answer. Use inline citations [1], [2], etc. "
        "Then list references with hyperlinks.\n\n"
        "Question: {question}\n\nResults:\n{context}\n\nAnswer:\n"
    )
)

def format_with_citation(docs: List[Document]):
    ctx = ""
    refs = []
    for i, d in enumerate(docs, 1):
        ctx += f"[{i}] {d.page_content[:800].strip()}...\n"
        refs.append(f"[{i}] [{d.metadata['title'] or d.metadata['source']}]({d.metadata['source']})")
    return ctx, refs

def rag_medical_explanation(query: str, k: int =2) -> str:
    key = cache_key(query, k)
    cache = load_cache()
    if key in cache:
        return cache[key]

    docs = keyword_dual_search(query, k)
    ctx, refs = format_with_citation(docs)
    llm = ChatOpenAI(temperature=0.3)
    answer = llm.predict(PROMPT.format(question=query, context=ctx))

    answer_full = f"{answer.strip()}\n\n**References**:\n" + "\n".join(refs)
    cache[key] = answer_full
    save_cache(cache)
    return answer_full
