# Databricks notebook source
# MAGIC %md
# MAGIC # Analytics-Only Report
# MAGIC This notebook renders analytics from the SQLite database using reusable Python modules (no Streamlit UI).

# COMMAND ----------

#%pip install pandas numpy matplotlib nbformat
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------


import os, sys, json
import pandas as pd

from pathlib import Path
#root = Path(__file__).resolve().parents[1]
root = Path(os.getcwd())
if str(root) not in sys.path:
    sys.path.insert(0, str(root))

from app.schemas import DEFAULT_DB_PATH
from app import db as dbmod
from app.analysis_pipeline import (
    merge_feedback_and_analysis, compute_kpis, counts_by_column,
    pivot_mean_severity, explode_options, severity_actionability_points
)
from app import report_charts as charts
ABS_DB_PATH = '/Workspace/Users/fagyeint@amgen.com/Genie_Evaluation/app/feedback.db'
DB_PATH = os.getenv("DB_PATH", ABS_DB_PATH)


conn = dbmod.get_db(DB_PATH)
fb_df = dbmod.load_feedback(conn)
an_df = dbmod.load_analysis(conn)

print(f"Loaded feedback: {len(fb_df)} rows")
print(f"Loaded analysis: {len(an_df)} rows")

merged = merge_feedback_and_analysis(fb_df, an_df)
merged.head(3)


# COMMAND ----------

# MAGIC %md
# MAGIC ## KPIs

# COMMAND ----------


kpis = compute_kpis(merged)
kpis


# COMMAND ----------

# MAGIC %md
# MAGIC ## Feedback Count by Response Model

# COMMAND ----------


#by_model = counts_by_column(merged, "response_model")
#if not by_model.empty:
#    charts.plot_counts(by_model, x_col="response_model", y_col="count",
#                       title="Feedback Count by Response Model",
#                       xlabel="Response Model")
#else:
#    print("No response_model data.")


# COMMAND ----------

import plotly.express as px
by_model = counts_by_column(merged, "response_model")
if not by_model.empty:
    fig = px.bar(by_model, x="response_model", y="count", 
                        title="Feedback Count by Response Model",
                        )
    fig.show()
else:
    print("No response_model data.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Feedback Count by Software Version

# COMMAND ----------


#by_version = counts_by_column(merged, "software_version")
#if not by_version.empty:
#    charts.plot_counts(by_version, x_col="software_version", y_col="count",
#                       title="Feedback Count by Software Version",
#                       xlabel="Software Version")
#else:
#    print("No software_version data.")

import plotly.express as px
by_version = counts_by_column(merged, "software_version")
if not by_model.empty:
    fig = px.bar(by_version, x="software_version", y="count",
                       title="Feedback Count by Software Version",
                      )
    fig.show()
else:
    print("No software_version data.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Mean Severity by Model & Version (Pivot Table)

# COMMAND ----------


pivot = pivot_mean_severity(merged)
pivot


# COMMAND ----------

# MAGIC %md
# MAGIC ## Issues by Selected Option

# COMMAND ----------


opt_long = explode_options(merged)
if not opt_long.empty:
    opt_counts = opt_long["option"].value_counts().rename("count").sort_index()
    #charts.plot_counts(opt_counts, title="Issues by Selected Option", xlabel="Option")
    
    df = opt_counts.reset_index()
    df.columns = ['Option', 'Count']
    fig = px.bar(df, x='Option', y='Count', title="Issues by Selected Option")
    fig.show()
else:
    print("No option selections available.")


# COMMAND ----------

# MAGIC %md
# MAGIC ## Severity vs. Actionability

# COMMAND ----------


pts = severity_actionability_points(merged)
if not pts.empty:
    #charts.plot_scatter(pts, x="severity", y="actionability",
    #                    title="Severity vs. Actionability",
    #                    xlabel="Severity", ylabel="Actionability")
    fig = px.scatter(pts, x='severity', y='actionability',title='Severity vs. Actionability')
    fig.show()
else:
    print("No scored items to chart.")
