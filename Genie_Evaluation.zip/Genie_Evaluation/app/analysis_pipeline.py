
# app/analysis_pipeline.py
import json
import numpy as np
import pandas as pd

def merge_feedback_and_analysis(fb_df: pd.DataFrame, an_df: pd.DataFrame) -> pd.DataFrame:
    merged = fb_df.merge(an_df, left_on="id", right_on="feedback_id", how="left").copy()
    # Parse JSON columns to Python objects
    merged["options"] = merged["options_json"].apply(lambda x: json.loads(x) if isinstance(x, str) else [])
    merged["analysis"] = merged["analysis_json"].apply(lambda x: json.loads(x) if isinstance(x, str) else {})
    merged["severity"] = merged["analysis"].apply(lambda d: d.get("severity", np.nan))
    merged["actionability"] = merged["analysis"].apply(lambda d: d.get("actionability", np.nan))
    merged["scores"] = merged["analysis"].apply(lambda d: d.get("scores", {}))
    for k in ["accuracy", "completeness", "clarity", "relevance"]:
        merged[f"score_{k}"] = merged["scores"].apply(lambda s: s.get(k, np.nan))
    merged["categories"] = merged["analysis"].apply(lambda d: d.get("categories", []))
    merged["root_cause"] = merged["analysis"].apply(lambda d: d.get("root_cause", "unknown"))
    merged["summary"] = merged["analysis"].apply(lambda d: d.get("summary", ""))
    return merged

def compute_kpis(df: pd.DataFrame) -> dict:
    sev = pd.to_numeric(df["severity"], errors="coerce")
    act = pd.to_numeric(df["actionability"], errors="coerce")
    return {
        "total_feedback": int(len(df)),
        "avg_severity": float(sev.mean()) if not sev.isna().all() else None,
        "avg_actionability": float(act.mean()) if not act.isna().all() else None,
        "top_response_model": df["response_model"].value_counts().idxmax() if "response_model" in df and not df["response_model"].empty else None,
        "top_software_version": df["software_version"].value_counts().idxmax() if "software_version" in df and not df["software_version"].empty else None,
    }

def counts_by_column(df: pd.DataFrame, col: str) -> pd.DataFrame:
    if col not in df.columns:
        return pd.DataFrame(columns=[col, "count"])
    out = df[col].value_counts().rename("count").reset_index()
    out.columns = [col, "count"]
    return out

def pivot_mean_severity(df: pd.DataFrame) -> pd.DataFrame:
    if "response_model" not in df.columns or "software_version" not in df.columns:
        return pd.DataFrame()
    return df.pivot_table(index="response_model", columns="software_version", values="severity", aggfunc="mean").round(3)

def explode_options(df: pd.DataFrame) -> pd.DataFrame:
    # turn options array into long rows
    rows = []
    for _, r in df.iterrows():
        for o in (r.get("options") or []):
            rows.append({"id": r["id"], "option": o})
    return pd.DataFrame(rows)

def severity_actionability_points(df: pd.DataFrame) -> pd.DataFrame:
    pts = df[["severity", "actionability"]].dropna().copy()
    return pts
