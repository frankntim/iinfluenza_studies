
# app/schemas.py
from typing import List

DEFAULT_DB_PATH: str = "app/feedback.db"

# Metadata enumerations (optional; keep if you want to validate/filter)
RESPONSE_MODELS: List[str] = ["gpt-4o", "gpt-4o-mini"]
SOFTWARE_VERSIONS: List[str] = ["version_1", "version_2"]
