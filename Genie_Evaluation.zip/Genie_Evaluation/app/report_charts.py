
# app/report_charts.py
import matplotlib.pyplot as plt
import pandas as pd

def plot_counts(series_or_df, x_col: str = None, y_col: str = None, title: str = "", xlabel: str = "", ylabel: str = "Count"):
    plt.figure()
    if isinstance(series_or_df, pd.Series):
        series_or_df.sort_index().plot(kind="bar")
    else:
        # expects a DataFrame with x and y columns
        df = series_or_df
        x = x_col or df.columns[0]
        y = y_col or df.columns[1]
        df = df.sort_values(x)
        plt.bar(df[x], df[y])
    plt.title(title)
    plt.xlabel(xlabel or (x_col if x_col else ""))
    plt.ylabel(ylabel)
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    return plt.gcf()

def plot_scatter(df: pd.DataFrame, x: str, y: str, title: str, xlabel: str, ylabel: str):
    plt.figure()
    plt.scatter(df[x], df[y])
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.grid(True, linestyle="--", alpha=0.3)
    plt.tight_layout()
    return plt.gcf()
