
# app/db.py
import sqlite3
import pandas as pd

def get_db(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def load_feedback(conn: sqlite3.Connection) -> pd.DataFrame:
    return pd.read_sql_query("SELECT * FROM feedback ORDER BY created_at DESC", conn, parse_dates=["created_at"])

def load_analysis(conn: sqlite3.Connection) -> pd.DataFrame:
    return pd.read_sql_query("SELECT * FROM analysis", conn)
