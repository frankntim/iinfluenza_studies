# feedback_store.py
from __future__ import annotations
import sqlite3
from contextlib import contextmanager
from pathlib import Path
import pandas as pd
from typing import Dict, Optional

DEFAULT_METRICS = ["correctness", "relevance", "faithfulness", "completeness", "conciseness"]

class FeedbackStore:
    """
    Normalized schema with Version support:
      - sessions(id, timestamp, prompt, expectedresponse)
      - responses(id, session_id, version, model, response, feedback, metrics..., created_at)
        UNIQUE(session_id, version, model)
    """

    def __init__(self, db_path: Path | str):
        self.db_path = str(db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    @contextmanager
    def get_conn(self):
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        try:
            yield conn
        finally:
            conn.close()

    def _init_db(self):
        with self.get_conn() as conn:
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT,
                    prompt TEXT,
                    expectedresponse TEXT
                )
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS responses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
                    version TEXT,
                    model TEXT,
                    response TEXT,
                    feedback TEXT,
                    correctness REAL,
                    relevance REAL,
                    faithfulness REAL,
                    completeness REAL,
                    conciseness REAL,
                    created_at TEXT,
                    UNIQUE(session_id, version, model)
                )
            """)
            cur.execute("CREATE INDEX IF NOT EXISTS idx_responses_session ON responses(session_id)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_responses_version ON responses(version)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_responses_model ON responses(model)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_responses_feedback ON responses(feedback)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_sessions_ts ON sessions(timestamp)")
            conn.commit()

    # -------------------------
    # Sessions
    # -------------------------
    def create_session(self, timestamp: str, prompt: str, expectedresponse: str) -> int:
        with self.get_conn() as conn:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO sessions (timestamp, prompt, expectedresponse) VALUES (?, ?, ?)",
                (timestamp, prompt, expectedresponse),
            )
            conn.commit()
            return cur.lastrowid

    def update_session_expected(self, session_id: int, expected: str):
        with self.get_conn() as conn:
            cur = conn.cursor()
            cur.execute("UPDATE sessions SET expectedresponse=? WHERE id=?", (expected, session_id))
            conn.commit()

    def fetch_session_history(self) -> pd.DataFrame:
        """Denormalized table: one row per (session, version, model)."""
        with self.get_conn() as conn:
            df = pd.read_sql_query(
                """
                SELECT
                    s.id AS session_id,
                    s.timestamp,
                    s.prompt,
                    s.expectedresponse,
                    r.id AS response_id,
                    r.version,
                    r.model,
                    r.response,
                    r.feedback,
                    r.correctness,
                    r.relevance,
                    r.faithfulness,
                    r.completeness,
                    r.conciseness
                FROM sessions s
                LEFT JOIN responses r ON r.session_id = s.id
                ORDER BY datetime(s.timestamp), r.version, r.model
                """,
                conn,
            )
        return df

    # -------------------------
    # Responses
    # -------------------------
    def upsert_response(
        self,
        session_id: int,
        version: str,
        model: str,
        response_text: str,
        created_at: str,
        metrics: Dict[str, float],
        feedback: Optional[str] = None,
    ) -> int:
        """Insert or update a response row for (session_id, version, model)."""
        with self.get_conn() as conn:
            cur = conn.cursor()
            cur.execute("SELECT id FROM responses WHERE session_id=? AND version=? AND model=?",
                        (session_id, version, model))
            row = cur.fetchone()
            if row:
                rid = row[0]
                cur.execute(
                    """
                    UPDATE responses
                    SET response=?, feedback=?, correctness=?, relevance=?, faithfulness=?,
                        completeness=?, conciseness=?, created_at=?
                    WHERE id=?
                    """,
                    (
                        response_text, feedback,
                        metrics.get("correctness", 0.0),
                        metrics.get("relevance", 0.0),
                        metrics.get("faithfulness", 0.0),
                        metrics.get("completeness", 0.0),
                        metrics.get("conciseness", 0.0),
                        created_at,
                        rid,
                    ),
                )
                conn.commit()
                return rid
            cur.execute(
                """
                INSERT INTO responses
                (session_id, version, model, response, feedback, correctness, relevance, faithfulness, completeness, conciseness, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    session_id, version, model, response_text, feedback,
                    metrics.get("correctness", 0.0),
                    metrics.get("relevance", 0.0),
                    metrics.get("faithfulness", 0.0),
                    metrics.get("completeness", 0.0),
                    metrics.get("conciseness", 0.0),
                    created_at,
                ),
            )
            conn.commit()
            return cur.lastrowid

    def update_response_fields(self, response_id: int, fields: Dict):
        if not fields:
            return
        cols, vals = [], []
        for k, v in fields.items():
            cols.append(f"{k}=?")
            vals.append(v)
        vals.append(response_id)
        sql = f"UPDATE responses SET {', '.join(cols)} WHERE id=?"
        with self.get_conn() as conn:
            cur = conn.cursor()
            cur.execute(sql, tuple(vals))
            conn.commit()

    # -------------------------
    # Analytics
    # -------------------------
    def fetch_feedback_counts(self) -> Dict[str, int]:
        with self.get_conn() as conn:
            cur = conn.cursor()
            cur.execute("SELECT feedback, COUNT(*) FROM responses GROUP BY feedback")
            rows = cur.fetchall()
            return {r[0] if r[0] else "": r[1] for r in rows}

    def fetch_trend_df(self) -> pd.DataFrame:
        with self.get_conn() as conn:
            df = pd.read_sql_query(
                "SELECT created_at, feedback FROM responses ORDER BY datetime(created_at)", conn
            )
        if df.empty:
            return pd.DataFrame(columns=["ts", "approval_rate"])
        df["ts"] = pd.to_datetime(df["created_at"], errors="coerce")
        df["up_num"] = (df["feedback"] == "up").astype(int)
        df["down_num"] = (df["feedback"] == "down").astype(int)
        df["cum_up"] = df["up_num"].cumsum()
        df["cum_total"] = (df["up_num"] + df["down_num"]).cumsum()
        df["approval_rate"] = df.apply(
            lambda r: ( (r.get("cum_up", 0) / max(1, r.get("cum_total", 1))) * 100 ) if hasattr(r, "get") else 0.0,
            axis=1,
        )
        return df[["ts", "approval_rate"]]

    def fetch_metric_means_overall(self) -> Dict[str, float]:
        with self.get_conn() as conn:
            sdf = pd.read_sql_query(
                "SELECT correctness, relevance, faithfulness, completeness, conciseness FROM responses", conn
            )
        if sdf.empty:
            return {m: 0.0 for m in DEFAULT_METRICS}
        return {m: float(pd.to_numeric(sdf[m], errors="coerce").dropna().mean()) if m in sdf.columns else 0.0
                for m in DEFAULT_METRICS}

    def fetch_metric_means_by_model(self) -> pd.DataFrame:
        with self.get_conn() as conn:
            df = pd.read_sql_query(
                """
                SELECT model,
                       AVG(correctness) AS correctness,
                       AVG(relevance) AS relevance,
                       AVG(faithfulness) AS faithfulness,
                       AVG(completeness) AS completeness,
                       AVG(conciseness) AS conciseness
                FROM responses
                GROUP BY model
                """,
                conn,
            )
        return df

    def fetch_metric_means_by_version(self) -> pd.DataFrame:
        with self.get_conn() as conn:
            df = pd.read_sql_query(
                """
                SELECT version,
                       AVG(correctness) AS correctness,
                       AVG(relevance) AS relevance,
                       AVG(faithfulness) AS faithfulness,
                       AVG(completeness) AS completeness,
                       AVG(conciseness) AS conciseness
                FROM responses
                GROUP BY version
                """,
                conn,
            )
        return df

    def fetch_metric_means_by_model_version(self) -> pd.DataFrame:
        with self.get_conn() as conn:
            df = pd.read_sql_query(
                """
                SELECT model, version,
                       AVG(correctness) AS correctness,
                       AVG(relevance) AS relevance,
                       AVG(faithfulness) AS faithfulness,
                       AVG(completeness) AS completeness,
                       AVG(conciseness) AS conciseness
                FROM responses
                GROUP BY model, version
                """,
                conn,
            )
        return df

    def fetch_feedback_counts_by_model(self) -> pd.DataFrame:
        """Return columns: model, feedback, count."""
        with self.get_conn() as conn:
            df = pd.read_sql_query(
                "SELECT model, feedback, COUNT(*) AS count FROM responses GROUP BY model, feedback",
                conn,
            )
        return df

    def fetch_feedback_counts_by_version(self) -> pd.DataFrame:
        """Return columns: version, feedback, count."""
        with self.get_conn() as conn:
            df = pd.read_sql_query(
                "SELECT version, feedback, COUNT(*) AS count FROM responses GROUP BY version, feedback",
                conn,
            )
        return df

    def fetch_trend_by_model(self) -> pd.DataFrame:
        """
        Approval rate over time per model.
        Returns columns: ts (datetime), model, approval_rate.
        """
        with self.get_conn() as conn:
            df = pd.read_sql_query(
                "SELECT created_at, model, feedback FROM responses ORDER BY datetime(created_at)",
                conn,
            )
        if df.empty:
            return pd.DataFrame(columns=["ts", "model", "approval_rate"])

        df["ts"] = pd.to_datetime(df["created_at"], errors="coerce")
        out = []
        for model, g in df.groupby("model", dropna=False):
            g = g.sort_values("ts").copy()
            g["up_num"] = (g["feedback"] == "up").astype(int)
            g["down_num"] = (g["feedback"] == "down").astype(int)
            g["cum_up"] = g["up_num"].cumsum()
            g["cum_total"] = (g["up_num"] + g["down_num"]).cumsum()
            g["approval_rate"] = g.apply(
                lambda r: ( (r.get("cum_up", 0) / max(1, r.get("cum_total", 1))) * 100 )
                if hasattr(r, "get") else 0.0,
                axis=1,
            )
            out.append(g[["ts", "model", "approval_rate"]])
        return pd.concat(out, axis=0, ignore_index=True)

    def fetch_trend_by_version(self) -> pd.DataFrame:
        """
        Approval rate over time per version.
        Returns columns: ts (datetime), version, approval_rate.
        """
        with self.get_conn() as conn:
            df = pd.read_sql_query(
                "SELECT created_at, version, feedback FROM responses ORDER BY datetime(created_at)",
                conn,
            )
        if df.empty:
            return pd.DataFrame(columns=["ts", "version", "approval_rate"])

        df["ts"] = pd.to_datetime(df["created_at"], errors="coerce")
        out = []
        for version, g in df.groupby("version", dropna=False):
            g = g.sort_values("ts").copy()
            g["up_num"] = (g["feedback"] == "up").astype(int)
            g["down_num"] = (g["feedback"] == "down").astype(int)
            g["cum_up"] = g["up_num"].cumsum()
            g["cum_total"] = (g["up_num"] + g["down_num"]).cumsum()
            g["approval_rate"] = g.apply(
                lambda r: ( (r.get("cum_up", 0) / max(1, r.get("cum_total", 1))) * 100 )
                if hasattr(r, "get") else 0.0,
                axis=1,
            )
            out.append(g[["ts", "version", "approval_rate"]])
        return pd.concat(out, axis=0, ignore_index=True)


    # -------------------------
    # Export
    # -------------------------
    def export_csv_df(self) -> pd.DataFrame:
        return self.fetch_session_history()
