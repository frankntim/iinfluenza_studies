# Databricks notebook source
# MAGIC %pip install plotly

# COMMAND ----------

# Notebook analytics renderer
# Requirements: pip install plotly pandas
# Assumes feedback_store.py (with the version-aware store + analytics helpers) is on PYTHONPATH

from pathlib import Path
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from feedback_store import FeedbackStore  # uses your existing DB and methods

def _build_radar(metrics_mean: dict, title: str):
    cats = list(metrics_mean.keys()) or ["correctness","relevance","faithfulness","completeness","conciseness"]
    vals = [metrics_mean.get(m, 0.0) for m in cats]
    fig = go.Figure()
    fig.add_trace(go.Scatterpolar(r=vals + [vals[0]], theta=cats + [cats[0]], fill="toself", name="Average"))
    fig.update_layout(title=title, polar=dict(radialaxis=dict(range=[0,5], visible=True)), showlegend=False)
    return fig

def render_all_analytics(db_path="data/feedback_versions.db", return_figs=False):
    """
    Render all analytics from an existing DB into this Jupyter notebook.
    Set return_figs=True to also get a dict of the figures without displaying.
    """
    store = FeedbackStore(Path(db_path))

    figs = {}

    # ========== Overall thumbs counts ==========
    counts = store.fetch_feedback_counts()
    up = int(counts.get("up", 0))
    down = int(counts.get("down", 0))
    bar_df = pd.DataFrame({"feedback": ["up","down"], "count": [up, down]})
    fig_counts_overall = px.bar(bar_df, x="feedback", y="count", title="Overall Thumbs Up vs Thumbs Down")
    fig_counts_overall.show()
    figs["overall_counts"] = fig_counts_overall

    # ========== Overall approval trend ==========
    trend_df = store.fetch_trend_df()
    if trend_df.empty:
        fig_trend_overall = px.line(title="Approval Rate Over Time (%)")
    else:
        fig_trend_overall = px.line(trend_df, x="ts", y="approval_rate", markers=True, title="Approval Rate Over Time (%)")
    fig_trend_overall.show()
    figs["overall_trend"] = fig_trend_overall

    # ========== Overall metric means ==========
    overall_means = store.fetch_metric_means_overall()
    fig_metrics_bar = px.bar(
        pd.DataFrame({"metric": list(overall_means.keys()), "value": list(overall_means.values())}),
        x="metric", y="value", range_y=[0,5], title="Average Judge Scores (Overall, 0–5)"
    )
    fig_metrics_bar.show()
    figs["overall_metrics_bar"] = fig_metrics_bar

    fig_metrics_radar = _build_radar(overall_means, "Judge Score Profile (Overall)")
    fig_metrics_radar.show()
    figs["overall_metrics_radar"] = fig_metrics_radar

    # ========== Metric means by model ==========
    by_model = store.fetch_metric_means_by_model()
    if by_model.empty:
        fig_metrics_by_model = px.bar(title="Average Judge Scores by Model (0–5)")
    else:
        fig_metrics_by_model = px.bar(
            by_model.melt(id_vars="model", var_name="metric", value_name="value"),
            x="model", y="value", color="metric", barmode="group", range_y=[0,5],
            title="Average Judge Scores by Model (0–5)"
        )
    fig_metrics_by_model.show()
    figs["metrics_by_model"] = fig_metrics_by_model

    # ========== Metric means by version ==========
    by_version = store.fetch_metric_means_by_version()
    if by_version.empty:
        fig_metrics_by_version = px.bar(title="Average Judge Scores by Version (0–5)")
    else:
        fig_metrics_by_version = px.bar(
            by_version.melt(id_vars="version", var_name="metric", value_name="value"),
            x="version", y="value", color="metric", barmode="group", range_y=[0,5],
            title="Average Judge Scores by Version (0–5)"
        )
    fig_metrics_by_version.show()
    figs["metrics_by_version"] = fig_metrics_by_version

    # ========== Metric means by model × version ==========
    by_mv = store.fetch_metric_means_by_model_version()
    if by_mv.empty:
        fig_metrics_by_mv = px.bar(title="Average Judge Scores by Model × Version (0–5)")
    else:
        fig_metrics_by_mv = px.bar(
            by_mv.melt(id_vars=["model","version"], var_name="metric", value_name="value"),
            x="model", y="value", color="metric", barmode="group", range_y=[0,5],
            facet_col="version", facet_col_wrap=2,
            title="Average Judge Scores by Model × Version (0–5)"
        )
    fig_metrics_by_mv.show()
    figs["metrics_by_model_version"] = fig_metrics_by_mv

    # ========== Counts by model (👍/👎) ==========
    cbm = store.fetch_feedback_counts_by_model()
    if cbm.empty:
        fig_counts_by_model = px.bar(title="Counts by Model (👍/👎)")
    else:
        fig_counts_by_model = px.bar(
            cbm, x="model", y="count", color="feedback", barmode="group",
            title="Counts by Model (👍/👎)"
        )
    fig_counts_by_model.show()
    figs["counts_by_model"] = fig_counts_by_model

    # ========== Counts by version (👍/👎) ==========
    cbv = store.fetch_feedback_counts_by_version()
    if cbv.empty:
        fig_counts_by_version = px.bar(title="Counts by Version (👍/👎)")
    else:
        fig_counts_by_version = px.bar(
            cbv, x="version", y="count", color="feedback", barmode="group",
            title="Counts by Version (👍/👎)"
        )
    fig_counts_by_version.show()
    figs["counts_by_version"] = fig_counts_by_version

    # ========== Approval rate over time by model ==========
    tbm = store.fetch_trend_by_model()
    if tbm.empty:
        fig_trend_by_model = px.line(title="Approval Rate Over Time by Model (%)")
    else:
        fig_trend_by_model = px.line(
            tbm, x="ts", y="approval_rate", color="model", markers=True,
            title="Approval Rate Over Time by Model (%)"
        )
    fig_trend_by_model.show()
    figs["trend_by_model"] = fig_trend_by_model

    # ========== Approval rate over time by version ==========
    tbv = store.fetch_trend_by_version()
    if tbv.empty:
        fig_trend_by_version = px.line(title="Approval Rate Over Time by Version (%)")
    else:
        fig_trend_by_version = px.line(
            tbv, x="ts", y="approval_rate", color="version", markers=True,
            title="Approval Rate Over Time by Version (%)"
        )
    fig_trend_by_version.show()
    figs["trend_by_version"] = fig_trend_by_version

    return figs if return_figs else None


# COMMAND ----------

render_all_analytics("data/feedback_versions.db")