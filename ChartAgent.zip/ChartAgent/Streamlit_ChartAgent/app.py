import os
import json
import time
import requests
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

from typing import Optional, Dict, Any, List
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from langchain_experimental.agents import create_pandas_dataframe_agent

import plotly.graph_objects as go #To uPse the Plotly library to create the graph
import plotly.express as px #To use the Plotly Express library to create the graph
import seaborn as sns
import statsmodels.api as sm
import statsmodels.formula.api as smf
#import ipywidgets as widgets
#from IPython.display import display, clear_output
#from pyspark.sql import SparkSession
from types import SimpleNamespace
import io
import base64
from langchain.prompts import ChatPromptTemplate
from genie_room import genie_query, clear_conversation #, CHART_PROMPT,LLM
import sqlparse
import uuid
import plotly.graph_objects as go
import re
import plotly.express as px
from requests.exceptions import Timeout, RequestException
from langchain_core.messages import SystemMessage, HumanMessage
import requests
import os
#from databricks.connect import DatabricksSession


# ==========
# Settings
# ==========
st.set_page_config(page_title="Genie → DataFrame → Charts", layout="wide")
st.markdown(
    """
    <style>
    .reportview-container .markdown-text-container { font-size: 1rem; }
    .stDataFrame { border-radius: 14px; }
    .stButton>button { border-radius: 10px; padding: 0.6rem 1rem; }
    </style>
    """,
    unsafe_allow_html=True,
)

#OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
#DATABRICKS_HOST = os.getenv("DATABRICKS_HOST", "")            # e.g., "https://adb-1234567890123456.17.azuredatabricks.net"
#DATABRICKS_TOKEN = os.getenv("DATABRICKS_TOKEN", "")
#DATABRICKS_GENIE_AGENT_ID = os.getenv("DATABRICKS_GENIE_AGENT_ID", "")  # Your Genie/Agents ID

# If you use a specific OpenAI model, adjust here
#OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"


# ==========
# Helpers
# ==========


def make_dataframe_agent(df: pd.DataFrame) -> Any:
    """
    Build a pandas DataFrame agent that can analyze df and create charts.
    We keep verbose=True so you can see the agent's thoughts in the Streamlit console.
    """
    #if not OPENAI_API_KEY:
    #    raise RuntimeError("OPENAI_API_KEY is not set.")
    #llm = ChatOpenAI(model=OPENAI_MODEL,temperature=0,api_key=OPENAI_API_KEY,)
    
    llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

    # allow_dangerous_code=True lets the agent execute Python plotting inside the process.
    # (This is required for matplotlib chart creation.)
    agent = create_pandas_dataframe_agent(
        llm=llm,
        df=df,
        verbose=True,
        allow_dangerous_code=True,
    )
    return agent


def render_all_matplotlib_figures():
    """
    If the agent created any matplotlib figures, display them all.
    """
    fig_nums = plt.get_fignums()
    if not fig_nums:
        return False

    for num in fig_nums:
        fig = plt.figure(num)
        st.pyplot(fig, use_container_width=True)
    return True


def run_agent_for_visualization(agent: Any, user_query: str) -> str:
    """
    Ask the agent to analyze the dataframe with respect to the user query.
    If a chart is appropriate, instruct it to create exactly one clear matplotlib figure.
    """
    instruction = (
        "You are a data visualization assistant working with a pandas DataFrame named df. "
        "First, briefly analyze the data relevant to the user's question. "
        "If a chart would help, create exactly one clear matplotlib figure that best matches the data (line, bar, scatter, pie, box, histogram, or heatmap). "
        "Label axes and add a concise title. Avoid printing raw code; just execute it. "
        "Do not display dataframes unless the user asks; prefer a chart when appropriate. "
        "If a chart is not helpful, return a short, plain-language answer."
    )

    prompt = f"{instruction}\n\nUser question: {user_query}"
    # .invoke/.run both work; .invoke gives a structured result in newer LC versions.
    try:
        return agent.run(prompt)  # returns a string (agent's final message)
    except Exception as e:
        return f"Agent error: {e}"


# ==========
# UI
# ==========
st.title("🔮 Databricks Genie → 📊 Pandas Agent Charts")
st.caption("Type a question about your data. I’ll ask Genie, then analyze and visualize the result with LangChain’s pandas agent.")

with st.sidebar:
    st.header("Configuration")
    #st.text_input("OpenAI model", value=OPENAI_MODEL, key="openai_model", help="Override via env var OPENAI_MODEL")
    #st.text_input("Databricks Host", value=DATABRICKS_HOST, key="db_host", help="e.g., https://adb-...databricks.net")
    #st.text_input("Genie Agent ID", value=DATABRICKS_GENIE_AGENT_ID, key="db_agent_id")
    #st.write("Environment variables expected:")
    #st.code("OPENAI_API_KEY\nDATABRICKS_HOST\nDATABRICKS_TOKEN\nDATABRICKS_GENIE_AGENT_ID", language="bash")

user_query = st.text_input("Ask a question about your data", placeholder="e.g., Compare weekly active users this quarter by region and show the trend.")

go = st.button("Run")

if go and user_query.strip():
    with st.spinner("Querying Databricks Genie…"):
        try:
            #df = fetch_dataframe_from_genie(user_query.strip())
            current_session_id = str(uuid.uuid4())
            df, query_text,result_description = genie_query(user_query, current_session_id)
        except Exception as e:
            st.error(str(e))
            st.stop()

    if df.empty:
        st.warning("Genie returned an empty result set.")
        st.stop()

    st.success("Got results from Genie.")
    st.subheader("Preview")
    st.dataframe(df, use_container_width=True, height=380)

    # Create the agent bound to this DataFrame
    try:
        agent = make_dataframe_agent(df)
    except Exception as e:
        st.error(f"Failed to create pandas agent: {e}")
        st.stop()

    # Let the agent decide the best visual
    with st.spinner("Analyzing data and generating visualization…"):
        # Clear old figs (important if users run multiple times)
        plt.close('all')
        response_text = run_agent_for_visualization(agent, user_query)

        # Try to render any figures the agent produced
        made_figs = render_all_matplotlib_figures()

    st.subheader("Answer")
    st.write(response_text)

    if not made_figs:
        st.info("No chart was generated. If you want a specific chart, try asking: "
                "**“Create a bar chart of X grouped by Y”** or **“Plot the trend over time.”**")
