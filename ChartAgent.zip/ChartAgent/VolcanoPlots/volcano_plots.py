# Databricks notebook source
# MAGIC %pip install langchain databricks-sql-connector langgraph==0.3.4 langchain-openai==0.3.0 langchain-experimental==0.3.4 databricks-langchain databricks-agents databricks-vectorsearch databricks-connect databricks-sql-connector

# COMMAND ----------

# MAGIC %pip install langchain-openai langchain-community

# COMMAND ----------

# MAGIC %pip install langchain langchain-core langchain-openai

# COMMAND ----------

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

# COMMAND ----------

# MAGIC %md
# MAGIC **PROMPT NOTE:**
# MAGIC
# MAGIC Estimate p-values based only on fold change magnitude that is the negative log 10 p-value. 
# MAGIC Use this expression to compute the pseudo p-values: 1 - EXP(-ABS(log fold change)) 

# COMMAND ----------

# MAGIC %md
# MAGIC **Use Case 1:** 
# MAGIC
# MAGIC _**version 1**_
# MAGIC
# MAGIC “Generate a volcano plot dataset for AMG160 using data from the table
# MAGIC edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_protein.
# MAGIC
# MAGIC Compare Cycle 2 Day 1 Pre-dose (C2D1PRE) versus Cycle 1 Day 1 Pre-dose (C1D1PRE) proteomic measurements across subjects to identify treatment-related protein changes.
# MAGIC Use this expression to compute the pseudo p-values: 1 - EXP(-ABS(log fold change)) and estimate its neg log p values"

# COMMAND ----------

# Create volcano dataset for AMG160 proteomics (C2D1PRE vs C1D1PRE)
df = spark.sql("""
WITH baseline AS (
    SELECT SUBJID, ANALYTE, STRESN AS BASE_VALUE
    FROM edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_protein
    WHERE VISITRAW = 'C1D1PRE'
),
postdose AS (
    SELECT SUBJID, ANALYTE, STRESN AS POST_VALUE
    FROM edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_protein
    WHERE VISITRAW = 'C2D1PRE'
),
fc AS (
    SELECT 
        b.ANALYTE,
        LOG2(AVG(p.POST_VALUE) / AVG(b.BASE_VALUE)) AS LOG2_FOLD_CHANGE,
        1 - EXP(-ABS(LOG2(AVG(p.POST_VALUE)/AVG(b.BASE_VALUE)))) AS P_VALUE
    FROM baseline b
    JOIN postdose p ON b.SUBJID = p.SUBJID AND b.ANALYTE = p.ANALYTE
    GROUP BY b.ANALYTE
)
SELECT 
    ANALYTE,
    LOG2_FOLD_CHANGE,
    -LOG10(P_VALUE) AS NEG_LOG10_PVAL,
    CASE 
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE > 0.58 THEN 'Increased'
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE < -0.58 THEN 'Decreased'
        ELSE 'No Change'
    END AS SIGNIFICANCE
FROM fc
""").toPandas()

plt.figure(figsize=(8,6))
plt.scatter(df["LOG2_FOLD_CHANGE"], df["NEG_LOG10_PVAL"], c="gray", alpha=0.6)
plt.title("Volcano Plot")
plt.xlabel("Log2 Fold Change")
plt.ylabel("-Log10(P-Value)")
plt.grid(True, linestyle="--", alpha=0.5)
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC **Use Case 2:** 
# MAGIC
# MAGIC _**version 1**_
# MAGIC
# MAGIC “Generate a volcano plot dataset for the AMG330 study using cytokine biomarker data from
# MAGIC edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb.
# MAGIC
# MAGIC Compare Cycle 1 Day 1 Pre-dose (C1D1PRE) versus Cycle 1 Day 1 6 hours post-dose (C1D1HR6) cytokine levels to identify early pharmacodynamic changes."

# COMMAND ----------

# MAGIC %md
# MAGIC _**version 2**_
# MAGIC
# MAGIC Generate a volcano plot dataset for the AMG330 study using cytokine biomarker data from edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb.
# MAGIC
# MAGIC Compare Cycle 1 Day 1 Pre-dose ('C1D1PRE', 'C1D1 Pre', 
# MAGIC                        'GRP 1 C1D1 PRE CYTOKINE', 
# MAGIC                        'GRP 2 C1D1 PRE CYTOKINE', 
# MAGIC                        'GRP 3 DS D1 PRE CYTOKINE', 
# MAGIC                        'GRP 4 DS D1 PRE CYTOKINE') 
# MAGIC                        
# MAGIC   versus Cycle 1 Day 1 6 hours post-dose ('C1D1HR6', 'C1D1 6 hour', 
# MAGIC                        'GRP 1 C1D1 6H CYTOKINE', 
# MAGIC                        'GRP 2 C1D1 6H CYTOKINE', 
# MAGIC                        'GRP 3 DS D1 6H CYTOKINE', 
# MAGIC                        'GRP 4 DS D1 6H CYTOKINE') cytokine levels to identify early pharmacodynamic changes.

# COMMAND ----------

spark.sql("""
CREATE OR REPLACE TABLE edl_dev.cbd_sandbox.amg330_cb_volcano AS
WITH baseline AS (
    SELECT SUBJID, ANALYTE, STRESN AS BASE_VALUE
    FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb
    WHERE VISITRAW IN ('C1D1PRE', 'C1D1 Pre', 
                       'GRP 1 C1D1 PRE CYTOKINE', 
                       'GRP 2 C1D1 PRE CYTOKINE', 
                       'GRP 3 DS D1 PRE CYTOKINE', 
                       'GRP 4 DS D1 PRE CYTOKINE')
),
postdose AS (
    SELECT SUBJID, ANALYTE, STRESN AS POST_VALUE
    FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb
    WHERE VISITRAW IN ('C1D1HR6', 'C1D1 6 hour', 
                       'GRP 1 C1D1 6H CYTOKINE', 
                       'GRP 2 C1D1 6H CYTOKINE', 
                       'GRP 3 DS D1 6H CYTOKINE', 
                       'GRP 4 DS D1 6H CYTOKINE')
),
fc AS (
    SELECT 
        b.ANALYTE,
        LOG2(AVG(p.POST_VALUE) / AVG(b.BASE_VALUE)) AS LOG2_FOLD_CHANGE,
        1 - EXP(-ABS(LOG2(AVG(p.POST_VALUE)/AVG(b.BASE_VALUE)))) AS P_VALUE
    FROM baseline b
    JOIN postdose p 
      ON b.SUBJID = p.SUBJID 
     AND b.ANALYTE = p.ANALYTE
    GROUP BY b.ANALYTE
)
SELECT 
    ANALYTE,
    LOG2_FOLD_CHANGE,
    -LOG10(P_VALUE) AS NEG_LOG10_PVAL,
    CASE 
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE > 1 THEN 'Increased'
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE < -1 THEN 'Decreased'
        ELSE 'No Change'
    END AS SIGNIFICANCE
FROM fc;

""")


# COMMAND ----------

import pandas as pd
import matplotlib.pyplot as plt

# Replace dataset name accordingly:
df = spark.table("edl_dev.cbd_sandbox.amg330_cb_volcano").toPandas()
print(df.shape)
plt.figure(figsize=(8,6))
plt.scatter(df["LOG2_FOLD_CHANGE"], df["NEG_LOG10_PVAL"], c="gray", alpha=0.6)
plt.title("Volcano Plot")
plt.xlabel("Log2 Fold Change")
plt.ylabel("-Log10(P-Value)")
plt.grid(True, linestyle="--", alpha=0.5)
plt.show()

# COMMAND ----------

df.head()

# COMMAND ----------

# MAGIC %md
# MAGIC **Use Case 3**: 
# MAGIC
# MAGIC Generate a volcano plot dataset for the AMG427 study using ctDNA variant data from
# MAGIC edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_ngs.
# MAGIC
# MAGIC Compare Screening (baseline/SCR) samples versus Cycle 1 Day 14 (on-treatment/C1D14) samples to identify ctDNA variants that expand or contract following treatment exposure.

# COMMAND ----------

df = spark.sql("""
WITH baseline AS (
    SELECT SUBJID, gene, CHROM, POS, REF, ALT, AF AS BASE_AF
    FROM edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_ngs
    WHERE UPPER(VISITRAW) = 'SCR'
),
ontx AS (
    SELECT SUBJID, gene, CHROM, POS, REF, ALT, AF AS ONTX_AF
    FROM edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_ngs
    WHERE UPPER(VISITRAW) = 'C1D14'
),
fc AS (
    SELECT 
        b.gene,
        b.CHROM,
        b.POS,
        b.REF,
        b.ALT,
        LOG2(AVG(o.ONTX_AF) / AVG(b.BASE_AF)) AS LOG2_FOLD_CHANGE,
        1 - EXP(-ABS(LOG2(AVG(o.ONTX_AF)/AVG(b.BASE_AF)))) AS P_VALUE
    FROM baseline b
    JOIN ontx o 
      ON b.SUBJID = o.SUBJID 
     AND b.gene = o.gene 
     AND b.CHROM = o.CHROM 
     AND b.POS = o.POS
     AND b.ALT = o.ALT
    GROUP BY b.gene, b.CHROM, b.POS, b.REF, b.ALT
)
SELECT 
    gene,
    CHROM,
    POS,
    REF,
    ALT,
    LOG2_FOLD_CHANGE,
    -LOG10(P_VALUE) AS NEG_LOG10_PVAL,
    CASE 
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE > 1 THEN 'Expanded'
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE < -1 THEN 'Contracted'
        ELSE 'Stable'
    END AS SIGNIFICANCE
FROM fc
""").toPandas()
#df = df.toPandas()

plt.figure(figsize=(8,6))
plt.scatter(df["LOG2_FOLD_CHANGE"], df["NEG_LOG10_PVAL"], c="gray", alpha=0.6)
plt.title("Volcano Plot")
plt.xlabel("Log2 Fold Change")
plt.ylabel("-Log10(P-Value)")
plt.grid(True, linestyle="--", alpha=0.5)
plt.show()

# COMMAND ----------

df.head()

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC **Use Case 4:** 
# MAGIC
# MAGIC “**Generate a volcano plot dataset comparing biomarker levels between responders and non-responders in the AMG701 study; responders as subjects whose best_response is ‘CR’ or ‘PR’, and non-responders as those with ‘SD’ or ‘PD’.**"
# MAGIC
# MAGIC Use data from the tables:
# MAGIC
# MAGIC edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb (for analyte-level biomarker concentrations), and
# MAGIC
# MAGIC edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl (for clinical subject-level response data).
# MAGIC
# MAGIC Define responders as subjects whose best_response is ‘CR’ or ‘PR’, and non-responders as those with ‘SD’ or ‘PD’.

# COMMAND ----------

spark.conf.set('spark.sql.ansi.enabled', False)

# COMMAND ----------

df = spark.sql("""
SELECT 
    ANALYTE,
    LOG2_FOLD_CHANGE,
    -LOG10(P_VALUE) AS NEG_LOG10_PVAL,
    CASE 
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE > 1 THEN 'Associated with Response'
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE < -1 THEN 'Associated with Nonresponse'
        ELSE 'Not Significant'
    END AS SIGNIFICANCE
FROM (
    WITH resp AS (
        SELECT cb.ANALYTE, AVG(cb.STRESN) AS RESP_AVG
        FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb cb
        JOIN edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl adsl
          ON cb.SUBJID = adsl.SUBJID
        WHERE adsl.best_response IN ('CR', 'PR')
        GROUP BY cb.ANALYTE
    ),
    nonresp AS (
        SELECT cb.ANALYTE, AVG(cb.STRESN) AS NONRESP_AVG
        FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb cb
        JOIN edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl adsl
          ON cb.SUBJID = adsl.SUBJID
        WHERE adsl.best_response IN ('SD', 'PD')
        GROUP BY cb.ANALYTE
    ),
    fc AS (
        SELECT 
            r.ANALYTE,
            LOG2(AVG(r.RESP_AVG) / AVG(n.NONRESP_AVG)) AS LOG2_FOLD_CHANGE,
            1 - EXP(-ABS(LOG2(AVG(r.RESP_AVG)/AVG(n.NONRESP_AVG)))) AS P_VALUE
        FROM resp r
        JOIN nonresp n ON r.ANALYTE = n.ANALYTE
        GROUP BY r.ANALYTE
    )
    SELECT * FROM fc
) subquery
""").toPandas()
plt.figure(figsize=(8,6))
plt.scatter(df["LOG2_FOLD_CHANGE"], df["NEG_LOG10_PVAL"], c="gray", alpha=0.6)
plt.title("Volcano Plot – AMG701 Biomarker Associations with Response (CR/PR vs SD/PD)")
plt.xlabel("Log2 Fold Change")
plt.ylabel("-Log10(P-Value)")
plt.grid(True, linestyle="--", alpha=0.5)
plt.show()

# COMMAND ----------

df.head()

# COMMAND ----------

df[df['ANALYTE']=='IFN-Gamma']

# COMMAND ----------

plt.figure(figsize=(9,6))
plt.scatter(df["LOG2_FOLD_CHANGE"], df["NEG_LOG10_PVAL"], color="gray", alpha=0.7, label="Not Significant")

# Add threshold lines
plt.axvline(x=1, color="red", linestyle="--", alpha=0.5, label="|Log2FC|=1")
plt.axvline(x=-1, color="red", linestyle="--", alpha=0.5)
plt.axhline(y=1.3, color="blue", linestyle="--", alpha=0.5, label="p=0.05 (-log10≈1.3)")

# Annotate selected analytes above the p-value threshold
for _, row in df.head(20).iterrows():
    if row["NEG_LOG10_PVAL"] > 2.5 or abs(row["LOG2_FOLD_CHANGE"]) > 0.1:
        plt.text(row["LOG2_FOLD_CHANGE"], row["NEG_LOG10_PVAL"] + 0.05, row["ANALYTE"], fontsize=8)

plt.title("Volcano Plot – AMG701 Biomarker Associations with Response (CR/PR vs SD/PD)")
plt.xlabel("Log2 Fold Change (Responders vs Non-Responders)")
plt.ylabel("-Log10(p-value)")
plt.legend()
plt.grid(alpha=0.3)
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC **ChatGPT vs Databricks Genie Calculation of p-value based on fold change**

# COMMAND ----------

# MAGIC %sql
# MAGIC --MEAN_LOG2_FC = 0.3
# MAGIC SELECT -LOG10(POWER(2, -ABS(0.3))); ---Genie Calculation negative log 10 p-value
# MAGIC SELECT (1 - EXP(-ABS(0.3)));--- ChatGPT negative log 10 p-value

# COMMAND ----------

# MAGIC %sql
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **React Agents**

# COMMAND ----------

# MAGIC %pip install langchain==0.3.14
# MAGIC %pip install langchain-openai==0.3.0
# MAGIC %pip install langchain-community==0.3.14
# MAGIC %pip install langgraph==0.2.66
# MAGIC %pip install langchain-experimental==0.3.4
# MAGIC %pip install databricks-langchain databricks-agents databricks-vectorsearch databricks-connect databricks-sql-connector seaborn

# COMMAND ----------

# Databricks Notebook or LangChain Python app
# ==================================================
# Imports
# ==================================================
from langchain_community.chat_models import ChatDatabricks
#from langchain.agents import Tool, initialize_agent
from langchain.schema import HumanMessage
from databricks import sql
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os


from langchain.tools import StructuredTool
from langchain.tools import Tool
from langchain_core.tools import tool
from langgraph.prebuilt import create_react_agent
from langchain.agents import initialize_agent
from langchain.agents import AgentType
from langchain.agents import AgentExecutor

# COMMAND ----------


# ==================================================
# Databricks Connection Configuration
# ==================================================
DATABRICKS_SERVER = "amgen-ai-dev.cloud.databricks.com"
DATABRICKS_HTTP_PATH = "/sql/1.0/warehouses/37c05da246f2f4bd"
DATABRICKS_TOKEN = "dapi5dd544df3e18db3cf4dcc7f1b8de7c47"

# ==================================================
# Function: Query Production Databricks Tables
# ==================================================
def query_databricks(sql_query: str) -> pd.DataFrame:
    """Execute a SQL query on Databricks production server and return a Pandas DataFrame."""
    with sql.connect(
        server_hostname=DATABRICKS_SERVER,
        http_path=DATABRICKS_HTTP_PATH,
        access_token=DATABRICKS_TOKEN
    ) as connection:
        cursor = connection.cursor()
        cursor.execute(sql_query)
        results = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        df = pd.DataFrame(results, columns=columns)
    return df


# ==================================================
# Function: Compute TEAE Risk Difference Forest Plot Dataset
# ==================================================
def compute_forest_df2() -> pd.DataFrame:
     sql_query =   """
     SELECT SUBJID,SEX
     FROM edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_adsl
     LIMIT 10;
     """
     return query_databricks(sql_query)


def compute_forest_df() -> pd.DataFrame:
    """
    Compute TEAE risk differences across demographic subgroups (Male vs Female, <65 vs ≥65)
    for the AMG160 study and return as a Pandas DataFrame.
    """
    sql_query = """
    WITH base AS (
        SELECT 
            adsl.SUBJID,
            adsl.SEX,
            CASE WHEN adsl.AGE < 65 THEN '<65' ELSE '≥65' END AS AGE_GROUP,
            ae.AEPT,
            MAX(ae.AETOXGR) AS MAX_GRADE
        FROM edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_ae ae
        JOIN edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_adsl adsl
          ON ae.SUBJID = adsl.SUBJID
        GROUP BY adsl.SUBJID, adsl.SEX, adsl.AGE, ae.AEPT
    ),
    summary AS (
        SELECT 
            AEPT AS AE_TERM,
            'Male vs Female' AS SUBGROUP_COMPARISON,
            (
                SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)
            ) -
            (
                SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0)
            ) AS RISK_DIFF,
            (
                (
                    (
                        SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                        NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)
                    ) -
                    (
                        SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                        NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0)
                    )
                ) -
                1.96 * SQRT(
                    (
                        (
                            SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                            NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)
                        ) * (
                            1 - (
                                SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                                NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)
                            )
                        ) / NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)
                    ) +
                    (
                        (
                            SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                            NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0)
                        ) * (
                            1 - (
                                SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                                NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0)
                            )
                        ) / NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0)
                    )
                )
            ) AS CI_LOWER,
            (
                (
                    (
                        SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                        NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)
                    ) -
                    (
                        SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                        NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0)
                    )
                ) +
                1.96 * SQRT(
                    (
                        (
                            SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                            NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)
                        ) * (
                            1 - (
                                SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                                NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)
                            )
                        ) / NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)
                    ) +
                    (
                        (
                            SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                            NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0)
                        ) * (
                            1 - (
                                SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) /
                                NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0)
                            )
                        ) / NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0)
                    )
                )
            ) AS CI_UPPER
        FROM base
        GROUP BY AEPT
    )
    SELECT * FROM summary
    WHERE RISK_DIFF IS NOT NULL
    ORDER BY ABS(RISK_DIFF) DESC
    LIMIT 10
    """
    return query_databricks(sql_query)


# ==================================================
# Function: Plot Forest Plot from DataFrame
# ==================================================
def plot_forest(df: pd.DataFrame, title: str):
    """Generate a forest plot from the computed TEAE risk difference DataFrame."""
    plt.figure(figsize=(10, 6))
    y_positions = np.arange(len(df))
    plt.errorbar(
        df["RISK_DIFF"],
        y_positions,
        xerr=[df["RISK_DIFF"] - df["CI_LOWER"], df["CI_UPPER"] - df["RISK_DIFF"]],
        fmt='o', color='darkblue', ecolor='gray', elinewidth=3, capsize=4
    )
    plt.axvline(x=0, color='red', linestyle='--', label='No Difference (Risk Diff = 0)')
    plt.yticks(y_positions, df["AE_TERM"])
    plt.xlabel("Risk Difference (Subgroup A - Subgroup B)")
    plt.ylabel("Adverse Event Term")
    plt.title(title)
    plt.legend()
    plt.grid(alpha=0.3, linestyle='--')
    plt.tight_layout()
    plt.show()


# ==================================================
# LangChain ReAct Agent with ChatDatabricks
# ==================================================
def generate_forest_plot(_: str) -> str:
    """Fetch AE risk difference data and generate a forest plot."""
    df = compute_forest_df2()
    print(df.head())
    #plot_forest(df, "Forest Plot — AMG160 TEAE Risk Differences (Male vs Female)")
    return "✅ Forest plot successfully generated from live production data."

# COMMAND ----------

# Define LangChain tools
tools = [
    Tool(
        name="Generate AMG160 Forest Plot",
        func=generate_forest_plot,
        description="Generates a forest plot summarizing TEAE risk differences across demographic subgroups for AMG160."
    )
]

# Initialize ChatDatabricks LLM
llm = ChatDatabricks(
    endpoint="project-115-Precision_Medicine_AI_Agent-2",  # Adjust if using another endpoint
    temperature=0.1,
)

# Initialize ReAct Agent
agent = initialize_agent(
    tools=tools,
    llm=llm,
    agent="chat-conversational-react-description",
    verbose=True
)



# COMMAND ----------

# ==================================================
# Run Agent with Natural Language Prompt
# ==================================================
query = """
Generate a forest plot summarizing the treatment-emergent adverse event (TEAE) 
risk differences across demographic subgroups (e.g., sex and age) for the AMG160 study.
"""

#response = agent.invoke(input=query,
#    chat_history=[])
response = agent.invoke({
    "input": query,
    "chat_history": []
})
print(response)


# COMMAND ----------

Rules:
    1. Join AE and ADSL on SUBJID when analyzing TEAE (treatment-emergent adverse events).
    2. Use SEX, AGEGRP, and TRTARM as subgroups if relevant.
    3. Compute event rates per treatment arm and their risk difference (treatment - control).
    4. Return valid Databricks SQL only (no explanations or markdown).

# COMMAND ----------





# COMMAND ----------

# MAGIC %md
# MAGIC **Agent 2**

# COMMAND ----------

# Databricks Notebook
# Clinical Query Agent with ChatDatabricks + Auto Table Resolver + Forest Plot
# Author: PMedGPT

# ---------------------------------------------------------------------
# 1. Imports and setup
# ---------------------------------------------------------------------
from pyspark.sql import SparkSession
import pandas as pd
import matplotlib.pyplot as plt
import re
import seaborn as sns

# LangChain ChatDatabricks integration
from langchain_community.chat_models import ChatDatabricks
from langchain.schema import SystemMessage, HumanMessage

# Initialize Spark
spark = SparkSession.builder.getOrCreate()
ENDPOINT = "project-115-Precision_Medicine_AI_Agent-2"

# Initialize ChatDatabricks model
# You can replace model with your chosen Databricks-hosted LLM, e.g. llama3 or mixtral
llm = ChatDatabricks(
    endpoint = ENDPOINT,  # or your registered model name
    temperature=0,
    max_tokens=1500
)


# ---------------------------------------------------------------------
# 2. Unity Catalog mapping (study → table names)
# ---------------------------------------------------------------------
STUDY_TABLES = {
    "AMG160": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_cb",
    },
    "AMG330": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb",
    },
    "AMG427": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_cb",
    },
    "AMG673": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg673_20160377_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg673_20160377_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg673_20160377_ne_cb",
    },
    "AMG701": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb",
    },
}


# ---------------------------------------------------------------------
# 3. Extract study name from user query
# ---------------------------------------------------------------------
def extract_study_from_query1(natural_query: str) -> str:
    match = re.search(r"AMG\\s?\\d+", natural_query.upper())
    if match:
        return match.group(0).replace(" ", "")
    raise ValueError("Could not detect study name (e.g., AMG160, AMG330) from query.")

STUDY_ALIASES = {
    "xaluritamig": "AMG509",
    "tarlatamab": "AMG757",
    "amg 509": "AMG509",
    "amg 757": "AMG757",
    "amg160": "AMG160",
    "amg 160": "AMG160",
    "amg330": "AMG330",
    "amg 330": "AMG330",
    "amg427": "AMG427",
    "amg 427": "AMG427",
    "amg673": "AMG673",
    "amg 673": "AMG673",
    "amg701": "AMG701",
    "amg 701": "AMG701",
}

def extract_study_from_query(natural_query: str) -> str:
    """
    Extract study identifier (AMG code) from user query.
    Supports both numeric codes (e.g., AMG160) and aliases (e.g., tarlatamab).
    """
    q_lower = natural_query.lower()

    # 1️⃣ Try to detect AMG### pattern
    match = re.search(r"amg\\s?\\d+", q_lower)
    if match:
        return match.group(0).replace(" ", "").upper()

    # 2️⃣ Try to detect known alias name (e.g., "tarlatamab")
    for alias, amg_code in STUDY_ALIASES.items():
        if alias in q_lower:
            return amg_code

    # 3️⃣ If not found, raise clear, user-friendly error
    raise ValueError(
        f"❌ Could not detect a study name or alias from the query: '{natural_query}'.\n"
        f"Please include a molecule name (e.g., 'AMG160') or known alias "
        f"({', '.join(sorted(set(STUDY_ALIASES.keys()) - set(['amg 160','amg160'])))})"
    )





# ---------------------------------------------------------------------
# 4. Generate SQL query using ChatDatabricks
# ---------------------------------------------------------------------
def generate_sql_with_chatdatabricks(natural_query: str, study: str) -> str:
    if study not in STUDY_TABLES:
        raise ValueError(f"No table mapping found for study {study}")
    
    tables = STUDY_TABLES[study]

    system_prompt = f"""
    You are an expert Databricks SQL analyst.
    You have access to the following Unity Catalog tables for {study}:
      - ADSL (subject-level): {tables['adsl']}
      - AE (adverse events): {tables['ae']}
      - CB (clinical biomarkers): {tables['cb']}

    Rules:
        1. Join AE and ADSL on SUBJID when analyzing TEAE (treatment-emergent adverse events).
        2. Use SEX, AGEGRP, and TRTARM as subgroups if relevant.
        3. Compute event rates per treatment arm and their risk difference (treatment - control).
        4. Return valid Databricks SQL only (no explanations or markdown).
    """

    user_prompt = f"""
    Natural language query:
    \"\"\"{natural_query}\"\"\"
    Generate only the SQL query that can be executed in Databricks.
    """


    system_prompt2 = """
You are an expert clinical data reasoning agent specialized in querying biomarker datasets in Databricks SQL 
to support biostatistical visualizations such as forest plots. You understand normalized clinical datasets used in 
Amgen BiTE trials (e.g., AMG160, AMG330, AMG701, etc.), where cytokine and biomarker data are stored in 
tables named like `edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb`.

Your job: When the user describes an analysis (e.g., “generate a forest plot comparing cytokine fold-change estimates 
across multiple post-dose timepoints vs pre-dose baseline for the AMG330 study”), you must generate 
a **Databricks SQL query** that retrieves the summarized data needed for visualization. 

Your query must:
1. Correctly reference the biomarker data layer: `edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb`.
2. Use the proper columns:
   - `SUBJID`: subject identifier
   - `ANALYTE`: cytokine name
   - `STRESN`: numeric cytokine concentration
   - `study_time`: numeric sampling time relative to dose (negative = pre-dose)
3. Compute **log2 fold-change** of post-dose vs pre-dose baseline:
   - Use baseline as the mean STRESN per subject and analyte where `study_time < 0`.
   - Join to all post-dose (`study_time > 0`) rows for the same subject and analyte.
   - Compute `log2(cb.STRESN / b.baseline_value)` as `log2_fc`.
4. Aggregate results:
   - Round study_time into 6-hour bins: `ROUND(cb.study_time / 6) * 6`.
   - Calculate `AVG(log2_fc)` as `mean_log2_fc` and `STDDEV(log2_fc)` as `sd_log2_fc`.
   - Group by `ANALYTE` and `study_time_6hr`.
   - Filter to cytokines of interest: `('IL-6', 'IL-10', 'IL-8', 'MCP-1', 'TNF-a', 'IFN-Gamma')`.
5. Return results ordered by analyte and time.

Expected SQL Output Template:
------------------------------------------------------------
WITH baseline AS (
    SELECT SUBJID, analyte, AVG(STRESN) AS baseline_value
    FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb
    WHERE study_time < 0 AND STRESN > 0
    GROUP BY SUBJID, analyte
),
summarized AS (
    SELECT cb.analyte,
           ROUND(cb.study_time / 6) * 6 AS study_time_6hr,
           log2(cb.STRESN / b.baseline_value) AS log2_fc
    FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb cb
    JOIN baseline b
      ON cb.SUBJID = b.SUBJID AND cb.analyte = b.analyte
    WHERE cb.study_time > 0 AND cb.STRESN > 0 AND b.baseline_value > 0
      AND cb.analyte IN ('IL-6', 'IL-10', 'IL-8', 'MCP-1', 'TNF-a', 'IFN-Gamma')
)
SELECT analyte,
       study_time_6hr,
       COALESCE(AVG(log2_fc), 0) AS mean_log2_fc,
       COALESCE(STDDEV(log2_fc), 0) AS sd_log2_fc
FROM summarized
GROUP BY analyte, study_time_6hr
ORDER BY analyte, study_time_6hr;
------------------------------------------------------------

Rules:
- Always use safe SQL that can run in Databricks without dynamic typing issues.
- Replace missing values (`NULL`) with `0` using COALESCE.
- Never hallucinate table or column names; use only those above.
- Do not add visualization code; output SQL only.

When the user asks for a “forest plot,” “fold-change,” “baseline,” or “cytokine kinetics,” generate this query logic.
When the user references another study (e.g., AMG160), adapt only the table name.
"""



    response = llm.invoke([
        SystemMessage(content=system_prompt2),
        HumanMessage(content=user_prompt)
    ])

    sql = response.content.strip()

    #if not (sql.lower().startswith("select") or sql.lower().startswith("with")):
    #    raise ValueError("ChatDatabricks did not return a valid SQL query:\n" + sql)

    return sql


# ---------------------------------------------------------------------
# 5. Execute SQL on Databricks and collect data
# ---------------------------------------------------------------------
def run_sql_and_collect(sql: str) -> pd.DataFrame:
    print("Running generated SQL on Databricks...")
    df_spark = spark.sql(sql)
    df = df_spark.toPandas()
    print(f"✅ Retrieved {len(df)} rows")
    return df


# ---------------------------------------------------------------------
# 6. Render forest plot
# ---------------------------------------------------------------------
def plot_forest(df: pd.DataFrame,
                subgroup_col: str = "SUBGROUP",
                effect_col: str = "RISK_DIFFERENCE",
                lower_col: str = None,
                upper_col: str = None):
    plt.figure(figsize=(8, 6))
    y_labels = df[subgroup_col]
    y_pos = range(len(df))

    if lower_col and upper_col and lower_col in df and upper_col in df:
        plt.errorbar(
            df[effect_col],
            y_pos,
            xerr=[df[effect_col] - df[lower_col], df[upper_col] - df[effect_col]],
            fmt="o",
            color="black",
            ecolor="gray",
            elinewidth=1,
            capsize=3,
        )
    else:
        plt.plot(df[effect_col], y_pos, "o", color="black")

    plt.yticks(y_pos, y_labels)
    plt.axvline(x=0, color="red", linestyle="--", alpha=0.7)
    plt.xlabel("Risk Difference (Treatment - Control)")
    plt.title("Forest Plot: TEAE Risk Differences by Subgroup")
    plt.grid(True, linestyle=":", linewidth=0.5)
    plt.tight_layout()
    plt.show()



# COMMAND ----------

# ---------------------------------------------------------------------
# 7. Main workflow
# ---------------------------------------------------------------------
natural_query = "Generate a forest plot summarizing the treatment-emergent adverse event (TEAE) risk differences across demographic subgroups (e.g., sex and age) for the AMG160 study"

natural_query = "Generate a forest plot comparing cytokine fold-change estimates across multiple post-dose timepoints versus pre-dose baseline for the AMG330 study"

# Step 1: Detect study
study = extract_study_from_query(natural_query)
print(f"Detected study: {study}")

# Step 2: Generate SQL using ChatDatabricks
sql_query = generate_sql_with_chatdatabricks(natural_query, study)
print("Generated SQL:")
print(sql_query)
'''
# Step 3: Execute SQL
df = run_sql_and_collect(sql_query)

# Step 4: Prepare subgroup column
if "SEX" in df.columns and "AGEGRP" in df.columns:
    df["SUBGROUP"] = df["SEX"].astype(str) + " | " + df["AGEGRP"].astype(str)
elif "SUBGROUP" not in df.columns:
    df["SUBGROUP"] = df.index.astype(str)

# Step 5: Plot
plot_forest(df)
'''

# COMMAND ----------

sql_query= """
WITH baseline AS (
    SELECT SUBJID, analyte, AVG(STRESN) AS baseline_value
    FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb
    WHERE study_time < 0 AND STRESN > 0
    GROUP BY SUBJID, analyte
),
summarized AS (
    SELECT cb.analyte,
           ROUND(cb.study_time / 6) * 6 AS study_time_6hr,
           log2(cb.STRESN / b.baseline_value) AS log2_fc
    FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb cb
    JOIN baseline b
      ON cb.SUBJID = b.SUBJID AND cb.analyte = b.analyte
    WHERE cb.study_time > 0 AND cb.STRESN > 0 AND b.baseline_value > 0
      AND cb.analyte IN ('IL-6', 'IL-10', 'IL-8', 'MCP-1', 'TNF-a', 'IFN-Gamma')
)
SELECT analyte,
       study_time_6hr,
       COALESCE(AVG(log2_fc), 0) AS mean_log2_fc,
       COALESCE(STDDEV(log2_fc), 0) AS sd_log2_fc
FROM summarized
GROUP BY analyte, study_time_6hr
ORDER BY analyte, study_time_6hr;
"""

# COMMAND ----------

dff = run_sql_and_collect(sql_query)

# COMMAND ----------

#dff = df.copy()

# COMMAND ----------

dff = dff.sort_values(by=['analyte', 'study_time_6hr'])
dff['study_time_6hr'] = dff['study_time_6hr'].astype(float)

# Set plotting style
sns.set(style="whitegrid", context="talk")

fig, ax = plt.subplots(figsize=(10, 6))

# Each cytokine gets a unique color
palette = sns.color_palette("husl", df['analyte'].nunique())

# Plot each cytokine separately
for i, (analyte, subset) in enumerate(dff.groupby('analyte')):
    ax.errorbar(
        subset['mean_log2_fc'],
        subset['study_time_6hr'] + (i * 0.5),  # small vertical offset to avoid overlap
        xerr=subset['sd_log2_fc'],
        fmt='o',
        label=analyte,
        capsize=3,
        markersize=6,
        elinewidth=1.5,
        color=palette[i],
        alpha=0.9
    )

# Add baseline line at log2FC = 0
ax.axvline(0, color='gray', linestyle='--', linewidth=1.2)

# ---------------------------------------------------------------------
# 🏷 STEP 3: Customize aesthetics
# ---------------------------------------------------------------------
ax.set_title("Forest Plot of Cytokine Fold-Change vs. Baseline (AMG330 Study)", fontsize=16, pad=15)
ax.set_xlabel("Mean log₂ Fold-Change (Post-dose vs Baseline)", fontsize=14)
ax.set_ylabel("Study Time (hr)", fontsize=14)
ax.legend(title="Cytokine", loc='best', fontsize=11, title_fontsize=12)
ax.grid(True, linestyle='--', linewidth=0.5, alpha=0.7)

# Invert y-axis so earlier times appear higher
ax.invert_yaxis()

plt.tight_layout()
plt.show()

# COMMAND ----------

dff.shape

# COMMAND ----------

dff.head(2)

# COMMAND ----------

"""
Forest Plot Visualization with Unique Y-Axis per Cytokine-Time Pair
Author: [Your Name]
Use case: AMG330 cytokine fold-change (log2) forest plot
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# ---------------------------------------------------------------------
# 🧩 STEP 1: Load or simulate forest plot dataset
# ---------------------------------------------------------------------
# Replace this with the dataset you queried from Databricks
df = dff.copy()

# ---------------------------------------------------------------------
# 🧮 STEP 2: Prepare data for forest plot
# ---------------------------------------------------------------------

# Create a unique label per cytokine-timepoint pair
df['label'] = df.apply(lambda x: f"{x['ANALYTE']} | {int(x['study_time_6hr'])}h", axis=1)

# Sort labels by analyte then time
df = df.sort_values(by=['ANALYTE', 'study_time_6hr'], ascending=[True, True])

# Reverse the order for top-down plotting
df = df.reset_index(drop=True)
df = df.head(30)

df['y_pos'] = range(len(df))[::-1]  # unique numeric y positions

# ---------------------------------------------------------------------
# 🎨 STEP 3: Plot forest plot
# ---------------------------------------------------------------------
sns.set(style="whitegrid", context="talk")

fig, ax = plt.subplots(figsize=(10, 7))

ax.errorbar(
    df['mean_log2_fc'],
    df['y_pos'],
    xerr=df['sd_log2_fc'],
    fmt='o',
    color='tab:blue',
    ecolor='gray',
    elinewidth=1.5,
    capsize=4,
)

# Add baseline line
ax.axvline(0, color='gray', linestyle='--', linewidth=1.2)

# ---------------------------------------------------------------------
# 🏷 STEP 4: Customize labels and aesthetics
# ---------------------------------------------------------------------
ax.set_yticks(df['y_pos'])
ax.set_yticklabels(df['label'], fontsize=11)
ax.set_xlabel("Mean log₂ Fold-Change (Post-dose vs Baseline)", fontsize=13)
ax.set_ylabel("Cytokine | Timepoint", fontsize=13)
ax.set_title("Forest Plot of Cytokine Fold-Change vs Baseline (AMG330 Study)", fontsize=15, pad=15)

# Grid and layout
ax.grid(axis='x', linestyle='--', linewidth=0.7, alpha=0.7)
sns.despine(left=True, bottom=True)
plt.tight_layout()

# ---------------------------------------------------------------------
# 💾 STEP 5: Show or save the figure
# ---------------------------------------------------------------------
plt.show()
# plt.savefig("amg330_cytokine_forest_plot_unique_yaxis.png", dpi=300, bbox_inches="tight")
