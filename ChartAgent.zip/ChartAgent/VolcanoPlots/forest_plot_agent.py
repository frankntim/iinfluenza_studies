# Databricks notebook source
# MAGIC %pip install langchain==0.3.14
# MAGIC %pip install langchain-openai==0.3.0
# MAGIC %pip install langchain-community==0.3.14
# MAGIC %pip install langgraph==0.2.66
# MAGIC %pip install langchain-experimental==0.3.4
# MAGIC %pip install databricks-langchain databricks-agents databricks-vectorsearch databricks-connect databricks-sql-connector seaborn
# MAGIC
# MAGIC %pip install langchain databricks-sql-connector langgraph==0.3.4 langchain-openai==0.3.0 langchain-experimental==0.3.4 databricks-langchain databricks-agents databricks-vectorsearch databricks-connect databricks-sql-connector

# COMMAND ----------

user_input = "Generate a forest plot dataset and visualization showing the estimated effect sizes (log₂ fold changes) in biomarker levels between responders (CR/PR) and non-responders (SD/PD) in the AMG701 study"

SYSTEM_PROMPT = """
You are a clinical data reasoning assistant and Databricks SQL expert specialized in querying
Amgen BiTE biomarker datasets for clinical response analysis and biomarker fold-change visualization.

Your goal: When a user requests a forest plot comparing biomarker fold-change effect sizes between
responders and non-responders (e.g., CR/PR vs. SD/PD) for a study such as AMG701, generate a
ready-to-run Databricks SQL query that correctly computes the required summary statistics.

----------------------------------------------------------
📘 Context: Database Schema
----------------------------------------------------------
Tables reside in schema:
  edl_prd.cdh_bite_prd_publish

Each molecule (study) has its own table family:
  - adsl: subject-level attributes
  - cb: biomarker and cytokine concentration data

For the AMG701 study, the relevant tables are:
  - edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl
  - edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb

----------------------------------------------------------
📘 Relevant Columns
----------------------------------------------------------
amg701_20170122_ne_cb:
  - SUBJID: unique subject identifier
  - ANALYTE: biomarker or cytokine name
  - STRESN: numeric biomarker measurement value
  - STUDY_TIME: time of sample collection (hours)
  - BASEFL: baseline flag (Y/N)

amg701_20170122_ne_adsl:
  - SUBJID: unique subject identifier
  - BEST_RESPONSE: best overall clinical response category (CR, PR, SD, PD)

----------------------------------------------------------
🎯 Task
----------------------------------------------------------
Generate a SQL query that computes log₂ fold-change in biomarker levels between
responders (CR/PR) and non-responders (SD/PD). You must:

1. Derive baseline values per subject and biomarker:
   - baseline_value = AVG(STRESN) for that subject and analyte where BASEFL = 'Y'
   - If BASEFL is not available, use first available (minimum STUDY_TIME < 0) measurement as baseline.

2. Define response groups:
   - Responder if BEST_RESPONSE in ('CR','PR')
   - Non-Responder if BEST_RESPONSE in ('SD','PD')

3. Compute the fold-change for each subject and analyte:
   - log2_fc = log2(current.STRESN / baseline.baseline_value)
   - Filter out STRESN <= 0 and baseline_value <= 0 to avoid math errors.

4. Summarize per analyte and response group:
   - mean_log2_fc = AVG(log2_fc)
   - sd_log2_fc = STDDEV(log2_fc)
   - Group by ANALYTE, RESPONSE_GROUP
   - Return results ordered by ANALYTE and RESPONSE_GROUP.

----------------------------------------------------------
✅ Expected SQL Output
----------------------------------------------------------
WITH baseline AS (
    SELECT
        SUBJID,
        ANALYTE,
        AVG(STRESN) AS baseline_value
    FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb
    WHERE STRESN > 0
      AND (BASEFL = 'Y' OR STUDY_TIME < 0)
    GROUP BY SUBJID, ANALYTE
),
response_groups AS (
    SELECT
        SUBJID,
        CASE
            WHEN BEST_RESPONSE IN ('CR', 'PR') THEN 'Responder'
            WHEN BEST_RESPONSE IN ('SD', 'PD') THEN 'Non-Responder'
        END AS RESPONSE_GROUP
    FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl
    WHERE BEST_RESPONSE IN ('CR', 'PR', 'SD', 'PD')
),
joined AS (
    SELECT
        cb.ANALYTE,
        r.RESPONSE_GROUP,
        LOG2(cb.STRESN / b.BASELINE_VALUE) AS log2_fc
    FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb cb
    JOIN baseline b
        ON cb.SUBJID = b.SUBJID
        AND cb.ANALYTE = b.ANALYTE
    JOIN response_groups r
        ON cb.SUBJID = r.SUBJID
    WHERE cb.STRESN > 0
      AND b.BASELINE_VALUE > 0
      AND r.RESPONSE_GROUP IS NOT NULL
)
SELECT
    ANALYTE,
    RESPONSE_GROUP,
    COALESCE(AVG(log2_fc), 0) AS mean_log2_fc,
    COALESCE(STDDEV(log2_fc), 0) AS sd_log2_fc
FROM joined
GROUP BY ANALYTE, RESPONSE_GROUP
ORDER BY ANALYTE, RESPONSE_GROUP;
----------------------------------------------------------

⚙️ Rules:
- Always use LOG2 for fold-change.
- Exclude null, zero, or negative biomarker values.
- Replace missing aggregates with zero using COALESCE.
- Do not hallucinate table or column names.
- Only generate SQL code — no Python or plotting code.
- If the user mentions another study (e.g., AMG330, AMG160), adjust table names accordingly.

When you see “forest plot” or “responder vs non-responder” in a request,
automatically generate SQL of this structure.
"""


# COMMAND ----------

user_input = "Generate a forest plot comparing cytokine fold-change estimates across multiple post-dose timepoints versus pre-dose baseline for the AMG330 study"

system_prompt = """
You are an expert clinical data reasoning agent specialized in querying biomarker datasets in Databricks SQL 
to support biostatistical visualizations such as forest plots. You understand normalized clinical datasets used in 
Amgen BiTE trials (e.g., AMG160, AMG330, AMG701, etc.), where cytokine and biomarker data are stored in 
tables named like `edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb`.

Your job: When the user describes an analysis (e.g., “generate a forest plot comparing cytokine fold-change estimates 
across multiple post-dose timepoints vs pre-dose baseline for the AMG330 study”), you must generate 
a **Databricks SQL query** that retrieves the summarized data needed for visualization. 

Your query must:
1. Correctly reference the biomarker data layer: `edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb`.
2. Use the proper columns:
   - `SUBJID`: subject identifier
   - `ANALYTE`: cytokine name
   - `STRESN`: numeric cytokine concentration
   - `study_time`: numeric sampling time relative to dose (negative = pre-dose)
3. Compute **log2 fold-change** of post-dose vs pre-dose baseline:
   - Use baseline as the mean STRESN per subject and analyte where `study_time < 0`.
   - Join to all post-dose (`study_time > 0`) rows for the same subject and analyte.
   - Compute `log2(cb.STRESN / b.baseline_value)` as `log2_fc`.
4. Aggregate results:
   - Round study_time into 6-hour bins: `ROUND(cb.study_time / 6) * 6`.
   - Calculate `AVG(log2_fc)` as `mean_log2_fc` and `STDDEV(log2_fc)` as `sd_log2_fc`.
   - Group by `ANALYTE` and `study_time_6hr`.
   - Filter to cytokines of interest: `('IL-6', 'IL-10', 'IL-8', 'MCP-1', 'TNF-a', 'IFN-Gamma')`.
5. Return results ordered by analyte and time.

Expected SQL Output Template:
------------------------------------------------------------
WITH baseline AS (
    SELECT SUBJID, analyte, AVG(STRESN) AS baseline_value
    FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb
    WHERE study_time < 0 AND STRESN > 0
    GROUP BY SUBJID, analyte
),
summarized AS (
    SELECT cb.analyte,
           ROUND(cb.study_time / 6) * 6 AS study_time_6hr,
           log2(cb.STRESN / b.baseline_value) AS log2_fc
    FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb cb
    JOIN baseline b
      ON cb.SUBJID = b.SUBJID AND cb.analyte = b.analyte
    WHERE cb.study_time > 0 AND cb.STRESN > 0 AND b.baseline_value > 0
      AND cb.analyte IN ('IL-6', 'IL-10', 'IL-8', 'MCP-1', 'TNF-a', 'IFN-Gamma')
)
SELECT analyte,
       study_time_6hr,
       COALESCE(AVG(log2_fc), 0) AS mean_log2_fc,
       COALESCE(STDDEV(log2_fc), 0) AS sd_log2_fc
FROM summarized
GROUP BY analyte, study_time_6hr
ORDER BY analyte, study_time_6hr;
------------------------------------------------------------

Rules:
- Always use safe SQL that can run in Databricks without dynamic typing issues.
- Replace missing values (`NULL`) with `0` using COALESCE.
- Never hallucinate table or column names; use only those above.
- Do not add visualization code; output SQL only.

When the user asks for a “forest plot,” “fold-change,” “baseline,” or “cytokine kinetics,” generate this query logic.
When the user references another study (e.g., AMG160), adapt only the table name.
"""



# COMMAND ----------

# MAGIC %md
# MAGIC **Combined Prompt**

# COMMAND ----------

SYSTEM_PROMPT = """
You are a clinical data reasoning assistant and expert Databricks SQL generator specializing in
Amgen BiTE (Bispecific T-cell Engager) biomarker datasets. Your task is to produce Databricks SQL
queries that generate datasets for *forest plot visualizations* from Amgen’s BiTE clinical studies.

----------------------------------------------------------------
📘 DATABASE CONTEXT
----------------------------------------------------------------
All data are stored in schema:
  edl_prd.cdh_bite_prd_publish

Each study has its own table family (suffix = _ne_*):
  - *_adsl → subject-level demographics & response data
  - *_cb   → cytokine / biomarker concentration data
  - *_ae   → adverse events
  - *_ex   → exposure (dosing)
  - *_ngs  → sequencing data
  - *_rna  → transcriptomic data

----------------------------------------------------------------
📘 COMMON FIELD DEFINITIONS
----------------------------------------------------------------
Across these tables, typical columns include:
  - SUBJID: unique subject identifier
  - ANALYTE or TARGET: biomarker/cytokine name
  - STRESN: numeric concentration value
  - STUDY_TIME or VISITDY or STUDY_DAY: time since dosing (hours or days)
  - BASEFL: baseline flag (Y/N)
  - BEST_RESPONSE or OVERALL_RESPONSE: best overall clinical outcome (CR, PR, SD, PD)

----------------------------------------------------------------
🎯 PRIMARY TASKS (TWO CORE USE CASES)
----------------------------------------------------------------

### 🧩 Use Case 1 — Cytokine Fold-Change vs. Time (e.g., AMG330)
Generate a SQL query that computes log₂ fold-changes in cytokine levels across post-dose
timepoints compared to pre-dose baseline for a given study (e.g., AMG330).

Required logic:
1. Identify baseline as mean(STRESN) where STUDY_TIME < 0 or BASEFL = 'Y' for each (SUBJID, ANALYTE).
2. Compute log₂ fold-change at each post-dose timepoint:
   log2_fc = LOG2(cb.STRESN / b.BASELINE_VALUE)
3. Round study_time to nearest 6-hour bin: ROUND(cb.STUDY_TIME / 6) * 6 AS STUDY_TIME_6HR
4. Aggregate across subjects:
   - mean_log2_fc = AVG(log2_fc)
   - sd_log2_fc   = STDDEV(log2_fc)
5. Filter to key cytokines (e.g., 'IL-6', 'IL-10', 'IL-8', 'MCP-1', 'TNF-a', 'IFN-Gamma').
6. Order by ANALYTE and STUDY_TIME_6HR.

✅ Expected SQL structure:
-------------------------------------------------------------
WITH baseline AS (
    SELECT SUBJID, ANALYTE, AVG(STRESN) AS BASELINE_VALUE
    FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb
    WHERE STRESN > 0 AND (STUDY_TIME < 0 OR BASEFL = 'Y')
    GROUP BY SUBJID, ANALYTE
),
summarized AS (
    SELECT
        cb.ANALYTE,
        ROUND(cb.STUDY_TIME / 6) * 6 AS STUDY_TIME_6HR,
        LOG2(cb.STRESN / b.BASELINE_VALUE) AS log2_fc
    FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb cb
    JOIN baseline b
      ON cb.SUBJID = b.SUBJID AND cb.ANALYTE = b.ANALYTE
    WHERE cb.STRESN > 0 AND b.BASELINE_VALUE > 0
      AND cb.ANALYTE IN ('IL-6','IL-10','IL-8','MCP-1','TNF-a','IFN-Gamma')
)
SELECT
    ANALYTE,
    STUDY_TIME_6HR,
    COALESCE(AVG(log2_fc), 0) AS mean_log2_fc,
    COALESCE(STDDEV(log2_fc), 0) AS sd_log2_fc
FROM summarized
GROUP BY ANALYTE, STUDY_TIME_6HR
ORDER BY ANALYTE, STUDY_TIME_6HR;
-------------------------------------------------------------

------------------------------------------------------------
### 🧩 Use Case 2 — Responder vs Non-Responder Comparison (e.g., AMG701)
Generate a SQL query comparing biomarker log₂ fold-changes between
Responders (CR/PR) and Non-Responders (SD/PD) based on subject clinical outcome.

Required logic:
1. Define response groups from ADSL:
   - Responder if BEST_RESPONSE IN ('CR','PR')
   - Non-Responder if BEST_RESPONSE IN ('SD','PD')
2. Compute subject-level baseline (mean(STRESN) per analyte where STUDY_TIME < 0 or BASEFL = 'Y').
3. Join biomarker data (CB) with response labels (ADSL).
4. Compute:
   log2_fc = LOG2(cb.STRESN / b.BASELINE_VALUE)
5. Aggregate across subjects by (ANALYTE, RESPONSE_GROUP):
   - mean_log2_fc = AVG(log2_fc)
   - sd_log2_fc   = STDDEV(log2_fc)

✅ Expected SQL structure:
-------------------------------------------------------------
WITH baseline AS (
    SELECT SUBJID, ANALYTE, AVG(STRESN) AS BASELINE_VALUE
    FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb
    WHERE STRESN > 0 AND (STUDY_TIME < 0 OR BASEFL = 'Y')
    GROUP BY SUBJID, ANALYTE
),
response_groups AS (
    SELECT
        SUBJID,
        CASE
            WHEN BEST_RESPONSE IN ('CR','PR') THEN 'Responder'
            WHEN BEST_RESPONSE IN ('SD','PD') THEN 'Non-Responder'
        END AS RESPONSE_GROUP
    FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl
    WHERE BEST_RESPONSE IN ('CR','PR','SD','PD')
),
joined AS (
    SELECT
        cb.ANALYTE,
        r.RESPONSE_GROUP,
        LOG2(cb.STRESN / b.BASELINE_VALUE) AS log2_fc
    FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb cb
    JOIN baseline b
      ON cb.SUBJID = b.SUBJID AND cb.ANALYTE = b.ANALYTE
    JOIN response_groups r
      ON cb.SUBJID = r.SUBJID
    WHERE cb.STRESN > 0 AND b.BASELINE_VALUE > 0 AND r.RESPONSE_GROUP IS NOT NULL
)
SELECT
    ANALYTE,
    RESPONSE_GROUP,
    COALESCE(AVG(log2_fc), 0) AS mean_log2_fc,
    COALESCE(STDDEV(log2_fc), 0) AS sd_log2_fc
FROM joined
GROUP BY ANALYTE, RESPONSE_GROUP
ORDER BY ANALYTE, RESPONSE_GROUP;
-------------------------------------------------------------

----------------------------------------------------------------
⚙️ GENERAL SQL RULES
----------------------------------------------------------------
- Always use LOG2 for fold-change computation.
- Exclude rows where STRESN ≤ 0 or BASELINE_VALUE ≤ 0.
- Replace NULL means/SDs with 0 using COALESCE.
- Never guess table or column names — use only those in schema.
- Always order final results by analyte and time (or response group).
- Return clean, executable Databricks SQL — not pseudo-code.
- If a user specifies another study (e.g., AMG160), update table names accordingly.

----------------------------------------------------------------
🧠 INTENT HANDLING
----------------------------------------------------------------
If the user asks for:
  "cytokine fold-change vs baseline" → Use Use Case 1 query logic.
  "responder vs non-responder" → Use Use Case 2 query logic.

If unsure, ask which type of forest plot they want.

----------------------------------------------------------------
💡 OUTPUT FORMAT
----------------------------------------------------------------
Output **only** the Databricks SQL code block. No Python or commentary.
The SQL should be runnable directly in Databricks SQL editor.
"""


# COMMAND ----------

# MAGIC %md
# MAGIC **Forest Plot Agent**

# COMMAND ----------

from pyspark.sql import SparkSession
import pandas as pd
import matplotlib.pyplot as plt
import re
import seaborn as sns

# LangChain ChatDatabricks integration
from langchain_community.chat_models import ChatDatabricks
#from langchain.schema import SystemMessage, HumanMessage
from langchain_core.messages import HumanMessage, SystemMessage

# Initialize Spark
spark = SparkSession.builder.getOrCreate()
ENDPOINT = "project-115-Precision_Medicine_AI_Agent-2"

# Initialize ChatDatabricks model
# You can replace model with your chosen Databricks-hosted LLM, e.g. llama3 or mixtral
llm = ChatDatabricks(
    endpoint = ENDPOINT,  # or your registered model name
    temperature=0,
    max_tokens=1500
)

# COMMAND ----------

# ---------------------------------------------------------------------
# 2. Unity Catalog mapping (study → table names)
# ---------------------------------------------------------------------
STUDY_TABLES = {
    "AMG160": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_cb",
    },
    "AMG330": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb",
    },
    "AMG427": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_cb",
    },
    "AMG673": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg673_20160377_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg673_20160377_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg673_20160377_ne_cb",
    },
    "AMG701": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb",
    },
}


# ---------------------------------------------------------------------
# 3. Extract study name from user query
# ---------------------------------------------------------------------
def extract_study_from_query1(natural_query: str) -> str:
    match = re.search(r"AMG\\s?\\d+", natural_query.upper())
    if match:
        return match.group(0).replace(" ", "")
    raise ValueError("Could not detect study name (e.g., AMG160, AMG330) from query.")

STUDY_ALIASES = {
    "xaluritamig": "AMG509",
    "tarlatamab": "AMG757",
    "amg 509": "AMG509",
    "amg 757": "AMG757",
    "amg160": "AMG160",
    "amg 160": "AMG160",
    "amg330": "AMG330",
    "amg 330": "AMG330",
    "amg427": "AMG427",
    "amg 427": "AMG427",
    "amg673": "AMG673",
    "amg 673": "AMG673",
    "amg701": "AMG701",
    "amg 701": "AMG701",
}

def extract_study_from_query(natural_query: str) -> str:
    """
    Extract study identifier (AMG code) from user query.
    Supports both numeric codes (e.g., AMG160) and aliases (e.g., tarlatamab).
    """
    q_lower = natural_query.lower()

    # 1️⃣ Try to detect AMG### pattern
    match = re.search(r"amg\\s?\\d+", q_lower)
    if match:
        return match.group(0).replace(" ", "").upper()

    # 2️⃣ Try to detect known alias name (e.g., "tarlatamab")
    for alias, amg_code in STUDY_ALIASES.items():
        if alias in q_lower:
            return amg_code

    # 3️⃣ If not found, raise clear, user-friendly error
    raise ValueError(
        f"❌ Could not detect a study name or alias from the query: '{natural_query}'.\n"
        f"Please include a molecule name (e.g., 'AMG160') or known alias "
        f"({', '.join(sorted(set(STUDY_ALIASES.keys()) - set(['amg 160','amg160'])))})"
    )


# COMMAND ----------

# ---------------------------------------------------------------------
# 4. Generate SQL query using ChatDatabricks
# ---------------------------------------------------------------------
def generate_sql_with_chatdatabricks(natural_query: str, study: str) -> str:
    if study not in STUDY_TABLES:
        raise ValueError(f"No table mapping found for study {study}")
    
    tables = STUDY_TABLES[study]

    user_prompt = f"""
    Natural language query:
    \"\"\"{natural_query}\"\"\"
    Generate only the SQL query that can be executed in Databricks.
    """


    system_prompt = """
    You are an expert clinical data reasoning agent specialized in querying biomarker datasets in Databricks SQL 
    to support biostatistical visualizations such as forest plots. You understand normalized clinical datasets used in 
    Amgen BiTE trials (e.g., AMG160, AMG330, AMG701, etc.), where cytokine and biomarker data are stored in 
    tables named like `edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb`.

    Your job: When the user describes an analysis (e.g., “generate a forest plot comparing cytokine fold-change estimates 
    across multiple post-dose timepoints vs pre-dose baseline for the AMG330 study”), you must generate 
    a **Databricks SQL query** that retrieves the summarized data needed for visualization. 

    Your query must:
    1. Correctly reference the biomarker data layer: `edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb`.
    2. Use the proper columns:
    - `SUBJID`: subject identifier
    - `ANALYTE`: cytokine name
    - `STRESN`: numeric cytokine concentration
    - `study_time`: numeric sampling time relative to dose (negative = pre-dose)
    3. Compute **log2 fold-change** of post-dose vs pre-dose baseline:
    - Use baseline as the mean STRESN per subject and analyte where `study_time < 0`.
    - Join to all post-dose (`study_time > 0`) rows for the same subject and analyte.
    - Compute `log2(cb.STRESN / b.baseline_value)` as `log2_fc`.
    4. Aggregate results:
    - Round study_time into 6-hour bins: `ROUND(cb.study_time / 6) * 6`.
    - Calculate `AVG(log2_fc)` as `mean_log2_fc` and `STDDEV(log2_fc)` as `sd_log2_fc`.
    - Group by `ANALYTE` and `study_time_6hr`.
    - Filter to cytokines of interest: `('IL-6', 'IL-10', 'IL-8', 'MCP-1', 'TNF-a', 'IFN-Gamma')`.
    5. Return results ordered by analyte and time.

    Expected SQL Output Template:
    ------------------------------------------------------------
    WITH baseline AS (
        SELECT SUBJID, analyte, AVG(STRESN) AS baseline_value
        FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb
        WHERE study_time < 0 AND STRESN > 0
        GROUP BY SUBJID, analyte
    ),
    summarized AS (
        SELECT cb.analyte,
            ROUND(cb.study_time / 6) * 6 AS study_time_6hr,
            log2(cb.STRESN / b.baseline_value) AS log2_fc
        FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb cb
        JOIN baseline b
        ON cb.SUBJID = b.SUBJID AND cb.analyte = b.analyte
        WHERE cb.study_time > 0 AND cb.STRESN > 0 AND b.baseline_value > 0
        AND cb.analyte IN ('IL-6', 'IL-10', 'IL-8', 'MCP-1', 'TNF-a', 'IFN-Gamma')
    )
    SELECT analyte,
        study_time_6hr,
        COALESCE(AVG(log2_fc), 0) AS mean_log2_fc,
        COALESCE(STDDEV(log2_fc), 0) AS sd_log2_fc
    FROM summarized
    GROUP BY analyte, study_time_6hr
    ORDER BY analyte, study_time_6hr;
    ------------------------------------------------------------

    Rules:
    - Always use safe SQL that can run in Databricks without dynamic typing issues.
    - Replace missing values (`NULL`) with `0` using COALESCE.
    - Never hallucinate table or column names; use only those above.
    - Do not add visualization code; output SQL only.

    When the user asks for a “forest plot,” “fold-change,” “baseline,” or “cytokine kinetics,” generate this query logic.
    When the user references another study (e.g., AMG160), adapt only the table name.
    """
    system_prompt = """
    You are a clinical data reasoning assistant and expert Databricks SQL generator specializing in
    Amgen BiTE (Bispecific T-cell Engager) biomarker datasets. Your task is to produce Databricks SQL
    queries that generate datasets for *forest plot visualizations* from Amgen’s BiTE clinical studies.

    ----------------------------------------------------------------
    📘 DATABASE CONTEXT
    ----------------------------------------------------------------
    All data are stored in schema:
    edl_prd.cdh_bite_prd_publish

    Each study has its own table family (suffix = _ne_*):
    - *_adsl → subject-level demographics & response data
    - *_cb   → cytokine / biomarker concentration data
    - *_ae   → adverse events
    - *_ex   → exposure (dosing)
    - *_ngs  → sequencing data
    - *_rna  → transcriptomic data

    ----------------------------------------------------------------
    📘 COMMON FIELD DEFINITIONS
    ----------------------------------------------------------------
    Across these tables, typical columns include:
    - SUBJID: unique subject identifier
    - ANALYTE or TARGET: biomarker/cytokine name
    - STRESN: numeric concentration value
    - STUDY_TIME or VISITDY or STUDY_DAY: time since dosing (hours or days)
    - BASEFL: baseline flag (Y/N)
    - BEST_RESPONSE or OVERALL_RESPONSE: best overall clinical outcome (CR, PR, SD, PD)

    ----------------------------------------------------------------
    🎯 PRIMARY TASKS (TWO CORE USE CASES)
    ----------------------------------------------------------------

    ### 🧩 Use Case 1 — Cytokine Fold-Change vs. Time (e.g., AMG330)
    Generate a SQL query that computes log₂ fold-changes in cytokine levels across post-dose
    timepoints compared to pre-dose baseline for a given study (e.g., AMG330).

    Required logic:
    1. Identify baseline as mean(STRESN) where STUDY_TIME < 0 or BASEFL = 'Y' for each (SUBJID, ANALYTE).
    2. Compute log₂ fold-change at each post-dose timepoint:
    log2_fc = LOG2(cb.STRESN / b.BASELINE_VALUE)
    3. Round study_time to nearest 6-hour bin: ROUND(cb.STUDY_TIME / 6) * 6 AS STUDY_TIME_6HR
    4. Aggregate across subjects:
    - mean_log2_fc = AVG(log2_fc)
    - sd_log2_fc   = STDDEV(log2_fc)
    5. Filter to key cytokines (e.g., 'IL-6', 'IL-10', 'IL-8', 'MCP-1', 'TNF-a', 'IFN-Gamma').
    6. Order by ANALYTE and STUDY_TIME_6HR.

    ✅ Expected SQL structure:
    -------------------------------------------------------------
    WITH baseline AS (
        SELECT SUBJID, ANALYTE, AVG(STRESN) AS BASELINE_VALUE
        FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb
        WHERE STRESN > 0 AND (STUDY_TIME < 0 OR BASEFL = 'Y')
        GROUP BY SUBJID, ANALYTE
    ),
    summarized AS (
        SELECT
            cb.ANALYTE,
            ROUND(cb.STUDY_TIME / 6) * 6 AS STUDY_TIME_6HR,
            LOG2(cb.STRESN / b.BASELINE_VALUE) AS log2_fc
        FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb cb
        JOIN baseline b
        ON cb.SUBJID = b.SUBJID AND cb.ANALYTE = b.ANALYTE
        WHERE cb.STRESN > 0 AND b.BASELINE_VALUE > 0
        AND cb.ANALYTE IN ('IL-6','IL-10','IL-8','MCP-1','TNF-a','IFN-Gamma')
    )
    SELECT
        ANALYTE,
        STUDY_TIME_6HR,
        COALESCE(AVG(log2_fc), 0) AS mean_log2_fc,
        COALESCE(STDDEV(log2_fc), 0) AS sd_log2_fc
    FROM summarized
    GROUP BY ANALYTE, STUDY_TIME_6HR
    ORDER BY ANALYTE, STUDY_TIME_6HR;
    -------------------------------------------------------------

    ------------------------------------------------------------
    ### 🧩 Use Case 2 — Responder vs Non-Responder Comparison (e.g., AMG701)
    Generate a SQL query comparing biomarker log₂ fold-changes between
    Responders (CR/PR) and Non-Responders (SD/PD) based on subject clinical outcome.

    Required logic:
    1. Define response groups from ADSL:
    - Responder if BEST_RESPONSE IN ('CR','PR')
    - Non-Responder if BEST_RESPONSE IN ('SD','PD')
    2. Compute subject-level baseline (mean(STRESN) per analyte where STUDY_TIME < 0 or BASEFL = 'Y').
    3. Join biomarker data (CB) with response labels (ADSL).
    4. Compute:
    log2_fc = LOG2(cb.STRESN / b.BASELINE_VALUE)
    5. Aggregate across subjects by (ANALYTE, RESPONSE_GROUP):
    - mean_log2_fc = AVG(log2_fc)
    - sd_log2_fc   = STDDEV(log2_fc)

    ✅ Expected SQL structure:
    -------------------------------------------------------------
    WITH baseline AS (
        SELECT SUBJID, ANALYTE, AVG(STRESN) AS BASELINE_VALUE
        FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb
        WHERE STRESN > 0 AND (STUDY_TIME < 0 OR BASEFL = 'Y')
        GROUP BY SUBJID, ANALYTE
    ),
    response_groups AS (
        SELECT
            SUBJID,
            CASE
                WHEN BEST_RESPONSE IN ('CR','PR') THEN 'Responder'
                WHEN BEST_RESPONSE IN ('SD','PD') THEN 'Non-Responder'
            END AS RESPONSE_GROUP
        FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl
        WHERE BEST_RESPONSE IN ('CR','PR','SD','PD')
    ),
    joined AS (
        SELECT
            cb.ANALYTE,
            r.RESPONSE_GROUP,
            LOG2(cb.STRESN / b.BASELINE_VALUE) AS log2_fc
        FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb cb
        JOIN baseline b
        ON cb.SUBJID = b.SUBJID AND cb.ANALYTE = b.ANALYTE
        JOIN response_groups r
        ON cb.SUBJID = r.SUBJID
        WHERE cb.STRESN > 0 AND b.BASELINE_VALUE > 0 AND r.RESPONSE_GROUP IS NOT NULL
    )
    SELECT
        ANALYTE,
        RESPONSE_GROUP,
        COALESCE(AVG(log2_fc), 0) AS mean_log2_fc,
        COALESCE(STDDEV(log2_fc), 0) AS sd_log2_fc
    FROM joined
    GROUP BY ANALYTE, RESPONSE_GROUP
    ORDER BY ANALYTE, RESPONSE_GROUP;
    -------------------------------------------------------------

    ----------------------------------------------------------------
    ⚙️ GENERAL SQL RULES
    ----------------------------------------------------------------
    - Always use LOG2 for fold-change computation.
    - Exclude rows where STRESN ≤ 0 or BASELINE_VALUE ≤ 0.
    - Replace NULL means/SDs with 0 using COALESCE.
    - Never guess table or column names — use only those in schema.
    - Always order final results by analyte and time (or response group).
    - Return clean, executable Databricks SQL — not pseudo-code.
    - If a user specifies another study (e.g., AMG160), update table names accordingly.

    ----------------------------------------------------------------
    🧠 INTENT HANDLING
    ----------------------------------------------------------------
    If the user asks for:
    "cytokine fold-change vs baseline" → Use Use Case 1 query logic.
    "responder vs non-responder" → Use Use Case 2 query logic.

    If unsure, ask which type of forest plot they want.

    ----------------------------------------------------------------
    💡 OUTPUT FORMAT
    ----------------------------------------------------------------
    Output **only** the Databricks SQL code block. No Python or commentary.
    The SQL should be runnable directly in Databricks SQL editor.
    """



    response = llm.invoke([
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt)
    ])

    sql = response.content.strip()

    #if not (sql.lower().startswith("select") or sql.lower().startswith("with")):
    #    raise ValueError("ChatDatabricks did not return a valid SQL query:\n" + sql)

    return sql

# COMMAND ----------

# ---------------------------------------------------------------------
# 5. Execute SQL on Databricks and collect data
# ---------------------------------------------------------------------
def run_sql_and_collect(sql: str) -> pd.DataFrame:
    print("Running generated SQL on Databricks...")
    df_spark = spark.sql(sql)
    df = df_spark.toPandas()
    print(f"✅ Retrieved {len(df)} rows")
    return df


# ---------------------------------------------------------------------
# 6. Render forest plot
# ---------------------------------------------------------------------
def plot_forest(df: pd.DataFrame,
                subgroup_col: str = "SUBGROUP",
                effect_col: str = "RISK_DIFFERENCE",
                lower_col: str = None,
                upper_col: str = None):
    plt.figure(figsize=(8, 6))
    y_labels = df[subgroup_col]
    y_pos = range(len(df))

    if lower_col and upper_col and lower_col in df and upper_col in df:
        plt.errorbar(
            df[effect_col],
            y_pos,
            xerr=[df[effect_col] - df[lower_col], df[upper_col] - df[effect_col]],
            fmt="o",
            color="black",
            ecolor="gray",
            elinewidth=1,
            capsize=3,
        )
    else:
        plt.plot(df[effect_col], y_pos, "o", color="black")

    plt.yticks(y_pos, y_labels)
    plt.axvline(x=0, color="red", linestyle="--", alpha=0.7)
    plt.xlabel("Risk Difference (Treatment - Control)")
    plt.title("Forest Plot: TEAE Risk Differences by Subgroup")
    plt.grid(True, linestyle=":", linewidth=0.5)
    plt.tight_layout()
    plt.show()


# COMMAND ----------

natural_query = "Generate a forest plot summarizing the treatment-emergent adverse event (TEAE) risk differences across demographic subgroups (e.g., sex and age) for the AMG160 study"

natural_query = "Generate a forest plot comparing cytokine fold-change estimates across multiple post-dose timepoints versus pre-dose baseline for the AMG330 study"

natural_query = "Generate a SQL query comparing biomarker log₂ fold-changes between Responders (CR/PR) and Non-Responders (SD/PD) based on subject clinical outcome in AMG701."

# Step 1: Detect study
study = extract_study_from_query(natural_query)
print(f"Detected study: {study}")

# Step 2: Generate SQL using ChatDatabricks
sql_query = generate_sql_with_chatdatabricks(natural_query, study)
print("Generated SQL:")
print(sql_query)

# COMMAND ----------

sql_query= """
WITH baseline AS (
    SELECT SUBJID, ANALYTE, AVG(STRESN) AS BASELINE_VALUE
    FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb
    WHERE STRESN > 0 AND (STUDY_TIME < 0 OR BASEFL = 'Y')
    GROUP BY SUBJID, ANALYTE
),
response_groups AS (
    SELECT
        SUBJID,
        CASE
            WHEN BEST_RESPONSE IN ('CR','PR') THEN 'Responder'
            WHEN BEST_RESPONSE IN ('SD','PD') THEN 'Non-Responder'
        END AS RESPONSE_GROUP
    FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl
    WHERE BEST_RESPONSE IN ('CR','PR','SD','PD')
),
joined AS (
    SELECT
        cb.ANALYTE,
        r.RESPONSE_GROUP,
        LOG2(cb.STRESN / b.BASELINE_VALUE) AS log2_fc
    FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb cb
    JOIN baseline b
    ON cb.SUBJID = b.SUBJID AND cb.ANALYTE = b.ANALYTE
    JOIN response_groups r
    ON cb.SUBJID = r.SUBJID
    WHERE cb.STRESN > 0 AND b.BASELINE_VALUE > 0 AND r.RESPONSE_GROUP IS NOT NULL
)
SELECT
    ANALYTE,
    RESPONSE_GROUP,
    COALESCE(AVG(log2_fc), 0) AS mean_log2_fc,
    COALESCE(STDDEV(log2_fc), 0) AS sd_log2_fc
FROM joined
GROUP BY ANALYTE, RESPONSE_GROUP
ORDER BY ANALYTE, RESPONSE_GROUP;
"""

# COMMAND ----------

dff = run_sql_and_collect(sql_query)

# COMMAND ----------

dff.head(6)