"""
Databricks Catalog Browser (ipywidgets)

A reusable Python module that spins up an interactive Unity Catalog explorer inside a Databricks notebook.

Quick start (**notebook cell**):

```python
# (1) Ensure the script is on DBFS or workspace, then load it
%run ./databricks_catalog_browser.py  # path may vary

# (2) Launch the UI
import databricks_catalog_browser as dcb

dcb.launch_catalog_browser()  # optional: default_limit=50
```

Features
--------
* Navigate **catalog → schema → table** via dropdowns.
* Select **multiple tables** at once.
* **Ad‑hoc SQL textarea**: write any query.
* Adjustable **row‑limit control**.
* Results shown inline with `display()`.

Requirements: Databricks Runtime 14.x + and `ipywidgets` (pre‑installed on DBR 14 +). Works in classic and Jupyter‑compatible Databricks notebooks.
"""
from __future__ import annotations
import pandas as pd
import ipywidgets as widgets
from IPython.display import display, clear_output, Markdown, HTML
import os
import pandas as pd
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from langchain_experimental.agents import create_pandas_dataframe_agent

import plotly.graph_objects as go #To uPse the Plotly library to create the graph
import plotly.express as px #To use the Plotly Express library to create the graph
import seaborn as sns
import statsmodels.api as sm
import statsmodels.formula.api as smf
import ipywidgets as widgets
from IPython.display import display, clear_output
from pyspark.sql import SparkSession
from types import SimpleNamespace
import io
import os
import base64


__all__ = ["launch_catalog_browser"]

#-------------------------------------------------------------
# Global variables



LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

# Initialize shared state using SimpleNamespace
state = SimpleNamespace()
state.llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)
state.agent = None
state.df = None
#-------------------------------------------------------------

# -----------------------------------------------------------------------------
# Spark session helper                                                          
# -----------------------------------------------------------------------------

def _spark() -> SparkSession:
    """Get (or create) the active SparkSession."""
    return SparkSession.builder.getOrCreate()


# -----------------------------------------------------------------------------
# Metadata fetchers                                                             
# -----------------------------------------------------------------------------

def _list_catalogs() -> list[str]:
    return [r.catalog for r in _spark().sql("SHOW CATALOGS").collect()]


def _list_schemas(catalog: str) -> list[str]:
    return [r.databaseName for r in _spark().sql(f"SHOW SCHEMAS IN `{catalog}`").collect()]


def _list_tables(catalog: str, schema: str) -> list[str]:
    rows = _spark().sql(f"SHOW TABLES IN `{catalog}`.`{schema}`").collect()
    return [r.tableName for r in rows]


# -----------------------------------------------------------------------------
# UI builder                                                                    
# -----------------------------------------------------------------------------

def _build_ui(default_limit: int = 20) -> widgets.VBox:
    """Create and wire up ipywidgets components."""

    # --- widgets ---
    analysis_button = widgets.Button(
        description="Survival - Cox - Linear Mixed Model",
        disabled=True,
        button_style = 'primary',
        layout=widgets.Layout(width='90%', height='80px'),
        style=widgets.ButtonStyle(button_color='blue', text_color = 'black', font_weight='bold')
    )
    catalog_dd = widgets.Dropdown(options=_list_catalogs(), description="Catalog:", layout=widgets.Layout(width="300px"))
    schema_dd = widgets.Dropdown(options=[], description="Schema:", layout=widgets.Layout(width="300px"))
    table_sel = widgets.SelectMultiple(options=[], description="Tables:", rows=8, layout=widgets.Layout(width="300px"))
    limit_int = widgets.BoundedIntText(value=default_limit, min=1, max=10000, description="Rows:", layout=widgets.Layout(width="200px"))
    run_btn = widgets.Button(description="Run Query", button_style="success")
    sql_box = widgets.Textarea(placeholder="Or write your own SQL here …", 
                               description="SQL:", 
                               layout=widgets.Layout(width="600px", height="120px"))
    upload_widget = widgets.FileUpload(
        accept='.csv', multiple=False, description='Upload CSV', layout = widgets.Layout(width='90%', height='80px')
    )
    submit_button = widgets.Button(
        description='Chat', 
        button_style='success', 
        layout = widgets.Layout(width='90%', height='80px')
    )
    out = widgets.Output()

    # --- callbacks ---
    def _on_catalog(change):
        catalog = change["new"]
        schema_dd.options = _list_schemas(catalog)
        if schema_dd.options:
            schema_dd.value = schema_dd.options[0]

    def _on_schema(change):
        catalog = catalog_dd.value
        schema = change["new"]
        table_sel.options = _list_tables(catalog, schema)

    def _run_query(_):
        with out:
            clear_output()
            sql = sql_box.value.strip()
            if not sql:
                if not table_sel.value:
                    print("⚠️ Select at least one table or type custom SQL.")
                    return
                refs = [f"{catalog_dd.value}.{schema_dd.value}.{t}" for t in table_sel.value]
                sql = "SELECT * FROM " + ", ".join(refs) + f" LIMIT {limit_int.value}"
            print("Executing:\n", sql)
            try:
                pdf = _spark().sql(sql).limit(limit_int.value).toPandas()
                state.df = pdf
                display(pdf)

                # Create the agent
                state.agent = create_pandas_dataframe_agent(state.llm, 
                                                            state.df, 
                                                            verbose=True,
                                                            handle_parsing_errors = True,
                                                            allow_dangerous_code=True )
            except Exception as exc:
                print("Query failed:", exc)

    # Upload handler
    def _handle_upload(change):
        out.clear_output()
        if upload_widget.value:
            uploaded_filename = list(upload_widget.value.keys())[0]
            uploaded_bytes = upload_widget.value[uploaded_filename]['content']
            state.df = pd.read_csv(io.BytesIO(uploaded_bytes))

            with out:
                print(f"✅ Successfully loaded: {uploaded_filename}")
                display(state.df.head())

            # Create the agent
            state.agent = create_pandas_dataframe_agent(state.llm, 
                                                        state.df, 
                                                        verbose=True,
                                                        handle_parsing_errors = True,
                                                        allow_dangerous_code=True )
    

    # Submit handler
    def on_submit_click(b):
        out.clear_output()

        if state.agent is None:
            with out:
                print("⚠️ Please upload a CSV file first.")
            return
        
        query = sql_box.value.strip()
        if not query:
            with out:
                print("⚠️ Please enter a query about the dataset.")
            return

        try:
            with out:
                print("🤖 Querying the dataset...\n")
                response = state.agent.invoke(query)
                print(response['output'])
        except Exception as e:
            with out:
                print("❌ Error while processing:", str(e))

    

    

    # wire observers
    catalog_dd.observe(_on_catalog, names="value")
    schema_dd.observe(_on_schema, names="value")
    run_btn.on_click(_run_query)
    upload_widget.observe(_handle_upload, names='value')
    submit_button.on_click(on_submit_click)

    # initial populate
    _on_catalog({"new": catalog_dd.value})

    # layout
    return widgets.VBox([
        widgets.HBox([analysis_button]),
        widgets.HBox([upload_widget]),
        widgets.HBox([catalog_dd, schema_dd]),
        widgets.HBox([table_sel, widgets.VBox([limit_int, run_btn])]),
        sql_box,
        #widgets.HBox([upload_widget]),
        widgets.HBox([submit_button]),
        out,
    ])


# -----------------------------------------------------------------------------
# Public API                                                                    
# -----------------------------------------------------------------------------

def launch_catalog_browser(default_limit: int = 2) -> None:
    """Display the catalog/table explorer in the current notebook cell."""
    display(_build_ui(default_limit))


# -----------------------------------------------------------------------------
# Script entry‑point                                                            
# -----------------------------------------------------------------------------

if __name__ == "__main__":
    launch_catalog_browser()