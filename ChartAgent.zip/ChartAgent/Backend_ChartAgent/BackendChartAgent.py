# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------

# MAGIC %pip install -U -qqq mlflow langgraph==0.3.4 langchain-experimental==0.3.4 plotly==5.24.1  langchain_community databricks-langchain databricks-agents matplotlib lifelines langchain-openai plotnine statsmodels
# MAGIC
# MAGIC dbutils.library.restartPython()

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

import app as dcb
dcb.launch_catalog_browser()