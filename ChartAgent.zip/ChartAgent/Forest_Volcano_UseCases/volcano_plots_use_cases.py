# Databricks notebook source
# MAGIC %pip install langchain databricks-sql-connector langgraph==0.3.4 langchain-openai==0.3.0 langchain-experimental==0.3.4 databricks-langchain databricks-agents databricks-vectorsearch databricks-connect databricks-sql-connector

# COMMAND ----------

# MAGIC %pip install langchain-openai langchain-community

# COMMAND ----------

# MAGIC %pip install langchain langchain-core langchain-openai

# COMMAND ----------

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

# COMMAND ----------

# MAGIC %md
# MAGIC **PROMPT NOTE:**
# MAGIC
# MAGIC Estimate p-values based only on fold change magnitude that is the negative log 10 p-value. 
# MAGIC Use this expression to compute the pseudo p-values: 1 - EXP(-ABS(log fold change)) 

# COMMAND ----------

# MAGIC %md
# MAGIC **Use Case 1:** 
# MAGIC
# MAGIC _**version 1**_
# MAGIC
# MAGIC “Generate a volcano plot dataset for AMG160 using data from the table
# MAGIC edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_protein.
# MAGIC
# MAGIC Compare Cycle 2 Day 1 Pre-dose (C2D1PRE) versus Cycle 1 Day 1 Pre-dose (C1D1PRE) proteomic measurements across subjects to identify treatment-related protein changes.
# MAGIC Use this expression to compute the pseudo p-values: 1 - EXP(-ABS(log fold change)) and estimate its neg log p values"

# COMMAND ----------

# Create volcano dataset for AMG160 proteomics (C2D1PRE vs C1D1PRE)
df = spark.sql("""
WITH baseline AS (
    SELECT SUBJID, ANALYTE, STRESN AS BASE_VALUE
    FROM edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_protein
    WHERE VISITRAW = 'C1D1PRE'
),
postdose AS (
    SELECT SUBJID, ANALYTE, STRESN AS POST_VALUE
    FROM edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_protein
    WHERE VISITRAW = 'C2D1PRE'
),
fc AS (
    SELECT 
        b.ANALYTE,
        LOG2(AVG(p.POST_VALUE) / AVG(b.BASE_VALUE)) AS LOG2_FOLD_CHANGE,
        1 - EXP(-ABS(LOG2(AVG(p.POST_VALUE)/AVG(b.BASE_VALUE)))) AS P_VALUE
    FROM baseline b
    JOIN postdose p ON b.SUBJID = p.SUBJID AND b.ANALYTE = p.ANALYTE
    GROUP BY b.ANALYTE
)
SELECT 
    ANALYTE,
    LOG2_FOLD_CHANGE,
    -LOG10(P_VALUE) AS NEG_LOG10_PVAL,
    CASE 
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE > 0.58 THEN 'Increased'
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE < -0.58 THEN 'Decreased'
        ELSE 'No Change'
    END AS SIGNIFICANCE
FROM fc
""").toPandas()

plt.figure(figsize=(8,6))
plt.scatter(df["LOG2_FOLD_CHANGE"], df["NEG_LOG10_PVAL"], c="gray", alpha=0.6)
plt.title("Volcano Plot")
plt.xlabel("Log2 Fold Change")
plt.ylabel("-Log10(P-Value)")
plt.grid(True, linestyle="--", alpha=0.5)
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC **Use Case 2:** 
# MAGIC
# MAGIC _**version 1**_
# MAGIC
# MAGIC “Generate a volcano plot dataset for the AMG330 study using cytokine biomarker data from
# MAGIC edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb.
# MAGIC
# MAGIC Compare Cycle 1 Day 1 Pre-dose (C1D1PRE) versus Cycle 1 Day 1 6 hours post-dose (C1D1HR6) cytokine levels to identify early pharmacodynamic changes."

# COMMAND ----------

# MAGIC %md
# MAGIC _**version 2**_
# MAGIC
# MAGIC Generate a volcano plot dataset for the AMG330 study using cytokine biomarker data from edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb.
# MAGIC
# MAGIC Compare Cycle 1 Day 1 Pre-dose ('C1D1PRE', 'C1D1 Pre', 
# MAGIC                        'GRP 1 C1D1 PRE CYTOKINE', 
# MAGIC                        'GRP 2 C1D1 PRE CYTOKINE', 
# MAGIC                        'GRP 3 DS D1 PRE CYTOKINE', 
# MAGIC                        'GRP 4 DS D1 PRE CYTOKINE') 
# MAGIC                        
# MAGIC   versus Cycle 1 Day 1 6 hours post-dose ('C1D1HR6', 'C1D1 6 hour', 
# MAGIC                        'GRP 1 C1D1 6H CYTOKINE', 
# MAGIC                        'GRP 2 C1D1 6H CYTOKINE', 
# MAGIC                        'GRP 3 DS D1 6H CYTOKINE', 
# MAGIC                        'GRP 4 DS D1 6H CYTOKINE') cytokine levels to identify early pharmacodynamic changes.

# COMMAND ----------

spark.sql("""
CREATE OR REPLACE TABLE edl_dev.cbd_sandbox.amg330_cb_volcano AS
WITH baseline AS (
    SELECT SUBJID, ANALYTE, STRESN AS BASE_VALUE
    FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb
    WHERE VISITRAW IN ('C1D1PRE', 'C1D1 Pre', 
                       'GRP 1 C1D1 PRE CYTOKINE', 
                       'GRP 2 C1D1 PRE CYTOKINE', 
                       'GRP 3 DS D1 PRE CYTOKINE', 
                       'GRP 4 DS D1 PRE CYTOKINE')
),
postdose AS (
    SELECT SUBJID, ANALYTE, STRESN AS POST_VALUE
    FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb
    WHERE VISITRAW IN ('C1D1HR6', 'C1D1 6 hour', 
                       'GRP 1 C1D1 6H CYTOKINE', 
                       'GRP 2 C1D1 6H CYTOKINE', 
                       'GRP 3 DS D1 6H CYTOKINE', 
                       'GRP 4 DS D1 6H CYTOKINE')
),
fc AS (
    SELECT 
        b.ANALYTE,
        LOG2(AVG(p.POST_VALUE) / AVG(b.BASE_VALUE)) AS LOG2_FOLD_CHANGE,
        1 - EXP(-ABS(LOG2(AVG(p.POST_VALUE)/AVG(b.BASE_VALUE)))) AS P_VALUE
    FROM baseline b
    JOIN postdose p 
      ON b.SUBJID = p.SUBJID 
     AND b.ANALYTE = p.ANALYTE
    GROUP BY b.ANALYTE
)
SELECT 
    ANALYTE,
    LOG2_FOLD_CHANGE,
    -LOG10(P_VALUE) AS NEG_LOG10_PVAL,
    CASE 
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE > 1 THEN 'Increased'
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE < -1 THEN 'Decreased'
        ELSE 'No Change'
    END AS SIGNIFICANCE
FROM fc;

""")


# COMMAND ----------

import pandas as pd
import matplotlib.pyplot as plt

# Replace dataset name accordingly:
df = spark.table("edl_dev.cbd_sandbox.amg330_cb_volcano").toPandas()
print(df.shape)
plt.figure(figsize=(8,6))
plt.scatter(df["LOG2_FOLD_CHANGE"], df["NEG_LOG10_PVAL"], c="gray", alpha=0.6)
plt.title("Volcano Plot")
plt.xlabel("Log2 Fold Change")
plt.ylabel("-Log10(P-Value)")
plt.grid(True, linestyle="--", alpha=0.5)
plt.show()

# COMMAND ----------

df.head()

# COMMAND ----------

# MAGIC %md
# MAGIC **Use Case 3**: 
# MAGIC
# MAGIC Generate a volcano plot dataset for the AMG427 study using ctDNA variant data from
# MAGIC edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_ngs.
# MAGIC
# MAGIC Compare Screening (baseline/SCR) samples versus Cycle 1 Day 14 (on-treatment/C1D14) samples to identify ctDNA variants that expand or contract following treatment exposure.

# COMMAND ----------

df = spark.sql("""
WITH baseline AS (
    SELECT SUBJID, gene, CHROM, POS, REF, ALT, AF AS BASE_AF
    FROM edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_ngs
    WHERE UPPER(VISITRAW) = 'SCR'
),
ontx AS (
    SELECT SUBJID, gene, CHROM, POS, REF, ALT, AF AS ONTX_AF
    FROM edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_ngs
    WHERE UPPER(VISITRAW) = 'C1D14'
),
fc AS (
    SELECT 
        b.gene,
        b.CHROM,
        b.POS,
        b.REF,
        b.ALT,
        LOG2(AVG(o.ONTX_AF) / AVG(b.BASE_AF)) AS LOG2_FOLD_CHANGE,
        1 - EXP(-ABS(LOG2(AVG(o.ONTX_AF)/AVG(b.BASE_AF)))) AS P_VALUE
    FROM baseline b
    JOIN ontx o 
      ON b.SUBJID = o.SUBJID 
     AND b.gene = o.gene 
     AND b.CHROM = o.CHROM 
     AND b.POS = o.POS
     AND b.ALT = o.ALT
    GROUP BY b.gene, b.CHROM, b.POS, b.REF, b.ALT
)
SELECT 
    gene,
    CHROM,
    POS,
    REF,
    ALT,
    LOG2_FOLD_CHANGE,
    -LOG10(P_VALUE) AS NEG_LOG10_PVAL,
    CASE 
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE > 1 THEN 'Expanded'
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE < -1 THEN 'Contracted'
        ELSE 'Stable'
    END AS SIGNIFICANCE
FROM fc
""").toPandas()
#df = df.toPandas()

plt.figure(figsize=(8,6))
plt.scatter(df["LOG2_FOLD_CHANGE"], df["NEG_LOG10_PVAL"], c="gray", alpha=0.6)
plt.title("Volcano Plot")
plt.xlabel("Log2 Fold Change")
plt.ylabel("-Log10(P-Value)")
plt.grid(True, linestyle="--", alpha=0.5)
plt.show()

# COMMAND ----------

df.head()

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC **Use Case 4:** 
# MAGIC
# MAGIC “**Generate a volcano plot dataset comparing biomarker levels between responders and non-responders in the AMG701 study; responders as subjects whose best_response is ‘CR’ or ‘PR’, and non-responders as those with ‘SD’ or ‘PD’.**"
# MAGIC
# MAGIC Use data from the tables:
# MAGIC
# MAGIC edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb (for analyte-level biomarker concentrations), and
# MAGIC
# MAGIC edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl (for clinical subject-level response data).
# MAGIC
# MAGIC Define responders as subjects whose best_response is ‘CR’ or ‘PR’, and non-responders as those with ‘SD’ or ‘PD’.

# COMMAND ----------

spark.conf.set('spark.sql.ansi.enabled', False)

# COMMAND ----------

df = spark.sql("""
SELECT 
    ANALYTE,
    LOG2_FOLD_CHANGE,
    -LOG10(P_VALUE) AS NEG_LOG10_PVAL,
    CASE 
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE > 1 THEN 'Associated with Response'
        WHEN P_VALUE < 0.05 AND LOG2_FOLD_CHANGE < -1 THEN 'Associated with Nonresponse'
        ELSE 'Not Significant'
    END AS SIGNIFICANCE
FROM (
    WITH resp AS (
        SELECT cb.ANALYTE, AVG(cb.STRESN) AS RESP_AVG
        FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb cb
        JOIN edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl adsl
          ON cb.SUBJID = adsl.SUBJID
        WHERE adsl.best_response IN ('CR', 'PR')
        GROUP BY cb.ANALYTE
    ),
    nonresp AS (
        SELECT cb.ANALYTE, AVG(cb.STRESN) AS NONRESP_AVG
        FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb cb
        JOIN edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl adsl
          ON cb.SUBJID = adsl.SUBJID
        WHERE adsl.best_response IN ('SD', 'PD')
        GROUP BY cb.ANALYTE
    ),
    fc AS (
        SELECT 
            r.ANALYTE,
            LOG2(AVG(r.RESP_AVG) / AVG(n.NONRESP_AVG)) AS LOG2_FOLD_CHANGE,
            1 - EXP(-ABS(LOG2(AVG(r.RESP_AVG)/AVG(n.NONRESP_AVG)))) AS P_VALUE
        FROM resp r
        JOIN nonresp n ON r.ANALYTE = n.ANALYTE
        GROUP BY r.ANALYTE
    )
    SELECT * FROM fc
) subquery
""").toPandas()
plt.figure(figsize=(8,6))
plt.scatter(df["LOG2_FOLD_CHANGE"], df["NEG_LOG10_PVAL"], c="gray", alpha=0.6)
plt.title("Volcano Plot – AMG701 Biomarker Associations with Response (CR/PR vs SD/PD)")
plt.xlabel("Log2 Fold Change")
plt.ylabel("-Log10(P-Value)")
plt.grid(True, linestyle="--", alpha=0.5)
plt.show()

# COMMAND ----------

df.head()

# COMMAND ----------

df[df['ANALYTE']=='IFN-Gamma']

# COMMAND ----------

plt.figure(figsize=(9,6))
plt.scatter(df["LOG2_FOLD_CHANGE"], df["NEG_LOG10_PVAL"], color="gray", alpha=0.7, label="Not Significant")

# Add threshold lines
plt.axvline(x=1, color="red", linestyle="--", alpha=0.5, label="|Log2FC|=1")
plt.axvline(x=-1, color="red", linestyle="--", alpha=0.5)
plt.axhline(y=1.3, color="blue", linestyle="--", alpha=0.5, label="p=0.05 (-log10≈1.3)")

# Annotate selected analytes above the p-value threshold
for _, row in df.head(20).iterrows():
    if row["NEG_LOG10_PVAL"] > 2.5 or abs(row["LOG2_FOLD_CHANGE"]) > 0.1:
        plt.text(row["LOG2_FOLD_CHANGE"], row["NEG_LOG10_PVAL"] + 0.05, row["ANALYTE"], fontsize=8)

plt.title("Volcano Plot – AMG701 Biomarker Associations with Response (CR/PR vs SD/PD)")
plt.xlabel("Log2 Fold Change (Responders vs Non-Responders)")
plt.ylabel("-Log10(p-value)")
plt.legend()
plt.grid(alpha=0.3)
plt.show()