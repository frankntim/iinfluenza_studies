# Databricks notebook source
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")

# COMMAND ----------

# MAGIC %md
# MAGIC **Use Case 1:**
# MAGIC

# COMMAND ----------

import pandas as pd

query = """
WITH ae_summary AS (
    SELECT 
        adsl.DOSESEQP AS DOSE_LEVEL,
        ae.AEPT AS AE_TERM,
        COUNT(DISTINCT CASE WHEN ae.AETOXGR >= 3 THEN ae.SUBJID END) AS AE_GTE3,
        COUNT(DISTINCT ae.SUBJID) AS TOTAL_SUBJ
    FROM edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_ae ae
    JOIN edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_adsl adsl
      ON ae.SUBJID = adsl.SUBJID
    GROUP BY adsl.DOSESEQP, ae.AEPT
),
stats AS (
    SELECT 
        AE_TERM,
        DOSE_LEVEL,
        AE_GTE3,
        TOTAL_SUBJ,
        AE_GTE3 / NULLIF(TOTAL_SUBJ, 0) AS EVENT_RATE
    FROM ae_summary
),
ref AS (
    SELECT 
        AE_TERM,
        MIN(DOSE_LEVEL) AS REF_DOSE
    FROM stats
    GROUP BY AE_TERM
),
odds AS (
    SELECT 
        s.AE_TERM,
        s.DOSE_LEVEL,
        s.EVENT_RATE,
        s.TOTAL_SUBJ,
        -- Compute odds safely using small adjustments to avoid zero/one
        CASE 
            WHEN s.DOSE_LEVEL != r.REF_DOSE THEN 
                ((NULLIF(s.EVENT_RATE, 0) + 0.0001) / (1 - LEAST(s.EVENT_RATE, 0.9999))) /
                ((NULLIF(ref_stats.EVENT_RATE, 0) + 0.0001) / (1 - LEAST(ref_stats.EVENT_RATE, 0.9999)))
            ELSE 1 
        END AS ODDS_RATIO
    FROM stats s
    JOIN ref r ON s.AE_TERM = r.AE_TERM
    JOIN stats ref_stats 
      ON ref_stats.AE_TERM = r.AE_TERM 
     AND ref_stats.DOSE_LEVEL = r.REF_DOSE
)
SELECT 
    AE_TERM,
    DOSE_LEVEL,
    EVENT_RATE,
    ODDS_RATIO,
    EXP(LOG(ODDS_RATIO) - 1.96 / NULLIF(SQRT(TOTAL_SUBJ), 0)) AS CI_LOWER,
    EXP(LOG(ODDS_RATIO) + 1.96 / NULLIF(SQRT(TOTAL_SUBJ), 0)) AS CI_UPPER
FROM odds
"""

df = spark.sql(query).toPandas()

# COMMAND ----------

# Databricks Python (PySpark + Matplotlib) Forest Plot for AMG160 Adverse Events
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# ✅ Load data directly from Databricks SQL table
df = spark.sql("""
    SELECT AE_TERM, DOSE_LEVEL, EVENT_RATE, ODDS_RATIO, CI_LOWER, CI_UPPER
    FROM edl_dev.cbd_sandbox.amg160_ae_forest
    WHERE ODDS_RATIO IS NOT NULL
""").toPandas()

# ✅ Keep only the first 10 AE terms (or adjust sample size)
df = df.groupby("AE_TERM").first().reset_index().head(10)

# ✅ Sort by odds ratio
df = df.sort_values("ODDS_RATIO")

# --- Plot setup ---
plt.figure(figsize=(10, 6))
y_positions = np.arange(len(df))

# ✅ Draw odds ratios with 95% CI error bars
plt.errorbar(
    df["ODDS_RATIO"],
    y_positions,
    xerr=[df["ODDS_RATIO"] - df["CI_LOWER"], df["CI_UPPER"] - df["ODDS_RATIO"]],
    fmt='o', color='darkblue', ecolor='gray', elinewidth=3, capsize=4
)

# ✅ Customize labels and style
plt.yticks(y_positions, df["AE_TERM"])
plt.axvline(x=1, color='red', linestyle='--', label='No Difference (OR = 1)')
plt.xlabel("Odds Ratio (95% Confidence Interval)")
plt.ylabel("Adverse Event Term")
plt.title("Forest Plot — AMG160 Adverse Events (Grade ≥3 by Dose Level)")
plt.legend()
plt.grid(alpha=0.3, linestyle='--')
plt.tight_layout()

# ✅ Display plot
plt.show()


# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC **Use Case #2**: Generate a forest plot comparing cytokine fold-change estimates across multiple post-dose timepoints versus pre-dose baseline for the AMG330 study

# COMMAND ----------

# Databricks Python cell
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 1️⃣ Load data from Databricks table
df = spark.sql("""
    SELECT ANALYTE, TIMEPOINT, LOG2_FOLD_CHANGE, CI_LOWER, CI_UPPER
    FROM edl_dev.cbd_sandbox.amg330_cb_forest
    WHERE LOG2_FOLD_CHANGE IS NOT NULL
    ORDER BY ANALYTE, TIMEPOINT
""").toPandas()

# 2️⃣ Clean and subset data
df = df.dropna(subset=["CI_LOWER", "CI_UPPER"])
df = df.sort_values(["ANALYTE", "TIMEPOINT"], ascending=[True, True]).reset_index(drop=True)

# Select only 10 cytokines (first 10 unique analytes alphabetically)
selected_analytes = df["ANALYTE"].unique()[:10]
df = df[df["ANALYTE"].isin(selected_analytes)]

# 3️⃣ Combine analyte + timepoint for y-axis labels
df["LABEL"] = df["ANALYTE"] + " — " + df["TIMEPOINT"]

# 4️⃣ Create the forest plot
plt.figure(figsize=(10, 6))
y_positions = np.arange(len(df))

plt.errorbar(
    df["LOG2_FOLD_CHANGE"],
    y_positions,
    xerr=[df["LOG2_FOLD_CHANGE"] - df["CI_LOWER"], df["CI_UPPER"] - df["LOG2_FOLD_CHANGE"]],
    fmt='o',
    color='darkgreen',
    ecolor='gray',
    elinewidth=3,
    capsize=4,
    label="Mean ± 95% CI"
)

# Add reference line (Log2FC = 0)
plt.axvline(x=0, color='red', linestyle='--', label='No Change (Log2FC = 0)')

# Customize plot
plt.yticks(y_positions, df["LABEL"])
plt.xlabel("Log2 Fold Change (Post vs Pre Baseline)")
plt.ylabel("Cytokine and Timepoint")
plt.title("Forest Plot — AMG330 Cytokine Fold-Change (Top 10 Cytokines)")
plt.legend()
plt.grid(alpha=0.3, linestyle='--')
plt.tight_layout()

# 5️⃣ Display the plot
plt.show()


# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC **Use Case 3:**
# MAGIC
# MAGIC **Generate a forest plot showing the estimated effect sizes (log₂ fold changes) in biomarker levels between responders (CR/PR) and non-responders (SD/PD) in the AMG701 study**

# COMMAND ----------

df = spark.sql("""
WITH resp AS (
    SELECT adsl.SUBJID, cb.ANALYTE, AVG(cb.STRESN) AS RESP_AVG
    FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb cb
    JOIN edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl adsl
      ON cb.SUBJID = adsl.SUBJID
    WHERE adsl.best_response IN ('CR', 'PR')
    GROUP BY adsl.SUBJID, cb.ANALYTE
),
nonresp AS (
    SELECT adsl.SUBJID, cb.ANALYTE, AVG(cb.STRESN) AS NONRESP_AVG
    FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb cb
    JOIN edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl adsl
      ON cb.SUBJID = adsl.SUBJID
    WHERE adsl.best_response IN ('SD', 'PD')
    GROUP BY adsl.SUBJID, cb.ANALYTE
),
fc AS (
    SELECT 
        r.ANALYTE,
        LOG2(try_divide(AVG(r.RESP_AVG), AVG(n.NONRESP_AVG))) AS LOG2_FOLD_CHANGE,
        STDDEV(LOG2(try_divide(r.RESP_AVG, n.NONRESP_AVG))) / SQRT(COUNT(*)) AS SE
    FROM resp r
    JOIN nonresp n 
      ON r.ANALYTE = n.ANALYTE
    GROUP BY r.ANALYTE
)
SELECT 
    ANALYTE,
    LOG2_FOLD_CHANGE,
    LOG2_FOLD_CHANGE - 1.96 * SE AS CI_LOWER,
    LOG2_FOLD_CHANGE + 1.96 * SE AS CI_UPPER
FROM fc
""").toPandas()
df.head()

# COMMAND ----------

# Databricks Python cell
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 1️⃣ Load the live dataset from Databricks
#df = spark.sql("""
#    SELECT ANALYTE, LOG2_FOLD_CHANGE, CI_LOWER, CI_UPPER
#    FROM edl_dev.cbd_sandbox.amg701_cb_forest
#    WHERE LOG2_FOLD_CHANGE IS NOT NULL
#""").toPandas()

# 2️⃣ Handle any missing confidence intervals
df = df.dropna(subset=["CI_LOWER", "CI_UPPER"])

# 3️⃣ Sort by absolute log2 fold change and select top 10 biomarkers
df = df.reindex(df["LOG2_FOLD_CHANGE"].abs().sort_values(ascending=False).index).head(10)

# 4️⃣ Create the forest plot
plt.figure(figsize=(10, 6))
y_positions = np.arange(len(df))

plt.errorbar(
    df["LOG2_FOLD_CHANGE"],
    y_positions,
    xerr=[df["LOG2_FOLD_CHANGE"] - df["CI_LOWER"], df["CI_UPPER"] - df["LOG2_FOLD_CHANGE"]],
    fmt='o',
    color='darkblue',
    ecolor='gray',
    elinewidth=3,
    capsize=4
)

# 5️⃣ Add a reference line for no difference (Log2FC = 0)
plt.axvline(x=0, color='red', linestyle='--', label='No Difference (Log₂FC = 0)')

# 6️⃣ Customize plot labels and style
plt.yticks(y_positions, df["ANALYTE"])
plt.xlabel("Log₂ Fold Change (Responders vs Non-Responders)")
plt.ylabel("Biomarker (Analyte)")
plt.title("Forest Plot — Top 10 AMG701 Biomarkers Associated with Clinical Response (CR/PR vs SD/PD)")
plt.legend()
plt.grid(alpha=0.3, linestyle='--')
plt.tight_layout()

# 7️⃣ Display the plot
plt.show()


# COMMAND ----------

# MAGIC %md
# MAGIC **Use Case 4** 
# MAGIC
# MAGIC Generate a forest plot summarizing the treatment-emergent adverse event (TEAE) risk differences across demographic subgroups (e.g., sex and age) for the AMG160 study.

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE edl_dev.cbd_sandbox.amg160_ae_subgroup_forest AS
# MAGIC WITH base AS (
# MAGIC     SELECT 
# MAGIC         adsl.SUBJID,
# MAGIC         adsl.SEX,
# MAGIC         CASE WHEN adsl.AGE < 65 THEN '<65' ELSE '≥65' END AS AGE_GROUP,
# MAGIC         ae.AEPT,
# MAGIC         MAX(ae.AETOXGR) AS MAX_GRADE
# MAGIC     FROM edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_ae ae
# MAGIC     JOIN edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_adsl adsl
# MAGIC       ON ae.SUBJID = adsl.SUBJID
# MAGIC     GROUP BY adsl.SUBJID, adsl.SEX, adsl.AGE, ae.AEPT
# MAGIC ),
# MAGIC summary AS (
# MAGIC     SELECT 
# MAGIC         AEPT AS AE_TERM,
# MAGIC         'Male vs Female' AS SUBGROUP_COMPARISON,
# MAGIC         SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0) -
# MAGIC         SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0)
# MAGIC         AS RISK_DIFF,
# MAGIC         -- 95% CI for difference in proportions
# MAGIC         ( 
# MAGIC           (SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)) -
# MAGIC           (SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0))
# MAGIC         ) 
# MAGIC         - 1.96 * SQRT(
# MAGIC             ((SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)) * 
# MAGIC             (1 - (SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0))) / 
# MAGIC             NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)) +
# MAGIC             ((SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0)) * 
# MAGIC             (1 - (SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0))) / 
# MAGIC             NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0))
# MAGIC         ) AS CI_LOWER,
# MAGIC         (
# MAGIC           (SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)) -
# MAGIC           (SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0))
# MAGIC         ) 
# MAGIC         + 1.96 * SQRT(
# MAGIC             ((SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)) * 
# MAGIC             (1 - (SUM(CASE WHEN SEX = 'M' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0))) / 
# MAGIC             NULLIF(SUM(CASE WHEN SEX = 'M' THEN 1 ELSE 0 END), 0)) +
# MAGIC             ((SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0)) * 
# MAGIC             (1 - (SUM(CASE WHEN SEX = 'F' AND MAX_GRADE >= 1 THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0))) / 
# MAGIC             NULLIF(SUM(CASE WHEN SEX = 'F' THEN 1 ELSE 0 END), 0))
# MAGIC         ) AS CI_UPPER
# MAGIC     FROM base
# MAGIC     GROUP BY AEPT
# MAGIC )
# MAGIC SELECT * FROM summary;
# MAGIC

# COMMAND ----------

# Databricks Python cell
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 1️⃣ Load the live dataset from Databricks
df = spark.sql("""
    SELECT AE_TERM, SUBGROUP_COMPARISON, RISK_DIFF, CI_LOWER, CI_UPPER
    FROM edl_dev.cbd_sandbox.amg160_ae_subgroup_forest
    WHERE RISK_DIFF IS NOT NULL
""").toPandas()

# 2️⃣ Drop any null values in confidence intervals for clean plotting
df = df.dropna(subset=["CI_LOWER", "CI_UPPER"])

# 3️⃣ Sort by absolute risk difference and select the top 10 adverse events
df = df.reindex(df["RISK_DIFF"].abs().sort_values(ascending=False).index).head(10)

# 4️⃣ Create the forest plot
plt.figure(figsize=(10, 6))
y_positions = np.arange(len(df))

plt.errorbar(
    df["RISK_DIFF"],
    y_positions,
    xerr=[df["RISK_DIFF"] - df["CI_LOWER"], df["CI_UPPER"] - df["RISK_DIFF"]],
    fmt='o',
    color='darkgreen',
    ecolor='gray',
    elinewidth=3,
    capsize=4
)

# 5️⃣ Add a reference line (no difference between groups)
plt.axvline(x=0, color='red', linestyle='--', label='No Difference (Risk Diff = 0)')

# 6️⃣ Customize labels and title
plt.yticks(y_positions, df["AE_TERM"])
plt.xlabel("Risk Difference (Subgroup A - Subgroup B)")
plt.ylabel("Adverse Event Term")
plt.title("Forest Plot — AMG160 Treatment-Emergent Adverse Event Risk Differences\n(Male vs Female, Top 10 AEs)")
plt.legend()
plt.grid(alpha=0.3, linestyle='--')
plt.tight_layout()

# 7️⃣ Display the plot
plt.show()


# COMMAND ----------

df = pd.read_csv('forest_plot_data2.csv')
# 2️⃣ Handle any missing confidence intervals
df = df.dropna(subset=["ci_lower", "ci_UPPER"])

# 3️⃣ Sort by absolute log2 fold change and select top 10 biomarkers
df = df.reindex(df["LOG2_FOLD_CHANGE"].abs().sort_values(ascending=False).index).head(10)

# 4️⃣ Create the forest plot
plt.figure(figsize=(10, 6))
y_positions = np.arange(len(df))

plt.errorbar(
    df["LOG2_FOLD_CHANGE"],
    y_positions,
    xerr=[df["LOG2_FOLD_CHANGE"] - df["CI_LOWER"], df["CI_UPPER"] - df["LOG2_FOLD_CHANGE"]],
    fmt='o',
    color='darkblue',
    ecolor='gray',
    elinewidth=3,
    capsize=4
)

# 5️⃣ Add a reference line for no difference (Log2FC = 0)
plt.axvline(x=0, color='red', linestyle='--', label='No Difference (Log₂FC = 0)')

# 6️⃣ Customize plot labels and style
plt.yticks(y_positions, df["ANALYTE"])
plt.xlabel("Log₂ Fold Change (Responders vs Non-Responders)")
plt.ylabel("Biomarker (Analyte)")
plt.title("Forest Plot — Top 10 AMG701 Biomarkers Associated with Clinical Response (CR/PR vs SD/PD)")
plt.legend()
plt.grid(alpha=0.3, linestyle='--')
plt.tight_layout()

# 7️⃣ Display the plot
plt.show()


# COMMAND ----------

# MAGIC %md
# MAGIC