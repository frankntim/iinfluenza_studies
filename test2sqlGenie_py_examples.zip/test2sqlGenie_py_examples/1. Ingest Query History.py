# Databricks notebook source
# MAGIC %sql
# MAGIC -- Databricks notebook source
# MAGIC -- MAGIC %md
# MAGIC -- MAGIC
# MAGIC -- MAGIC # Unity Catalog Data Ingestion Notebook
# MAGIC -- MAGIC This notebook provides a solution for ingesting table structures and query history from Unity Catalog into a format that can be consumed by LLMs for text-to-SQL applications. By leveraging the power of Unity Catalog metadata and LLMs, customers can enhance their data exploration and analysis capabilities.
# MAGIC -- MAGIC
# MAGIC -- MAGIC ## Overview
# MAGIC -- MAGIC The notebook focuses on two main tasks:
# MAGIC -- MAGIC
# MAGIC -- MAGIC 1. Extracting Table Structures: It retrieves the metadata of tables stored in Unity Catalog, including table names, column names, data types, and other relevant information. This information is crucial for understanding the structure of the data and forming accurate SQL queries.
# MAGIC -- MAGIC 2. Capturing Query History: It captures the historical queries executed on the tables in Unity Catalog. Then it uses AI Functions to extract table names used in each query. Then AI Functions are used to generate synthetic questions and summaries. This will be useful for both the RAG chain and Fine Tuning an LLM later on.
# MAGIC -- MAGIC
# MAGIC -- MAGIC <img src="https://github.com/rmosleydb/text-to-sql/blob/main/_resources/T2S_pipeline_1.png?raw=true" width="800">
# MAGIC -- MAGIC
# MAGIC -- MAGIC ## Conclusion
# MAGIC -- MAGIC By leveraging the power of Unity Catalog and Language and Learning Models (LLMs), this notebook provides a solution for ingesting table structures and query history into a format suitable for text-to-SQL applications. Customers can benefit from improved data exploration, enhanced query generation, and optimized query performance. Follow the usage steps to integrate this notebook into your data analysis workflow and unlock the potential of LLMs for seamless data interaction.
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Setup Schema
# MAGIC use catalog robert_mosley;
# MAGIC create schema if not exists text_to_sql;
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Build a minimum unique name
# MAGIC create or replace table text_to_sql.unique_table as 
# MAGIC with table_set as (
# MAGIC   select t.table_catalog
# MAGIC       , t.table_schema
# MAGIC       , concat(t.table_catalog, ".", t.table_schema, ".", t.table_name) as full_table_name
# MAGIC       , concat(t.table_schema, ".", t.table_name) as schema_table_name
# MAGIC       , t.table_name
# MAGIC       , count(1) over (partition by concat(t.table_schema, ".", t.table_name)) as schema_table_name_count
# MAGIC       , count(1) over (partition by t.table_name) as table_name_count
# MAGIC   from system.information_schema.tables t
# MAGIC )
# MAGIC select full_table_name
# MAGIC   , table_catalog
# MAGIC   , table_schema
# MAGIC   , table_name
# MAGIC   , case when table_name_count = 1 then 'TABLE'
# MAGIC         when schema_table_name_count = 1 then 'SCHEMA' else 'CATALOG' end as unique_level
# MAGIC   , case when table_name_count = 1 then 1
# MAGIC         when schema_table_name_count = 1 then 2 else 3 end as unique_level_nbr
# MAGIC   , case when table_name_count = 1 then table_name
# MAGIC         when schema_table_name_count = 1 then schema_table_name else full_table_name end as unique_table_name
# MAGIC from table_set
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,View Table Uniqueness by Namespace level
# MAGIC select unique_level
# MAGIC   , count(1) as table_cnt 
# MAGIC from text_to_sql.unique_table
# MAGIC group by all
# MAGIC
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- MAGIC %md
# MAGIC -- MAGIC Next we will get a unique set of queries from the query history.
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Retrieve Unique set of Queries from History
# MAGIC create or replace table text_to_sql.query_history_unique
# MAGIC with cte as (
# MAGIC   select statement_id
# MAGIC     , REGEXP_REPLACE(REGEXP_REPLACE(statement_text, '\'([^\']+)\'', '\'{value}\''), '"([^"]+)"', '"{value}"') as statement_text
# MAGIC     , end_time
# MAGIC   from system.query.history
# MAGIC   --from text_to_sql.query_history_api
# MAGIC   where execution_status = 'FINISHED'
# MAGIC     and statement_type = 'SELECT'
# MAGIC )
# MAGIC select distinct first_value(statement_id) over (partition by statement_text order by end_time desc) as statement_id
# MAGIC   , statement_text
# MAGIC from cte
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- MAGIC %md
# MAGIC -- MAGIC Using similarity scores, we analyze subsequent queries from the same user and remove extremely similar queries to eliminate situations where someone may be iterating over a query. If the queries are similar, we take the most recently run version.
# MAGIC -- MAGIC
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Perform a Similarity Check between Executions
# MAGIC create table text_to_sql.query_history_similarity_filter as 
# MAGIC with cte as (
# MAGIC   select h.* 
# MAGIC     , lead(h.end_time) over (partition by warehouse_id, executed_by order by end_time asc) as next_end_time
# MAGIC     , timestampdiff(MINUTE, end_time, lead(h.start_time) over (partition by warehouse_id, executed_by order by end_time asc))/60 as minutes_until_next_execution
# MAGIC     , lead(h.statement_text) over (partition by warehouse_id, executed_by order by end_time asc) next_statement_text
# MAGIC     , lead(h.statement_id) over (partition by warehouse_id, executed_by order by end_time asc) next_statement_id
# MAGIC   from system.query.history h
# MAGIC   --from text_to_sql.query_history_api h
# MAGIC     inner join text_to_sql.query_history_unique l on h.statement_id = l.statement_id
# MAGIC )
# MAGIC , similarity as (
# MAGIC   select *
# MAGIC     , ai_similarity(coalesce(next_statement_text, ''), statement_text) as next_similarity_score
# MAGIC   from cte
# MAGIC   order by end_time desc
# MAGIC   limit 10
# MAGIC )
# MAGIC select * from similarity
# MAGIC where next_similarity_score < .93 
# MAGIC order by executed_by, end_time desc
# MAGIC ;
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- MAGIC %md
# MAGIC -- MAGIC Now we begin to extract tables out of the sql query.
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC create or replace function text_to_sql.pull_tables_from_json(json_str STRING)
# MAGIC     RETURNS ARRAY<STRING>
# MAGIC     LANGUAGE PYTHON
# MAGIC     as $$
# MAGIC         import json
# MAGIC         array_str = ""
# MAGIC         try:
# MAGIC             start_index = json_str.index('[')
# MAGIC             end_index = json_str.index(']') + 1
# MAGIC             array_str = json_str[start_index:end_index]
# MAGIC             array_str = array_str.replace("\_", "_").replace("`", "").lower().strip()
# MAGIC             ret = json.loads(array_str)
# MAGIC             
# MAGIC             return ret
# MAGIC         except:
# MAGIC             return ["PARSING ERROR", array_str]
# MAGIC     $$
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- MAGIC %md
# MAGIC -- MAGIC We are going to fine tune a llama3 model in the 3rd notebook. Due to TOS of many models, as we generate synthetic data using models, we often need to generate the synthetic data within the same model family (ie, llama 3 70b to fine tune llama 3 8b). 
# MAGIC -- MAGIC
# MAGIC -- MAGIC Llama3 doesn't have a big enough context window to handle the largest queries, so we will use mixtral for those, which performs worse, but has a broader TOS when it comes to synthetic data being used to improve other models.
# MAGIC -- MAGIC
# MAGIC -- MAGIC Disclaimer: I am not a lawyer, and this shouldn't be taken as legal advice. Please consult with a legal representative before accepting the above claims.
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Extract Tables from Longer SQL
# MAGIC create or replace table text_to_sql.table_extract as
# MAGIC with long_statements as (
# MAGIC   select *
# MAGIC   from text_to_sql.query_history_similarity_filter
# MAGIC   where len(statement_text) >= 20000
# MAGIC )
# MAGIC select statement_id
# MAGIC   , statement_text
# MAGIC   , ai_query("databricks-mixtral-8x7b-instruct", concat("Extract the table names out of the following SQL statement. Think carefully and do NOT confuse a reference to an alias or a CTE as a table name. Where applicable, extract the fully declared table name (catalog.schema.table). Output the tables, and only the tables, in a json code block. For example: \nExample SQL:\nwith cte as (\n select customer_id\n , name\n from customer\n)\nselect c.name\n , order_number\nfrom sap.sales.orders o \n inner join cte c on o.customer_id = c.customer_id\n\n```json\n{\n  \"tables\": [\"customer\", \"sap.sales.orders\"]\n}\n```\n\nRemember, only output the json code block, and think carefully about the tables you extract. If there are no tables, leave the array empty.\n\nSQL:\n", statement_text)) as manual_table_list
# MAGIC   , "databricks-mixtral-8x7b-instruct" as extraction_model
# MAGIC from long_statements
# MAGIC
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Extract Tables from Shorter SQL
# MAGIC --create or replace table text_to_sql.table_extract as
# MAGIC --databricks-mixtral-8x7b-instruct
# MAGIC --databricks-meta-llama-3-70b-instruct
# MAGIC insert into text_to_sql.table_extract
# MAGIC with short_statements as (
# MAGIC   select * 
# MAGIC   from text_to_sql.query_history_similarity_filter
# MAGIC   where statement_id not in (select statement_id from text_to_sql.table_extract)
# MAGIC )
# MAGIC select statement_id
# MAGIC   , statement_text
# MAGIC   , ai_query("databricks-meta-llama-3-70b-instruct", concat("Extract the table names out of the following SQL statement. Think carefully and do NOT confuse a reference to an alias or a CTE as a table name. Where applicable, extract the fully declared table name (catalog.schema.table). Output the tables, and only the tables, in a json code block. For example: \nExample SQL:\nwith cte as (\n select customer_id\n , name\n from customer\n)\nselect c.name\n , order_number\nfrom sap.sales.orders o \n inner join cte c on o.customer_id = c.customer_id\n\n```json\n{\n  \"tables\": [\"customer\", \"sap.sales.orders\"]\n}\n```\n\nRemember, only output the json code block, and think carefully about the tables you extract. If there are no tables, leave the array empty.\n\nSQL:\n", statement_text)) as manual_table_list
# MAGIC   , "databricks-meta-llama-3-70b-instruct" as extraction_model
# MAGIC from short_statements
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Parse Table Names from JSON
# MAGIC create or replace table text_to_sql.table_extract_parse as 
# MAGIC select * 
# MAGIC   , text_to_sql.pull_tables_from_json(manual_table_list) as parsed_table_list
# MAGIC from text_to_sql.table_extract
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Check Parsing Errors
# MAGIC select * from text_to_sql.table_extract_parse
# MAGIC where array_contains(parsed_table_list, "PARSING ERROR")
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Retrieve Table Components
# MAGIC create or replace table text_to_sql.table_extract_final
# MAGIC with cte as (
# MAGIC   select explode(parsed_table_list) as table_contender
# MAGIC     , * except (parsed_table_list)
# MAGIC   from text_to_sql.table_extract_parse
# MAGIC )
# MAGIC , cte2 as (
# MAGIC select table_contender as full_table
# MAGIC   , element_at(split(table_contender, '\\.'), -1) as table_name
# MAGIC   , element_at(split(table_contender, '\\.'), -2)as schema_name
# MAGIC   , element_at(split(table_contender, '\\.'), -3) as catalog_name
# MAGIC   , * except (table_contender)
# MAGIC from cte)
# MAGIC , cte3 as (
# MAGIC select full_table
# MAGIC   , case when contains(statement_text, table_name) then table_name else null end as valid_table_name
# MAGIC   , case when contains(statement_text, schema_name) then schema_name else null end as valid_schema_name
# MAGIC   , case when contains(statement_text, catalog_name) then catalog_name else null end as valid_catalog_name
# MAGIC   , * except (full_table)
# MAGIC from cte2
# MAGIC )
# MAGIC , cte4 as (
# MAGIC   /* 
# MAGIC    - verifies that the table reference is unique enough to map back to a table in UC 
# MAGIC    - sets the catalog and schema name where it might be null from the parsing.*/
# MAGIC   select cte3.* except (valid_catalog_name, valid_schema_name)
# MAGIC     , coalesce(cte3.valid_catalog_name, u.table_catalog) as valid_catalog_name
# MAGIC     , coalesce(cte3.valid_schema_name, u.table_schema) as valid_schema_name
# MAGIC     , case when u.table_name is not null then true else false end as matched_ind
# MAGIC     , case when coalesce(cte3.valid_catalog_name, '') <> u.table_catalog or coalesce(cte3.valid_schema_name, '') <> u.table_schema then true else false end as fixed_ind
# MAGIC     , cte3.extraction_model
# MAGIC   from cte3
# MAGIC     left outer join text_to_sql.unique_table u on cte3.valid_table_name = u.table_name 
# MAGIC       and (cte3.valid_schema_name = u.table_schema or (u.unique_level_nbr = 1 and cte3.valid_schema_name is null))
# MAGIC       and (cte3.valid_catalog_name = u.table_catalog or (u.unique_level_nbr < 3 and cte3.valid_schema_name is null))
# MAGIC )
# MAGIC select statement_id
# MAGIC   , array_agg(struct(valid_catalog_name as catalog_name, valid_schema_name as schema_name, valid_table_name as table_name)) as table_struct_list
# MAGIC   , array_compact(array_distinct(array_agg(valid_catalog_name))) as catalog_list
# MAGIC   , array_compact(array_distinct(array_agg(concat(valid_catalog_name, '.', valid_schema_name)))) as schema_list
# MAGIC   , array_compact(array_distinct(array_agg(concat(valid_catalog_name, '.', valid_schema_name, '.', valid_table_name)))) as table_list
# MAGIC   , statement_text
# MAGIC   , array_contains(array_agg(matched_ind), true) as matched_ind
# MAGIC   , array_contains(array_agg(fixed_ind), true) as fixed_ind
# MAGIC   , cte4.extraction_model
# MAGIC from cte4
# MAGIC where valid_table_name is not null
# MAGIC   -- filter out tables where there's no unique tie to the current UC table list
# MAGIC   and valid_catalog_name is not null 
# MAGIC   and valid_schema_name is not null 
# MAGIC group by all
# MAGIC
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- MAGIC %md
# MAGIC -- MAGIC Now we generate synthetic data for SQL Queries: 
# MAGIC -- MAGIC 1. summaries (unused for now, but they could be useful later)
# MAGIC -- MAGIC 2. sample questions
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Summarize Query and Generate Question
# MAGIC create or replace table text_to_sql.summary_processed as
# MAGIC select q.statement_id
# MAGIC , q.executed_by
# MAGIC , q.next_similarity_score
# MAGIC , ai_query("databricks-meta-llama-3-70b-instruct", concat("summarize what the following SQL is doing in plain english, in 100 words or less: \n", q.statement_text)) as manual_summarization
# MAGIC --, ai_summarize(statement_text, 100) as sql_summarization
# MAGIC , trim('"' from ai_query("databricks-meta-llama-3-70b-instruct", concat("Reverse Engineer Text-to-SQL: Write a user question or request that would result in this query, in 50 words or less: \n", q.statement_text))) as generated_question
# MAGIC , q.statement_text
# MAGIC , t.extraction_model
# MAGIC --, q.next_statement_text
# MAGIC --, q.start_time
# MAGIC --, q.end_time
# MAGIC from text_to_sql.query_history_similarity_filter q
# MAGIC   -- filter to statements that can be matched to an existing table
# MAGIC   inner join text_to_sql.table_extract_final t on q.statement_id = t.statement_id and t.matched_ind
# MAGIC where t.extraction_model = "databricks-meta-llama-3-70b-instruct"
# MAGIC order by executed_by, end_time desc
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Round 2 (Mixtral Generation)
# MAGIC insert into text_to_sql.summary_processed
# MAGIC select q.statement_id
# MAGIC , q.executed_by
# MAGIC , q.next_similarity_score
# MAGIC , ai_query("databricks-mixtral-8x7b-instruct", concat("summarize what the following SQL is doing in plain english, in 100 words or less: \n", q.statement_text)) as manual_summarization
# MAGIC --, ai_summarize(statement_text, 100) as sql_summarization
# MAGIC , trim('"' from ai_query("databricks-mixtral-8x7b-instruct", concat("Reverse Engineer Text-to-SQL: Write a user question or request that would result in this query, in 50 words or less: \n", q.statement_text))) as generated_question
# MAGIC , q.statement_text
# MAGIC , t.extraction_model
# MAGIC --, q.next_statement_text
# MAGIC --, q.start_time
# MAGIC --, q.end_time
# MAGIC from text_to_sql.query_history_similarity_filter q
# MAGIC   -- filter to statements that can be matched to an existing table
# MAGIC   inner join text_to_sql.table_extract_final t on q.statement_id = t.statement_id and t.matched_ind
# MAGIC where t.extraction_model = "databricks-mixtral-8x7b-instruct"
# MAGIC order by executed_by, end_time desc
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- MAGIC %md
# MAGIC -- MAGIC Now, we generate Embeddings of questions and statements. We will use the question embeddings for the fine tuning notebook (#3)
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Generate Embeddings for Questions and Statements
# MAGIC create or replace table robert_mosley.text_to_sql.query_history_embeddings as
# MAGIC select p.statement_id
# MAGIC   , p.generated_question
# MAGIC   , p.statement_text
# MAGIC   , ai_query("databricks-bge-large-en", p.generated_question, "ARRAY<FLOAT>") as question_embeddings
# MAGIC   , ai_query("databricks-bge-large-en", p.statement_text, "ARRAY<FLOAT>") as statement_embeddings
# MAGIC from robert_mosley.text_to_sql.summary_processed p
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- MAGIC %md
# MAGIC -- MAGIC Now we create our unified table that will be used for vector search and other tasks.
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Bring Everything Together
# MAGIC create or replace table robert_mosley.text_to_sql.query_history_pre_index as
# MAGIC select p.* except (next_statement_text)
# MAGIC   --, t.table_struct_list
# MAGIC   , t.catalog_list
# MAGIC   , t.schema_list
# MAGIC   , t.table_list
# MAGIC   , e.question_embeddings
# MAGIC   , e.statement_embeddings
# MAGIC from robert_mosley.text_to_sql.summary_processed p
# MAGIC   inner join robert_mosley.text_to_sql.query_history_embeddings e on p.statement_id = e.statement_id
# MAGIC   left outer join robert_mosley.text_to_sql.table_extract_final t on p.statement_id = t.statement_id
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- MAGIC %md
# MAGIC -- MAGIC We also create table and column datasets that can be used for the model chain.
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Create a Table of Tables
# MAGIC create or replace table table_search_pre_index as
# MAGIC select t.table_catalog
# MAGIC   , t.table_schema
# MAGIC   , t.table_name
# MAGIC   , array_join(array(t.table_catalog, t.table_schema, t.table_name), '.') as full_table
# MAGIC   , t.table_type
# MAGIC   , t.comment
# MAGIC   , array_join(array_agg(c.column_name), ', ') as column_list
# MAGIC   , array_join(array_agg(concat("  ", c.column_name, " ", upper(c.full_data_type), case when c.comment is not null then concat(" COMMENT '", c.comment, "'") else "" end)), ',\n') column_description_list
# MAGIC   , to_json(named_struct('table', array_join(array(t.table_catalog, t.table_schema, t.table_name), '.'), 'comment', t.comment)) as table_search
# MAGIC from system.information_schema.tables t
# MAGIC   left outer join system.information_schema.columns c on t.table_catalog = c.table_catalog and t.table_schema = c.table_schema and t.table_name = c.table_name
# MAGIC group by t.table_catalog, t.table_schema, t.table_name, t.table_type, t.comment
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Create a Table of Columns
# MAGIC create or replace table column_search_pre_index as
# MAGIC select array_join(array(table_catalog, table_schema, table_name, column_name), '.') as id
# MAGIC   , array_join(array(table_catalog, table_schema, table_name), '.') as full_table
# MAGIC   , column_name
# MAGIC   , is_nullable
# MAGIC   , full_data_type as data_type
# MAGIC   , comment
# MAGIC   , to_json(named_struct('table', array_join(array(table_catalog, table_schema, table_name), '.'), 'column_name', column_name, 'comment', comment)) as column_search
# MAGIC from system.information_schema.columns
# MAGIC
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Enable Change Data Feed
# MAGIC ALTER TABLE `robert_mosley`.`text_to_sql`.`query_history_pre_index` SET TBLPROPERTIES (delta.enableChangeDataFeed = true);
# MAGIC ALTER TABLE `robert_mosley`.`text_to_sql`.`table_search_pre_index` SET TBLPROPERTIES (delta.enableChangeDataFeed = true);
# MAGIC ALTER TABLE `robert_mosley`.`text_to_sql`.`column_search_pre_index` SET TBLPROPERTIES (delta.enableChangeDataFeed = true);
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Set Table Primary Keys
# MAGIC -- 1. Modify the column to be non-nullable
# MAGIC ALTER TABLE `robert_mosley`.`text_to_sql`.`table_search_pre_index`
# MAGIC alter COLUMN `full_table` set NOT NULL;
# MAGIC
# MAGIC ALTER TABLE `robert_mosley`.`text_to_sql`.`table_search_pre_index` ADD CONSTRAINT table_search_pre_index_pk PRIMARY KEY(full_table);
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Set Column Primary keys
# MAGIC -- 1. Modify the column to be non-nullable
# MAGIC ALTER TABLE `robert_mosley`.`text_to_sql`.`column_search_pre_index`
# MAGIC alter COLUMN `id` set NOT NULL;
# MAGIC
# MAGIC ALTER TABLE `robert_mosley`.`text_to_sql`.`column_search_pre_index` ADD CONSTRAINT column_search_pre_index_pk_pk PRIMARY KEY(id);
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- MAGIC %md
# MAGIC -- MAGIC We create functions that will be used in both the RAG chain and in the Model Training.
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Create Function for Retrieving Table Definitions
# MAGIC CREATE OR REPLACE FUNCTION robert_mosley.text_to_sql.get_table_definitions(tables ARRAY<STRING>)
# MAGIC     RETURNS ARRAY<STRING>
# MAGIC     RETURN 
# MAGIC     WITH cte as (
# MAGIC     SELECT robert_mosley.text_to_sql.format_table_definitions(t.full_table, t.comment, t.column_description_list) as table_definitions
# MAGIC     FROM robert_mosley.text_to_sql.table_search_pre_index t
# MAGIC     WHERE array_contains(tables, t.full_table)
# MAGIC     )
# MAGIC     select array_agg(table_definitions) from cte;
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Build Function for Online Functions
# MAGIC CREATE OR REPLACE FUNCTION robert_mosley.text_to_sql.format_table_definitions(full_table STRING, comment STRING, column_description_list STRING)
# MAGIC     RETURNS STRING
# MAGIC     LANGUAGE PYTHON
# MAGIC     as $$
# MAGIC         try:
# MAGIC             if not comment:
# MAGIC                 comment = ''
# MAGIC             else:
# MAGIC                 comment = "\nCOMMENT '" + comment + "'"
# MAGIC
# MAGIC             ret = f"CREATE TABLE {full_table} (\n{column_description_list}){comment};"
# MAGIC
# MAGIC             return ret
# MAGIC         except:
# MAGIC             return ""
# MAGIC     $$
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- MAGIC %md
# MAGIC -- MAGIC **Special Note for build_prompt**
# MAGIC -- MAGIC
# MAGIC -- MAGIC This function serves as a prompt template. Langchain has prompt features that allow you to create a prompt from a prompt template, so you won't necessarily need this function for the RAG Chain (though my notebooks do use it).
# MAGIC -- MAGIC
# MAGIC -- MAGIC The reason for this is because I use this function in the fine tuning notebook (#3), and by relying on the same function in both processes, I guarantee that I will fine-tune my models *on the exact same prompt format* that I pass into the model as part of the RAG chain. This way I don't have to manage the prompt template in two different places.
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Build function for prompt
# MAGIC CREATE or REPLACE FUNCTION robert_mosley.text_to_sql.build_prompt(question STRING, table_definitions ARRAY<STRING>, sample_queries ARRAY<STRUCT<question: STRING, sql: STRING>>)
# MAGIC   RETURNS STRING
# MAGIC   LANGUAGE PYTHON
# MAGIC   AS $$
# MAGIC     PROMPT_TEMPLATE = """--Instructions\n/*\nYou are a helpful assistant that replies with SQL queries. Users will provide you with table definitions and sample SQL queries for similar prompts. Then users will submit a prompt using a SQL comment. Answer the user's prompt with a SELECT SQL statement ending with a ;.\n*/
# MAGIC \n--Tables\n{tables}
# MAGIC \n--Sample Prompt and SQL Response\n{samples}
# MAGIC \n--User Prompt\n/*\n{question}\n*/
# MAGIC \n--Your SQL Response\n"""
# MAGIC
# MAGIC     samples = '\n\n'.join([f"/*\n{q['question']}\n*/ \n{q['sql']}" for q in sample_queries])
# MAGIC     tables = '\n\n'.join(table_definitions)
# MAGIC
# MAGIC     ret = PROMPT_TEMPLATE.format(question=question, tables=tables, samples=samples)
# MAGIC
# MAGIC     return ret
# MAGIC   $$
# MAGIC
# MAGIC -- COMMAND ----------
# MAGIC
# MAGIC -- DBTITLE 1,Test Functions
# MAGIC select robert_mosley.text_to_sql.build_prompt('What is the average number of orders per product?', array('system.information_schema.columns', 'system.information_schema.tables'), array(named_struct("question",'points per game', "sql",'SELECT SUM(POINTS), game from scores group by game;'), named_struct("question",'points per game', "sql",'SELECT SUM(POINTS), game from scores group by game;')))