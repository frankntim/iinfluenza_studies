# Databricks notebook source
# MAGIC %md
# MAGIC # Multi-agent system with Genie
# MAGIC

# COMMAND ----------

# MAGIC %pip install -U -qqq mlflow langgraph==0.3.4 langchain-experimental==0.3.4 databricks-langchain databricks-agents langgraph-checkpoint-sqlite plotnine uv
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

#%%writefile agent.py
import functools
import os
from typing import Any, Generator, Literal, Optional

import mlflow
from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from databricks_langchain.genie import GenieAgent
from langchain_core.runnables import RunnableLambda
from langgraph.graph import END, StateGraph
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import create_react_agent
from mlflow.langchain.chat_agent_langgraph import ChatAgentState
from mlflow.pyfunc import ChatAgent
from mlflow.types.agent import (
    ChatAgentChunk,
    ChatAgentMessage,
    ChatAgentResponse,
    ChatContext,
)
from pydantic import BaseModel

from langchain_experimental.utilities import PythonREPL
from langchain_core.tools import tool
from langchain_core.messages import trim_messages
from langgraph.checkpoint.memory import MemorySaver
from typing import Annotated
import plotly.graph_objects as go #To uPse the Plotly library to create the graph
import plotly.express as px #To use the Plotly Express library to create the graph
import seaborn as sns
from plotnine import ggplot, aes, geom_line, geom_bar


# COMMAND ----------

# Set the variables

DATABRICKS_HOST = 'https://amgen-ai-dev.cloud.databricks.com/'
GENIE_SPACE_URL = "https://amgen-ai-dev.cloud.databricks.com/genie/rooms/01f009af5a301a0683d008356f8f3289?o=2249790853314266"

#https://amgen-ai-dev.cloud.databricks.com/genie/rooms/01f009af5a301a0683d008356f8f3289?o=2249790853314266

base_url="https://amgen-ai-dev.cloud.databricks.com/serving-endpoints"
api_key = "dapif3bc3b1e718c335b48f4c410b07c9c12"
model_name = "project-115-Precision_Medicine_AI_Agent-2"

os.environ['DATABRICKS_GENIE_PAT'] = "dapif3bc3b1e718c335b48f4c410b07c9c12"
os.environ['DATABRICKS_HOST'] = DATABRICKS_HOST
GENIE_SPACE_ID = "01f009af5a301a0683d008356f8f3289"
#workspaceUrl = spark.conf.get('spark.databricks.workspaceUrl')
#workspaceUrl = f"https://{workspaceUrl}"
#os.environ['DATABRICKS_HOST'] = workspaceUrl
#llm.invoke("What is the name of the program that is associated with the assay type 'HLA-DRB1'?")

# COMMAND ----------

###################################################
## Create a GenieAgent with access to a Genie Space
###################################################

# TODO add GENIE_SPACE_ID and a description for this space
# You can find the ID in the URL of the genie room /genie/rooms/<GENIE_SPACE_ID>
#GENIE_SPACE_ID = ""
genie_agent_description = "This agent can answer questions from the Genie Space which links to Unity Catalog database"

genie_agent = GenieAgent(
    genie_space_id="01f009af5a301a0683d008356f8f3289",
    genie_agent_name="Genie",
    description=genie_agent_description,
    # DB_MODEL_SERVING_HOST_URL is set on an agent endpoints but doesn't exist in the notebook
    client=WorkspaceClient(
        host=os.getenv("DATABRICKS_HOST") ,
        token=os.getenv("DATABRICKS_GENIE_PAT"),
    )

)
############################################
# Define your LLM endpoint and system prompt
############################################

#llm = ChatDatabricks(model=model_name, streaming=False, base_url=base_url, api_key=api_key,   #max_tokens=3000)
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

# COMMAND ----------



###############################################
# Create a chart agent
################################################

repl = PythonREPL()

@tool
def python_repl_tool(
    code: Annotated[str, "The python code to execute code to generate charts."],
):
    """Use this to execute python code and do math. If you want to see the output of a value,
    you should print it out with `print(...)`. This is visible to the user.
    To generate charts, you must use ONLY plotly express. The figure sizes should by 5 by 3. Select different colours and styles.
    """
    try:
        result = repl.run(code)
    except BaseException as e:
        return f"Failed to execute. Error: {repr(e)}"
    result_str = f"Successfully executed:\n```python\n{code}\n```\nCODE OUTPUT:\n {result}"
    return result_str



chart_agent_description = ("The chart agent specializes in generating charts and visualizations with ONLY plotly express from the results from coding agent. Figure size should be 5 by 3. Select different colours and styles.")


chart_agent = create_react_agent(llm, 
                                 tools=[python_repl_tool], 
                                 state_modifier="""You are a coder who can write and run python code and also visualize charts and graphs with ONLY plotly express. Figure size should be 5 by 3.  Select different colours and styles. Only extract the most relevant data related to the question before running code or creating graphs.Once your task is done report back to the supervisor.
                                 
                                 """)



#############################
# Define the supervisor agent
#############################

# TODO update the max number of iterations between supervisor and worker nodes
# before returning to the user
MAX_ITERATIONS = 3

worker_descriptions = {
    "Genie": genie_agent_description,
    "Charter": chart_agent_description,
}

formatted_descriptions = "\n".join(
    f"- {name}: {desc}" for name, desc in worker_descriptions.items()
)

system_prompt = f"Decide between routing between the following workers or ending the conversation if an answer is provided. \n{formatted_descriptions}"
options = ["FINISH"] + list(worker_descriptions.keys())


def supervisor_agent(state):
    count = state.get("iteration_count", 0) + 1
    print('iteration count', count)
    if count > MAX_ITERATIONS:
        return {"next_node": "FINISH"}
    
    class nextNode(BaseModel):
        next_node: Literal[tuple(options)]

    preprocessor = RunnableLambda(
        lambda state: [{"role": "system", "content": system_prompt}] + state["messages"]
    )
    supervisor_chain = preprocessor | llm.with_structured_output(nextNode)
    next_node = supervisor_chain.invoke(state).next_node
    print(type(next_node), next_node)
    return {
        "iteration_count": count,
        "next_node": next_node
    }

# COMMAND ----------

#######################################
# Define our multiagent graph structure
#######################################

def agent_node(state, agent, name):
    result = agent.invoke(state)
    return {
        "messages": [
            {
                "role": "assistant",
                "content": result["messages"][-1].content,
                "name": name,
            }
        ]
    }

def final_answer(state):
    system_prompt = "Using only the content in the messages, respond to the user's question using the answer given by the other agents."
    preprocessor = RunnableLambda(
        lambda state: [{"role": "system", "content": system_prompt}] + state["messages"]
    )
    final_answer_chain = preprocessor | llm
    return {"messages": [final_answer_chain.invoke(state)]}

class AgentState(ChatAgentState):
    next_node: str
    iteration_count: int


chart_node = functools.partial(agent_node, agent=chart_agent, name="Charter")
genie_node = functools.partial(agent_node, agent=genie_agent, name="Genie")

workflow = StateGraph(AgentState)
workflow.add_node("Genie", genie_node)
workflow.add_node("Charter", chart_node)
workflow.add_node("supervisor", supervisor_agent)
workflow.add_node("final_answer", final_answer)

workflow.set_entry_point("supervisor")
# We want our workers to ALWAYS "report back" to the supervisor when done
for worker in worker_descriptions.keys():
    workflow.add_edge(worker, "supervisor")

# Let the supervisor decide which next node to go
workflow.add_conditional_edges(
    "supervisor",
    lambda x: x["next_node"],
    {**{k: k for k in worker_descriptions.keys()}, "FINISH": "final_answer"},
)
workflow.add_edge("final_answer", END)

memory = MemorySaver()
multi_agent = workflow.compile()

# COMMAND ----------

###################################
# Wrap our multi-agent in ChatAgent
###################################


class LangGraphChatAgent(ChatAgent):
    def __init__(self, agent: CompiledStateGraph):
        self.agent = agent

    def predict(
        self,
        messages: list[ChatAgentMessage],
        context: Optional[ChatContext] = None,
        custom_inputs: Optional[dict[str, Any]] = None,
    ) -> ChatAgentResponse:
        request = {
            "messages": [m.model_dump_compat(exclude_none=True) for m in messages]
        }

        messages = []
        for event in self.agent.stream(request, stream_mode="updates"):
            for node_data in event.values():
                messages.extend(
                    ChatAgentMessage(**msg) for msg in node_data.get("messages", [])
                )
        return ChatAgentResponse(messages=messages)

    def predict_stream(
        self,
        messages: list[ChatAgentMessage],
        context: Optional[ChatContext] = None,
        custom_inputs: Optional[dict[str, Any]] = None,
    ) -> Generator[ChatAgentChunk, None, None]:
        request = {
            "messages": [m.model_dump_compat(exclude_none=True) for m in messages]
        }
       
        for event in self.agent.stream(request, stream_mode="updates"):
            for node_data in event.values():
                yield from (
                    ChatAgentChunk(**{"delta": msg})
                    for msg in node_data.get("messages", [])
                )

# COMMAND ----------

# Create the agent object, and specify it as the agent object to use when
# loading the agent back for inference via mlflow.models.set_model()
mlflow.langchain.autolog()
AGENT = LangGraphChatAgent(multi_agent)
mlflow.models.set_model(AGENT)

# COMMAND ----------

#input_example = {"messages": [{"role": "user", "content": "Group all subjects by DoseSeqp"}]}
#prediction = AGENT.predict(input_example)

# COMMAND ----------

from IPython.display import Markdown, display


#prompt = "Categorize age into groups of 3: 0-34, 35-66, > 67 then plot the results with appropriate chart" 
#prompt = "Group age into groups of 3: 0-34, 35-66, > 67"
prompt = "Aggregate categories of DoseSeqp by count, then plot the results with appropriate chart"
input_example = {"messages": [{"role": "user", "content": prompt}]}
#AGENT.predict(input_example)

for event in AGENT.predict_stream(input_example):
  #print(event, "-----------\n")
  display(Markdown(event.delta.content))


# COMMAND ----------

from IPython.display import Markdown, display

def center_markdown(markdown_text: str)->str:
    return f'<div align="center">\n\n{markdown_text}\n\n</div>'

def generate_markdown_table(headers, data):
    markdown_text = "| " + " | ".join(headers) + " |\n"
    markdown_text += "| " + " | ".join(["---"] * len(headers)) + " |\n"
    for row in data:
        markdown_text += "| " + " | ".join(row) + " |\n"

    #centered_text = center_markdown(markdown_text)
    return markdown_text






# COMMAND ----------

prompt = "Fetch average age grouped by gender, then plot the results with appropriate chart"
#prompt = "Aggregate subjects by DoseSeqp, then plot the results with appropriate chart"
events = multi_agent.invoke(
        {"messages":  [{"role": "user", "content": prompt}]}

    )
assistant_messages = [d.items() for d in events['messages'] if d.get('role') == 'assistant']

assistant_messages2 = [dict(data).get('content') for data in assistant_messages]
for data in assistant_messages: 
    display(Markdown(dict(data).get('content')))
    print('\n')

##headers = ["Chat Assistant"]
#markdown_table = generate_markdown_table(headers, assistant_messages2)
#centered_mk_markdown = center_markdown(markdown_table)
#display(Markdown(centered_mk_markdown))


# COMMAND ----------

from databricks.sdk import WorkspaceClient

#secret_scope: pmed_ai_genie_25
#secret_value: dapi7225a6c8ec529b88c04b51d61de2c876
#secret_key: PMED_AI_GENIE

#w = WorkspaceClient()

#w.secrets.put_secret("pmed_ai_genie_25","PMED_AI_GENIE",#string_value="dapi7225a6c8ec529b88c04b51d61de2c876")

# COMMAND ----------

password = dbutils.secrets.get(scope = "pmed_ai_genie_25", key = "PMED_AI_GENIE")

# COMMAND ----------

password

# COMMAND ----------

# MAGIC %md
# MAGIC **Deployment Script**

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC **Register to UCatalog**

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC **Test out Prediction**

# COMMAND ----------

mlflow.models.predict(
    model_uri=f"runs:/{logged_agent_info.run_id}/agent",
    input_data=input_example,
    env_manager="uv",
)

# COMMAND ----------

mlflow.set_registry_uri("databricks-uc")

# TODO: define the catalog, schema, and model name for your UC model
catalog = "edl_dev"
schema = "cbd_sandbox"
model_name = "pmed_ai_chat_v0"
UC_MODEL_NAME = f"{catalog}.{schema}.{model_name}"

# register the model to UC
uc_registered_model_info = mlflow.register_model(
    model_uri=logged_agent_info.model_uri, name=UC_MODEL_NAME
)

# COMMAND ----------

# MAGIC %md
# MAGIC **Deploy**

# COMMAND ----------

from databricks import agents
secret_scope_name = 'pmed_ai_genie_25'
secret_key_name = 'PMED_AI_GENIE'


agents.deploy(
    UC_MODEL_NAME,
    uc_registered_model_info.version,
    tags={"endpointSource": "docs"},
    environment_vars={
        "DATABRICKS_GENIE_PAT": f"{{{{secrets/{secret_scope_name}/{secret_key_name}}}}}"
    },
    budget_policy='aiwb_project_115_policy'
)