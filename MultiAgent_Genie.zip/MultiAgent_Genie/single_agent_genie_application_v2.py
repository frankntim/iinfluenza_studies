# Databricks notebook source
# MAGIC %md
# MAGIC # Multi-agent system with Genie
# MAGIC

# COMMAND ----------

# MAGIC %pip install -U -qqq mlflow langgraph==0.3.4 langchain-experimental==0.3.4 langchain-community==0.3.14 databricks-langchain databricks-agents uv
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

#%%writefile agent.py
import functools
import os
from typing import Any, Generator, Literal, Optional

import mlflow
from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from databricks_langchain.genie import GenieAgent
from langchain_core.runnables import RunnableLambda
from langgraph.graph import END, StateGraph
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import create_react_agent
from mlflow.langchain.chat_agent_langgraph import ChatAgentState
from mlflow.pyfunc import ChatAgent
from mlflow.types.agent import (
    ChatAgentChunk,
    ChatAgentMessage,
    ChatAgentResponse,
    ChatContext,
)
from pydantic import BaseModel

from langchain_experimental.utilities import PythonREPL
from langchain_core.tools import tool
from typing import Annotated


# COMMAND ----------

# Set the variables

DATABRICKS_HOST = 'https://amgen-ai-dev.cloud.databricks.com/'
GENIE_SPACE_URL = "https://amgen-ai-dev.cloud.databricks.com/genie/rooms/01f009af5a301a0683d008356f8f3289?o=2249790853314266"
Warehouse_ID: "792838787cf72ed7"

#https://amgen-ai-dev.cloud.databricks.com/genie/rooms/01f009af5a301a0683d008356f8f3289?o=2249790853314266

base_url="https://amgen-ai-dev.cloud.databricks.com/serving-endpoints"
api_key = "dapif3bc3b1e718c335b48f4c410b07c9c12"
model_name = "project-115-Precision_Medicine_AI_Agent-2"

os.environ['DATABRICKS_GENIE_PAT'] = api_key
os.environ['DATABRICKS_HOST'] = DATABRICKS_HOST
GENIE_SPACE_ID = "01f009af5a301a0683d008356f8f3289"
#workspaceUrl = spark.conf.get('spark.databricks.workspaceUrl')
#workspaceUrl = f"https://{workspaceUrl}"
#os.environ['DATABRICKS_HOST'] = workspaceUrl
#llm.invoke("What is the name of the program that is associated with the assay type 'HLA-DRB1'?")

# COMMAND ----------

from langchain_core.messages import SystemMessage

SQL_PREFIX = """You are an agent designed to interact with a Databricks Unity Catalog database.
The Unity Catalog is formatted as: {catalog}.{schema}.{table}

Given an input question, create a syntactically correct Databricks SQL query to run, then look at the results of the query and return the answer.
Unless the user specifies a specific number of examples they wish to obtain, always limit your query to at most 10 results.
You can order the results by a relevant column to return the most interesting examples in the database.
Never query for all the columns from a specific table, only ask for the relevant columns given the question.
Make sure you generate a correct Databricks SQL query as plain text without any formatting or code blocks.
Do not include sql or similar markers.
Do not try to explain the query, just provide the query as-is, like this: SELECT ...

You have access to tools for interacting with the database.
Only use the below tools. Only use the information returned by the below tools to construct your final answer.

You MUST double check your query before executing it. If you get an error while executing a query, rewrite the query and try again.
DO NOT make any DML statements (INSERT, UPDATE, DELETE, DROP etc.) to the database even if the user asks.

To start you should ALWAYS look at the tables in the database to see what you can query.
Do NOT skip this step.
Then you should query the schema of the most relevant tables.

When generating the final answer in markdown from the results,
if there are special characters in the text, such as the dollar symbol,
ensure they are escaped properly for correct rendering e.g $25.5 should become \$25.5
"""

SYS_PROMPT = SystemMessage(content=SQL_PREFIX)

# COMMAND ----------

###################################################
## Create a GenieAgent with access to a Genie Space
###################################################

# TODO add GENIE_SPACE_ID and a description for this space
# You can find the ID in the URL of the genie room /genie/rooms/<GENIE_SPACE_ID>
#GENIE_SPACE_ID = ""
genie_agent_description = "This agent can answer questions from the Genie Space which links to Unity Catalog database"

genie_agent = GenieAgent(
    genie_space_id=GENIE_SPACE_ID,
    genie_agent_name="Genie",
    description=genie_agent_description,
    # DB_MODEL_SERVING_HOST_URL is set on an agent endpoints but doesn't exist in the notebook
    client=WorkspaceClient(
        host=os.getenv("DATABRICKS_HOST") ,
        token=os.getenv("DATABRICKS_GENIE_PAT"),
    ),
)
############################################
# Define your LLM endpoint and system prompt
############################################

#llm = ChatDatabricks(model=model_name, streaming=False, base_url=base_url, api_key=api_key,   #max_tokens=3000)
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

# COMMAND ----------

############################################################
# Create a code agent
# You can also create agents with access to additional tools
############################################################
tools = []

# TODO if desired, add additional tools and update the description of this agent
####################python tools
repl = PythonREPL()

@tool
def python_repl_tool(
    code: Annotated[str, "The python code to execute code, generate charts."],
):
    """Use this to execute python code and do math. If you want to see the output of a value,
    you should print it out with `print(...)`. This is visible to the user."""
    try:
        result = repl.run(code)
    except BaseException as e:
        return f"Failed to execute. Error: {repr(e)}"
    result_str = f"Successfully executed:\n```python\n{code}\n```\nCODE OUTPUT:\n {result}"
    return result_str

################### uc tools#################
#uc_tool_names = ["ai_dev.aiwb_115_cbd_sandbox.*"]
uc_tool_names = ["edl_dev.cbd_sandbox.*"] 
#uc_tool_names = ["edl_dev.cbd_sandbox.amg427_20170528_ne_adsl_clone", 
#                "edl_dev.cbd_sandbox.amg427_20170528_ne_cb_clone"]
uc_toolkit = UCFunctionToolkit(function_names=uc_tool_names)


tools.extend(uc_toolkit.tools)
#tools.extend([python_repl_tool])

# COMMAND ----------

text2sql_agent = create_react_agent(model=llm,
                                    tools=tools,
                                    state_modifier=SYS_PROMPT)
text2sql_agent

# COMMAND ----------

from IPython.display import display, Markdown
from langchain_core.messages import HumanMessage


for s in text2sql_agent.stream(
    {"messages": [HumanMessage(content="What is the capabilities of the dataset?")]}
):
    display(Markdown(str(s)))
    print("----")

# COMMAND ----------

for event in text2sql_agent.stream(
    {"messages": [HumanMessage(content="List all the tables in the database")]},
    stream_mode='values' #returns full agent state with all messages including updates
):
    event["messages"][-1].pretty_print()

print('\n\nFinal Response:\n')
display(Markdown(event["messages"][-1].content))

# COMMAND ----------



# COMMAND ----------






# COMMAND ----------




# COMMAND ----------

from langchain_community.tools.databricks import UCFunctionToolkit
import pandas as pd

Warehouse_ID = "792838787cf72ed7"
tools = (
    UCFunctionToolkit(
        # SQL warehouse ID is required to execute UC functions
        warehouse_id=Warehouse_ID
    ).include(
        # Include functions as tools using their qualified names.
        # You can use "{catalog_name}.{schema_name}.*" to get all functions in a schema.
        "edl_dev.cbd_sandbox.*"
    ).get_tools()
)

def display_tools(tools):
    display(pd.DataFrame([{k: str(v) for k, v in vars(tool).items()} for tool in tools]))

# COMMAND ----------

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.chat_models import ChatDatabricks


# Utilize a Foundational Model API via ChatDatabricks 


llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME)


# Define the prompt for the model, note the description to use the tools
prompt = ChatPromptTemplate.from_messages(
    [(
        "system",
        "You are a helpful assistant for a large online retail company.Make sure to use tool for information.Refer the tools description and make a decision of the tools to call for each user query.",
        ),
        ("placeholder", "{chat_history}"),
        ("human", "{input}"),
        ("placeholder", "{agent_scratchpad}"),
    ]
)

# COMMAND ----------

from langchain.agents import AgentExecutor, create_tool_calling_agent


agent = create_tool_calling_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

# COMMAND ----------

agent_executor.invoke({"input": "What is the capabilities of the dataset?"})