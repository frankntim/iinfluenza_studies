# Databricks notebook source
# MAGIC %md
# MAGIC # Multi-agent system with Genie
# MAGIC

# COMMAND ----------

# MAGIC %pip install -U -qqq mlflow langgraph==0.3.4 langchain-experimental==0.3.4 databricks-langchain databricks-agents langgraph-checkpoint-sqlite plotnine uv
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

#%%writefile agent.py
import functools
import os
from typing import Any, Generator, Literal, Optional

import mlflow
from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from databricks_langchain.genie import GenieAgent
from langchain_core.runnables import RunnableLambda
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import create_react_agent
from mlflow.langchain.chat_agent_langgraph import ChatAgentState
from mlflow.pyfunc import ChatAgent
from mlflow.types.agent import (
    ChatAgentChunk,
    ChatAgentMessage,
    ChatAgentResponse,
    ChatContext,
)
from pydantic import BaseModel

from langchain_experimental.utilities import PythonREPL
from langchain_core.tools import tool
from langchain_core.messages import trim_messages
from langgraph.checkpoint.memory import MemorySaver
from typing import Annotated
import plotly.graph_objects as go #To uPse the Plotly library to create the graph
import plotly.express as px #To use the Plotly Express library to create the graph
import seaborn as sns
from plotnine import ggplot, aes, geom_line, geom_bar


# COMMAND ----------

# Set the variables

DATABRICKS_HOST = 'https://amgen-ai-dev.cloud.databricks.com/'
GENIE_SPACE_URL = "https://amgen-ai-dev.cloud.databricks.com/genie/rooms/01f009af5a301a0683d008356f8f3289?o=2249790853314266"

#https://amgen-ai-dev.cloud.databricks.com/genie/rooms/01f009af5a301a0683d008356f8f3289?o=2249790853314266

base_url="https://amgen-ai-dev.cloud.databricks.com/serving-endpoints"
api_key = "dapif3bc3b1e718c335b48f4c410b07c9c12"
model_name = "project-115-Precision_Medicine_AI_Agent-2"

os.environ['DATABRICKS_GENIE_PAT'] = "dapif3bc3b1e718c335b48f4c410b07c9c12"
os.environ['DATABRICKS_HOST'] = DATABRICKS_HOST
GENIE_SPACE_ID = "01f009af5a301a0683d008356f8f3289"
#workspaceUrl = spark.conf.get('spark.databricks.workspaceUrl')
#workspaceUrl = f"https://{workspaceUrl}"
#os.environ['DATABRICKS_HOST'] = workspaceUrl
#llm.invoke("What is the name of the program that is associated with the assay type 'HLA-DRB1'?")

# COMMAND ----------

###################################################
## Create a GenieAgent with access to a Genie Space
###################################################

# TODO add GENIE_SPACE_ID and a description for this space
# You can find the ID in the URL of the genie room /genie/rooms/<GENIE_SPACE_ID>
#GENIE_SPACE_ID = ""
genie_agent_description = "This agent can answer questions from the Genie Space which links to Unity Catalog database"

genie_agent = GenieAgent(
    genie_space_id="01f009af5a301a0683d008356f8f3289",
    genie_agent_name="Genie",
    description=genie_agent_description,
    # DB_MODEL_SERVING_HOST_URL is set on an agent endpoints but doesn't exist in the notebook
    client=WorkspaceClient(
        host=os.getenv("DATABRICKS_HOST") ,
        token=os.getenv("DATABRICKS_GENIE_PAT"),
    ),

)
############################################
# Define your LLM endpoint and system prompt
############################################

#llm = ChatDatabricks(model=model_name, streaming=False, base_url=base_url, api_key=api_key,   #max_tokens=3000)
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

# COMMAND ----------



###############################################
# Create a chart agent
################################################

repl = PythonREPL()

@tool
def python_repl_tool(
    code: Annotated[str, "The python code to execute code to generate charts."],
):
    """Use this to execute python code for chart generation. If you want to see the output of a value, you should print it out with `print(...)`. This is visible to the user.
    To generate charts, you must use ONLY plotly express. The figure sizes should by 5 by 3. Select different colours and styles.
    """
    try:
        result = repl.run(code)
    except BaseException as e:
        return f"Failed to execute. Error: {repr(e)}"
    result_str = f"Successfully executed:\n```python\n{code}\n```\nCODE OUTPUT:\n {result}"
    return result_str



chart_agent_description = ("The chart agent specializes in generating charts and visualizations with ONLY plotly express from the results from coding agent. Figure size should be 5 by 3. Select different colours and styles.")


chart_agent = create_react_agent(llm, 
                                 tools=[python_repl_tool], 
                                 state_modifier="""You are a coder who can write and run python code and also visualize charts and graphs with ONLY plotly express. Figure size should be 5 by 3.  Select different colours and styles. Only extract the most relevant data related to the question before running code or creating graphs.Once your task is done report back to the supervisor.
                                 
                                 """)



#############################
# Define the supervisor agent
#############################

# TODO update the max number of iterations between supervisor and worker nodes
# before returning to the user
MAX_ITERATIONS = 3

worker_descriptions = {
    "Genie": genie_agent_description,
    "Charter": chart_agent_description,
}

formatted_descriptions = "\n".join(
    f"- {name}: {desc}" for name, desc in worker_descriptions.items()
)

system_prompt = f"Decide between routing between the following workers or ending the conversation if an answer is provided. \n{formatted_descriptions}"
options = ["FINISH"] + list(worker_descriptions.keys())


def supervisor_agent(state):
    count = state.get("iteration_count", 0) + 1
    print('iteration count', count)
    if count > MAX_ITERATIONS:
        return {"next_node": "FINISH"}
    
    class nextNode(BaseModel):
        next_node: Literal[tuple(options)]

    preprocessor = RunnableLambda(
        lambda state: [{"role": "system", "content": system_prompt}] + state["messages"]
    )
    supervisor_chain = preprocessor | llm.with_structured_output(nextNode)
    next_node = supervisor_chain.invoke(state).next_node
    print(type(next_node), next_node)
    return {
        "iteration_count": count,
        "next_node": next_node
    }

# COMMAND ----------

#######################################
# Define our multiagent graph structure
#######################################

def agent_node(state, agent, name):
    result = agent.invoke(state)
    return {
        "messages": [
            {
                "role": "assistant",
                "content": result["messages"][-1].content,
                "name": name,
            }
        ]
    }

def final_answer(state):
    system_prompt = "Using only the content in the messages, respond to the user's question using the answer given by the other agents."
    preprocessor = RunnableLambda(
        lambda state: [{"role": "system", "content": system_prompt}] + state["messages"]
    )
    final_answer_chain = preprocessor | llm
    return {"messages": [final_answer_chain.invoke(state)]}

class AgentState(ChatAgentState):
    next_node: str
    iteration_count: int
    #messages: Annotated[list, add_messages]


chart_node = functools.partial(agent_node, agent=chart_agent, name="Charter")
genie_node = functools.partial(agent_node, agent=genie_agent, name="Genie")

workflow = StateGraph(AgentState)
workflow.add_node("Genie", genie_node)
workflow.add_node("Charter", chart_node)
workflow.add_node("supervisor", supervisor_agent)
workflow.add_node("final_answer", final_answer)

workflow.set_entry_point("supervisor")
# We want our workers to ALWAYS "report back" to the supervisor when done
for worker in worker_descriptions.keys():
    workflow.add_edge(worker, "supervisor")

# Let the supervisor decide which next node to go
workflow.add_conditional_edges(
    "supervisor",
    lambda x: x["next_node"],
    {**{k: k for k in worker_descriptions.keys()}, "FINISH": "final_answer"},
)
workflow.add_edge("final_answer", END)

memory = MemorySaver()
multi_agent = workflow.compile(checkpointer=memory)
#multi_agent = workflow.compile()

# COMMAND ----------

###################################
# Wrap our multi-agent in ChatAgent
###################################


class LangGraphChatAgent(ChatAgent):
    def __init__(self, agent: CompiledStateGraph):
        self.agent = agent

    def predict(
        self,
        messages: list[ChatAgentMessage],
        context: Optional[ChatContext] = None,
        custom_inputs: Optional[dict[str, Any]] = None,
    ) -> ChatAgentResponse:
        request = {
            "messages": [m.model_dump_compat(exclude_none=True) for m in messages]
        }

        messages = []
        for event in self.agent.stream(request, stream_mode="updates"):
            for node_data in event.values():
                messages.extend(
                    ChatAgentMessage(**msg) for msg in node_data.get("messages", [])
                )
        return ChatAgentResponse(messages=messages)

    def predict_stream(
        self,
        messages: list[ChatAgentMessage],
        context: Optional[ChatContext] = None,
        custom_inputs: Optional[dict[str, Any]] = None,
    ) -> Generator[ChatAgentChunk, None, None]:
        request = {
            "messages": [m.model_dump_compat(exclude_none=True) for m in messages]
        }
       
        for event in self.agent.stream(request, stream_mode="updates"):
            for node_data in event.values():
                yield from (
                    ChatAgentChunk(**{"delta": msg})
                    for msg in node_data.get("messages", [])
                )

# COMMAND ----------

# Create the agent object, and specify it as the agent object to use when
# loading the agent back for inference via mlflow.models.set_model()
mlflow.langchain.autolog()
AGENT = LangGraphChatAgent(multi_agent)
mlflow.models.set_model(AGENT)

# COMMAND ----------

memory

# COMMAND ----------

from IPython.display import Markdown, display


def call_conversational_agent(agent, prompt, user_session_id, verbose=False):
    events = agent.stream(
        {"messages": [{"role": "user", "content": prompt}]},
        {"configurable": {"thread_id": user_session_id}, "stream_mode": "values"}
    )
    print('Running Agent. Please wait..')
    for event in events:
        for node_data in event.values():
            for msg in node_data.get("messages", []):
                if verbose:
                    #print(msg.content)
                    display(Markdown(msg.get('content')))
                    #display(Markdown(msg.content))
    

# COMMAND ----------

uid = 'john002'
#query = "Count the number of subjects grouped by gender"
query = " display the results with appropriate chart"
call_conversational_agent(agent=multi_agent,
                          prompt=query,
                          user_session_id=uid,
                          verbose=True)

# COMMAND ----------

from IPython.display import Markdown, display

uid = 'john002'
#prompt = "Categorize age into groups of 3: 0-34, 35-66, > 67 then plot the results with #appropriate chart" 
#query = "Group age into groups of 3: 0-34, 35-66, > 67"
query = "then plot the results with #appropriate chart"
call_conversational_agent(agent=multi_agent,
                          prompt=query,
                          user_session_id=uid,
                          verbose=True)


# COMMAND ----------








# COMMAND ----------

from databricks.sdk import WorkspaceClient

#secret_scope: pmed_ai_genie_25
#secret_value: dapi7225a6c8ec529b88c04b51d61de2c876
#secret_key: PMED_AI_GENIE

#w = WorkspaceClient()

#w.secrets.put_secret("pmed_ai_genie_25","PMED_AI_GENIE",#string_value="dapi7225a6c8ec529b88c04b51d61de2c876")

# COMMAND ----------

password = dbutils.secrets.get(scope = "pmed_ai_genie_25", key = "PMED_AI_GENIE")

# COMMAND ----------

password

# COMMAND ----------

# MAGIC %md
# MAGIC **Deployment Script**

# COMMAND ----------

# MAGIC %%writefile multiuser_agent.py
# MAGIC import functools
# MAGIC import os
# MAGIC from typing import Any, Generator, Literal, Optional
# MAGIC
# MAGIC import mlflow
# MAGIC from databricks.sdk import WorkspaceClient
# MAGIC from databricks_langchain import (
# MAGIC     ChatDatabricks,
# MAGIC     UCFunctionToolkit,
# MAGIC )
# MAGIC from databricks_langchain.genie import GenieAgent
# MAGIC from langchain_core.runnables import RunnableLambda
# MAGIC from langgraph.graph import END, StateGraph
# MAGIC from langgraph.graph.message import add_messages
# MAGIC from langgraph.graph.state import CompiledStateGraph
# MAGIC from langgraph.prebuilt import create_react_agent
# MAGIC from mlflow.langchain.chat_agent_langgraph import ChatAgentState
# MAGIC from mlflow.pyfunc import ChatAgent
# MAGIC from mlflow.types.agent import (
# MAGIC     ChatAgentChunk,
# MAGIC     ChatAgentMessage,
# MAGIC     ChatAgentResponse,
# MAGIC     ChatContext,
# MAGIC )
# MAGIC from pydantic import BaseModel
# MAGIC
# MAGIC from langchain_experimental.utilities import PythonREPL
# MAGIC from langchain_core.tools import tool
# MAGIC from langchain_core.messages import trim_messages
# MAGIC from langgraph.checkpoint.memory import MemorySaver
# MAGIC from IPython.display import Markdown, display
# MAGIC
# MAGIC from typing import Annotated
# MAGIC import plotly.graph_objects as go #To uPse the Plotly library to create the graph
# MAGIC import plotly.express as px #To use the Plotly Express library to create the graph
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC DATABRICKS_HOST = 'https://amgen-ai-dev.cloud.databricks.com/'
# MAGIC
# MAGIC os.environ['DATABRICKS_GENIE_PAT'] = "dapif3bc3b1e718c335b48f4c410b07c9c12"
# MAGIC os.environ['DATABRICKS_HOST'] = DATABRICKS_HOST
# MAGIC GENIE_SPACE_ID = "01f009af5a301a0683d008356f8f3289"
# MAGIC
# MAGIC
# MAGIC ###################################################
# MAGIC ## Create a GenieAgent with access to a Genie Space
# MAGIC ###################################################
# MAGIC
# MAGIC # TODO add GENIE_SPACE_ID and a description for this space
# MAGIC # You can find the ID in the URL of the genie room /genie/rooms/<GENIE_SPACE_ID>
# MAGIC #GENIE_SPACE_ID = ""
# MAGIC genie_agent_description = "This agent can answer questions from the Genie Space which links to Unity Catalog database"
# MAGIC
# MAGIC genie_agent = GenieAgent(
# MAGIC     genie_space_id="01f009af5a301a0683d008356f8f3289",
# MAGIC     genie_agent_name="Genie",
# MAGIC     description=genie_agent_description,
# MAGIC     # DB_MODEL_SERVING_HOST_URL is set on an agent endpoints but doesn't exist in the notebook
# MAGIC     client=WorkspaceClient(
# MAGIC         host=os.getenv("DATABRICKS_HOST") ,
# MAGIC         token=os.getenv("DATABRICKS_GENIE_PAT"),
# MAGIC     ),
# MAGIC
# MAGIC )
# MAGIC ############################################
# MAGIC # Define your LLM endpoint and system prompt
# MAGIC ############################################
# MAGIC
# MAGIC
# MAGIC LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
# MAGIC llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)
# MAGIC
# MAGIC ###############################################
# MAGIC # Create a chart agent
# MAGIC ################################################
# MAGIC
# MAGIC repl = PythonREPL()
# MAGIC
# MAGIC @tool
# MAGIC def python_repl_tool(
# MAGIC     code: Annotated[str, "The python code to execute code to generate charts."],
# MAGIC ):
# MAGIC     """Use this to execute python code and do math. If you want to see the output of a value,
# MAGIC     you should print it out with `print(...)`. This is visible to the user.
# MAGIC     To generate charts, you must use ONLY plotly express. The figure sizes should by 5 by 3. Select different colours and styles.
# MAGIC     """
# MAGIC     try:
# MAGIC         result = repl.run(code)
# MAGIC     except BaseException as e:
# MAGIC         return f"Failed to execute. Error: {repr(e)}"
# MAGIC     result_str = f"Successfully executed:\n```python\n{code}\n```\nCODE OUTPUT:\n {result}"
# MAGIC     return result_str
# MAGIC
# MAGIC
# MAGIC
# MAGIC chart_agent_description = ("The chart agent specializes in generating charts and visualizations with ONLY plotly express from the results from coding agent. Figure size should be 5 by 3. Select different colours and styles.")
# MAGIC
# MAGIC
# MAGIC chart_agent = create_react_agent(llm, 
# MAGIC                                  tools=[python_repl_tool], 
# MAGIC                                  state_modifier="""You are a coder who can write and run python code and also visualize charts and graphs with ONLY plotly express. Figure size should be 5 by 3.  Select different colours and styles. Only extract the most relevant data related to the question before running code or creating graphs.Once your task is done report back to the supervisor.
# MAGIC                                  
# MAGIC                                  """)
# MAGIC
# MAGIC
# MAGIC
# MAGIC #############################
# MAGIC # Define the supervisor agent
# MAGIC #############################
# MAGIC
# MAGIC # TODO update the max number of iterations between supervisor and worker nodes
# MAGIC # before returning to the user
# MAGIC MAX_ITERATIONS = 3
# MAGIC
# MAGIC worker_descriptions = {
# MAGIC     "Genie": genie_agent_description,
# MAGIC     "Charter": chart_agent_description,
# MAGIC }
# MAGIC
# MAGIC formatted_descriptions = "\n".join(
# MAGIC     f"- {name}: {desc}" for name, desc in worker_descriptions.items()
# MAGIC )
# MAGIC
# MAGIC system_prompt = f"Decide between routing between the following workers or ending the conversation if an answer is provided. \n{formatted_descriptions}"
# MAGIC options = ["FINISH"] + list(worker_descriptions.keys())
# MAGIC
# MAGIC
# MAGIC def supervisor_agent(state):
# MAGIC     count = state.get("iteration_count", 0) + 1
# MAGIC     print('iteration count', count)
# MAGIC     if count > MAX_ITERATIONS:
# MAGIC         return {"next_node": "FINISH"}
# MAGIC     
# MAGIC     class nextNode(BaseModel):
# MAGIC         next_node: Literal[tuple(options)]
# MAGIC
# MAGIC     preprocessor = RunnableLambda(
# MAGIC         lambda state: [{"role": "system", "content": system_prompt}] + state["messages"]
# MAGIC     )
# MAGIC     supervisor_chain = preprocessor | llm.with_structured_output(nextNode)
# MAGIC     next_node = supervisor_chain.invoke(state).next_node
# MAGIC     print(type(next_node), next_node)
# MAGIC     return {
# MAGIC         "iteration_count": count,
# MAGIC         "next_node": next_node
# MAGIC     }
# MAGIC
# MAGIC #######################################
# MAGIC # Define our multiagent graph structure
# MAGIC #######################################
# MAGIC
# MAGIC def agent_node(state, agent, name):
# MAGIC     result = agent.invoke(state)
# MAGIC     return {
# MAGIC         "messages": [
# MAGIC             {
# MAGIC                 "role": "assistant",
# MAGIC                 "content": result["messages"][-1].content,
# MAGIC                 "name": name,
# MAGIC             }
# MAGIC         ]
# MAGIC     }
# MAGIC
# MAGIC def final_answer(state):
# MAGIC     system_prompt = "Using only the content in the messages, respond to the user's question using the answer given by the other agents."
# MAGIC     preprocessor = RunnableLambda(
# MAGIC         lambda state: [{"role": "system", "content": system_prompt}] + state["messages"]
# MAGIC     )
# MAGIC     final_answer_chain = preprocessor | llm
# MAGIC     return {"messages": [final_answer_chain.invoke(state)]}
# MAGIC
# MAGIC class AgentState(ChatAgentState):
# MAGIC     next_node: str
# MAGIC     iteration_count: int
# MAGIC     #messages: Annotated[list, add_messages]
# MAGIC
# MAGIC
# MAGIC chart_node = functools.partial(agent_node, agent=chart_agent, name="Charter")
# MAGIC genie_node = functools.partial(agent_node, agent=genie_agent, name="Genie")
# MAGIC
# MAGIC workflow = StateGraph(AgentState)
# MAGIC workflow.add_node("Genie", genie_node)
# MAGIC workflow.add_node("Charter", chart_node)
# MAGIC workflow.add_node("supervisor", supervisor_agent)
# MAGIC workflow.add_node("final_answer", final_answer)
# MAGIC
# MAGIC workflow.set_entry_point("supervisor")
# MAGIC # We want our workers to ALWAYS "report back" to the supervisor when done
# MAGIC for worker in worker_descriptions.keys():
# MAGIC     workflow.add_edge(worker, "supervisor")
# MAGIC
# MAGIC # Let the supervisor decide which next node to go
# MAGIC workflow.add_conditional_edges(
# MAGIC     "supervisor",
# MAGIC     lambda x: x["next_node"],
# MAGIC     {**{k: k for k in worker_descriptions.keys()}, "FINISH": "final_answer"},
# MAGIC )
# MAGIC workflow.add_edge("final_answer", END)
# MAGIC
# MAGIC memory = MemorySaver()
# MAGIC multi_agent = workflow.compile(checkpointer=memory)
# MAGIC
# MAGIC
# MAGIC
# MAGIC class LangGraphChatAgent(ChatAgent):
# MAGIC     def __init__(self, agent: CompiledStateGraph):
# MAGIC         self.agent = agent
# MAGIC
# MAGIC     def predict(
# MAGIC         self,
# MAGIC         messages: list[ChatAgentMessage],
# MAGIC         context: Optional[ChatContext] = None,
# MAGIC         custom_inputs: Optional[dict[str, Any]] = None,
# MAGIC     ) -> ChatAgentResponse:
# MAGIC         request = {
# MAGIC             "messages": [m.model_dump_compat(exclude_none=True) for m in messages]
# MAGIC         }
# MAGIC
# MAGIC         messages = []
# MAGIC         for event in self.agent.stream(request, stream_mode="updates"):
# MAGIC             for node_data in event.values():
# MAGIC                 messages.extend(
# MAGIC                     ChatAgentMessage(**msg) for msg in node_data.get("messages", [])
# MAGIC                 )
# MAGIC         return ChatAgentResponse(messages=messages)
# MAGIC
# MAGIC     def predict_stream(
# MAGIC         self,
# MAGIC         messages: list[ChatAgentMessage],
# MAGIC         context: Optional[ChatContext] = None,
# MAGIC         custom_inputs: Optional[dict[str, Any]] = None,
# MAGIC     ) -> Generator[ChatAgentChunk, None, None]:
# MAGIC         request = {
# MAGIC             "messages": [m.model_dump_compat(exclude_none=True) for m in messages]
# MAGIC         }
# MAGIC        
# MAGIC         for event in self.agent.stream(request, stream_mode="updates"):
# MAGIC             for node_data in event.values():
# MAGIC                 yield from (
# MAGIC                     ChatAgentChunk(**{"delta": msg})
# MAGIC                     for msg in node_data.get("messages", [])
# MAGIC                 )
# MAGIC
# MAGIC     def call_conversational_agent(self, 
# MAGIC                                   prompt, 
# MAGIC                                   user_session_id, 
# MAGIC                                   verbose=False):
# MAGIC         events = self.agent.stream(
# MAGIC             {"messages": [{"role": "user", "content": prompt}]},
# MAGIC             {"configurable": {"thread_id": user_session_id}, "stream_mode": "values"}
# MAGIC         )
# MAGIC         print('Running Agent. Please wait..')
# MAGIC         for event in events:
# MAGIC             for node_data in event.values():
# MAGIC                 for msg in node_data.get("messages", []):
# MAGIC                     if verbose:
# MAGIC                         #print(msg.content)
# MAGIC                         display(Markdown(msg.get('content')))
# MAGIC                         #display(Markdown(msg.content))
# MAGIC
# MAGIC
# MAGIC # Create the agent object, and specify it as the agent object to use when
# MAGIC # loading the agent back for inference via mlflow.models.set_model()
# MAGIC mlflow.langchain.autolog()
# MAGIC AGENT = LangGraphChatAgent(multi_agent)
# MAGIC mlflow.models.set_model(AGENT)
# MAGIC

# COMMAND ----------

import re
#import PythonShell as pi
from IPython.display import Markdown, display, display_html

'''
def display_html(html: str) -> None:
    """
    Use databricks displayHTML from an external package
    
    Args:
    - html : html document to display
    """
    import inspect
    for frame in inspect.getouterframes(inspect.currentframe()):
        global_names = set(frame.frame.f_globals)
        # Use multiple functions to reduce risk of mismatch
        if all(v in global_names for v in ["displayHTML", "display", "spark"]):
            return frame.frame.f_globals["displayHTML"](html)
    raise EnvironmentError(
        "Unable to detect displayHTML function"
    )
'''

def call_conversational_agent(agent, 
                                  prompt, 
                                  user_session_id, 
                                  verbose=False):
        events = agent.stream(
            {"messages": [{"role": "user", "content": prompt}]},
            {"configurable": {"thread_id": user_session_id}, "stream_mode": "values"}
        )
        print('Running Agent. Please wait..')
        clean_code = None
        for event in events:
            for node_data in event.values():
                for msg in node_data.get("messages", []):
                    if verbose:
                        #print(msg.content)
                        code_match = re.search(r'```(?:[Pp]ython)?(.*?)```', msg.get('content'), re.DOTALL)
                        if code_match:
                            clean_code = code_match.group(1)
                        display(Markdown(msg.get('content')))
                        #display_html(msg.get('content'))

 
            
                       

# COMMAND ----------

import multiuser_agent
from IPython.display import Markdown, display, display_html
from langgraph.checkpoint.memory import MemorySaver
from IPython.display import HTML, display
from IPython import get_ipython

memory = MemorySaver()

multi_agent = multiuser_agent.workflow.compile(checkpointer=memory)

uid = 'john010'
#prompt = "Categorize age into groups of 3: 0-34, 35-66, > 67 then plot the results with appropriate chart" 
query = "Group DoseSeqp by subject count only, then plot with appropriate chart"
call_conversational_agent(
                         multi_agent,
                       prompt=query,
                          user_session_id=uid,
                          verbose=True)

# COMMAND ----------



# COMMAND ----------

from dash import Dash, html, dcc

import plotly.express as px
import pandas as pd

# Data
data = {
    'DOSESEQP': [160, 10, 80, 40],
    'subject_count': [14, 42, 18, 13]
}

df = pd.DataFrame(data)

# Plot
p = px.bar(df, x='DOSESEQP', y='subject_count', title='Subject Count by DOSESEQP', 
           labels={'DOSESEQP': 'Dose Sequence', 'subject_count': 'Subject Count'},
           color='DOSESEQP', height=300, width=500)

# Display
p_html = p.to_html(full_html=False, include_plotlyjs='cdn')
displayHTML(p_html)





#fig.show()

# COMMAND ----------


import multiuser_agent
from IPython.display import Markdown, display
from langgraph.checkpoint.memory import MemorySaver

multi_agent = multiuser_agent.multi_agent
AGENT = multiuser_agent.LangGraphChatAgent(multi_agent)

uid = 'john001'
#prompt = "Categorize age into groups of 3: 0-34, 35-66, > 67 then plot the results with #appropriate chart" 
query = "Group DoseSeqp by subject count only, then plot with appropriate chart"
#query = "then plot the results with appropriate chart"
#query  ="Categorize age into groups of 3: 0-34, 35-66, > 67 then display as a table"
#query = "plot the table with plotly express"
AGENT.call_conversational_agent(
                          prompt=query,
                          user_session_id=uid,
                          verbose=True)






# COMMAND ----------

# MAGIC %md
# MAGIC **Register to UCatalog**

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC **Test out Prediction**

# COMMAND ----------

mlflow.models.predict(
    model_uri=f"runs:/{logged_agent_info.run_id}/agent",
    input_data=input_example,
    env_manager="uv",
)

# COMMAND ----------

mlflow.set_registry_uri("databricks-uc")

# TODO: define the catalog, schema, and model name for your UC model
catalog = "edl_dev"
schema = "cbd_sandbox"
model_name = "pmed_ai_chat_v0"
UC_MODEL_NAME = f"{catalog}.{schema}.{model_name}"

# register the model to UC
uc_registered_model_info = mlflow.register_model(
    model_uri=logged_agent_info.model_uri, name=UC_MODEL_NAME
)

# COMMAND ----------

# MAGIC %md
# MAGIC **Deploy**

# COMMAND ----------

from databricks import agents
secret_scope_name = 'pmed_ai_genie_25'
secret_key_name = 'PMED_AI_GENIE'


agents.deploy(
    UC_MODEL_NAME,
    uc_registered_model_info.version,
    tags={"endpointSource": "docs"},
    environment_vars={
        "DATABRICKS_GENIE_PAT": f"{{{{secrets/{secret_scope_name}/{secret_key_name}}}}}"
    },
    budget_policy='aiwb_project_115_policy'
)