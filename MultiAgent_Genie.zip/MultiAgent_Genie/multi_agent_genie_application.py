# Databricks notebook source
# MAGIC %md
# MAGIC # Multi-agent system with Genie
# MAGIC

# COMMAND ----------

# MAGIC %pip install -U -qqq mlflow langgraph==0.3.4 databricks-langchain databricks-agents uv
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

#%%writefile agent.py
import functools
import os
from typing import Any, Generator, Literal, Optional

import mlflow
from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from databricks_langchain.genie import GenieAgent
from langchain_core.runnables import RunnableLambda
from langgraph.graph import END, StateGraph
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import create_react_agent
from mlflow.langchain.chat_agent_langgraph import ChatAgentState
from mlflow.pyfunc import ChatAgent
from mlflow.types.agent import (
    ChatAgentChunk,
    ChatAgentMessage,
    ChatAgentResponse,
    ChatContext,
)
from pydantic import BaseModel

# COMMAND ----------

# Set the variables

DATABRICKS_HOST = 'https://amgen-ai-dev.cloud.databricks.com/'
GENIE_SPACE_URL = "https://amgen-ai-dev.cloud.databricks.com/genie/rooms/01f009af5a301a0683d008356f8f3289?o=2249790853314266"

#https://amgen-ai-dev.cloud.databricks.com/genie/rooms/01f009af5a301a0683d008356f8f3289?o=2249790853314266

base_url="https://amgen-ai-dev.cloud.databricks.com/serving-endpoints"
api_key = "dapif3bc3b1e718c335b48f4c410b07c9c12"
model_name = "project-115-Precision_Medicine_AI_Agent-2"

os.environ['DATABRICKS_GENIE_PAT'] = api_key
os.environ['DATABRICKS_HOST'] = DATABRICKS_HOST
GENIE_SPACE_ID = "01f009af5a301a0683d008356f8f3289"
#workspaceUrl = spark.conf.get('spark.databricks.workspaceUrl')
#workspaceUrl = f"https://{workspaceUrl}"
#os.environ['DATABRICKS_HOST'] = workspaceUrl
#llm.invoke("What is the name of the program that is associated with the assay type 'HLA-DRB1'?")

# COMMAND ----------

DATABRICKS_HOST = 'https://amgen-ai-dev.cloud.databricks.com/'
GENIE_SPACE_URL = "https://amgen-ai-dev.cloud.databricks.com/genie/rooms/01f009af5a301a0683d008356f8f3289?o=2249790853314266"

#https://amgen-ai-dev.cloud.databricks.com/genie/rooms/01f009af5a301a0683d008356f8f3289?o=2249790853314266

base_url="https://amgen-ai-dev.cloud.databricks.com/serving-endpoints"
api_key = "dapif3bc3b1e718c335b48f4c410b07c9c12"
model_name = "project-115-Precision_Medicine_AI_Agent-2"

os.environ['DATABRICKS_GENIE_PAT'] = api_key
os.environ['DATABRICKS_HOST'] = DATABRICKS_HOST
GENIE_SPACE_ID = "01f009af5a301a0683d008356f8f3289"

###################################################
## Create a GenieAgent with access to a Genie Space
###################################################

# TODO add GENIE_SPACE_ID and a description for this space
# You can find the ID in the URL of the genie room /genie/rooms/<GENIE_SPACE_ID>
#GENIE_SPACE_ID = ""
genie_agent_description = "This agent can answer questions from the Genie Space which links to database containing Study/Subject, Assay type, Program/Product, Response time, response feedback"

genie_agent = GenieAgent(
    genie_space_id=GENIE_SPACE_ID,
    genie_agent_name="Genie",
    description=genie_agent_description,
    # DB_MODEL_SERVING_HOST_URL is set on an agent endpoints but doesn't exist in the notebook
    client=WorkspaceClient(
        host=os.getenv("DATABRICKS_HOST") ,
        token=os.getenv("DATABRICKS_GENIE_PAT"),
    ),
)
############################################
# Define your LLM endpoint and system prompt
############################################

#llm = ChatDatabricks(model=model_name, streaming=False, base_url=base_url, api_key=api_key,   #max_tokens=3000)
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME)

# COMMAND ----------

############################################################
# Create a code agent
# You can also create agents with access to additional tools
############################################################
tools = []

# TODO if desired, add additional tools and update the description of this agent
uc_tool_names = ["ai_dev.aiwb_115_cbd_sandbox.*"]
uc_toolkit = UCFunctionToolkit(function_names=uc_tool_names)
tools.extend(uc_toolkit.tools)
code_agent_description = (
    "The Coder agent specializes in solving programming challenges, generating code snippets, debugging issues, and explaining complex coding concepts.",
)
code_agent = create_react_agent(llm, tools=tools)

#############################
# Define the supervisor agent
#############################

# TODO update the max number of iterations between supervisor and worker nodes
# before returning to the user
MAX_ITERATIONS = 3

worker_descriptions = {
    "Genie": genie_agent_description,
    "Coder": code_agent_description,
}

formatted_descriptions = "\n".join(
    f"- {name}: {desc}" for name, desc in worker_descriptions.items()
)

system_prompt = f"Decide between routing between the following workers or ending the conversation if an answer is provided. \n{formatted_descriptions}"
options = ["FINISH"] + list(worker_descriptions.keys())


def supervisor_agent(state):
    count = state.get("iteration_count", 0) + 1
    print('iteration count', count)
    if count > MAX_ITERATIONS:
        return {"next_node": "FINISH"}
    
    class nextNode(BaseModel):
        next_node: Literal[tuple(options)]

    preprocessor = RunnableLambda(
        lambda state: [{"role": "system", "content": system_prompt}] + state["messages"]
    )
    supervisor_chain = preprocessor | llm.with_structured_output(nextNode)
    next_node = supervisor_chain.invoke(state).next_node
    print(type(next_node), next_node)
    return {
        "iteration_count": count,
        "next_node": next_node
    }

# COMMAND ----------

#######################################
# Define our multiagent graph structure
#######################################


def agent_node(state, agent, name):
    result = agent.invoke(state)
    return {
        "messages": [
            {
                "role": "assistant",
                "content": result["messages"][-1].content,
                "name": name,
            }
        ]
    }
def final_answer(state):
    system_prompt = "Using only the content in the messages, respond to the user's question using the answer given by the other agents."
    preprocessor = RunnableLambda(
        lambda state: [{"role": "system", "content": system_prompt}] + state["messages"]
    )
    final_answer_chain = preprocessor | llm
    return {"messages": [final_answer_chain.invoke(state)]}

class AgentState(ChatAgentState):
    next_node: str
    iteration_count: int


code_node = functools.partial(agent_node, agent=code_agent, name="Coder")
genie_node = functools.partial(agent_node, agent=genie_agent, name="Genie")

workflow = StateGraph(AgentState)
workflow.add_node("Genie", genie_node)
workflow.add_node("Coder", code_node)
workflow.add_node("supervisor", supervisor_agent)
workflow.add_node("final_answer", final_answer)

workflow.set_entry_point("supervisor")
# We want our workers to ALWAYS "report back" to the supervisor when done
for worker in worker_descriptions.keys():
    workflow.add_edge(worker, "supervisor")

# Let the supervisor decide which next node to go
workflow.add_conditional_edges(
    "supervisor",
    lambda x: x["next_node"],
    {**{k: k for k in worker_descriptions.keys()}, "FINISH": "final_answer"},
)
workflow.add_edge("final_answer", END)
multi_agent = workflow.compile()

# COMMAND ----------

from IPython.display import display, Image

#display(Image(multi_agent.get_graph().draw_mermaid_png(verify_ssl=False)))

# COMMAND ----------

###################################
# Wrap our multi-agent in ChatAgent
###################################


class LangGraphChatAgent(ChatAgent):
    def __init__(self, agent: CompiledStateGraph):
        self.agent = agent

    def predict(
        self,
        messages: list[ChatAgentMessage],
        context: Optional[ChatContext] = None,
        custom_inputs: Optional[dict[str, Any]] = None,
    ) -> ChatAgentResponse:
        request = {
            "messages": [m.model_dump_compat(exclude_none=True) for m in messages]
        }

        messages = []
        for event in self.agent.stream(request, stream_mode="updates"):
            for node_data in event.values():
                messages.extend(
                    ChatAgentMessage(**msg) for msg in node_data.get("messages", [])
                )
        return ChatAgentResponse(messages=messages)

    def predict_stream(
        self,
        messages: list[ChatAgentMessage],
        context: Optional[ChatContext] = None,
        custom_inputs: Optional[dict[str, Any]] = None,
    ) -> Generator[ChatAgentChunk, None, None]:
        request = {
            "messages": [m.model_dump_compat(exclude_none=True) for m in messages]
        }
        for event in self.agent.stream(request, stream_mode="updates"):
            for node_data in event.values():
                yield from (
                    ChatAgentChunk(**{"delta": msg})
                    for msg in node_data.get("messages", [])
                )

# COMMAND ----------

# Create the agent object, and specify it as the agent object to use when
# loading the agent back for inference via mlflow.models.set_model()
mlflow.langchain.autolog()
AGENT = LangGraphChatAgent(multi_agent)
mlflow.models.set_model(AGENT)

# COMMAND ----------

input_example = {"messages": [{"role": "user", "content": "Explain the datasets and capabilities that the Genie agent has access to."}]}
AGENT.predict(input_example)

# COMMAND ----------



# COMMAND ----------


