import requests
from flask import request
 
user_email = request.headers.get("X-Forwarded-Email")
user_token = request.headers.get("X-Forwarded-Access-Token")
 
headers = {

    "X-Forwarded-Email": user_email,

    "X-Forwarded-Access-Token": user_token

}
 
response = requests.get(

    "https://biolojinn-test-2249790853314266.aws.databricksapps.com/",

    headers=headers

)
print(response)


 