#from langchain_core.messages import HumanMessage
import genie_agent
import gradio as gr
import pandas as pd
import numpy as np
import random

def call_conversational_agent(agent, prompt, user_session_id, verbose=False):
    events = agent.stream(
        {"messages":[{"role": "user", "content": prompt}]},
        {"configurable": {"thread_id": user_session_id}},
        stream_mode = "values",
    )
    print('Running Agent. Please wait...')
    for event in events:
        if verbose:
            event["messages"][-1].pretty_print()






compiled_flow = genie_agent.compiled_graph_wo_memory

def predict(message, history):
    #history.append({"role": "user", "content": message})
    chunks = []
    for event in compiled_flow.stream(
                        {"messages":[{"role": "user", "content": message}]},
                        stream_mode='values' ):
      chunks.append(event["messages"][-1].content or "")
      yield "".join(chunks)
      
    return 

#uid = 'frank008'
#query = 'Aggregate the average Age by DoseSeqp only, then visualize the data'
#query = 'Please visualize the data'
#call_conversational_agent(compiled_flow, 
#                          prompt=query, 
#                          user_session_id=uid, 
#                          verbose=True)


#df = pd.DataFrame({
#    'height': np.random.randint(50, 70, 25),
#    'weight': np.random.randint(120, 320, 25),
#    'age': np.random.randint(18, 65, 25),
##    'ethnicity': [random.choice(["white", "black", "asian"]) for _ in range(25)]
#})


#with gr.Blocks() as demo:
#    gr.LinePlot(df, x="weight", y="height")


demo = gr.ChatInterface(
    predict,
    type="messages"
)
demo.launch(debug=True)
