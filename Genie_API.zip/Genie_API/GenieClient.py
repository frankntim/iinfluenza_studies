# Databricks notebook source
import json
import requests

# COMMAND ----------


base_url="https://amgen-ai-dev.cloud.databricks.com/serving-endpoints"
api_key = "dapif3bc3b1e718c335b48f4c410b07c9c12"
host  ="https://amgen-ai-dev.cloud.databricks.com"
model_name = "project-115-Precision_Medicine_AI_Agent-2"

genie_token = 'dapif3bc3b1e718c335b48f4c410b07c9c12'
host  ="https://amgen-ai-dev.cloud.databricks.com"
 
space_id = '01f009af5a301a0683d008356f8f3289'

# Genie Space ID
#https://amgen-ai-dev.cloud.databricks.com/genie/rooms/01f009af5a301a0683d008356f8f3289?#o=2249790853314266
#Genie Space ID = 01f009af5a301a0683d008356f8f3289
#OR = 2249790853314266

# COMMAND ----------


 
url = f"{host}/api/2.0/genie/spaces/{space_id}"
 
headers = {
    "Authorization": f"Bearer {genie_token}"
}
 
response = requests.get(url, headers=headers)
 
print(response.json())

# COMMAND ----------




# COMMAND ----------

conversation_messages = [{"content": "Return distribution of subject ages less than 30 years of age, between 31 and 47 years of age, and 48 and 60 years of age, and 61 and 78 years of age"},
                         {"content": "Return the dose escalation vs CD8"}]

# COMMAND ----------

def get_conversation_id():

    #url = f"{host}/api/2.0/genie/spaces/{space_id}/start-conversation"
    url = "https://amgen-ai-dev.cloud.databricks.com/api/2.0/genie/spaces/01f009af5a301a0683d008356f8f3289/start-conversation"
    
    headers = {
        "Authorization": f"Bearer {genie_token}",
        "Content-Type": "application/json"
        }
    
    contents = {
    "content": "Begin analyzing subject biomarker data"
    }
    
    response = requests.post(url, headers=headers, json=contents)
    response.json()['message_id']
    conversation_id = response.json()['message']['conversation_id']

    return conversation_id
conversation_id = get_conversation_id()

print(conversation_id)

# COMMAND ----------

url = f"{host}/api/2.0/genie/spaces/{space_id}/conversations/{conversation_id}/messages"

headers = {
    "Authorization": f"Bearer {genie_token}",
    "Content-Type": "application/json"
    }
 
contents = {
  "content": "Return the dose escalation vs CD8"
}
 
response = requests.post(url, headers=headers, json=contents)
 
#print(response.json())
message_id = response.json()['message_id']
message_id

# COMMAND ----------

url = f"{host}/api/2.0/genie/spaces/{space_id}/conversations/{conversation_id}/messages/{message_id}"
 
headers = {
    "Authorization": f"Bearer {genie_token}"
}
response = requests.get(url, headers=headers)
print(response.json())

# COMMAND ----------

response.json()

# COMMAND ----------

from IPython.display import Markdown
#display(Markdown(response.json()['attachments'][0]['query']['query']))

#print(response.json()['attachments'][0]['query']['query'])
#print(response.json()['attachments'][0]['attachment_id'])
attachment_id = response.json()['attachments'][0]['attachment_id']
attachment_id

# COMMAND ----------

#POST /api/2.0/genie/spaces/{space_id}/conversations/{conversation_id}/messages/{message_id}/attachments/{attachment_id}/execute-query
 
#url = f"{host}/api/2.0/genie/spaces/{space_id}/conversations/{conversation_id}/messages/3#{message_id}/attachments/{attachment_id}/execute-query"
 
#headers = {
 #   "Authorization": f"Bearer {genie_token}",
  #  "Content-Type": "application/json"
   # }
 
response = requests.post(url, headers=headers)
print(response.json())

# COMMAND ----------

#/api/2.0/genie/spaces/{space_id}/conversations/{conversation_id}/messages/{message_id}/#attachments/{attachment_id}/query-result
 
url = f"{host}/api/2.0/genie/spaces/{space_id}/conversations/{conversation_id}/messages/{message_id}/attachments/{attachment_id}/query-result"
 
headers = {
    "Authorization": f"Bearer {genie_token}"
    }
 
response = requests.get(url, headers=headers)
print(response.json())  

# COMMAND ----------

response.json()

# COMMAND ----------

import pandas as pd
dataset = response.json()['statement_response']['result']['data_array']
df = pd.DataFrame(dataset)
df.head()

# COMMAND ----------

features_0 = response.json()['statement_response']['manifest']['schema']['columns'][0]['name']
features_1 = response.json()['statement_response']['manifest']['schema']['columns'][1]['name']
features = [features_0, features_1]

# COMMAND ----------

df.columns = features
   

# COMMAND ----------

df['DOSETARN'].value_counts()

# COMMAND ----------

# MAGIC %md
# MAGIC **Genie API/Agent**

# COMMAND ----------

# MAGIC %pip install -U -qqq mlflow langgraph==0.3.4 langchain-experimental==0.3.4 databricks-langchain databricks-agents langgraph-checkpoint-sqlite transformers uv
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

dbutils.library.restartPython()


# COMMAND ----------

# MAGIC %md
# MAGIC Genie API/Agent

# COMMAND ----------

import functools
import os
from typing import Any, Generator, Literal, Optional

import mlflow
from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from databricks_langchain.genie import GenieAgent
from langchain_core.runnables import RunnableLambda
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import create_react_agent
from mlflow.langchain.chat_agent_langgraph import ChatAgentState
from mlflow.pyfunc import ChatAgent
from mlflow.types.agent import (
    ChatAgentChunk,
    ChatAgentMessage,
    ChatAgentResponse,
    ChatContext,
)
from pydantic import BaseModel

from langchain_experimental.utilities import PythonREPL
from langchain_core.tools import tool
from langchain_core.messages import trim_messages
from langgraph.checkpoint.memory import MemorySaver
from typing import Annotated
import plotly.graph_objects as go #To uPse the Plotly library to create the graph
import plotly.express as px #To use the Plotly Express library to create the graph
import seaborn as sns
#from plotnine import ggplot, aes, geom_line, geom_bar

# COMMAND ----------

GENIE_SPACE_ID = '01f009af5a301a0683d008356f8f3289'
genie_agent_description = "This agent can answer questions from the Genie Space which links to Unity Catalog database"
 
DATABRICKS_GENIE_PAT = "dapif3bc3b1e718c335b48f4c410b07c9c12"
DATABRICKS_HOST  ="https://amgen-ai-dev.cloud.databricks.com"
client = WorkspaceClient(
    host=DATABRICKS_HOST ,
    token=DATABRICKS_GENIE_PAT
)
 
#genie_agent = GenieAgent(
#    genie_space_id=GENIE_SPACE_ID,
#    genie_agent_name="Genie",
#    description=genie_agent_description,
#    client=client,
#)
 
def ask_genie_with_metadata(prompt: str):
    raw_response = client.genie.start_conversation(
        space_id=GENIE_SPACE_ID,
        content=prompt
    ).result()
 
    return {
        "raw": raw_response
    }

# COMMAND ----------

prompt = 'aggregate the DoseSeqp by subject Age'
#prompt = 'what is the min age of subjects'
#prompt = 'Return the dose escalation vs CD8'

# COMMAND ----------

response = ask_genie_with_metadata(prompt)

# COMMAND ----------

response

# COMMAND ----------

message_id_id  = response['raw'].id
space_id = response['raw'].space_id
conversation_id = response['raw'].conversation_id
question_content = response['raw'].content
attachment_id = response['raw'].attachments[0].attachment_id
query_description = response['raw'].attachments[0].query.description
query= response['raw'].attachments[0].query.query
statement_id = response['raw'].query_result.statement_id
status = response['raw'].status


# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC **Agentic AI**

# COMMAND ----------

# MAGIC %pip install -U -qqq mlflow langgraph==0.3.4 langchain-experimental==0.3.4 databricks-langchain databricks-agents langgraph-checkpoint-sqlite transformers uv
# MAGIC dbutils.library.restartPython()
# MAGIC

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

import json
import requests
import functools
import pandas as pd
import numpy as np
import os
from typing import Any, Generator, Literal, Optional
from typing_extensions import TypedDict

import mlflow
from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from databricks_langchain.genie import GenieAgent
from langchain_core.runnables import RunnableLambda
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import create_react_agent, ToolNode, tools_condition
from mlflow.langchain.chat_agent_langgraph import ChatAgentState
from mlflow.pyfunc import ChatAgent
from mlflow.types.agent import (
    ChatAgentChunk,
    ChatAgentMessage,
    ChatAgentResponse,
    ChatContext,
)
from pydantic import BaseModel

from langchain_experimental.utilities import PythonREPL
from langchain_core.tools import tool
from langchain_core.messages import trim_messages, SystemMessage
from langgraph.checkpoint.memory import MemorySaver
from typing import Annotated
import plotly.graph_objects as go #To uPse the Plotly library to create the graph
import plotly.express as px #To use the Plotly Express library to create the graph
import seaborn as sns
#from plotnine import ggplot, aes, geom_line, geom_bar

# COMMAND ----------




GENIE_SPACE_ID = '01f009af5a301a0683d008356f8f3289'
 
DATABRICKS_GENIE_PAT = "dapif3bc3b1e718c335b48f4c410b07c9c12"
DATABRICKS_HOST  ="https://amgen-ai-dev.cloud.databricks.com"
client = WorkspaceClient(
    host=DATABRICKS_HOST ,
    token=DATABRICKS_GENIE_PAT
)
 


@tool
def get_data_from_genie(prompt: str):
    """Retrieve data from Genie based on the prompt request"""

    def get_conversation_metadata_from_genie(prompt: str):
        raw_response = client.genie.start_conversation(
            space_id=GENIE_SPACE_ID,
            content=prompt
        ).result()
    
        return {
            "raw": raw_response
        }


    genie_token = 'dapif3bc3b1e718c335b48f4c410b07c9c12'
    host  ="https://amgen-ai-dev.cloud.databricks.com"

    response = get_conversation_metadata_from_genie(prompt)

    message_id  = response['raw'].id
    space_id = response['raw'].space_id
    conversation_id = response['raw'].conversation_id
    question_content = response['raw'].content
    attachment_id = response['raw'].attachments[0].attachment_id
    query_description = response['raw'].attachments[0].query.description
    sql_query= response['raw'].attachments[0].query.query
    statement_id = response['raw'].query_result.statement_id
    status = response['raw'].status


    # Use Metadata to create get prompt results
    url = f"{host}/api/2.0/genie/spaces/{space_id}/conversations/{conversation_id}/messages/{message_id}/attachments/{attachment_id}/query-result"
 
    headers = {
        "Authorization": f"Bearer {genie_token}"
        }
    
    results = requests.get(url, headers=headers)
     

    # Parse the data into a dataframe
    row_count = results.json()['statement_response']['manifest']['total_row_count']
    data = results.json()['statement_response']['result']['data_array']
    data_df = pd.DataFrame(data)
    if row_count > 30:
        data_df = data_df.head(10)
    
    # Parse the columns into a list
    col_count = results.json()['statement_response']['manifest']['schema']['column_count']
    if col_count > 0 :
        col_list_of_dict = results.json()['statement_response']['manifest']['schema']['columns']
        feature_list = []
        for element in col_list_of_dict:
            a = [element[key] for key in element if key=='name']
            feature_list.extend(a)

        data_df.columns =feature_list

    output = (query_description + """:\n\n """ + 
          data_df.to_markdown() + 
          """ \n\n """ + sql_query)


    return output

# COMMAND ----------

AGENT_SYS_PROMP = """Role: You are biomarker assistant tasked with providing up-to-date information about the clinical trial data. 

Objective: Assist data-driven researchers by giving accurate information about the clinical trial data solely from GenieClient.

Capabilities: You have been given a tool called get_data_from_genie. Please retrieve your data from this tool. Do not construct any query.
"""

# COMMAND ----------

class State(TypedDict):
    messages: Annotated[list, add_messages]

graph_builder = StateGraph(State)

tools = [get_data_from_genie]

#llm = ChatDatabricks(model="gpt-4", temperature=0)
#llm = ChatOpenAI(model=model_name,    streaming=False,    base_url=base_url,   #api_key=api_key,    max_tokens=3000)

#import pandas as pd
#from langchain_openai import ChatOpenAI
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

llm_with_tools = llm.bind_tools(tools)

SYS_MSG = SystemMessage(content=AGENT_SYS_PROMP)

def chatbot(state: State):
    messages = trim_messages(state["messages"], 
                             strategy='last', 
                             max_tokens=1000,
                             #token_counter=ChatDatabricks(model="gpt-4"),
                             token_counter=llm,
                             include_system=True,
                             allow_partial=True)
    return {"messages": [llm_with_tools.invoke([SYS_MSG] + messages)]}
 
graph_builder.add_node("chatbot", chatbot)

tool_node = ToolNode(tools = tools)
graph_builder.add_node('tools', tool_node)

graph_builder.add_conditional_edges('chatbot', 
                                    tools_condition, 
                                    ['tools', END]
                                    )
graph_builder.add_edge('tools', 'chatbot')
graph_builder.set_entry_point('chatbot')

memory = MemorySaver()

compiled_graph = graph_builder.compile(checkpointer=memory)

# COMMAND ----------

from IPython.display import Markdown, display, Image


# COMMAND ----------

def call_conversational_agent(agent, prompt, user_session_id, verbose=False):
    events = agent.stream(
        {"messages":[{"role": "user", "content": prompt}]},
        {"configurable": {"thread_id": user_session_id}},
        stream_mode = "values",
    )
    print('Running Agent. Please wait...')
    for event in events:
        if verbose:
            event["messages"][-1].pretty_print()
    display(Markdown(event["messages"][-1].content))
    

# COMMAND ----------

#prompt = 'Aggregate the average Age by Gender only'
#prompt = 'What is the minimum age of subjects'
#result = get_data_from_genie(prompt)


# COMMAND ----------

uid = 'frank002'
query = 'Aggregate the average Age by DoseSeqp only'
call_conversational_agent(compiled_graph, 
                          prompt=query, 
                          user_session_id=uid, 
                          verbose=True)