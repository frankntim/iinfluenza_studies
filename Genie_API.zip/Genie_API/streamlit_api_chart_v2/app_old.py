import streamlit as st
import json
from langchain.prompts import ChatPromptTemplate
from genie_room import genie_query, clear_conversation #, CHART_PROMPT,LLM
from plotting_tool import general_plotting_agent, get_plotting_agent
import pandas as pd
import sqlparse
import uuid
import plotly.graph_objects as go
import re
import plotly.express as px
from requests.exceptions import Timeout, RequestException
from langchain_core.messages import SystemMessage, HumanMessage
import requests




#==========Functions

def format_sql_query(sql_query):
    """Format SQL query using sqlparse library"""
    formatted_sql = sqlparse.format(
        sql_query,
        keyword_case='upper',  # Makes keywords uppercase
        identifier_case=None,  # Preserves identifier case
        reindent=True,         # Adds proper indentation
        indent_width=2,        # Indentation width
        strip_comments=False,  # Preserves comments
        comma_first=False      # Commas at the end of line, not beginning
    )
    return formatted_sql


def get_fig_from_code(code):
    local_variables = {}
    exec(code, {}, local_variables)
    return local_variables['fig']

st.write('<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">',unsafe_allow_html=True)


def main():
    """Main Streamlit application"""
    st.set_page_config(
        page_title="PMed Conversational AI Chatbot",
        page_icon="assets/genie_logo.png",
        layout="wide"
    )
    LOGO_L = "assets/genie_logo.png"
    LOGO_S = "assets/genie_logo.png"
    st.logo(LOGO_L, icon_image=LOGO_S)

    st.image(LOGO_L)
    st.title("PMed Conversational AI Chatbot")
    st.markdown("""
    Analyze your Biomarker Clinical Trial leveraging AI/BI Dashboard. Deep dive into your data and metrics.
    """)
    
    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []
    
    # Display chat messages from history on app rerun
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    
    # Accept user input
    if prompt := st.chat_input("Ask your question..."):
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        # Display user message in chat message container
        with st.chat_message("user"):
            st.markdown(prompt)
        
        # Display assistant response in chat message container
        with st.chat_message("assistant", avatar='🧬'):
            with st.spinner("Wait for Genie..."):
                message_placeholder = st.empty()
                full_response = ""
                
                try:
                    # Pass the session_id to genie_query to maintain conversation context
                    session_id = str(uuid.uuid4())

                    response, query_text,result_description = genie_query(prompt, session_id)
                        
                    if isinstance(response, str) and "Your request is already being processed" in response:
                        pass
                    
                    if isinstance(response, str):
                        response = response.replace("`", "")
                        full_response += response
                        message_placeholder.markdown(full_response)
                    else:
                        full_response += result_description
                        message_placeholder.markdown(full_response)
                        full_response += response
                        st.dataframe(response)
                        full_response += query_text
                        st.code(query_text,language="SQL",wrap_lines=True)

                        fig, plot_description = get_plotting_agent(response,  result_description, prompt)
                        st.plotly_chart(fig, use_container_width=True)
                    
                            
                except Exception as err:
                    full_response += str(err)
                    message_placeholder.markdown(full_response)
                finally:
                    # Add assistant response to chat history
                    st.session_state.messages.append({"role": "assistant", "content": full_response})
    
    # Add sidebar with information
    with st.sidebar:
        st.header("About")
        st.markdown("""
        Conversation History.
        
        
        **Sample Questions:**
        - Show me the average age by dose sequence
        - Create a bar chart of patient age distribution
        - Visualize the relationship between dose sequence and age
        """)
        
        st.divider()
        st.caption("Built with Streamlit, LangGraph, and Plotly")

if __name__ == "__main__":
    main()