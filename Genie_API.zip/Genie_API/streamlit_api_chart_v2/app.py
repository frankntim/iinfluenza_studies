import streamlit as st
#from rag_pubmed import rag_medical_explanation
import pathlib
from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
import json
from langchain.prompts import ChatPromptTemplate
from genie_room import genie_query, clear_conversation #, CHART_PROMPT,LLM
from plotting_tool import general_plotting_agent, get_plotting_agent
import pandas as pd
import sqlparse
import uuid
import plotly.graph_objects as go
import re
import plotly.express as px
from requests.exceptions import Timeout, RequestException
from langchain_core.messages import SystemMessage, HumanMessage
import requests

################################ CSS ############################################
def inject_css(file_path):
    with open(file_path) as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

inject_css("assets/style.css")
#################################### Functions #############################
#==========Functions

def format_sql_query(sql_query):
    """Format SQL query using sqlparse library"""
    formatted_sql = sqlparse.format(
        sql_query,
        keyword_case='upper',  # Makes keywords uppercase
        identifier_case=None,  # Preserves identifier case
        reindent=True,         # Adds proper indentation
        indent_width=2,        # Indentation width
        strip_comments=False,  # Preserves comments
        comma_first=False      # Commas at the end of line, not beginning
    )
    return formatted_sql


def get_fig_from_code(code):
    local_variables = {}
    exec(code, {}, local_variables)
    return local_variables['fig']

############################ Streamlit ########################################
LOGO_L = "assets/genie_logo.png"
LOGO_S = "assets/genie_logo.png"
st.logo(LOGO_L, icon_image=LOGO_S)

st.image(LOGO_L)
st.title("PMed Conversational AI Chatbot")
st.markdown("""
    Analyze your Biomarker Clinical Trial leveraging AI/BI Dashboard. Deep dive into your data and metrics.
    """)

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

user_avatar = "🧑‍⚕️"
assistant_avatar = "🧬"

#st.markdown('<div id="main-container"><div id="chat-area">', unsafe_allow_html=True)
for msg in st.session_state.chat_history:
    with st.chat_message("user", avatar=user_avatar):
        st.markdown(msg["query"])
    with st.chat_message("assistant", avatar=assistant_avatar):
        result_description, response_str_dict = msg["response"].split("**Dataframe**:")
        st.markdown(result_description, unsafe_allow_html=True)
        #dict_from_string = eval(response_str_dict)
        #st.dataframe(dict_from_string)  
st.markdown('</div></div>', unsafe_allow_html=True)

user_input = st.chat_input("Ask a medical question…")
if user_input:
    with st.chat_message("user", avatar=user_avatar):
        st.markdown(user_input)
    with st.chat_message("assistant", avatar=assistant_avatar):
    #with st.spinner("🔍 Searching…"):
        
        #with st.chat_message("assistant", avatar=assistant_avatar): # Swap
        with st.spinner("🔍 Thinking…"):
            try:
                session_id = str(uuid.uuid4())
                response, query_text, result_description = genie_query(user_input, session_id) 
                if isinstance(response, str) and "Your request is already being processed" in response:
                    pass
                if isinstance(response, str):
                    response = response.replace("`", "")
                    response_full = f"{result_description}\n\n**Response**:\n" + "\n".join(response)
                    #st.markdown(result_description.strip(), unsafe_allow_html=True)
                    st.markdown(result_description, unsafe_allow_html=True)
                    #st.markdown(response.strip(), unsafe_allow_html=True)
                    st.markdown(response, unsafe_allow_html=True)
                    st.session_state.chat_history.append({"query": user_input, "response": response_full})
                else:
                    response_full = f"{result_description}\n\n**Dataframe**:\n" + "\n".join(str(response.to_dict(orient='records')))
                    #st.markdown(result_description.strip(), unsafe_allow_html=True)
                    st.markdown(result_description, unsafe_allow_html=True)
                    st.dataframe(response)
                    st.session_state.chat_history.append({"query": user_input, "response": response_full})
                    st.code(query_text,language="SQL",wrap_lines=True)

                    fig, plot_description = get_plotting_agent(response,  result_description, user_input)

                    if fig.data:
                        st.plotly_chart(fig, use_container_width=True)
                        st.markdown(plot_description, unsafe_allow_html=True)
                    else:
                        st.markdown("The LLM cannot generate plot")

                    # Plot the graph

            except Exception as err:
                st.markdown(str(err), unsafe_allow_html=True)
        