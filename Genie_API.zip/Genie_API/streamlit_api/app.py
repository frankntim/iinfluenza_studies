"""
Combined Biomarker Clinical Trial Assistant Application
This single file combines all the functionality from the modular app
including the Streamlit interface, LangGraph agent, tools, and prompts.
"""

import streamlit as st
import time
import re
import os
import sqlparse
import pandas as pd
from dotenv import load_dotenv
from typing import Annotated
from typing_extensions import TypedDict
from genie_room import genie_query, clear_conversation

# LangChain imports
#from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage, HumanMessage

# LangGraph imports
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition
from langgraph.checkpoint.memory import MemorySaver


import json
import requests
import functools
import pandas as pd
import numpy as np
import os
from typing import Any, Generator, Literal, Optional
from typing_extensions import TypedDict

import mlflow
from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from databricks_langchain.genie import GenieAgent
from langchain_core.runnables import RunnableLambda
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import create_react_agent, ToolNode, tools_condition
from mlflow.langchain.chat_agent_langgraph import ChatAgentState
from mlflow.pyfunc import ChatAgent
from mlflow.types.agent import (
    ChatAgentChunk,
    ChatAgentMessage,
    ChatAgentResponse,
    ChatContext,
)
from pydantic import BaseModel

from langchain_experimental.utilities import PythonREPL
from langchain_core.tools import tool
from langchain_core.messages import trim_messages, SystemMessage
from langgraph.checkpoint.memory import MemorySaver
from typing import Annotated
import plotly.graph_objects as go #To uPse the Plotly library to create the graph
import plotly.express as px #To use the Plotly Express library to create the graph




#load_dotenv()

# Load environment variables
#GENIE_SPACE_ID = os.environ.get("SPACE_ID")
#DATABRICKS_HOST = os.environ.get("DATABRICKS_HOST")
#DATABRICKS_HOST_URL = f"https://{DATABRICKS_HOST}"
#DATABRICKS_TOKEN = os.environ.get("DATABRICKS_TOKEN")
#LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"

##################################3
# Change this line

GENIE_SPACE_ID = "01f009af5a301a0683d008356f8f3289"
DATABRICKS_TOKEN = "dapif3bc3b1e718c335b48f4c410b07c9c12"
#POSIT_DEMO_KEY = "KPK5PphoGu53tPqMOQ58OxFkwRcO9Crc"
DATABRICKS_HOST_URL  ="https://amgen-ai-dev.cloud.databricks.com"
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"


#----------functions---------
def format_sql_query(sql_query):
    """Format SQL query using sqlparse library"""
    formatted_sql = sqlparse.format(
        sql_query,
        keyword_case='upper',  # Makes keywords uppercase
        identifier_case=None,  # Preserves identifier case
        reindent=True,         # Adds proper indentation
        indent_width=2,        # Indentation width
        strip_comments=False,  # Preserves comments
        comma_first=False      # Commas at the end of line, not beginning
    )
    return formatted_sql


#---------- PROMPTS ----------#
AGENT_SYS_PROMP = """
Role: You are biomarker assistant tasked with providing up-to-date information about the clinical trial data.

Objective: Assist data-driven researchers by giving accurate information about the clinical trial data.

Capabilities: You have been given a tool called get_data_from_genie. Please retrieve your data only from this tool. Do not construct any query.

Next Steps: When asked to visualize data, provide Python code using Plotly Express to generate charts. 
The plotting figure sizes should be 5 by 3. Select different colours and styles.
Include all necessary imports in your code snippets.
"""

#---------- TOOLS ----------#
@tool
def get_data_from_database(prompt: str):
    """Retrieve data from database on the prompt request"""
    
    query_description = '''This analysis provides the average age of participants,
    categorized by their dose sequence. The results focus on groups
    where the dose sequence is specified, allowing for insights into age distribution across different dosing protocols.
    '''
    
    # Pass the session_id to genie_query to maintain conversation context
    session_id = "1234567890"
    response, query_text = genie_query(prompt, session_id)

    if isinstance(response, str):
        response = response.replace("`", "")
        data  = response
    else:
        data = response.to_markdown()

    sql_query = format_sql_query(query_text)

    
    
    output = (query_description + """:\n\n """ +
        data +
        """ \n\n """ + sql_query)
    return output


#---------- MAIN AGENT SETUP ----------#
class State(TypedDict):
    messages: Annotated[list, add_messages]

def setup_agent():
    """Set up and return the LangGraph agent for text-to-SQL queries"""
    graph_builder = StateGraph(State)
    
    tools = [get_data_from_database]
    

    llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)
    llm_with_tools = llm.bind_tools(tools)
    
    SYS_MSG = SystemMessage(content=AGENT_SYS_PROMP)
    
    def chatbot(state: State):
        return {"messages": [llm_with_tools.invoke([SYS_MSG] + state["messages"])]}
    
    graph_builder.add_node("chatbot", chatbot)
    
    tool_node = ToolNode(tools=tools)
    graph_builder.add_node('tools', tool_node)
    graph_builder.add_conditional_edges('chatbot',
                                        tools_condition,
                                        ['tools', END])
    graph_builder.add_edge('tools', 'chatbot')
    graph_builder.set_entry_point('chatbot')
    
    memory = MemorySaver()
    
    return graph_builder.compile()

# Initialize the agent
text2sql_agent = setup_agent()

def predict(message, history):
    """Stream predictions from the agent"""
    chunks = []
    for event in text2sql_agent.stream(
        {"messages": [{"role": "user", "content": message}]},
        stream_mode='values'
    ):
        chunks.append(event["messages"][-1].content or "")
        yield "".join(chunks)
    return

#---------- STREAMLIT APP ----------#
def main():
    """Main Streamlit application"""
    st.set_page_config(
        page_title="PMed Conversational AI Chatbot",
        page_icon="🧬",
        layout="wide"
    )
    
    st.title("🧬 PMed Conversational AI Chatbot")
    st.markdown("""
    This assistant provides information about clinical trial data and can generate visualizations based on your queries.
    Ask questions about patient data, dosage information, or request specific charts.
    """)
    
    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []
    
    # Display chat messages from history on app rerun
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    
    # Accept user input
    if prompt := st.chat_input("Ask about clinical trial data..."):
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        # Display user message in chat message container
        with st.chat_message("user"):
            st.markdown(prompt)
        
        # Display assistant response in chat message container
        with st.chat_message("assistant"):
            message_placeholder = st.empty()
            full_response = ""
            
            # Simulate stream of response with cursor
            for event in text2sql_agent.stream(
                {"messages": [HumanMessage(content=prompt)]},
                stream_mode='values'
            ):
                response_content = event["messages"][-1].content or ""
                full_response += response_content
                message_placeholder.markdown(full_response + "▌")
                time.sleep(0.01)
            
            message_placeholder.markdown(full_response)
            
            # Handle plots - extract and execute code blocks
            code_pattern = r"```python(.*?)```"
            match = re.search(code_pattern, full_response, re.DOTALL)
            
            if match:
                code = match.group(1).strip()
                
                # Ensure we have the necessary imports
                if "import plotly.express" not in code:
                    code = "import plotly.express as px\nimport pandas as pd\n" + code
                
                # If no figure output code is present, add it
                if "fig" in code and not ".show()" in code and not "st.plotly_chart" in code:
                    code += "\nst.plotly_chart(fig, use_container_width=True)"
                elif "fig" in code and ".show()" in code:
                    code = code.replace(".show()", "")
                    code += "\nst.plotly_chart(fig)"
                
                # Also save the figure as an image for backup display method
                output_file = "average_age_plot.png"
                save_line = f'\nfig.write_image("{output_file}")'
                modified_code = code + save_line
                
                # Execute the modified code
                try:
                    # Create a local namespace for execution to avoid conflicts
                    local_namespace = {
                        'pd': pd, 
                        'st': st,
                        'os': os,
                    }
                    # Add plotly if needed
                    try:
                        import plotly.express as px
                        local_namespace['px'] = px
                    except ImportError:
                        st.error("Plotly Express is required but not installed.")
                        
                    # Execute the code in the namespace
                    exec(modified_code, globals(), local_namespace)
                    st.success("Visualization generated successfully!")
                    
                    # # As a backup, display the saved image if it exists
                    # if os.path.exists(output_file):
                    #     st.image(output_file, caption="Average Age by Dose", use_column_width=True)
                except Exception as e:
                    st.error(f"Error while executing the visualization code: {e}")
        
        # Add assistant response to chat history
        st.session_state.messages.append({"role": "assistant", "content": full_response})
    
    # Add sidebar with information
    with st.sidebar:
        st.header("About")
        st.markdown("""
        This application provides insights into clinical trial data using a LangGraph agent powered by LLMs.
        
        **Features:**
        - Query clinical trial database
        - Generate visualizations using Plotly
        - Analyze biomarker data
        
        **Sample Questions:**
        - Show me the average age by dose sequence
        - Create a bar chart of patient age distribution
        - Visualize the relationship between dose sequence and age
        """)
        
        st.divider()
        st.caption("Built with Streamlit, LangGraph, and Plotly")

if __name__ == "__main__":
    main()
