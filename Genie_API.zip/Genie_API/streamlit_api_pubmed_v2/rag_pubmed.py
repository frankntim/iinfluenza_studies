import os, hashlib, json
from typing import List, Dict
from langchain.schema import Document
from langchain.prompts import PromptTemplate
#from langchain.tools.tavily_search import TavilySearchResults
from langchain_community.tools.tavily_search.tool import TavilySearchResults

import pandas as pd
import time
import requests
import os
from dotenv import load_dotenv
from typing import Dict, Any, Optional, List, Union, Tuple
import logging
import backoff
import uuid

from typing import Annotated
from typing_extensions import TypedDict
# LangChain imports
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage, HumanMessage

# LangGraph imports
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition

from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)

from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import create_react_agent, ToolNode, tools_condition
from pydantic import BaseModel
from langchain_experimental.utilities import PythonREPL

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()

# Load environment variables
SPACE_ID = os.environ.get("SPACE_ID")
DATABRICKS_HOST_BASE = os.environ.get("DATABRICKS_HOST_BASE")
DATABRICKS_TOKEN = os.environ.get("DATABRICKS_TOKEN")
LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")

# Set API keys here or via environment variables
TAVILY_API_KEY = "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"
#OPENAI_API_KEY = "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"
os.environ["TAVILY_API_KEY"] = TAVILY_API_KEY
#os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

CACHE_FILE = "pubmed_clinical_cache.json"

def load_cache() -> Dict:
    if os.path.exists(CACHE_FILE):
        return json.load(open(CACHE_FILE))
    return {}

def save_cache(cache: Dict):
    with open(CACHE_FILE, "w") as f:
        json.dump(cache, f)

def cache_key(query: str, k: int):
    return hashlib.md5(f"{query}_{k}".encode()).hexdigest()

def keyword_dual_search(query: str, k: int) -> List[Document]:
    """Search both PubMed and ClinicalTrials.gov using Tavily keyword search."""
    tool = TavilySearchResults()
    sources = ["site:pubmed.ncbi.nlm.nih.gov", "site:clinicaltrials.gov"]

    docs = []
    for src in sources:
        results = tool.run(f"{query} {src}")
        for r in results[:k]:
            docs.append(Document(
                page_content=r["content"],
                metadata={"source": r["url"], "title": r.get("title", "")}
            ))
    return docs

PROMPT = PromptTemplate(
    input_variables=["question","context"],
    template=(
        "You are a medical research assistant. Based on the following search results, "
        "provide a clear and concise answer. Use inline citations [1], [2], etc. "
        "Then list references with hyperlinks.\n\n"
        "Question: {question}\n\nResults:\n{context}\n\nAnswer:\n"
    )
)

def format_with_citation(docs: List[Document]):
    ctx = ""
    refs = []
    for i, d in enumerate(docs, 1):
        ctx += f"[{i}] {d.page_content[:800].strip()}...\n"
        refs.append(f"[{i}] [{d.metadata['title'] or d.metadata['source']}]({d.metadata['source']})")
    return ctx, refs

def rag_medical_explanation(query: str, k: int =2) -> str:
    key = cache_key(query, k)
    cache = load_cache()
    if key in cache:
        return cache[key]

    docs = keyword_dual_search(query, k)
    ctx, refs = format_with_citation(docs)
    #llm = ChatOpenAI(temperature=0.3)
    llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0.0)
    answer = llm.invoke(PROMPT.format(question=query, context=ctx))

    answer_full = f"{answer.content.strip()}\n\n**References**:\n" + "\n".join(refs)
    #answer_full = f"{answer}\n\n**References**:\n" + "\n".join(refs)
    cache[key] = answer_full
    save_cache(cache)
    return answer_full
