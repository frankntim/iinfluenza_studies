import dash
from dash import dcc, html, Input, Output, State, ctx
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import asyncio
import threading
import traceback
import plotly.io as pio
from lifelines import KaplanMeierFitter, CoxPHFitter
from lifelines.statistics import logrank_test
from statsmodels.formula.api import mixedlm
from dotenv import load_dotenv

from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)

from langchain_experimental.agents.agent_toolkits import create_pandas_dataframe_agent
from langchain.agents import Tool
from langchain_core.messages import HumanMessage
from langchain_core.callbacks import BaseCallbackHandler
from langchain.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field
from langchain.prompts import PromptTemplate

import os

# Load environment variables
SPACE_ID = os.environ.get("SPACE_ID")
DATABRICKS_HOST_BASE = os.environ.get("DATABRICKS_HOST_BASE")
DATABRICKS_TOKEN = os.environ.get("DATABRICKS_TOKEN")
LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")

# LLM for plotting graph
LLM = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

pio.renderers.default = "svg"


# === Create empty dataset ===
df = pd.DataFrame()


streamed_tokens = []
streamed_plot = {"fig": None}
streamed_table = {"html": "", "columns": []}
is_streaming = {"active": False}

# === Chart tool ===
def plot_chart(query: str):
    query = query.lower()
    if "age distribution" in query:
        fig = px.histogram(df, x="Age", nbins=30, title="Age Distribution")
    elif "survival by class" in query:
        fig = px.histogram(df, x="Pclass", color="Survived", barmode="group", title="Survival by Class")
    elif "fare vs age" in query:
        fig = px.scatter(df, x="Age", y="Fare", color="Survived", title="Fare vs Age")
    else:
        return "Sorry, I couldn't generate a chart for that."
    streamed_plot["fig"] = fig
    streamed_table["html"] = ""
    return "Here's the chart you requested."

# === KM tool ===
class KMArgs(BaseModel):
    time_column: str
    event_column: str
    group_column: str = None

parser_km = PydanticOutputParser(pydantic_object=KMArgs)
prompt_km = PromptTemplate(
    template="""Extract Kaplan-Meier arguments from user query as JSON: time_column, event_column, and optional group_column.

Query: {query}
{format_instructions}
""",
    input_variables=["query"],
    partial_variables={"format_instructions": parser_km.get_format_instructions()}
)
#llm_chain_km = LLMChain(llm=ChatOpenAI(model="gpt-4", temperature=0, api_key=OPEN_AI_KEY), prompt=prompt_km)
llm_chain_km = LLM | prompt_km

def km_survival_plot(query: str):
    try:
        parsed = parser_km.parse(llm_chain_km.invoke({"query":query}))
        T_col, E_col, group_col = parsed.time_column, parsed.event_column, parsed.group_column
        if T_col not in df.columns or E_col not in df.columns:
            return f"⚠️ `{T_col}` or `{E_col}` not found."
        fig = go.Figure()
        if group_col and group_col in df.columns:
            for g, sub in df.groupby(group_col):
                kmf = KaplanMeierFitter()
                kmf.fit(sub[T_col], sub[E_col], label=str(g))
                fig.add_trace(go.Scatter(x=kmf.survival_function_.index, y=kmf.survival_function_[kmf._label], mode="lines", name=str(g)))
            fig.update_layout(title=f"KM Curve by {group_col}", xaxis_title=T_col, yaxis_title="Survival Prob")
        else:
            kmf = KaplanMeierFitter()
            kmf.fit(df[T_col], df[E_col], label="All")
            fig.add_trace(go.Scatter(x=kmf.survival_function_.index, y=kmf.survival_function_["All"], mode="lines", name="All"))
            fig.update_layout(title="Kaplan-Meier Curve", xaxis_title=T_col, yaxis_title="Survival Prob")
        streamed_plot["fig"] = fig
        streamed_table["html"] = ""
        return "Kaplan-Meier plot generated."
    except Exception as e:
        return f"❌ KM Error: {e}"

# === Cox tool ===
class CoxArgs(BaseModel):
    time_column: str
    event_column: str
    covariates: list[str]

parser_cox = PydanticOutputParser(pydantic_object=CoxArgs)
prompt_cox = PromptTemplate(
    template="""Extract Cox regression inputs from this query. Return JSON: time_column, event_column, covariates.

Query: {query}
{format_instructions}
""",
    input_variables=["query"],
    partial_variables={"format_instructions": parser_cox.get_format_instructions()}
)
#llm_chain_cox = LLMChain(llm=ChatOpenAI(model="gpt-4", temperature=0,api_key=OPEN_AI_KEY), prompt=prompt_cox)
llm_chain_cox = LLM | prompt_cox

def coxph_plot(query: str):
    try:
        args = parser_cox.parse(llm_chain_cox.run(query))
        T_col, E_col, covs = args.time_column, args.event_column, args.covariates
        for col in [T_col, E_col] + covs:
            if col not in df.columns:
                return f"⚠️ `{col}` not found."
        dfc = df[[T_col, E_col] + covs].dropna()
        dfc = pd.get_dummies(dfc, drop_first=True)
        cph = CoxPHFitter()
        cph.fit(dfc, duration_col=T_col, event_col=E_col)
        summary = cph.summary.reset_index().rename(columns={
            'covariate': 'Variable', 'exp(coef)': 'Hazard Ratio', 'se(coef)': 'Std. Error',
            'p': 'p-value', 'coef lower 95%': 'Lower 95%', 'coef upper 95%': 'Upper 95%'
        })
        fig = go.Figure()
        fig.add_trace(go.Bar(
            x=summary['Hazard Ratio'], y=summary['Variable'], orientation='h',
            error_x=dict(type='data', array=summary['Upper 95%'] - summary['Hazard Ratio'],
                         arrayminus=summary['Hazard Ratio'] - summary['Lower 95%'])
        ))
        fig.update_layout(title="Hazard Ratios with 95% CI", xaxis_title="Hazard Ratio", yaxis_title="Variables")
        streamed_plot["fig"] = fig
        streamed_table["html"] = summary.to_dict("records")
        streamed_table["columns"] = [{"name": col, "id": col} for col in summary.columns]
        return "Cox model fitted. Table and plot rendered below."
    except Exception as e:
        return f"❌ CoxPH Error: {e}"


class LogRankArgs(BaseModel):
    time_column: str
    event_column: str
    group_column: str

parser_logrank = PydanticOutputParser(pydantic_object=LogRankArgs)
prompt_logrank = PromptTemplate(
    template="""Extract log-rank test arguments from this query: time_column, event_column, group_column.

Query: {query}
{format_instructions}
""",
    input_variables=["query"],
    partial_variables={"format_instructions": parser_logrank.get_format_instructions()}
)
#llm_chain_logrank = LLMChain(llm=ChatOpenAI(model="gpt-4", temperature=0,api_key=OPEN_AI_KEY), prompt=prompt_logrank)
llm_chain_logrank = LLM | prompt_logrank


def logrank_comparison(query: str):
    try:
        args = parser_logrank.parse(llm_chain_logrank.run(query))
        T_col, E_col, G_col = args.time_column, args.event_column, args.group_column
        if not all(col in df.columns for col in [T_col, E_col, G_col]):
            return f"⚠️ One or more columns not found: {T_col}, {E_col}, {G_col}"
        unique_groups = df[G_col].dropna().unique()
        if len(unique_groups) != 2:
            return "⚠️ Log-rank test only supports exactly two groups."
        group1, group2 = unique_groups[:2]
        data1 = df[df[G_col] == group1][[T_col, E_col]].dropna()
        data2 = df[df[G_col] == group2][[T_col, E_col]].dropna()
        result = logrank_test(data1[T_col], data2[T_col], event_observed_A=data1[E_col], event_observed_B=data2[E_col])
        pval = result.p_value
        streamed_plot["fig"] = None
        streamed_table["html"] = [{"Group 1": group1, "Group 2": group2, "p-value": round(pval, 4)}]
        streamed_table["columns"] = [
            {"name": "Group 1", "id": "Group 1"},
            {"name": "Group 2", "id": "Group 2"},
            {"name": "p-value", "id": "p-value"}
        ]
        return f"Log-rank test completed between {group1} and {group2}."
    except Exception as e:
        return f"❌ Log-rank test error: {e}"



class LMMArgs(BaseModel):
    response: str
    time: str
    group: str
    subject_id: str

parser_lmm = PydanticOutputParser(pydantic_object=LMMArgs)
prompt_lmm = PromptTemplate(
    template="""Extract the response, time variable, group variable, and subject_id for a linear mixed effects model.

Query: {query}
{format_instructions}
""",
    input_variables=["query"],
    partial_variables={"format_instructions": parser_lmm.get_format_instructions()}
)
#llm_chain_lmm = LLMChain(llm=ChatOpenAI(model="gpt-4", temperature=0,api_key=OPEN_AI_KEY), prompt=prompt_lmm)
llm_chain_lmm = LLM | prompt_lmm

def lmm_fit(query: str):
    try:
        #args = parser_lmm.parse(llm_chain_lmm.run(query))
        args = parser_lmm.parse(llm_chain_lmm.invoke(query))
        y, t, g, subj = args.response, args.time, args.group, args.subject_id
        for col in [y, t, g, subj]:
            if col not in df.columns:
                return f"⚠️ Column `{col}` not found."
        dff = df[[y, t, g, subj]].dropna()
        dff["interaction"] = dff[t].astype(float) * dff[g].astype("category").cat.codes
        model = mixedlm(f"{y} ~ {t} + {g} + interaction", dff, groups=dff[subj])
        result = model.fit()
        summary_df = result.summary().tables[1]
        summary_df.columns = summary_df.columns.str.strip()
        streamed_table["html"] = summary_df.round(3).to_dict("records")
        streamed_table["columns"] = [{"name": col, "id": col} for col in summary_df.columns]

        # Plot only smoothed trend lines (fixed effects) by group with confidence intervals
        dff_sorted = dff.sort_values(by=[g, t])
        group_stats = dff_sorted.groupby([g, t])[y].agg(["mean", "sem"]).reset_index()
        group_stats["lower"] = group_stats["mean"] - 1.96 * group_stats["sem"]
        group_stats["upper"] = group_stats["mean"] + 1.96 * group_stats["sem"]

        # Plot: individual trajectories colored by group
        fig = go.Figure()
        #fig = px.line(dff, x=t, y=y, color=subj, line_group=subj, hover_name=subj, 
        #              line_shape="linear", facet_col=g, title="Individual Trajectories by Group")
        #fig.update_traces(line=dict(width=1), showlegend=False)

        # Add smoothed trend lines (fixed effects) by group
        #dff_sorted = dff.sort_values(by=[g, t])
        #group_means = dff_sorted.groupby([g, t])[y].mean().reset_index()
        #for grp in group_means[g].unique():
        #    group_df = group_means[group_means[g] == grp]
        #    fig.add_trace(go.Scatter(x=group_df[t], y=group_df[y], mode='lines',
        #                             name=f"Mean Trend - {grp}", line=dict(width=3)))
        #fig = go.Figure()
        for grp in group_stats[g].unique():
            group_df = group_stats[group_stats[g] == grp]
            fig.add_trace(go.Scatter(x=group_df[t], y=group_df["mean"], mode='lines',
                                     name=f"Mean Trend - {grp}", line=dict(width=3)))
            fig.add_trace(go.Scatter(x=list(group_df[t]) + list(group_df[t])[::-1],
                                     y=list(group_df["upper"]) + list(group_df["lower"])[::-1],
                                     fill='toself', fillcolor='rgba(0,100,80,0.2)',
                                     line=dict(color='rgba(255,255,255,0)'),
                                     hoverinfo="skip", showlegend=False))

        fig.update_layout(title="Fixed Effect Trends with Confidence Intervals", xaxis_title=t, yaxis_title=y)
        streamed_plot["fig"] = fig


        return "Linear mixed model fitted. Summary, individual trajectories, and fixed effect trends shown below."
    except Exception as e:
        return f"❌ LMM Error: {e}"
# === Tools ===
tools = [
    Tool(name="ChartGenerator", func=plot_chart, description="Basic charts like age distribution, fare vs age, etc."),
    Tool(name="KaplanMeierPlot", func=km_survival_plot, description="Kaplan-Meier plots with time/event/group."),
    Tool(name="CoxPHFitter", func=coxph_plot, description="Cox regression with time/event/covariates."),
    Tool(name="LogRankTest", func=logrank_comparison, description="Compare two survival groups using the log-rank test."),
    Tool(name="LinearMixedModel", func=lmm_fit, description="Fit a linear mixed effects model with time, group, and subject ID.")
]

#llm_stream = ChatOpenAI(model="gpt-4", temperature=0, streaming=True,api_key=OPEN_AI_KEY)
agent = create_pandas_dataframe_agent(LLM, 
                                      df, 
                                      extra_tools=tools, 
                                      verbose=True,
                                      allow_dangerous_code=True)

class StreamingHandler(BaseCallbackHandler):
    def on_llm_new_token(self, token: str, **kwargs) -> None:
        streamed_tokens.append(token)

# === Dash App ===
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
app.title = "Chatbot: KM + CoxPH"

app.layout = html.Div(style={
    "backgroundImage": "url('/assets/double-bubble-dark.webp')",
    "backgroundRepeat": "repeat",
    "backgroundSize": "auto",
    "backgroundAttachment": "fixed",
    "minHeight": "100vh",
    "padding": "2rem"
}, children=[
    #dbc.Button("Open Chatbot", id="open1", n_clicks=0),
    #dbc.Card([
    #            dbc.CardImg(src="/assets/general_analysis.png", 
    #                        top=True, style={"height": "180px", 
    #                                        "objectFit": "cover"}),
    #            dbc.CardBody(html.H5("General Analysis", className="card-title")),
    #            dbc.CardFooter(dbc.Button("Run Analysis", id="open", color="primary",  n_clicks=0))
    #        ]),
    dbc.Container([
        dbc.Row([
            dbc.Col(dbc.Card([
                dbc.CardImg(src="/assets/moroccan-flower-dark.png", 
                            top=True, 
                            style={"height": "180px", 
                                   "objectFit": "cover"}),
                #dbc.CardBody(html.H5("Survival -  Cox Fit - Mixed Models", className="card-title"),
                #             style={"width": "350px"}),
                dbc.CardBody([
                    html.H5("Survival -  Cox Fit - Mixed Models", className="card-title"),
                    dcc.Upload(
                        id="upload-data",
                        children=html.Div(["📁 Drag and Drop or ", html.A("Select CSV")]),
                        style={
                            'width': '100%', 'height': '60px', 'lineHeight': '60px', 'borderWidth': '1px',
                            'borderStyle': 'dashed', 'borderRadius': '5px', 'textAlign': 'center', 'cursor':'pointer'
                        },
                        multiple=False
                    ),
                    html.Div(id="upload-status", style={"marginTop": "10px", "color": "green"})
                ],style={"width": "350px"}),
                dbc.CardFooter(dbc.Button("Chat with Data",
                                           id="open", 
                                           color="primary",
                                           n_clicks=0,
                                           className="d-block mx-auto"))
            ]), 
            width="auto", 
            #style={"maxWidth": "50%"}
            ),
        ], className="mb-4 justify-content-center")]),
    dcc.Store(id="chat-text", data=[]),
    dcc.Interval(id="poll-stream", interval=250, n_intervals=0),
    dbc.Modal([
        dbc.ModalHeader("Data Analyst Chatbot"),
        dbc.ModalBody([
            html.Div(id="chat-output", style={"whiteSpace": "pre-wrap",
                                               "overflowY": "scroll",
                                                 "maxHeight": "300px",
                                              "border": "1px solid #ccc", "padding": "10px", "marginBottom": "10px"}),
            dcc.Input(id="user-input", type="text", placeholder="Ask something...", className="form-control"),
            dbc.Button("Send", id="send", n_clicks=0, color="primary", className="mt-2"),
            dcc.Graph(id="chat-graph", style={"marginTop": "20px"}),
            html.Div(id="cox-summary", className="mt-3")
        ]),
        dbc.ModalFooter(dbc.Button("Close", id="close", className="ms-auto", n_clicks=0)),
    ], id="modal", is_open=False),
])

@app.callback(
    Output("upload-status", "children"),
    Input("upload-data", "contents"),
    State("upload-data", "filename"),
    prevent_initial_call=True
)
def upload_csv(contents, filename):
    import base64
    import io
    global df
    global agent
    content_type, content_string = contents.split(',')
    decoded = base64.b64decode(content_string)
    df = pd.read_csv(io.StringIO(decoded.decode('utf-8')))

    agent = create_pandas_dataframe_agent(LLM, 
                                      df, 
                                      extra_tools=tools, 
                                      verbose=True,
                                      allow_dangerous_code=True)
    
    return f"✅ Uploaded {filename} with {df.shape[0]} rows."




@app.callback(Output("modal", "is_open", allow_duplicate=True),
              [Input("open", "n_clicks"), Input("close", "n_clicks")],
              [State("modal", "is_open")], prevent_initial_call="initial_duplicate")
def toggle_modal(open_clicks, close_clicks, is_open):
    return not is_open if ctx.triggered_id in ["open", "close"] else is_open

@app.callback(Output("chat-text", "data"),
              Input("send", "n_clicks"),
              State("user-input", "value"),
              State("chat-text", "data"),
              prevent_initial_call=True)
def trigger_agent(n, user_query, history):
    if not user_query: return history
    history.append(f"\U0001F464: {user_query}")
    streamed_tokens.clear()
    streamed_plot["fig"] = None
    streamed_table["html"] = ""
    streamed_table["columns"] = []
    is_streaming["active"] = True
    def run():
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(agent.ainvoke([HumanMessage(content=user_query)], config={"callbacks": [StreamingHandler()]}))
        except Exception as e:
            streamed_tokens.append(f"\n⚠️ Error:\n{traceback.format_exc()}")
        finally:
            is_streaming["active"] = False
    threading.Thread(target=run).start()
    history.append("\U0001F916: ")
    return history

@app.callback(
    Output("chat-output", "children"),
    Output("chat-graph", "figure"),
    Output("chat-graph", "style"),
    Output("cox-summary", "children"),
    Input("poll-stream", "n_intervals"),
    State("chat-text", "data"),
    prevent_initial_call=True)
def stream_to_output(_, chat_history):
    if chat_history and chat_history[-1].startswith("\U0001F916: "):
        chat_history[-1] = "\U0001F916: " + "".join(streamed_tokens)
    fig = streamed_plot["fig"]
    table_data = streamed_table["html"]
    table = dbc.Table.from_dataframe(pd.DataFrame(table_data), striped=True, bordered=True, hover=True, responsive=True) if table_data else ""
    return ("\n".join(chat_history), fig if fig else dash.no_update, {"display": "block"} if fig else {"display": "none"}, table)

if __name__ == "__main__":
    app.run_server(debug=True)
