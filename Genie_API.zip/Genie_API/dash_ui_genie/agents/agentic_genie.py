import pandas as pd
import time
import requests
import os
import json
from dotenv import load_dotenv
from typing import Dict, Any, Optional, List, Union, Tuple, Annotated
import logging
import backoff
import numpy as np

from typing_extensions import TypedDict
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage, HumanMessage

# LangGraph imports
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition

from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)

from utilities.validate_sql import validate_sql_query
from langchain.prompts import ChatPromptTemplate
from prompt_store.genie_prompt import DESCRIPTION_PROMPT

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()

# Load environment variables
SPACE_ID = os.environ.get("SPACE_ID")
DATABRICKS_HOST_BASE = os.environ.get("DATABRICKS_HOST_BASE")
DATABRICKS_TOKEN = os.environ.get("DATABRICKS_TOKEN")
LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")

# Removing Databricks authentication credentials from the environment variables
os.environ.pop('DATABRICKS_CLIENT_ID', None)
os.environ.pop('DATABRICKS_CLIENT_SECRET', None)

# LLM for generating descriptions
LLM = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

# Store active conversation IDs by session ID
active_conversations = {}

class GenieClient:
    def __init__(self, host: str, token: str, space_id: str):
        self.host = host
        self.token = token
        self.space_id = space_id
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        self.base_url = f"https://{host}/api/2.0/genie/spaces/{space_id}"
    
    @backoff.on_exception(
        backoff.expo,
        Exception,
        max_tries=5,
        factor=2,
        jitter=backoff.full_jitter,
        on_backoff=lambda details: logger.warning(
            f"API request failed. Retrying in {details['wait']:.2f} seconds (attempt {details['tries']})"
        )
    )
    def start_conversation(self, question: str) -> Dict[str, Any]:
        """Start a new conversation with the given question"""
        url = f"{self.base_url}/start-conversation"
        payload = {"content": question}
        
        response = requests.post(url, headers=self.headers, json=payload)
        response.raise_for_status()
        return response.json()
    
    @backoff.on_exception(
        backoff.expo,
        Exception,
        max_tries=5,
        factor=2,
        jitter=backoff.full_jitter,
        on_backoff=lambda details: logger.warning(
            f"API request failed. Retrying in {details['wait']:.2f} seconds (attempt {details['tries']})"
        )
    )
    def send_message(self, conversation_id: str, message: str) -> Dict[str, Any]:
        """Send a follow-up message to an existing conversation"""
        url = f"{self.base_url}/conversations/{conversation_id}/messages"
        payload = {"content": message}
        
        response = requests.post(url, headers=self.headers, json=payload)
        response.raise_for_status()
        return response.json()

    @backoff.on_exception(
        backoff.expo,
        Exception,
        max_tries=5,
        factor=2,
        jitter=backoff.full_jitter,
        on_backoff=lambda details: logger.warning(
            f"API request failed. Retrying in {details['wait']:.2f} seconds (attempt {details['tries']})"
        )
    )
    def get_message(self, conversation_id: str, message_id: str) -> Dict[str, Any]:
        """Get the details of a specific message"""
        url = f"{self.base_url}/conversations/{conversation_id}/messages/{message_id}"
        
        response = requests.get(url, headers=self.headers)
        response.raise_for_status()
        return response.json()

    @backoff.on_exception(
        backoff.expo,
        Exception,
        max_tries=5,
        factor=2,
        jitter=backoff.full_jitter,
        on_backoff=lambda details: logger.warning(
            f"API request failed. Retrying in {details['wait']:.2f} seconds (attempt {details['tries']})"
        )
    )
    def get_query_result(self, conversation_id: str, message_id: str, attachment_id: str) -> Dict[str, Any]:
        """Get the query result using the attachment_id endpoint"""
        url = f"{self.base_url}/conversations/{conversation_id}/messages/{message_id}/attachments/{attachment_id}/query-result"
        
        response = requests.get(url, headers=self.headers)
        response.raise_for_status()
        result = response.json()
        
        # Extract data_array from the correct nested location
        data_array = []
        if 'statement_response' in result:
            if 'result' in result['statement_response']:
                data_array = result['statement_response']['result'].get('data_array', [])
            
        return {
            'data_array': data_array,
            'schema': result.get('statement_response', {}).get('manifest', {}).get('schema', {})
        }

    @backoff.on_exception(
        backoff.expo,
        Exception,
        max_tries=5,
        factor=2,
        jitter=backoff.full_jitter,
        on_backoff=lambda details: logger.warning(
            f"API request failed. Retrying in {details['wait']:.2f} seconds (attempt {details['tries']})"
        )
    )
    def execute_query(self, conversation_id: str, message_id: str, attachment_id: str) -> Dict[str, Any]:
        """Execute a query using the attachment_id endpoint"""
        url = f"{self.base_url}/conversations/{conversation_id}/messages/{message_id}/attachments/{attachment_id}/execute-query"
        
        response = requests.post(url, headers=self.headers)
        response.raise_for_status()
        return response.json()
    
    def wait_for_message_completion(self, conversation_id: str, message_id: str, timeout: int = 300, poll_interval: int = 2) -> Dict[str, Any]:
        """
        Wait for a message to reach a terminal state (COMPLETED, ERROR, etc.).
        """
        start_time = time.time()
        attempt = 1
        
        while time.time() - start_time < timeout:
            message = self.get_message(conversation_id, message_id)
            status = message.get("status")
            
            if status in ["COMPLETED", "ERROR", "FAILED"]:
                return message
                
            time.sleep(poll_interval)
            attempt += 1
            
        raise TimeoutError(f"Message processing timed out after {timeout} seconds")

# Define the state for our LangGraph
class GenieWorkflowState(TypedDict):
    """State for the Genie workflow"""
    messages: Annotated[list, add_messages]
    session_id: str
    conversation_id: Optional[str]
    query_text: Optional[str]
    result_description: Optional[str]
    data: Optional[Any]
    error: Optional[str]

# Agent nodes for the workflow
def query_processor(state: GenieWorkflowState) -> Dict:
    """Process the user query and determine if we need to start a new conversation or continue an existing one"""
    global active_conversations
    messages = state["messages"]
    session_id = state["session_id"]
    # conversation_id = active_conversations[session_id]
    
    # Get the last user message
    user_messages = [m for m in messages if isinstance(m, HumanMessage)]
    if not user_messages:
        return {"error": "No user message found"}
    
    last_user_message = user_messages[-1].content
    
    logger.info(f"Processing query for session {session_id}: {last_user_message[:30]}...")
    
    try:
        if session_id in active_conversations:
            conversation_id = active_conversations[session_id]
            logger.info(f"Found existing conversation {conversation_id} for session {session_id}")
            return {"next": "continue_conversation"}
        # if conversation_id and conversation_id in active_conversations.values():
        #     # Continue existing conversation
        #     return {"next": "continue_conversation"}
        else:
            # Start a new conversation
            return {"next": "start_conversation"}
    except Exception as e:
        logger.error(f"Error in query processor: {str(e)}")
        return {"error": str(e)}

def start_new_conversation(state: GenieWorkflowState) -> Dict:
    """Start a new conversation with Genie"""
    messages = state["messages"]
    session_id = state["session_id"]
    global active_conversations
    # Get the last user message
    user_messages = [m for m in messages if isinstance(m, HumanMessage)]
    last_user_message = user_messages[-1].content
    
    client = GenieClient(
        host=DATABRICKS_HOST_BASE,
        token=DATABRICKS_TOKEN,
        space_id=SPACE_ID
    )
    
    try:
        # Start a new conversation
        response = client.start_conversation(last_user_message)
        conversation_id = response.get("conversation_id")
        message_id = response.get("message_id")
        
        logger.info(f"Created new conversation {conversation_id}")
        
        # Wait for the message to complete
        complete_message = client.wait_for_message_completion(conversation_id, message_id)
        
        # Process the response
        result, query_text, result_description = process_genie_response(
            client, last_user_message, conversation_id, message_id, complete_message
        )
        
        # Update conversation mapping
        if conversation_id:
            active_conversations[session_id] = conversation_id
        
        return {
            "conversation_id": conversation_id,
            "query_text": query_text,
            "result_description": result_description,
            "data": result,
            "next": "format_response"
        }
        
    except Exception as e:
        logger.error(f"Error starting new conversation: {str(e)}")
        return {"error": str(e)}

def continue_conversation(state: GenieWorkflowState) -> Dict:
    """Continue an existing conversation with Genie"""
    messages = state["messages"]
    session_id = state["session_id"]
    conversation_id = active_conversations[session_id]
    
    # Get the last user message
    user_messages = [m for m in messages if isinstance(m, HumanMessage)]
    last_user_message = user_messages[-1].content
    
    client = GenieClient(
        host=DATABRICKS_HOST_BASE,
        token=DATABRICKS_TOKEN,
        space_id=SPACE_ID
    )
    
    try:
        # Send follow-up message in existing conversation
        response = client.send_message(conversation_id, last_user_message)
        message_id = response.get("message_id")
        
        # Wait for the message to complete
        complete_message = client.wait_for_message_completion(conversation_id, message_id)
        
        # Process the response
        result, query_text, result_description = process_genie_response(
            client, last_user_message, conversation_id, message_id, complete_message
        )
        
        # Check if we need to start a new conversation due to expiry
        if isinstance(result, str) and "conversation has expired" in result:
            logger.info(f"Conversation {conversation_id} expired, starting new one")
            return {"next": "start_conversation"}
        
        return {
            "query_text": query_text,
            "result_description": result_description,
            "data": result,
            "next": "format_response"
        }
        
    except Exception as e:
        if "Conversation not found" in str(e):
            logger.info(f"Conversation {conversation_id} not found, starting new one")
            return {"next": "start_conversation"}
        else:
            logger.error(f"Error continuing conversation: {str(e)}")
            return {"error": str(e)}

def format_response(state: GenieWorkflowState) -> Dict:
    """Format the response from Genie for the user"""
    data = state["data"]
    query_text = state.get("query_text")
    result_description = state.get("result_description")
    
    # Validate SQL query if present
    if query_text:
        query_text = validate_sql_query(query_text)
    
    try:
        if isinstance(data, str):
            # Text response
            data = data.replace("`", "")
            formatted_data = data
        else:
            # DataFrame response
            formatted_data = data.to_markdown()
        
        sql_section = f"\n```SQL\n{query_text}\n```\n\n" if query_text else ""
        
        description = result_description or "Here are the results of your query:"
        df_dict = {
            "data": data.to_dict(orient="records"),
            "columns": data.columns.tolist()
        }
        # output = f"{description}:\n\n{formatted_data}\n\n{sql_section}"
        output = {
            "result":df_dict,
            "query_text":query_text,
            "result_description":description
        }
        output_json = json.dumps(output)
        
        return {
            "messages": [SystemMessage(content=output_json)],
            "next": END
        }
        
    except Exception as e:
        logger.error(f"Error formatting response: {str(e)}")
        return {"error": str(e)}

def handle_error(state: GenieWorkflowState) -> Dict:
    """Handle errors in the workflow"""
    error = state.get("error", "An unknown error occurred")
    
    if "429" in error or "Too Many Requests" in error:
        message = "Sorry, the system is currently experiencing high demand. Please try again in a few moments."
    elif "Conversation not found" in error or "conversation has expired" in error:
        message = "Sorry, the previous conversation has expired. Please try your query again to start a new conversation."
    else:
        message = f"Sorry, an error occurred: {error}"
    
    return {
        "messages": [SystemMessage(content=message)],
        "next": END
    }

def process_genie_response(client, question, conversation_id, message_id, complete_message) -> Tuple[Union[str, pd.DataFrame], Optional[str], Optional[str]]:
    """Process the response from Genie"""
    # Check attachments first
    attachments = complete_message.get("attachments", [])
    for attachment in attachments:
        attachment_id = attachment.get("attachment_id")
        
        # If there's text content in the attachment, return it
        if "text" in attachment and "content" in attachment["text"]:
            text_content = attachment["text"]["content"]
            if question.strip()==text_content.strip():
                text_content = "Genie is not able to produce correct result. Kindly try after sometime."
            return text_content, None, None
        
        # If there's a query, get the result
        elif "query" in attachment:
            query_text = attachment.get("query", {}).get("query", "")
            result_description = attachment.get("query", {}).get("description", "")
            query_result = client.get_query_result(conversation_id, message_id, attachment_id)
           
            data_array = query_result.get('data_array', [])
            schema = query_result.get('schema', {})
            columns = [col.get('name') for col in schema.get('columns', [])]
            
            # If we have data, return as DataFrame
            if data_array:
                # If no columns from schema, create generic ones
                if not columns and data_array and len(data_array) > 0:
                    columns = [f"column_{i}" for i in range(len(data_array[0]))]
                
                df = pd.DataFrame(data_array, columns=columns)
                # Create a prompt for the description
                chart_prompt = ChatPromptTemplate.from_template(DESCRIPTION_PROMPT)
                description_agent_chain = chart_prompt | LLM
                df = df.replace({None: np.nan})
                # Fill NaN values with 0
                df = df.fillna(0)
                description_agent_response = description_agent_chain.invoke({
                    "columns": df.columns.tolist(),
                    "data": df.to_dict(orient="records"),
                    "prompt": question
                })
                result_description = description_agent_response.content.strip() or result_description
                return df, query_text, result_description
    
    # If no attachments or no data in attachments, return text content
    if 'content' in complete_message:
        return complete_message.get('content', ''), None, None
    
    return "No response available", None, None

def build_genie_workflow() -> StateGraph:
    """Build the LangGraph workflow for Genie interactions"""
    # Create the workflow graph
    workflow = StateGraph(GenieWorkflowState)
    
    # Add nodes for each step in the workflow
    workflow.add_node("query_processor", query_processor)
    workflow.add_node("start_conversation", start_new_conversation)
    workflow.add_node("continue_conversation", continue_conversation)
    workflow.add_node("format_response", format_response)
    workflow.add_node("handle_error", handle_error)
    
    # Add edges to connect the nodes
    workflow.set_entry_point("query_processor")
    workflow.add_conditional_edges(
        "query_processor",
        lambda state: state.get("next", "handle_error"),
        {
            "start_conversation": "start_conversation",
            "continue_conversation": "continue_conversation",
            "handle_error": "handle_error"
        }
    )
    
    workflow.add_conditional_edges(
        "start_conversation",
        lambda state: state.get("next", "handle_error") if "error" not in state else "handle_error",
        {
            "format_response": "format_response",
            "handle_error": "handle_error"
        }
    )
    
    workflow.add_conditional_edges(
        "continue_conversation",
        lambda state: state.get("next", "handle_error") if "error" not in state else "handle_error",
        {
            "format_response": "format_response",
            "start_conversation": "start_conversation",
            "handle_error": "handle_error"
        }
    )
    
    # Format response goes to end or error handler
    workflow.add_conditional_edges(
        "format_response",
        lambda state: "handle_error" if "error" in state else "end",
        {
            "end": END,
            "handle_error": "handle_error"
        }
    )
    
    # Error handler goes to end
    workflow.add_edge("handle_error", END)

    graph = workflow.compile()

    return graph

agent_runnable = build_genie_workflow()