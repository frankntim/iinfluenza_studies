import uuid
import os
import json
import logging
import plotly.graph_objects as go
import plotly.express as px
from plotly.utils import PlotlyJSONEncoder

logger = logging.getLogger(__name__)

def convert_plotly_figure(fig_plotly=None, chart_description="", user_prompt=""):
    """Convert Plotly figure to HTML and JSON for web display"""
    try:
        chart_filename = f"{uuid.uuid4()}"
        
        # Ensure charts directory exists
        os.makedirs("static/charts", exist_ok=True)
        plot_folder = f"static/charts/{chart_filename}"
        os.makedirs(plot_folder, exist_ok=True)

        if fig_plotly is not None:
            # Fix hovertemplate issues by updating traces
            for trace in fig_plotly.data:
                if hasattr(trace, 'hovertemplate') and trace.hovertemplate:
                    # Remove problematic marker.color references
                    if '%{marker.color}' in trace.hovertemplate:
                        # Replace with actual y-value reference
                        trace.hovertemplate = trace.hovertemplate.replace(
                            '%{marker.color}', '%{y}'
                        )
                    # Clean up any remaining marker.color references
                    trace.hovertemplate = trace.hovertemplate.replace(
                        'marker.color=', 'value='
                    )
            
            # Convert Plotly figure to HTML and JSON
            chart_html = fig_plotly.to_html(include_plotlyjs='cdn', div_id=f"plotly-div-{chart_filename}")
            chart_json = json.dumps(fig_plotly, cls=PlotlyJSONEncoder)
            
            # Save HTML file for embedding
            html_path = os.path.join(plot_folder, f"{chart_filename}.html")
            with open(html_path, 'w') as f:
                f.write(chart_html)
            
            # Save JSON for dynamic loading
            json_path = os.path.join(plot_folder, f"{chart_filename}.json")
            with open(json_path, 'w') as f:
                f.write(chart_json)
                
            chart_description = chart_description or "Interactive chart generated from agent"
            
            # Return the web-accessible path instead of file system path
            web_path = f"/static/charts/{chart_filename}/{chart_filename}.html"
        else:
            # If no figure, create a placeholder
            chart_filename = None
            chart_description = "No chart available"
            chart_json = json.dumps({"message": "No chart available"})
            web_path = None

        logger.info(f"Plotly chart saved successfully: {chart_filename}")
        return chart_filename, chart_description, chart_json, web_path
        
    except Exception as e:
        logger.exception("Failed to save Plotly chart")