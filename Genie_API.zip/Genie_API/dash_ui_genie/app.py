from fastapi import FastAPI, Request, Depends, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, StreamingResponse, HTMLResponse, JSONResponse
from pydantic import BaseModel
import pandas as pd
import os
import uuid
import time
from datetime import datetime
import json
import plotly.graph_objects as go
import plotly.express as px
from plotly.utils import PlotlyJSONEncoder
import dotenv
import logging
from utilities.utility import convert_plotly_figure

# Load environment variables
dotenv.load_dotenv()
# Setting up logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(levelname)s: %(message)s')
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)


# Import agents - prioritize simplified versions
try:
    # Try simplified agents first to avoid dependency issues
    # from agents.genie_space import genie_query, clear_conversation
    from agents.agentic_genie import GenieWorkflowState, agent_runnable
    from prompt_store.genie_prompt import AGENT_SYS_PROMPT
    from agents.plotting_tool import general_plotting_agent, get_plotting_agent
    from agents.rag_workflow import call_rag_agent
    AGENTS_AVAILABLE = True
    logger.info("Agents imported successfully")
except ImportError as e:
        logger.error(f"No agents available: {e}")
        AGENT_SYS_PROMPT = "Biomarker assistant for clinical trial data analysis"
        AGENTS_AVAILABLE = False
        

# --- Step 1: Get the Main Dashboard URL from Environment Variables ---
# This is a CRITICAL security step. It specifies who is allowed to embed this app.
# In Databricks App deployment, you MUST set this to the URL of your Dash app.
DASHBOARD_APP_URL = os.getenv('DASHBOARD_APP_URL', 'http://127.0.0.1:8050')

app = FastAPI(title="PMed Conversational AI API")

# --- Step 2: Add Middleware to set Security Headers ---
# This middleware runs for every request.
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    # This CSP header prevents other sites from embedding your app in an iframe.
    response.headers['Content-Security-Policy'] = f"frame-ancestors 'self' {DASHBOARD_APP_URL};"
    return response

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/app-config-files", StaticFiles(directory="app-config-files"), name="app-config-files")

# Ensure charts directory exists
os.makedirs("static/charts", exist_ok=True)

# Global variables for chat management
chat_sessions = {}
active_requests = {}

# Pydantic models
class PromptRequest(BaseModel):
    prompt: str
    agent: str  # Remove default value - must come from UI
    model: str  # Remove default value - must come from UI  
    session_id: str = None
    timestamp: int = None  # Optional timestamp for debugging


class VoteRequest(BaseModel):
    vote: str  # 'up' or 'down'
    message_id: str
    timestamp: str
    feedback: str = None
    feedback_types: list = None

# --- Step 2: Add Middleware to set Security Headers ---
# This middleware runs for every request.
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    # This CSP header prevents other sites from embedding your app in an iframe.
    response.headers['Content-Security-Policy'] = f"frame-ancestors 'self' {DASHBOARD_APP_URL};"
    return response  

def get_user_info(request: Request):
    # FastAPI automatically converts headers to lowercase.
    user_email = request.headers.get('x-forwarded-email')

    if not user_email:
        # If the header is missing, deny access immediately.
        raise HTTPException(
            status_code=401,
            detail="Unauthorized: User identity not provided. This app can only be accessed from the main dashboard inside Databricks.",
        )
    return user_email

def format_welcome_message(username: str) -> str:
    """
    Format welcome message using user's first name
    """
    return f"Welcome {username.capitalize()}"

@app.get("/api/user")
async def get_current_user(request: Request):
    """Get current user information from Databricks"""
    try:
        print("headers:", request.headers)
        user_email = request.headers.get("x-forwarded-email")
        print(f"User email from headers: {user_email}")
        username = user_email.split('@')[0] if user_email else "User"
        print(f"Username derived from email: {username}")
        # Generate initials: First letter of First Name + First letter of Last Name
        initials = (username[0].upper() if username else "U")
        print(f"Initials generated: {initials}")
        welcome_message = format_welcome_message(username)
        print(f"Welcome message: {welcome_message}")
        print("Returning user info...")
        print(f"User info: username={username}, first_name={username.capitalize()}, last_name='', initials={initials}, email={user_email}")
        return {
            "username": username,
            "first_name": username.capitalize(),
            "last_name": "",
            "initials": initials,
            "email": user_email,
            "welcome_message": welcome_message
        }
    except Exception as e:
        print(f"Error getting user info: {str(e)}")
        # Return default user info
        return {
            "username": "User",
            "first_name": "User",
            "last_name": "",
            "initials": "U",
            "email": "user@company.com",
            "welcome_message": "Welcome User"
        }

@app.get("/")
# async def read_root(current_user: str = Depends(get_user_info)):
#     return FileResponse("templates/index.html")
async def read_root():
    return FileResponse("templates/index.html")

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    if exc.status_code == 401:
        content = """
        <html>
            <body style="font-family: sans-serif; background-color: #fbeae5; color: #d83511; padding: 20px;">
                <h2>&#128683; 401: Unauthorized Access</h2>
                <p>You cannot access this application directly.</p>
                <p>Please access it through the main analytics dashboard.</p>
            </body>
        </html>
        """
        return HTMLResponse(content=content, status_code=exc.status_code)
    # Default behavior for other errors
    return Response(content=exc.detail, status_code=exc.status_code)

@app.post("/api/new-chat")
async def new_chat():
    """Create a new chat session"""
    try:
        session_id = str(uuid.uuid4())
        chat_sessions[session_id] = {
            "messages": [],
            "agent": "Genie",
            "model": "ChatGPT 4",
            "thinking": False
        }
        logger.info(f"New chat session created: {session_id}")
        return JSONResponse({"session_id": session_id})
    except Exception as e:
        logger.exception("Failed to create new chat session")
        return JSONResponse(status_code=500, content={"error": "Failed to create new chat session"})


@app.post("/vote")
async def record_vote(vote_request: VoteRequest):
    """Record user vote and feedback for responses"""
    try:
        # Log the vote/feedback data
        log_data = {
            "message_id": vote_request.message_id,
            "vote": vote_request.vote,
            "timestamp": vote_request.timestamp,
            "feedback": vote_request.feedback,
            "feedback_types": vote_request.feedback_types
        }
        
        print(f"Vote recorded: {log_data}")
        
        # Here you could save to database, file, or analytics service
        # For now, we'll just log it and save to a simple JSON file
        votes_file = "static/json/votes_feedback.json"
        try:
            with open(votes_file, "r") as f:
                existing_votes = json.load(f)
        except FileNotFoundError:
            existing_votes = []
        
        existing_votes.append(log_data)
        
        with open(votes_file, "w") as f:
            json.dump(existing_votes, f, indent=2)
        
        return {
            "status": "success",
            "message": "Vote recorded successfully",
            "vote_id": vote_request.message_id
        }
        
    except Exception as e:
        print(f"Error recording vote: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error recording vote: {str(e)}")

@app.post("/agent-stream")
async def agent_stream_workflow(request: PromptRequest):
    """
    Execute agentic workflow with streaming updates. 
    This single endpoint handles both progress streaming and the final response.
    """
    print(f"🚀 Agent stream endpoint called with prompt: {request.prompt}")
    
    async def stream_generator():
        try:
            print("🔄 Starting agent workflow stream...")
            # Initialize response data
            response_data = {
            "text": None,
            "chart_html_path": None,
            "chart_json_path": None,
            "table": None,
            "sql_query": None,
            "python_code": None,
            "agent": request.agent,
            "model": request.model
            }

            if not AGENTS_AVAILABLE:
                logger.warning("Agents not available, using fallback response")
                response_data["text"] = "I'm sorry, but the agent system is currently unavailable. Please check the agent configuration and try again."
                data = json.dumps(response_data)
                yield f"data: {data}\n\n"

            update = {
                "type": "workflow_start",
                "message": "🚀 Initializing agentic AI workflow...",
                "timestamp": datetime.now().isoformat()
            }
            data = json.dumps(update)
            yield f"data: {data}\n\n"
            if request.agent=="Genie" and request.model=="Genie-Space":
                start_time = time.time()
                update = {
                    "type": "agent_start",
                    "agent": "Genie Conversation Started",
                    "task": "Starting Conversation with Genie",
                    "timestamp": datetime.now().isoformat()
                }
                data = json.dumps(update)
                yield f"data: {data}\n\n"
                        
                # result, query_text, result_description = genie_query(request.prompt, request.session_id)
                initial_state = GenieWorkflowState(session_id=request.session_id,messages=[request.prompt])
                intermediate_states = {}
                start_time = time.time()
                async for chunk in agent_runnable.astream(initial_state):

                    node_name = list(chunk.keys())[0]
                    intermediate_states.update(chunk)
                    chunk_data=chunk[node_name]

                content = intermediate_states["format_response"]["messages"][0].content
                response = json.loads(content)
                df_dict = response["result"]
                result = pd.DataFrame(df_dict["data"], columns=df_dict["columns"])
                query_text = response["query_text"]
                result_description = response["result_description"]
                logger.info(f"Genie agent result type: {type(result)}")
                update = {
                            "type": "agent_complete",
                            "agent": "Genie Conversation Started",
                            "duration": f"{time.time() - start_time}:.2f s",
                            "result": "",
                            "timestamp": datetime.now().isoformat()
                        }
                data = json.dumps(update)
                yield f"data: {data}\n\n"

                # Handle different result types
                if isinstance(result, pd.DataFrame):
                    # We got a DataFrame from the agent
                    start_time = time.time()
                    update = {
                        "type": "agent_start",
                        "agent": "Generating Plot",
                        "task": "Generating Required Plot",
                        "timestamp": datetime.now().isoformat()
                    }
                    data = json.dumps(update)
                    yield f"data: {data}\n\n"
                        
                    logger.info(f"Received DataFrame with shape: {result.shape}")
                    
                    
                    # Try to use plotting agent to generate a chart
                    try:
                        fig, fig_summary, graph_result_output = general_plotting_agent(
                            result, AGENT_SYS_PROMPT, request.prompt
                        )
                        
                        # Convert plotly figure and save
                        if fig is not None:
                            chart_filename, chart_description, chart_json, web_path = convert_plotly_figure(
                                fig, fig_summary, request.prompt
                            )
                            response_data["chart_html_path"] = web_path
                            response_data["chart_json_path"] = chart_json
                        update = {
                            "type": "agent_complete",
                            "agent": "Generating Plot",
                            "duration": f"{time.time() - start_time}:.2f s",
                            "result": "",
                            "timestamp": datetime.now().isoformat()
                        }
                        data = json.dumps(update)
                        yield f"data: {data}\n\n"
                        
                        start_time = time.time()
                        update = {
                            "type": "agent_start",
                            "agent": "Formatting Response",
                            "task": "Formatting Response",
                            "timestamp": datetime.now().isoformat()
                                }
                        data = json.dumps(update)
                        yield f"data: {data}\n\n"
                        # Generate table HTML from DataFrame (limit size to prevent JSON truncation)
                        # Show only first 50 rows to prevent streaming issues
                        display_df = result.head(50) if len(result) > 50 else result
                        table_html = display_df.to_html(classes='response-table', table_id='data-table')
                        
                        # Add a note if data was truncated
                        if len(result) > 50:
                            table_html += f'<p class="table-note"><em>Showing first 50 rows of {len(result)} total rows</em></p>'
                        
                        response_data["table"] = table_html
                        
                        # Set response text
                        response_data["text"] = result_description or "Data analysis completed successfully."
                        
                        # Include SQL query if available
                        if query_text:
                            response_data["sql_query"] = query_text
                        
                        # Generate Python code for the analysis
                        response_data["python_code"] = graph_result_output
                        update = {
                            "type": "agent_complete",
                            "agent": "Formatting Response",
                            "duration": f"{time.time() - start_time}:.2f s",
                            "result": "",
                            "timestamp": datetime.now().isoformat()
                        }
                        data = json.dumps(update)
                        yield f"data: {data}\n\n"

                    except Exception as plot_error:
                        logger.warning(f"Plotting agent failed: {plot_error}")
                        # Still return the table even if plotting fails
                        table_html = result.to_html(classes='response-table', table_id='data-table')
                        response_data["table"] = table_html
                        response_data["text"] = result_description or "Data analysis completed, but chart generation failed."
                        response_data["sql_query"] = query_text
                        response_data["python_code"] = graph_result_output

                else:
                    # We got a text response
                    response_data["text"] = str(result)
                    
            elif request.agent == "RAG" or request.agent == "RAG_VectorSearch":
                start_time = time.time()
                update = {
                    "type": "agent_start",
                    "agent": "RAG Pipeline Started",
                    "task": "Starting Conversation with Genie",
                    "timestamp": datetime.now().isoformat()
                }
                data = json.dumps(update)
                yield f"data: {data}\n\n"
                # Use RAG agent
                result, query_text, result_description = call_rag_agent(request.prompt, request.model, request.session_id)
                logger.info(f"RAG agent result type: {type(result)}")
                update = {
                            "type": "agent_complete",
                            "agent": "RAG Pipeline Started",
                            "duration": f"{time.time() - start_time}s",
                            "result": "",
                            "timestamp": datetime.now().isoformat()
                        }
                data = json.dumps(update)
                yield f"data: {data}\n\n"

                # Handle different result types for RAG agent
                if isinstance(result, pd.DataFrame):
                    # We got a DataFrame from the RAG agent
                    logger.info(f"Received DataFrame from RAG with shape: {result.shape}")
                    
                    # Try to use plotting agent to generate a chart
                    try:
                        start_time = time.time()
                        update = {
                            "type": "agent_start",
                            "agent": "Generating Plots",
                            "task": "Starting Conversation with Genie",
                            "timestamp": datetime.now().isoformat()
                        }
                        fig, fig_summary, graph_result_output = general_plotting_agent(
                            result, AGENT_SYS_PROMPT, request.prompt
                        )
                        
                        # Convert plotly figure and save
                        if fig is not None:
                            chart_filename, chart_description, chart_json, web_path = convert_plotly_figure(
                                fig, fig_summary, request.prompt
                            )
                            response_data["chart_html_path"] = web_path
                            response_data["chart_json_path"] = chart_json
                            update = {
                                "type": "agent_complete",
                                "agent": "RAG Pipeline Started",
                                "duration": f"{time.time() - start_time}s",
                                "result": "",
                                "timestamp": datetime.now().isoformat()
                            }
                            data = json.dumps(update)
                            yield f"data: {data}\n\n"

                        # Generate table HTML from DataFrame (limit size to prevent JSON truncation)
                        display_df = result.head(50) if len(result) > 50 else result
                        table_html = display_df.to_html(classes='response-table', table_id='data-table')
                        
                        # Add a note if data was truncated
                        if len(result) > 50:
                            table_html += f'<p class="table-note"><em>Showing first 50 rows of {len(result)} total rows</em></p>'
                        
                        response_data["table"] = table_html
                        
                        # Set response text
                        response_data["text"] = result_description or "RAG vector search analysis completed successfully."
                        
                        # Include SQL query if available
                        if query_text:
                            response_data["sql_query"] = query_text
                        
                        # Generate Python code for the analysis
                        response_data["python_code"] = graph_result_output
                            
                    except Exception as plot_error:
                        logger.warning(f"Plotting agent failed for RAG: {plot_error}")
                        # Still return the table even if plotting fails
                        display_df = result.head(50) if len(result) > 50 else result
                        table_html = display_df.to_html(classes='response-table', table_id='data-table')
                        response_data["table"] = table_html
                        response_data["text"] = result_description or "RAG analysis completed, but chart generation failed."
                        
                else:
                    # We got a text response from RAG
                    response_data["text"] = str(result)
                    if query_text:
                        response_data["sql_query"] = query_text
                    
            else:
                # Default to Genie
                result, query_text, result_description = genie_query(request.prompt, request.session_id)
                response_data["text"] = str(result)
            
            logger.info(f"Agentic workflow completed successfully for session {request.session_id}")
            
            data = json.dumps(response_data)
            yield f"data: {data}\n\n"
        except Exception as e:
            print(f"❌ Agent workflow error: {str(e)}")
            error_data = {
                "type": "workflow_error",
                "message": f"Agent workflow error: {str(e)}",
                "timestamp": datetime.now().isoformat()
            }
            yield f"data: {json.dumps(error_data)}\n\n"

    return StreamingResponse(
        stream_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no", # Important for disabling buffering in proxies
            "Access-Control-Allow-Origin": "*",
        }
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)