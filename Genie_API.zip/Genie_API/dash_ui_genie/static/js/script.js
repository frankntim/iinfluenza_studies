// **** COOKIE HELPER FUNCTIONS ****
function setCookie(name, value, days) {
    let expires = "";
    if (days) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
}

function getCookie(name) {
    const nameEQ = name + "=";
    const ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}


document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM fully loaded - initializing app');
    
    const runBtn = document.getElementById('run-btn');
    const promptInput = document.getElementById('prompt-input');
    const responseArea = document.getElementById('response-area');
    const runSettingsBtn = document.getElementById('run-settings-btn');
    const settingsSidebar = document.getElementById('settings-sidebar');
    const closeSettingsBtn = document.getElementById('close-settings-btn');
    
    // Load agent and model data dynamically
    loadAgentModelData();
    initializeUser();
    
    // Initialize Tailwind dropdowns
    initializeTailwindDropdowns();
    
    // Global data storage for agent/model information
    let globalAgentModelData = {};
    
    // Height constants for input box
    const oneLineHeight = 48; // Height for one line (increased for better appearance)
    const maxInputHeight = 120; // Maximum height (about 5 lines)
    
    // Get the initial computed height of the input box
    const initialHeight = promptInput.clientHeight;

    // Add this to your DOMContentLoaded event handler
    function ensureSessionId() {
        let sessionId = getCookie('session_id');
        if (!sessionId) {
            // Only create a new session if one doesn't exist
            startNewChatSession();
        } else {
            console.log('Using existing session ID:', sessionId);
        }
    }

    // Call this function when the page loads
    ensureSessionId();


    // Load agent and model data dynamically
    async function loadAgentModelData() {
        try {
            const response = await fetch('/app-config-files/agent-workflow-model.json');
            if (!response.ok) throw new Error(`Failed to load config: ${response.statusText}`);
            const data = await response.json();
            
            // Store data globally
            globalAgentModelData = data;
            
            // Populate Agent dropdown
            populateDropdown('agent-dropdown', data.agents, 'Select Agent');
            
            // Initialize the Model dropdown based on the first agent selection
            if (data.agents && data.agents.length > 0) {
                updateModelDropdown(data.agents[0]);
            }

            // Initialize the AI config panel with default values
            updateAIConfigPanel();
            
        } catch (error) {
            console.error('Error loading agent/model data:', error);
            // Fallback to default options
            const fallbackData = {
                agents: [
                    { label: 'Genie', value: 'Genie', models: [{ label: 'Genie-Space', value: 'Genie-Space' }] },
                    {
                        label: 'RAG_VectorSearch',
                        value: 'RAG_VectorSearch',
                        models: [
                            { label: 'ChatGPT-4', value: 'project-115-Precision_Medicine_AI_Agent-2' },
                            { label: 'LLAMA-4', value: 'databricks-llama-4-maverick' }
                        ]
                    }
                ]
            };

            
            globalAgentModelData = fallbackData;
            populateDropdown('agent-dropdown', fallbackData.agents, 'Select Agent');
            
            if (fallbackData.agents && fallbackData.agents.length > 0) {
                updateModelDropdown(fallbackData.agents[0]);
            }
            
            updateAIConfigPanel();
        }
    }

    // Function to update the model dropdown based on selected agent
    function updateModelDropdown(selectedAgent) {
        const modelDropdown = document.getElementById('model-dropdown');
        const modelSelectedText = document.getElementById('model-selected-text');
        
        if (!modelDropdown) return;
        
        // Clear current dropdown items
        modelDropdown.innerHTML = '';
        
        // Add new options based on selected agent
        if (selectedAgent && selectedAgent.models) {
            selectedAgent.models.forEach(model => {
                const li = document.createElement('li');
                const a = document.createElement('a');
                a.href = "#";
                a.className = "block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white";
                a.textContent = model.label;
                a.setAttribute('data-value', model.value);
                
                // Add click event
                a.addEventListener('click', function(e) {
                    e.preventDefault();
                    modelSelectedText.textContent = model.label;
                    modelSelectedText.setAttribute('data-value', model.value);
                    
                    // Hide dropdown
                    document.getElementById('model-dropdown-menu').classList.add('hidden');
                    
                    // Update AI config panel
                    updateAIConfigPanel();
                    
                    // Dispatch custom event
                    const changeEvent = new CustomEvent('dropdown-changed', { detail: { dropdown: 'model', value: model.value, label: model.label } });
                    document.dispatchEvent(changeEvent);
                });
                
                li.appendChild(a);
                modelDropdown.appendChild(li);
            });
            
            // Set default selection
            if (selectedAgent.models.length > 0) {
                modelSelectedText.textContent = selectedAgent.models[0].label;
                modelSelectedText.setAttribute('data-value', selectedAgent.models[0].value);
            }
        }
    }


    // Function to update the AI Configuration Panel
    function updateAIConfigPanel() {
        if (!globalAgentModelData) return;
        
        const currentAgentElement = document.getElementById('current-agent');
        const currentModelElement = document.getElementById('current-model');
        
        if (!currentAgentElement || !currentModelElement) return;
        
        // Get current selections
        const selectedAgentValue = getSelectedAgent();
        const selectedModelValue = getSelectedModel();
        
        // Find agent data
        const agentData = globalAgentModelData.agents.find(agent => agent.value === selectedAgentValue) || 
                          globalAgentModelData.agents[0];
        
        // Find model data from the selected agent's models
        let modelData = null;
        if (agentData && agentData.models) {
            modelData = agentData.models.find(model => model.value === selectedModelValue);
        }
        
        // Add subtle animation effect
        const elements = [currentAgentElement, currentModelElement];
        elements.forEach(el => {
            if (el) {
                el.style.opacity = '0.7';
                el.style.transform = 'scale(0.95)';
            }
        });
        
        // Update content after a brief delay for smooth transition
        setTimeout(() => {
            // Update agent display
            if (agentData) {
                currentAgentElement.textContent = agentData.label;
            }
            
            // Update model display
            if (modelData) {
                currentModelElement.textContent = modelData.label;
            } else if (agentData && agentData.models && agentData.models.length > 0) {
                // If no model is selected but the agent has models, display the first model
                currentModelElement.textContent = agentData.models[0].label;
                
                // Also update the model dropdown selection
                const modelDropdown = document.getElementById('model-dropdown');
                if (modelDropdown && agentData.models.length > 0) {
                    modelDropdown.value = agentData.models[0].value;
                }
            } else {
                currentModelElement.textContent = 'No model available';
            }
            
            // Restore animation
            elements.forEach(el => {
                if (el) {
                    el.style.opacity = '1';
                    el.style.transform = 'scale(1)';
                }
            });
        }, 150);
    }

    // Function to populate dropdowns
    function populateDropdown(dropdownId, items, placeholder) {
            const dropdown = document.getElementById(dropdownId);
            const dropdownButton = document.getElementById(`${dropdownId}-button`);
            const dropdownSelectedText = document.getElementById(`${dropdownId.replace('dropdown', 'selected')}-text`);
            
            // Check if dropdown exists
            if (!dropdown) {
                console.error(`Dropdown with ID '${dropdownId}' not found`);
                return;
            }
            
            // Clear existing options
            dropdown.innerHTML = '';
            
            // Add options
            items.forEach(item => {
                const li = document.createElement('li');
                const a = document.createElement('a');
                a.href = "#";
                a.className = "block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white";
                a.textContent = item.label;
                a.setAttribute('data-value', item.value);
                
                // Add click event
                a.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    // Update selected text
                    if (dropdownSelectedText) {
                        dropdownSelectedText.textContent = item.label;
                        dropdownSelectedText.setAttribute('data-value', item.value);
                    }
                    
                    // Hide dropdown menu
                    const dropdownMenu = document.getElementById(`${dropdownId}-menu`);
                    if (dropdownMenu) {
                        dropdownMenu.classList.add('hidden');
                    }
                    
                    // If this is the agent dropdown, update the model dropdown
                    if (dropdownId === 'agent-dropdown') {
                        const selectedAgent = globalAgentModelData.agents.find(agent => agent.value === item.value);
                        if (selectedAgent) {
                            updateModelDropdown(selectedAgent);
                        }
                    }
                    
                    // Update AI config panel
                    updateAIConfigPanel();
                    
                    // Dispatch custom event
                    const changeEvent = new CustomEvent('dropdown-changed', { 
                        detail: { dropdown: dropdownId, value: item.value, label: item.label } 
                    });
                    document.dispatchEvent(changeEvent);
                });
                
                li.appendChild(a);
                dropdown.appendChild(li);
            });
            
            // Set default selection if available
            if (items.length > 0 && dropdownSelectedText) {
                dropdownSelectedText.textContent = items[0].label;
                dropdownSelectedText.setAttribute('data-value', items[0].value);
            }
        }


    // Initialize Tailwind dropdowns to make them interactive
    function initializeTailwindDropdowns() {
        const dropdownButtons = document.querySelectorAll('[data-dropdown-toggle]');
        
        dropdownButtons.forEach(button => {
            const targetId = button.getAttribute('data-dropdown-toggle');
            const targetMenu = document.getElementById(targetId);
            
            if (!targetMenu) {
                console.error(`Dropdown menu with ID '${targetId}' not found`);
                return;
            }
            
            // Toggle dropdown on click
            button.addEventListener('click', function(e) {
                e.stopPropagation();
                
                // Toggle the hidden class
                targetMenu.classList.toggle('hidden');
                
                // Close other dropdowns
                dropdownButtons.forEach(otherButton => {
                    if (otherButton !== button) {
                        const otherId = otherButton.getAttribute('data-dropdown-toggle');
                        const otherMenu = document.getElementById(otherId);
                        if (otherMenu && !otherMenu.classList.contains('hidden')) {
                            otherMenu.classList.add('hidden');
                        }
                    }
                });
            });
        });
        
        // Close dropdowns when clicking outside
        document.addEventListener('click', function(event) {
            const dropdownMenus = document.querySelectorAll('[id$="-dropdown-menu"]');
            dropdownMenus.forEach(menu => {
                // If click is outside the menu and its button
                const button = document.querySelector(`[data-dropdown-toggle="${menu.id}"]`);
                if (!menu.contains(event.target) && (!button || !button.contains(event.target))) {
                    // Hide this menu
                    if (!menu.classList.contains('hidden')) {
                        menu.classList.add('hidden');
                    }
                }
            });
        });
        
        console.log('Tailwind dropdowns initialized');
    }
    
    // Call this function after the page loads
    document.addEventListener('DOMContentLoaded', function() {
        initializeTailwindDropdowns();
    });

    // Set the initial height for one-liner
    promptInput.style.height = oneLineHeight + 'px';
    
    // Add professional styling to the select dropdowns
    const styleDropdowns = function() {
        const dropdowns = document.querySelectorAll('select.setting-control');
        dropdowns.forEach(dropdown => {
            // Add animation class
            dropdown.classList.add('animated-dropdown');
            
            // Add change animation
            dropdown.addEventListener('change', function() {
                this.classList.add('changed');
                setTimeout(() => {
                    this.classList.remove('changed');
                }, 500);
            });
        });
    };
    
    // Call styling function when DOM is loaded
    styleDropdowns();
    
    // Auto-resize textarea
    promptInput.addEventListener('input', function() {
        // Reset height to calculate new scroll height
        this.style.height = oneLineHeight + 'px';
        
        const scrollHeight = this.scrollHeight;
        
        // Set new height based on content, with min and max constraints
        const newHeight = Math.max(oneLineHeight, Math.min(scrollHeight, maxInputHeight));
        this.style.height = newHeight + 'px';
        
        // Show scrollbar if content exceeds max height
        if (scrollHeight > maxInputHeight) {
            this.style.overflowY = 'auto';
        } else {
            this.style.overflowY = 'hidden';
        }
    });

    // Handle prompt submission
    runBtn.addEventListener('click', async () => {
        submitMessage();
    });

    // Handle Enter key press
    promptInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey && !promptInput.disabled) {
            e.preventDefault();
            submitMessage();
        }
    });

    async function submitMessage() {
        const promptText = promptInput.value.trim();
        if (!promptText) return;
        
        setInputState(false);
        
        const welcomeContent = responseArea.querySelector('.main-title');
        if (welcomeContent) {
            responseArea.innerHTML = '';
        }
        
        // >>> REQUIREMENT MET: On new prompt, clear previous values and expand the section.
        resetNavAgentStream();

        addUserMessage(promptText);
        
        promptInput.value = '';
        promptInput.style.height = oneLineHeight + 'px';
        promptInput.style.overflowY = 'hidden';

        const loadingBubble = addBotMessage('Analyzing your query...', 'loading');

        try {
            startAgentStreamWithResponse(promptText, loadingBubble);
        } catch (error) {
            console.error('Error:', error);
            if (loadingBubble && loadingBubble.parentNode) loadingBubble.remove();
            addBotMessage('Failed to get response. Please try again.', 'error');
            setInputState(true);
            collapseAgentStreamSection(); // Collapse on error
        }
    }

    function setInputState(enabled) {
        promptInput.disabled = !enabled;
        runBtn.disabled = !enabled;
        
        if (enabled) {
            promptInput.style.opacity = '1';
            promptInput.style.cursor = 'text';
            runBtn.style.opacity = '1';
            runBtn.style.cursor = 'pointer';
            promptInput.placeholder = 'Ask me anything...';
        } else {
            promptInput.style.opacity = '0.6';
            promptInput.style.cursor = 'not-allowed';
            runBtn.style.opacity = '0.6';
            runBtn.style.cursor = 'not-allowed';
            promptInput.placeholder = 'Processing your request...';
        }
    }

    function addUserMessage(message) {
        const userBubble = document.createElement('div');
        userBubble.className = 'chat-message user-message';
        // Use actual user info if available
        const userInfo = window.currentUserInfo || { initials: 'U', first_name: 'User' };
        userBubble.innerHTML = `
            <div class="message-container">
                <div class="message-header">
                    <div class="message-avatar user-avatar">
                        <span class="user-initials">${userInfo.initials}</span>
                    </div>
                    <span class="message-name">${userInfo.first_name}</span>
                </div>
                <div class="message-bubble user-bubble">
                    <p>${message}</p>
                </div>
            </div>
        `;
        responseArea.appendChild(userBubble);
        scrollToBottom();
    }

    function addBotMessage(message, type = 'text') {
        const botBubble = document.createElement('div');
        botBubble.className = `chat-message bot-message ${type}`;
        botBubble.innerHTML = `
            <div class="message-container">
                <div class="message-header">
                    <div class="message-avatar bot-avatar">
                        <img src="/static/img/assistant_logo.png" alt="Assistant" style="width: 30px; height: 30px; border-radius: 50%;" />
                    </div>
                    <span class="message-name">Assistant</span>
                </div>
                <div class="message-bubble bot-bubble">
                    <p>${message}</p>
                </div>
            </div>
        `;
        responseArea.appendChild(botBubble);
        scrollToBottom();
        return botBubble;
    }

    // Collapses the left sidebar's agent stream section
    function collapseAgentStreamSection() {
        const agentStreamSection = document.querySelector('.agent-stream-section');
        if (agentStreamSection && !agentStreamSection.classList.contains('collapsed')) {
            agentStreamSection.classList.add('collapsed');
            console.log('✅ Agent Stream section collapsed.');
        }
    }

    // In the startAgentStreamWithResponse function, modify the chunk handling:
    async function startAgentStreamWithResponse(prompt, loadingBubble) {
        console.log('🚀 Starting agent stream...');
        console.log('📋 Using session ID:', getCookie('session_id'));
        resetNavAgentStream();

        let workflowCompleted = false; // Flag to track completion
        let accumulatedChunks = ''; // Add this to accumulate partial JSON chunks

        try {
            clearNavAgentSteps();
            
            const response = await fetch('/agent-stream', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    prompt: prompt,
                    agent: getSelectedAgent(),
                    model: getSelectedModel(),
                    session_id: getCookie('session_id')
                })
            });

            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

            const reader = response.body.getReader();
            const decoder = new TextDecoder();

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                const chunk = decoder.decode(value, { stream: true });
                accumulatedChunks += chunk; // Accumulate chunks
                
                // Process any complete JSON messages
                let processedUpTo = 0;
                let nextDataIndex = accumulatedChunks.indexOf('data: ', processedUpTo);
                
                while (nextDataIndex !== -1) {
                    // Find the start of the next data chunk or the end of the accumulated data
                    let endOfJson = accumulatedChunks.indexOf('data: ', nextDataIndex + 6);
                    if (endOfJson === -1) endOfJson = accumulatedChunks.length;
                    
                    // Extract the JSON part
                    const jsonPart = accumulatedChunks.substring(nextDataIndex + 6, endOfJson).trim();
                    
                    try {
                        // Only try to parse if the JSON looks complete
                        if (jsonPart && (jsonPart.endsWith('}') || jsonPart.endsWith(']'))) {
                            const data = JSON.parse(jsonPart);
                            
                            // Process the data as before
                            if (data.type) {
                                handleAgentUpdate(data);
                            }

                            let isFinalMessage = false;
                            let finalPayload = null;

                            if (data.type === 'workflow_complete') {
                                isFinalMessage = true;
                                finalPayload = data.output;
                            } else if (!data.type && (data.text || data.table || data.chart_html_path)) {
                                isFinalMessage = true;
                                finalPayload = data;
                            }
                            
                            if (isFinalMessage) {
                                workflowCompleted = true;
                                if (loadingBubble && loadingBubble.parentNode) loadingBubble.remove();
                                
                                if (finalPayload) {
                                    addBotResponse(finalPayload); 
                                }
                                
                                setInputState(true);
                                collapseAgentStreamSection();
                            }
                            
                            // Update where we've processed up to
                            processedUpTo = endOfJson;
                        }
                    } catch (e) {
                        // If parsing fails, it might be an incomplete JSON
                        // We'll keep it in the accumulated chunks and try again when more data arrives
                        console.log('Incomplete JSON, waiting for more data...');
                    }
                    
                    // Look for the next data chunk
                    nextDataIndex = accumulatedChunks.indexOf('data: ', processedUpTo);
                }
                
                // Keep only the unprocessed part
                accumulatedChunks = accumulatedChunks.substring(processedUpTo);
            }

            // After the loop, check if the workflow completed successfully via the stream
            if (!workflowCompleted) {
                // Try one last time with any remaining data
                if (accumulatedChunks.includes('data: ')) {
                    try {
                        const jsonPart = accumulatedChunks.substring(accumulatedChunks.lastIndexOf('data: ') + 6).trim();
                        if (jsonPart && (jsonPart.endsWith('}') || jsonPart.endsWith(']'))) {
                            const data = JSON.parse(jsonPart);
                            
                            if (data.type === 'workflow_complete' || (!data.type && (data.text || data.table || data.chart_html_path))) {
                                workflowCompleted = true;
                                if (loadingBubble && loadingBubble.parentNode) loadingBubble.remove();
                                
                                const finalPayload = data.type === 'workflow_complete' ? data.output : data;
                                if (finalPayload) {
                                    addBotResponse(finalPayload);
                                }
                                
                                setInputState(true);
                                collapseAgentStreamSection();
                            }
                        }
                    } catch (e) {
                        console.error('Error parsing final chunk:', e);
                    }
                }
                
                if (!workflowCompleted) {
                    throw new Error('Stream ended without a completion event.');
                }
            }

        } catch (error) {
            console.error('❌ Agent stream error:', error);
            handleAgentUpdate({ type: 'workflow_error', message: error.message });
            if (loadingBubble && loadingBubble.parentNode) loadingBubble.remove();
            addBotMessage('Failed to get response. Please try again.', 'error');
            setInputState(true);
            collapseAgentStreamSection();
        }
    }
    
    function handleAgentUpdate(data) {
        console.log('🔄 Handling agent update for left sidebar:', data.type, data);

        switch (data.type) {
            case 'workflow_start':
                addNavAgentStep('workflow_start', 'Initializing...');
                break;
            case 'agent_start':
                updateNavAgentStep('workflow_start', 0.01, 'success');
                addNavAgentStep(data.agent, data.task, Date.now());
                break;
            case 'agent_complete':
                updateNavAgentStep(data.agent, data.duration, 'success');
                break;
            case 'workflow_error':
                const runningStep = agentNavSteps.querySelector('.nav-agent-step.running');
                if (runningStep) {
                    const nodeName = runningStep.dataset.node;
                    const startTime = runningStep.dataset.startTime;
                    const duration = (Date.now() - (startTime || Date.now())) / 1000;
                    updateNavAgentStep(nodeName, duration, 'error');
                }
                break;
            default:
                // Ignore other types like 'workflow_complete' for the sidebar UI updates
                break; 
        }
    }

    const nodeToTitleMap = {
        "workflow_start": "Initializing Workflow",
        "data_analysis_agent": "Analyzing Data",
        "visualization_agent": "Creating Visualizations", 
        "reporting_agent": "Generating Report",
        "Data Analysis Agent": "Analyzing Data",
        "Visualization Agent": "Creating Visualizations",
        "Reporting Agent": "Generating Report"
    };

    // --- Agent Stream Section Logic (Left Sidebar) ---
    const agentStreamToggle = document.getElementById('agent-stream-toggle');
    const agentNavSteps = document.getElementById('agent-nav-steps');
    const agentProgressFill = document.getElementById('agent-progress-fill');
    const agentProgressText = document.getElementById('agent-progress-text');
    let totalSteps = 0;
    let completedSteps = 0;

    if (agentStreamToggle) {
        agentStreamToggle.addEventListener('click', () => {
            const agentStreamSection = document.querySelector('.agent-stream-section');
            agentStreamSection.classList.toggle('collapsed');
        });
    }

    function addNavAgentStep(nodeName, details, startTime) {
        const placeholder = agentNavSteps.querySelector('.nav-step-placeholder');
        if (placeholder) placeholder.remove();

        const stepDiv = document.createElement('div');
        stepDiv.className = 'nav-agent-step running';
        stepDiv.dataset.node = nodeName;
        stepDiv.dataset.startTime = startTime || Date.now();
        
        const title = nodeToTitleMap[nodeName] || nodeName;
        stepDiv.innerHTML = `
            <span class="nav-step-icon running"><span class="material-icons">hourglass_empty</span></span>
            <div class="nav-step-details">
                <div class="nav-step-name">${title}</div>
                <div class="nav-step-time">Starting...</div>
            </div>
        `;
        
        if (agentNavSteps) {
            agentNavSteps.appendChild(stepDiv);
            agentNavSteps.scrollTop = agentNavSteps.scrollHeight;
        }

        totalSteps++;
        updateProgress();
    }

    function updateNavAgentStep(nodeName, duration, status = 'success') {
        const steps = agentNavSteps.querySelectorAll(`[data-node="${nodeName}"].running`);
        const stepDiv = steps[steps.length - 1];
        if (!stepDiv) return;

        const iconElement = stepDiv.querySelector('.nav-step-icon');
        const iconMaterial = iconElement?.querySelector('.material-icons');
        const timeElement = stepDiv.querySelector('.nav-step-time');
        
        iconElement.classList.remove('running');
        stepDiv.classList.remove('running');
        
        const durationNumber = typeof duration === 'string' ? parseFloat(duration) : duration;
        
        if (status === 'success') {
            iconElement.classList.add('success');
            stepDiv.classList.add('success');
            if (iconMaterial) iconMaterial.textContent = 'check_circle';
            if (timeElement) timeElement.textContent = `Completed in ${durationNumber.toFixed(2)}s`;
            completedSteps++;
        } else if (status === 'error') {
            iconElement.classList.add('error');
            stepDiv.classList.add('error');
            if (iconMaterial) iconMaterial.textContent = 'error';
            if (timeElement) timeElement.textContent = `Failed after ${durationNumber.toFixed(2)}s`;
        }
        updateProgress();
    }

    function updateProgress() {
        if (!agentProgressFill || !agentProgressText) return;
        const progressPercent = totalSteps > 0 ? (completedSteps / totalSteps) * 100 : 0;
        agentProgressFill.style.width = `${progressPercent}%`;
        agentProgressText.textContent = `${Math.round(progressPercent)}% Complete`;
    }

    function clearNavAgentSteps() {
        if (agentNavSteps) {
            agentNavSteps.innerHTML = '<div class="nav-step-placeholder"><span class="material-icons">psychology</span><span>No active workflow</span></div>';
        }
        totalSteps = 0;
        completedSteps = 0;
        updateProgress();
    }

    // From your script.js file

    function resetNavAgentStream() {
        clearNavAgentSteps();
        
        // Ensure the section is expanded when a new workflow starts
        const agentStreamSection = document.querySelector('.agent-stream-section');
        if (agentStreamSection) {
            // THIS IS THE LINE THAT EXPANDS THE SECTION
            agentStreamSection.classList.remove('collapsed');
        }
    }

    function addBotResponse(data) {
        const botBubble = document.createElement('div');
        botBubble.className = 'chat-message bot-message';
        const messageId = 'msg_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        botBubble.dataset.messageId = messageId;
        
        let content = `
            <div class="message-container">
                <div class="message-header">
                    <div class="message-avatar bot-avatar">
                        <img src="/static/img/assistant_logo.png" alt="Assistant" style="width: 30px; height: 30px; border-radius: 50%;"/>
                    </div>
                    <span class="message-name">Assistant</span>
                </div>
                <div class="message-bubble bot-bubble">`;
        if (data.chart_html_path) {
            const chartId = 'chart_' + messageId;
            content += `<div class="response-image chart-container-iframe">
                <iframe id="${chartId}" src="${data.chart_html_path}" frameborder="0"></iframe>
                <button class="download-chart-overlay" onclick="downloadPlotlyChart('${chartId}')" title="Download Chart as PNG">
                    <span class="material-icons">download</span>
                </button>
            </div>`;
        }
        if (data.text) content += `<div class="response-text"><p>${data.text}</p></div>`;
         // Add metadata display
        if (data.agent && data.model) {
            content += `<div class="response-metadata">
                <small class="text-muted">
                    <span class="metadata-item">
                        <span class="material-icons">smart_toy</span>
                        Agent: ${data.agent}
                    </span>
                    <span class="metadata-item">
                        <span class="material-icons">psychology</span>
                        Model: ${data.model}
                    </span>
                </small>
            </div>`;
        }
        content += `<div class="response-toggles">
            <button class="toggle-btn visualization-toggle" data-target="response-image" style="display: ${data.chart_html_path ? 'inline-flex' : 'none'}"><span class="material-icons">visibility</span><span class="toggle-text">Hide Visualization</span></button>
            <button class="toggle-btn" data-target="table-section" style="display: ${data.table ? 'inline-flex' : 'none'}"><span class="material-icons">table_chart</span><span class="toggle-text">Show Data Table</span></button>
            <button class="toggle-btn" data-target="sql-section" style="display: ${data.sql_query ? 'inline-flex' : 'none'}"><span class="material-icons">storage</span><span class="toggle-text">Show SQL Query</span></button>
            <button class="toggle-btn" data-target="python-section" style="display: ${data.python_code ? 'inline-flex' : 'none'}"><span class="material-icons">code</span><span class="toggle-text">Show Python Code</span></button>
        </div>`;
        content += `<div class="voting-section"><button class="vote-btn vote-up" onclick="voteResponse(this, 'up')" title="This was helpful"><span class="material-icons">thumb_up</span></button><button class="vote-btn vote-down" onclick="voteResponse(this, 'down')" title="This needs improvement"><span class="material-icons">thumb_down</span></button></div>`;
        if (data.table) content += `<div class="collapsible-section table-section" style="display: none;"><div class="section-header"><div class="header-left"><span class="material-icons">table_chart</span><span>Data Table</span></div><button class="export-csv-button" onclick="exportTableAsCSV(this)"><span class="material-icons">download</span>Export as CSV</button></div><div class="table-container">${data.table}</div></div>`;
        if (data.sql_query) content += `<div class="collapsible-section sql-section" style="display: none;"><div class="section-header"><span class="material-icons">storage</span><span>SQL Query</span><button class="copy-button" onclick="copyCode(this, 'sql')"><span class="material-icons">content_copy</span>Copy</button></div><div class="code-block"><pre><code class="language-sql">${data.sql_query}</code></pre></div></div>`;
        if (data.python_code) content += `<div class="collapsible-section python-section" style="display: none;"><div class="section-header"><span class="material-icons">code</span><span>Python Code</span><button class="copy-button" onclick="copyCode(this, 'python')"><span class="material-icons">content_copy</span>Copy</button></div><div class="code-block"><pre><code class="language-python">${data.python_code}</code></pre></div></div>`;
        content += '</div></div>';
        botBubble.innerHTML = content;
        responseArea.appendChild(botBubble);
        
        botBubble.querySelectorAll('.toggle-btn').forEach(button => {
            button.addEventListener('click', () => {
                const targetClass = button.getAttribute('data-target');
                const isVizToggle = button.classList.contains('visualization-toggle');
                const targetElement = isVizToggle ? botBubble.querySelector('.response-image') : botBubble.querySelector(`.${targetClass}`);
                const toggleText = button.querySelector('.toggle-text');
                const icon = button.querySelector('.material-icons');
                const isHidden = targetElement.style.display === 'none';

                targetElement.style.display = isHidden ? (isVizToggle ? 'block' : 'block') : 'none';
                button.classList.toggle('active', !isHidden);
                
                if (isVizToggle) {
                    toggleText.textContent = isHidden ? 'Hide Visualization' : 'Show Visualization';
                    icon.textContent = isHidden ? 'visibility' : 'visibility_off';
                } else {
                    toggleText.textContent = toggleText.textContent.replace(isHidden ? 'Show' : 'Hide', isHidden ? 'Hide' : 'Show');
                }
                scrollToBottom();
            });
        });
        scrollToBottom();
    }

    function scrollToBottom() {
        responseArea.scrollTop = responseArea.scrollHeight;
    }

    // --- The rest of the helper functions (copyCode, settings sidebar, welcome screen, etc.) remain unchanged ---

    window.copyCode = function(button, type) {
        const codeBlock = button.parentElement.nextElementSibling.querySelector('code');
        const textToCopy = codeBlock.textContent;
        
        navigator.clipboard.writeText(textToCopy).then(() => {
            const originalText = button.innerHTML;
            button.innerHTML = '<span class="material-icons">check</span>Copied!';
            button.style.background = '#4caf50';
            
            setTimeout(() => {
                button.innerHTML = originalText;
                button.style.background = '';
            }, 2000);
        }).catch(err => {
            console.error('Failed to copy text: ', err);
            button.innerHTML = '<span class="material-icons">error</span>Failed';
            setTimeout(() => {
                button.innerHTML = '<span class="material-icons">content_copy</span>Copy';
            }, 2000);
        });
    }

    if (runSettingsBtn && settingsSidebar && closeSettingsBtn) {
        runSettingsBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            settingsSidebar.classList.add('is-open');
        });

        closeSettingsBtn.addEventListener('click', () => {
            settingsSidebar.classList.remove('is-open');
        });
        
        document.addEventListener('click', (event) => {
            if (!settingsSidebar.contains(event.target) && settingsSidebar.classList.contains('is-open')) {
                 settingsSidebar.classList.remove('is-open');
            }
        });
    }

    const dropdowns = document.querySelectorAll('.dropdown');
    
    function initializeDropdowns() {
        dropdowns.forEach(dropdown => {
            dropdown.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdowns.forEach(other => { if (other !== dropdown) other.classList.remove('is-open'); });
                dropdown.classList.toggle('is-open');
            });
        });
        document.addEventListener('click', () => dropdowns.forEach(d => d.classList.remove('is-open')));
    }
    
    initializeDropdowns();

    document.querySelector('.ai-config-compact')?.addEventListener('click', (e) => {
        e.stopPropagation();
        settingsSidebar.classList.add('is-open');
    });
    

    function getSelectedAgent() {
        return document.getElementById('agent-selected-text')?.getAttribute('data-value') || 'Genie';
    }

    function getSelectedModel() {
        return document.getElementById('model-selected-text')?.getAttribute('data-value') || 'Genie-Space';
    }

    const newChatBtn = document.querySelector('.nav-item.active');

    function generateWelcomeContent() {
        return fetch('app-config-files/welcome-screen-setup.json')
            .then(response => response.ok ? response.json() : Promise.reject('Failed to load welcome config'))
            .then(config => {
                // Use the user's name if available
                if (window.currentUserInfo && window.currentUserInfo.first_name) {
                    config.title.content = `Welcome ${window.currentUserInfo.first_name}`;
                }
                
                let content = createElementFromConfig(config.title);
                content += createElementFromConfig(config.caption);
                content += generateAiConfigCompact(config.aiConfigCompact);
                content += generateWhatsNewContainer(config.whatsNewContainer);
                return content;
            })
            .catch(error => {
                console.error('Error loading welcome content:', error);
                return `<div class="error-message">Failed to load welcome content.</div>`;
            });
    }

    function createElementFromConfig(config) {
        if (!config || !config.tag) return '';
        let attributes = config.id ? ` id="${config.id}"` : '';
        attributes += config.class ? ` class="${config.class}"` : '';
        let content = config.content || '';
        if (config.bold) content = `<b>${content}</b>`;
        return `<${config.tag}${attributes}>${content}</${config.tag}>`;
    }

    function generateAiConfigCompact(config) {
        if (!config) return '';
        let content = `<${config.tag} class="${config.class}">`;
        const compactContent = config.content.configCompactContent;
        content += `<${compactContent.tag} class="${compactContent.class}">`;
        compactContent.items.forEach(item => {
            if (item.class === 'config-separator') {
                content += `<${item.tag} class="${item.class}">${item.content}</${item.tag}>`;
            } else {
                content += `<${item.tag} class="${item.class}">`;
                item.icons?.forEach(icon => { content += `<${icon.tag} class="${icon.class}">${icon.content}</${icon.tag}>`; });
                if (item.type) content += `<${item.type.tag} class="${item.type.class}">${item.type.content}</${item.type.tag}>`;
                if (item.badge) {
                    let attrs = `class="${item.badge.class}"` + (item.badge.id ? ` id="${item.badge.id}"` : '');
                    content += `<${item.badge.tag} ${attrs}>${item.badge.content}</${item.badge.tag}>`;
                }
                content += `</${item.tag}>`;
            }
        });
        content += `</${compactContent.tag}></${config.tag}>`;
        return content;
    }

    function generateWhatsNewContainer(config) {
        if (!config) return '';
        let content = `<${config.tag} class="${config.class}">`;
        content += createElementFromConfig(config.title);
        content += `<${config.grid.tag} class="${config.grid.class}">`;
        config.grid.cards.forEach((card, idx) => {
            content += `<${card.tag} class="${card.class}" data-card-idx="${idx}">
                <${card.iconPlaceholder.tag} class="${card.iconPlaceholder.class}">
                    <${card.iconPlaceholder.icon.tag} class="${card.iconPlaceholder.icon.class}">${card.iconPlaceholder.icon.content}</${card.iconPlaceholder.icon.tag}>
                </${card.iconPlaceholder.tag}>
                <${card.content.tag} class="${card.content.class}">
                    <${card.content.header.tag}>${card.content.header.content}</${card.content.header.tag}>
                    <${card.content.description.tag}>${card.content.description.content}</${card.content.description.tag}>
                </${card.content.tag}>
            </${card.tag}>`;
        });
        content += `</${config.grid.tag}></${config.tag}>`;
        return content;
    }

    async function startNewChatSession() {
        // Only create a new session if we don't have one already
        if (!getCookie('session_id')) {
            try {
                const response = await fetch('/api/new-chat', { method: 'POST' });
                if (!response.ok) throw new Error('Failed to start a new chat session.');
                const data = await response.json();
                setCookie('session_id', data.session_id, 7); // Store session ID for 7 days
                console.log('New chat session started:', data.session_id);
            } catch (error) {
                console.error('Error starting new chat session:', error);
                const tempId = 'temp_' + Date.now();
                setCookie('session_id', tempId, 1); // Fallback to a temporary ID for 1 day
            }
        }
    }

    async function loadWelcomeContent() {
        // First initialize user to get their information
        await initializeUser();
        
        // Then generate welcome content with the user info available
        const content = await generateWelcomeContent();
        const responseArea = document.getElementById('response-area');
        if (responseArea) {
            responseArea.innerHTML = content;
            
            // After setting the content, check if we need to update the welcome title again
            // (in case it was overwritten by the content)
            const welcomeTitle = document.getElementById('welcome-title');
            if (welcomeTitle && window.currentUserInfo && window.currentUserInfo.first_name) {
                welcomeTitle.innerHTML = `<b>Welcome ${window.currentUserInfo.first_name}</b>`;
            }
            
            attachCardListeners();
        }
        await startNewChatSession(); // Start a new session when welcome screen loads
    }
    
    loadWelcomeContent();

    if (newChatBtn) {
        newChatBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            // Clear the current session ID to force creation of a new one
            setCookie('session_id', '', -1); // Expire the cookie
            await loadWelcomeContent();
            initializeUser();
            promptInput.value = '';
            promptInput.style.height = oneLineHeight + 'px';
            promptInput.style.overflowY = 'hidden';
            collapseAgentStreamSection();
        });
    }

    function attachCardListeners() {
        document.querySelectorAll('.card').forEach(card => {
            card.removeEventListener('click', card._cardClickHandler || (() => {}));
            const handler = () => {
                if (promptInput.disabled) return;
                const cardText = card.querySelector('.card-content p')?.textContent || card.innerText;
                setInputState(false);
                responseArea.innerHTML = '';
                addUserMessage(cardText);
                const loadingBubble = addBotMessage('Analyzing your query...', 'loading');
                startAgentStreamWithResponse(cardText, loadingBubble);
            };
            card._cardClickHandler = handler;
            card.addEventListener('click', handler);
        });
    }

    // --- All remaining window functions (voting, export, etc.) are unchanged ---
    window.exportTableAsCSV = function(button) {
        try {
            const table = button.closest('.table-section').querySelector('table');
            if (!table) return alert('No table found to export');
            let csv = [];
            table.querySelectorAll('tr').forEach(row => {
                let rowData = [];
                row.querySelectorAll('th, td').forEach(cell => {
                    rowData.push(`"${cell.textContent.trim().replace(/"/g, '""')}"`);
                });
                csv.push(rowData.join(','));
            });
            const blob = new Blob([csv.join('\n')], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = `data_export_${new Date().toISOString().slice(0,10)}.csv`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (e) { console.error('Export error:', e); alert('Failed to export CSV.'); }
    };
    
    // MODIFIED FUNCTION: Correctly downloads the chart from within the iframe
    window.downloadPlotlyChart = function(chartId) {
        try {
            // Get the iframe element by its ID
            const iframe = document.getElementById(chartId);
            if (!iframe) {
                console.error('Error downloading chart: iframe not found with ID:', chartId);
                alert('Unable to find the chart container.');
                return;
            }

            // Access the content window of the iframe
            const iframeWindow = iframe.contentWindow;

            // Check if the iframe's content and the Plotly library within it are accessible
            if (!iframeWindow || !iframeWindow.Plotly) {
                console.error('Error downloading chart: Plotly library not found inside the iframe.');
                alert('The chart is not ready for download. Please wait a moment and try again.');
                return;
            }
            
            // Find the actual chart element inside the iframe's document
            const chartElement = iframeWindow.document.querySelector('.plotly-graph-div');
            if (!chartElement) {
                console.error('Error downloading chart: Plotly chart element not found inside the iframe.');
                alert('Unable to find the chart data within the frame.');
                return;
            }

            // Call the downloadImage function from the iframe's context
            iframeWindow.Plotly.downloadImage(chartElement, {
                format: 'png',
                width: 1200,
                height: 800,
                filename: `plotly-chart-${Date.now()}`
            });

        } catch (error) {
            console.error('Error downloading Plotly chart:', error);
            alert('An unexpected error occurred while trying to download the chart.');
        }
    }

    // Vote response function
    window.voteResponse = function(button, voteType) {
        try {
            const messageContainer = button.closest('.chat-message');
            const messageId = messageContainer.dataset.messageId || Date.now().toString();
            const voteUpBtn = messageContainer.querySelector('.vote-up');
            const voteDownBtn = messageContainer.querySelector('.vote-down');
            
            // Check if feedback has been provided (like button disabled)
            if (voteType === 'up' && voteUpBtn.classList.contains('disabled')) {
                alert('You cannot like this response after providing negative feedback.');
                return;
            }

            const responseData = {
                vote: voteType,
                timestamp: new Date().toISOString(),
                message_id: messageId
            };

            // Clear previous votes
            const voteButtons = messageContainer.querySelectorAll('.vote-btn');
            voteButtons.forEach(btn => btn.classList.remove('voted'));
            button.classList.add('voted');

            if (voteType === 'up') {
                // Check if user is switching from dislike to like
                const wasDisliked = messageContainer.dataset.hasNegativeFeedback === 'true';
                if (wasDisliked) {
                    alert('You cannot like this response after providing negative feedback.');
                    return;
                }

                // Send thumbs up vote
                sendVoteToAPI(responseData);
                
                // Visual feedback
                button.style.color = '#4caf50';
                setTimeout(() => {
                    button.style.color = '';
                }, 2000);
                
            } else if (voteType === 'down') {
                // Show feedback modal for thumbs down
                showFeedbackModal(responseData, messageContainer);
            }

        } catch (error) {
            console.error('Vote error:', error);
            alert('Failed to record vote. Please try again.');
        }
    };

    // Show feedback modal for negative votes
    function showFeedbackModal(voteData, messageContainer) {
        // Create modal if it doesn't exist
        let modal = document.getElementById('feedback-modal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'feedback-modal';
            modal.className = 'feedback-modal';
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Help us improve</h3>
                        <button class="modal-close" onclick="closeFeedbackModal()">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>What could be better about this response?</p>
                        <textarea id="feedback-text" placeholder="Please share your feedback to help us improve..." rows="4"></textarea>
                        <div class="feedback-options">
                            <label><input type="checkbox" name="feedback-type" value="inaccurate"> Information was inaccurate</label>
                            <label><input type="checkbox" name="feedback-type" value="incomplete"> Response was incomplete</label>
                            <label><input type="checkbox" name="feedback-type" value="unclear"> Response was unclear</label>
                            <label><input type="checkbox" name="feedback-type" value="irrelevant"> Response was not relevant</label>
                            <label><input type="checkbox" name="feedback-type" value="other"> Other</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn-cancel" onclick="closeFeedbackModal()">Cancel</button>
                        <button class="btn-submit" onclick="submitFeedback()">Submit Feedback</button>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        }

        // Store vote data and message container reference for submission
        modal.dataset.voteData = JSON.stringify(voteData);
        modal.dataset.messageId = messageContainer.dataset.messageId;
        
        // Show modal
        modal.style.display = 'flex';
        document.getElementById('feedback-text').focus();
    }

    // Close feedback modal
    window.closeFeedbackModal = function() {
        const modal = document.getElementById('feedback-modal');
        if (modal) {
            modal.style.display = 'none';
            // Clear form
            document.getElementById('feedback-text').value = '';
            document.querySelectorAll('input[name="feedback-type"]').forEach(cb => cb.checked = false);
        }
    };

    // Submit feedback
    window.submitFeedback = function() {
        try {
            const modal = document.getElementById('feedback-modal');
            const voteData = JSON.parse(modal.dataset.voteData);
            const messageId = modal.dataset.messageId;
            const feedbackText = document.getElementById('feedback-text').value;
            const selectedTypes = Array.from(document.querySelectorAll('input[name="feedback-type"]:checked'))
                                       .map(cb => cb.value);

            const feedbackData = {
                ...voteData,
                feedback: feedbackText,
                feedback_types: selectedTypes
            };

            // Send to API
            sendVoteToAPI(feedbackData);

            // Disable like button for this message after feedback is provided
            const messageContainer = document.querySelector(`[data-message-id="${messageId}"]`);
            if (messageContainer) {
                const likeButton = messageContainer.querySelector('.vote-up');
                if (likeButton) {
                    likeButton.classList.add('disabled');
                    likeButton.style.opacity = '0.5';
                    likeButton.style.cursor = 'not-allowed';
                    likeButton.title = 'You cannot like this response after providing negative feedback';
                }
                // Mark that this message has negative feedback
                messageContainer.dataset.hasNegativeFeedback = 'true';
            }

            // Close modal
            closeFeedbackModal();

            // Show success message
            alert('Thank you for your feedback! We will use it to improve our responses.');

        } catch (error) {
            console.error('Feedback submission error:', error);
            alert('Failed to submit feedback. Please try again.');
        }
    };

    // Send vote/feedback to API
    async function sendVoteToAPI(data) {
        try {
            const response = await fetch('/vote', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            console.log('Vote recorded:', result);

        } catch (error) {
            console.error('API vote error:', error);
        }
    }
});

// **** USER INITIALIZATION ****
async function initializeUser() {
    try {
        console.log('🔍 Fetching user information...');
        const response = await fetch('/api/user');
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const userInfo = await response.json();
        console.log('👤 User info received:', userInfo);
        
        // Store the user info globally so it can be accessed elsewhere
        window.currentUserInfo = userInfo;
        
        const welcomeTitle = document.getElementById('welcome-title');
        if (welcomeTitle) welcomeTitle.innerHTML = `<b>${userInfo.welcome_message}</b>`;
        
        const userInitials = document.getElementById('user-initials');
        if (userInitials) userInitials.textContent = userInfo.initials;
        
        console.log('✅ User UI updated successfully');
    } catch (error) {
        console.error('❌ Error fetching user info:', error);
        // Set fallback values
        window.currentUserInfo = { initials: 'U', first_name: 'User' };
        
        const welcomeTitle = document.getElementById('welcome-title');
        if (welcomeTitle) welcomeTitle.innerHTML = '<b>Welcome User</b>';
        
        const userInitials = document.getElementById('user-initials');
        if (userInitials) userInitials.textContent = 'U';
    }
}