# General Template

[[_TOC_]]

Welcome to your new General project! This template has been created to simplify the process of creating a project in GitLab at Amgen. This project will help you think about all the aspects of code quality and SSDLC as you develop both your code and the project to support your code development. While this not a lot of files in this template at the beginning, it does contain a CI/CD pipeline that will help you automate the testing and deployment of your code.

## Project Overview

This project contains a GitLab pipeline along with this readme. The GitLab pipeline file is the definiton file that GitLab uses to perform a CI/CD pipeline on this project. If you take a look at the pipeline file (.gitlab-ci.yml) you can see that there is an include that brings in all the power of GitLab to scan your code. The pipeline can be expanded to include more stages such as compiling and deployment.

## Project Structure

```
general-template/ 
├── .gitlab-ci.yml
├── README.md 
```

## Prerequisites

## Local Setup

## Usage

## Development

This minimum project is a framework to use to expand into your program neeeds. The purpose is to give you examples and links to help you as you expand your project to also include code quality and security.

## CI/CD

This project uses GitLab CI/CD for automated testing and deployment. See `.gitlab-ci.yml` for details.

## Security

For more information on the security used in the pipelines, see the [SSDLC Global Templates](https://gitlab.nimbus.amgen.com/gipappsec/ssdlc-global-templates/-/tree/main?ref_type=heads) and associated [sharepoint site](https://amgen.sharepoint.com/sites/secure-SDLC/SitePages/CICD-Automation-Info.aspx)

## CI/CD Components

This project leverages GitLab's [CI/CD Components](https://docs.gitlab.com/ee/ci/components/) to streamline your development and deployment processes.

See more components in the [CI/CD Catalog](https://gitlab.nimbus.amgen.com/explore/catalog)

### What are CI/CD Templates and Components?

[CI/CD Templates](https://docs.gitlab.com/ee/development/cicd/templates.html) were pre-configured modular pipelines that define how your project is built, tested, and deployed. They save you time and ensure best practices are followed, but had some limitations that are addressed by [CI/CD Components](https://docs.gitlab.com/ee/ci/components/).  

[Components](https://docs.gitlab.com/ee/ci/components/) are reusable parts of CI/CD configurations that can be included in your pipeline. They allow you to add specific functionality without writing complex CI/CD code from scratch.

### Our CI/CD Setup

By default, this project includes the following CI/CD components:

1. Python Linting: Checks your code quality
   [Learn more about the Python Linting component](placeholder)

2. Python Testing: Runs your test suite
   [Learn more about the Python Testing component](placeholder)

3. Serverless Deployment: Handles deploying your Lambda functions
   [Learn more about the Serverless Deployment component](https://www.serverless.com/framework/docs)

### Customizing CI/CD

You can customize the CI/CD pipeline by modifying the `.gitlab-ci.yml` file. Here are some ways to do this:

- Add or remove components
- Adjust component inputs
- Add custom stages or jobs

If you're new to components or GitLab: Start by reviewing the existing setup and make small changes as needed. The component documentation (linked above) provides easy-to-follow guides.

For experienced users: You can create custom components or complex pipeline logic to suit your specific needs. Refer to the [GitLab CI/CD documentation](https://docs.gitlab.com/ee/topics/build_your_application.html) for advanced features.

### Getting Help

If you're unsure about CI/CD or need assistance, don't hesitate to:
1. Check the [GitLab CI/CD Components documentation](https://docs.gitlab.com/ee/ci/components/)
2. Reach out to [Nimbus](https://amgennow.service-now.com/it_self_service?id=sc_cat_item&table=sc_cat_item&sys_id=b0df88b51bd5d25030e086ee6e4bcb2f)

CI/CD is here to make your life easier, not harder. Start simple and expand as you grow more comfortable!

## Customization

Feel free to modify any part of this template to fit your specific needs. You can add new files, change existing ones, or remove anything you don't need. This template is meant to be a starting point, not a final product.

## Contribution

To contribute to this template please follow the below process:
1. Fork this project
2. Make the changes to the template
3. Open a Merge Request on this project and tag [Nimbus] as reviewers.  

## Support

If you encounter any issues or have questions about this template, please contact [Nimbus](https://amgennow.service-now.com/it_self_service?id=sc_cat_item&table=sc_cat_item&sys_id=b0df88b51bd5d25030e086ee6e4bcb2f).
