GENERAL_CHART_PROMPT = '''
    Create a beautiful and interactive graph using Plotly Express based on the provided data 
    (either a pandas DataFrame or a list of dictionaries). The visualization should include 
    appropriate styling, color schemes (Consider colorblinds as audience as well), and interactive features. Return only the Python code 
    without any explanations or comments. If user prompt ask for a specific chart or plot 
    create code for that otherwise use your intelligence to choose the chart which will best 
    fit. Keep the font size small. Give maximum area to the graph. make graph of size 
    width: 645,height: 430.
    Input variable will be:
    columns: {columns}
    data: {data}
    context: {context}
    prompt: {task}
    '''