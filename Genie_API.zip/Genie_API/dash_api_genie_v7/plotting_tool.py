import pandas as pd
import numpy as np
import os
from dotenv import load_dotenv
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.io as pio
from lifelines import KaplanMeierFitter, NelsonAalenFitter, BreslowFlemingHarringtonFitter, CoxPHFitter,  WeibullFitter
from lifelines.statistics import logrank_test
#from langchain.chat_models import ChatOpenAI
import json
from langchain.prompts import ChatPromptTemplate
from langchain.schema import SystemMessage, HumanMessage
from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
import re
from sklearn.preprocessing import LabelEncoder

load_dotenv()

# Load environment variables

LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")

# LLM for plotting graph
LLM = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

def general_plotting_agent(df, context_description, user_input):
    def get_fig_from_code(code):
        local_variables = {}
        exec(code, {}, local_variables)
        return local_variables['fig']
    
    CHART_PROMPT = '''
    Role: You are biomarker assistant tasked with providing up-to-date information about the clinical trial data.

    Objective: Your job is to write pandas code to visualize and plot charts based on the given data and column names, context and task.

    Capabilities: You have been given a dataframe as data. The data columns are provided. The context of the task is presented as context.

    Next Steps: When asked to visualize data, provide only python code using Plotly Express to generate charts. 
    The plotting figure sizes should be 5 by 3. Font size for the title and axes should be 9px. Select different colours and styles.
    Include all necessary imports in your code snippets.
    If the task request specific graph use it otherwise use appropriate chart

    columns: {columns}

    data: {data}

    context: {context}

    prompt: {task}

    '''

    chart_prompt = ChatPromptTemplate.from_template(CHART_PROMPT)
    graph_agent_chain = chart_prompt | LLM

    graph_agent_response = graph_agent_chain.invoke({
                "columns":df.columns.tolist(),
                "data": df.to_dict(orient="records"),
                "context": context_description,
                "task": user_input
            })
    graph_result_output = graph_agent_response.content.strip() or ""
    code_block_match = re.search(r'```(?:[Pp]ython)?(.*?)```', graph_result_output, re.DOTALL)

    if code_block_match:
        code_block = code_block_match.group(1).strip()
        cleaned_code = re.sub(r'(?m)^\s*fig\.show\(\)\s*$', '', code_block)
        try:
            fig = get_fig_from_code(cleaned_code)
            return fig, graph_result_output
        except Exception as e:
            fig = go.Figure()
            return fig, str(e)
            pass
    else:
        fig = go.Figure()
        return fig, "LLM cannot generate plotting code for this data"
    


def survival_plotting_agent(df: pd.DataFrame):
    def identify_survival_columns(df: pd.DataFrame) -> dict:
        prompt = f"""
        I have a dataset with the following columns: {', '.join(df.columns)}.
        I want to generate survival curves.
        Which columns should be used for duration and event?
        Return result in the form of json, Don't add explanation: {{"duration": "col1", "event": "col2"}}
        """
        messages = [
            SystemMessage(content="You are a helpful assistant that identifies survival analysis columns."),
            HumanMessage(content=prompt)
        ]
        response = LLM.invoke(messages)
        return json.loads(response.content)
    
    def generate_survival_subplots(df: pd.DataFrame, columns: dict):
        #df = df[[columns['duration'], columns['event']] + ([columns['group']] if 'group' in columns else #[])]
        #df.columns = ['duration', 'event'] + (['group'] if 'group' in columns else [])
        # Retain only numerical data
        
        inferred_column_dict = {v: k for k, v in columns.items()}
        df = df.rename(columns=inferred_column_dict)

        if 'SUBJID' in df.columns:
            df = df.drop('SUBJID', axis = 1)
        df['duration'] = df['duration'].astype(float)
        df['event'] = df['event'].astype(float)
        df['event'] = df['event'].astype(int)
        df = df.apply(LabelEncoder().fit_transform)
        

        fitters = [
            (KaplanMeierFitter, "Kaplan-Meier"),
            (NelsonAalenFitter, "Nelson-Aalen"),
            (BreslowFlemingHarringtonFitter, "BH")
        ]

        fig = make_subplots(rows=3, cols=1, shared_xaxes=True, vertical_spacing=0.1,
                            subplot_titles=[name for _, name in fitters])

        for i, (fitter_cls, title) in enumerate(fitters, start=1):
            fitter = fitter_cls()
            if 'group' in df.columns:
                for name, grouped_df in df.groupby("group"):
                    fitter.fit(grouped_df["duration"], grouped_df["event"], label=f"{title} - {name}")
                    curve_df = (fitter.survival_function_ if hasattr(fitter, 'survival_function_') else fitter.cumulative_hazard_).reset_index()
                    fig.add_trace(
                        go.Scatter(x=curve_df["timeline"], y=curve_df[fitter._label], mode='lines', name=fitter._label),
                        row=i, col=1
                    )
            else:
                fitter.fit(df["duration"], df["event"], label=f"{title} - Overall")
                curve_df = (fitter.survival_function_ if hasattr(fitter, 'survival_function_') else fitter.cumulative_hazard_).reset_index()
                fig.add_trace(
                    go.Scatter(x=curve_df["timeline"], y=curve_df[fitter._label], mode='lines', name=fitter._label),
                    row=i, col=1
                )

        fig.update_layout(
            height=900,
            title_text="Survival Curves by Method",
            showlegend=True
        )
        return fig
    
    def generate_survival_curves_km(df: pd.DataFrame, columns: dict):
        
        inferred_column_dict = {v: k for k, v in columns.items()}
        df = df.rename(columns=inferred_column_dict)

        if 'SUBJID' in df.columns:
            df = df.drop('SUBJID', axis = 1)
        df['duration'] = df['duration'].astype(float)
        df['event'] = df['event'].astype(float)
        df['event'] = df['event'].astype(int)
        df.columns = df.columns.str.lower()
        df = df.apply(LabelEncoder().fit_transform)
        #print(df.columns)
        kmf = KaplanMeierFitter()
        fig = px.line()
        
        
        if 'group' in df.columns:
            for name, grouped_df in df.groupby("group"):
                kmf.fit(grouped_df["duration"], grouped_df["event"], label=name)
                survival_df = kmf.survival_function_.reset_index()
                survival_df["group"] = name
                fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name=name)
            kmf.fit(df["duration"], df["event"], label="Mean Survival")
            survival_df = kmf.survival_function_.reset_index()
            fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name="Mean Survival")

            groups = df['group'].unique()
            if len(groups) == 2:
                g1 = df[df['group'] == groups[0]]
                g2 = df[df['group'] == groups[1]]
                result = logrank_test(g1['duration'], g2['duration'], g1['event'], g2['event'])
                fig.update_layout(title=f'Kaplan-Meier Survival Curves Log-Rank Test p-value: {result.p_value:.4f}')
            else:
                fig.update_layout(title='Kaplan-Meier Survival Curves Log-Rank Plot')

        elif 'strata' in df.columns:
            for name, grouped_df in df.groupby("strata"):
                kmf.fit(grouped_df["duration"], grouped_df["event"], label=name)
                survival_df = kmf.survival_function_.reset_index()
                survival_df["strata"] = name
                fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name=name)
            kmf.fit(df["duration"], df["event"], label="Mean Survival")
            survival_df = kmf.survival_function_.reset_index()
            fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name="Mean Survival")
            
            groups = df['strata'].unique()
            if len(groups) == 2:
                g1 = df[df['strata'] == groups[0]]
                g2 = df[df['strata'] == groups[1]]
                result = logrank_test(g1['duration'], g2['duration'], g1['event'], g2['event'])
                fig.update_layout(title=f'Kaplan-Meier Survival Curves Log-Rank Test p-value: {result.p_value:.4f}')
            else:
                fig.update_layout(title='Kaplan-Meier Survival Curves Log-Rank Plot')

        elif 'stratification' in df.columns:
            for name, grouped_df in df.groupby("stratification"):
                kmf.fit(grouped_df["duration"], grouped_df["event"], label=name)
                survival_df = kmf.survival_function_.reset_index()
                survival_df["stratification"] = name
                fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name=name)
            kmf.fit(df["duration"], df["event"], label="Mean Survival")
            survival_df = kmf.survival_function_.reset_index()
            fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name="Mean Survival")

            groups = df['stratification'].unique()
            if len(groups) == 2:
                g1 = df[df['stratification'] == groups[0]]
                g2 = df[df['stratification'] == groups[1]]
                result = logrank_test(g1['duration'], g2['duration'], g1['event'], g2['event'])
                fig.update_layout(title=f'Kaplan-Meier Survival Curves Log-Rank Test p-value: {result.p_value:.4f}')
            else:
                fig.update_layout(title='Kaplan-Meier Survival Curves Log-Rank Plot')
        else:
            kmf.fit(df["duration"], df["event"], label="Survival")
            survival_df = kmf.survival_function_.reset_index()
            fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name="Survival")
            fig.update_layout(title='Kaplan-Meier Survival Curves')

        fig.update_layout(height=450,
                        #title="Kaplan-Meier Survival Curves",
                        xaxis_title="Time",
                        yaxis_title="Survival Probability")
        return fig
    
    def plot_cox_coefficients(df: pd.DataFrame, columns: dict):

        inferred_column_dict = {v: k for k, v in columns.items()}
        df = df.rename(columns=inferred_column_dict)

        if 'SUBJID' in df.columns:
            df = df.drop('SUBJID', axis = 1)
        df['duration'] = df['duration'].astype(float)
        df['event'] = df['event'].astype(float)
        df['event'] = df['event'].astype(int)
        df = df.apply(LabelEncoder().fit_transform)
        df.columns = df.columns.str.lower()


        #covariates = [col for col in df.columns if col not in ['duration', 'event']]
        
        cph = CoxPHFitter()
        #cph.fit(df[['duration', 'event'] + covariates], duration_col='duration', event_col='event')
        if 'strata' in df.columns:
            cph.fit(df, duration_col='duration', event_col='event', strata=['strata'])
        elif 'stratification' in df.columns:
            cph.fit(df, duration_col='duration', event_col='event', strata=['stratification'])
        else:
            cph.fit(df, duration_col='duration', event_col='event')

        '''
        summary = cph.summary.reset_index()
        summary['HR'] = np.exp(summary['coef'])
        summary['CI_lower'] = np.exp(summary['coef lower 95%'])
        summary['CI_upper'] = np.exp(summary['coef upper 95%'])

        fig = go.Figure()

        fig.add_trace(go.Scatter(
            x=summary['HR'],
            y=summary['covariate'],
            #y=summary.index,
            mode='markers',
            error_x=dict(
                type='data',
                symmetric=False,
                array=summary['CI_upper'] - summary['HR'],
                arrayminus=summary['HR'] - summary['CI_lower']
            ),
            marker=dict(size=10, color='blue'),
            name='Hazard Ratio'
        ))

        fig.add_shape(type='line', x0=1, x1=1, y0=-0.5, y1=len(summary)-0.5,
                    line=dict(color='red', dash='dash'))

        fig.update_layout(
            title="Cox Model Coefficients (Hazard Ratios)",
            xaxis_title="Hazard Ratio (log scale)",
            yaxis_title="Covariate",
            xaxis_type="log",
            height=400 + len(summary)*20
        )
        '''
        summary = cph.summary.reset_index().round(3)
        if summary.empty:
            fig_summary = go.Figure()
            fig = go.Figure()
        else:
            #summary = cph.summary.reset_index()
            summary['HR'] = np.exp(summary['coef'])
            summary['CI_lower'] = np.exp(summary['coef lower 95%'])
            summary['CI_upper'] = np.exp(summary['coef upper 95%'])

            fig = go.Figure()

            fig.add_trace(go.Scatter(
                x=summary['HR'],
                y=summary['covariate'],
                #y=summary.index,
                mode='markers',
                error_x=dict(
                    type='data',
                    symmetric=False,
                    array=summary['CI_upper'] - summary['HR'],
                    arrayminus=summary['HR'] - summary['CI_lower']
                ),
                marker=dict(size=10, color='blue'),
                name='Hazard Ratio'
            ))

            fig.add_shape(type='line', x0=1, x1=1, y0=-0.5, y1=len(summary)-0.5,
                        line=dict(color='red', dash='dash'))

            fig.update_layout(
                title="Cox Model Coefficients (Hazard Ratios)",
                xaxis_title="Hazard Ratio (log scale)",
                yaxis_title="Covariate",
                xaxis_type="log",
                height=400 + len(summary)*20
            )

            # Summary Plots
            summary_df = summary[['covariate','exp(coef) lower 95%','exp(coef)','exp(coef) upper 95%','p']]
            summary_df.columns = ['covariate', 'Lo-HR','HR(log)','Hi-HR','p-value']
            #print(summary_df.columns)
            fig_summary = go.Figure(data=[go.Table(
                header=dict(values=list(summary_df.columns),
                            fill_color='lightgrey',
                            align='left'),
                cells=dict(values=[summary_df[col] for col in summary_df.columns],
                        fill_color='white',
                        align='left'))
            ])
            
            fig_summary.update_layout(title='Cox PH Model Summary', margin=dict(l=0, r=0, t=40, b=0))
            '''
             # Model summary
            #summary_df = cph.summary.reset_index().round(3)
            # Global metrics
            global_metrics = {
                "Number of observations": cph._n_examples,
                "Concordance Index": round(cph.concordance_index_, 3),
                "AIC": round(cph.AIC_partial_, 3),
                #"Global p-value": round(cph._compute_p_values_for_log_likelihood_test(), 4),
            }
            global_metrics_df = pd.DataFrame(global_metrics.items(), columns=["Metric", "Value"])
            # Plotly figure
            fig_summary = make_subplots(
                rows=2, cols=1,
                row_heights=[0.8, 0.2],
                vertical_spacing=0.1,
                subplot_titles=("CoxPH Model Coefficients", "Model Summary Stats"),
                specs=[
                    [{"type":"table"}],
                    [{"type":"table"}]
                ]
            )
            # Coefficient table
            # Columns renamed for display (e.g., "exp(coef)" → "HR"), 95% Lower HR, HR ,95% Upper HR, p-value
            summary_df = summary_df[['exp(coef) lower 95%','exp(coef)','exp(coef) upper 95%','p']]
            #summary_df.columns = ['95% Lower HR', 'HR' ,'95% Upper HR','p-value']
            fig_summary.add_trace(
                go.Table(
                    header=dict(values=list(summary_df.columns), fill_color='lightgrey', align='left'),
                    cells=dict(values=[summary_df[col] for col in summary_df.columns], fill_color='white', align='left')
                ),
                row=1, col=1
            )
            # Global stats table
            fig_summary.add_trace(
                go.Table(
                    header=dict(values=["Metric", "Value"], fill_color='lightgrey', align='left'),
                    cells=dict(values=[global_metrics_df[col] for col in global_metrics_df.columns], fill_color='white', align='left')
                ),
                row=2, col=1
            )

            fig_summary.update_layout(title='Cox PH Model Summary and Global Statistics', height=400)
            '''
        return fig, fig_summary
    
    try:
        inferred_duration_event_dict = identify_survival_columns(df)
        # Check if duration and event are in the dict
        duration_event_keys_to_check = {"duration", "event"}
        if duration_event_keys_to_check.issubset(inferred_duration_event_dict):
           
            # 2. Generate Cox Fitting plot 
            # 3. Generate Cox Coefficients
            # 4. Check if target covariate is found, Generate partial coefficients for Cox
            # 5. Check if strata, Generate Cox Coefficient for Strata
            combined_fig = go.Figure()
            # 1. Check if group is found, Generate Group /Generate survival single plot
            #fig = generate_survival_subplots(df, inferred_duration_event_dict)
            
            fig1 = generate_survival_curves_km(df, inferred_duration_event_dict)
            fig2, fig3 = plot_cox_coefficients(df, inferred_duration_event_dict)
            combined_fig = make_subplots(rows=3, cols=1, subplot_titles=(fig1.layout.title.text, 
                                                                         fig2.layout.title.text,
                                                                         fig3.layout.title.text,
                                                                         ),
                                         specs=[[{"type": "xy"}], 
                                                [{"type": "xy"}],
                                                [{"type": "table"}]
                                                ])
            # Add traces from fig1 to subplot 1
            for trace in fig1.data:
                combined_fig.add_trace(trace, row=1, col=1)

            # Add traces from fig2 to subplot 2
            for trace in fig2.data:
                combined_fig.add_trace(trace, row=2, col=1)

            # Add traces from fig3 to subplot 3
            for trace in fig3.data:
                combined_fig.add_trace(trace, row=3, col=1)

            # Update layout
            combined_fig.update_layout(
                height=1200, 
                #title_text="Combined Subplots of Two Figures",
                showlegend=False  # If you want to disable duplicate legends
            )
            # 2. Generate Cox Fitting plot
            return combined_fig, ""
        else:
            error_message = """
                               This query wants to construct a Survival Plot
                               However, the LLM cannot detect the 
                               Event variable (eg. CNSROS) and 
                               Duration variable (eg. OSVRTMMO)
                               Add this line to the query prompt: 
                               ``Provide OSVRTMMO and CNSROS in addition``
                               """
            fig = go.Figure()
       
            return fig, error_message
        
        
    except Exception as e:
        fig = go.Figure()
        return fig, str(e)
       
    

    
# Multi-agent decision routing
def get_plotting_agent(df,  context_description,user_query):
    def route_query(user_query: str) -> str:
        messages = [
            SystemMessage(content="You are a routing assistant. Decide if the query is about survival analysis or general plotting. Return 'survival' or 'general' only."),
            HumanMessage(content=f"Query: {user_query}")
        ]
        response = LLM.invoke(messages)
        return response.content.strip().lower()
    
    task = route_query(user_query)
    #print(task)
    if task == "survival":
        fig, plot_code = survival_plotting_agent(df)
        
    elif task == "general":
        fig, plot_code = general_plotting_agent(df, context_description,user_query)
        
    else:
        fig = go.Figure()
        plot_code = ""
    return fig, plot_code


