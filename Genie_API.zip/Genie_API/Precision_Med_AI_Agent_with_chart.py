# Databricks notebook source
# MAGIC %md
# MAGIC **Precision Medicine AI Chatbot**

# COMMAND ----------

# MAGIC %pip install -U -qqq mlflow langgraph==0.3.4 langchain-experimental==0.3.4 databricks-langchain databricks-agents langgraph-checkpoint-sqlite  uv
# MAGIC dbutils.library.restartPython()
# MAGIC

# COMMAND ----------

#transformers torch
dbutils.library.restartPython()

# COMMAND ----------

import json
import requests
import functools
import pandas as pd
import numpy as np
import os
from typing import Any, Generator, Literal, Optional
from typing_extensions import TypedDict

import mlflow
from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from databricks_langchain.genie import GenieAgent
from langchain_core.runnables import RunnableLambda
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import create_react_agent, ToolNode, tools_condition
from mlflow.langchain.chat_agent_langgraph import ChatAgentState
from mlflow.pyfunc import ChatAgent
from mlflow.types.agent import (
    ChatAgentChunk,
    ChatAgentMessage,
    ChatAgentResponse,
    ChatContext,
)
from pydantic import BaseModel

from langchain_experimental.utilities import PythonREPL
from langchain_core.tools import tool
from langchain_core.messages import trim_messages, SystemMessage
from langgraph.checkpoint.memory import MemorySaver
from typing import Annotated
import plotly.graph_objects as go #To uPse the Plotly library to create the graph
import plotly.express as px #To use the Plotly Express library to create the graph
import seaborn as sns
#from plotnine import ggplot, aes, geom_line, geom_bar

# COMMAND ----------


GENIE_SPACE_ID = '01f009af5a301a0683d008356f8f3289'
 
DATABRICKS_GENIE_PAT = "dapif3bc3b1e718c335b48f4c410b07c9c12"
DATABRICKS_HOST  ="https://amgen-ai-dev.cloud.databricks.com"
client = WorkspaceClient(
    host=DATABRICKS_HOST ,
    token=DATABRICKS_GENIE_PAT
)
 
repl = PythonREPL()

@tool
def get_data_from_genie(prompt: str):
    """Retrieve data from Genie based on the prompt request"""

    def get_conversation_metadata_from_genie(prompt: str):
        raw_response = client.genie.start_conversation(
            space_id=GENIE_SPACE_ID,
            content=prompt
        ).result()
    
        return {
            "raw": raw_response
        }


    genie_token = 'dapif3bc3b1e718c335b48f4c410b07c9c12'
    host  ="https://amgen-ai-dev.cloud.databricks.com"

    response = get_conversation_metadata_from_genie(prompt)

    message_id  = response['raw'].id
    space_id = response['raw'].space_id
    conversation_id = response['raw'].conversation_id
    question_content = response['raw'].content
    attachment_id = response['raw'].attachments[0].attachment_id
    query_description = response['raw'].attachments[0].query.description
    sql_query= response['raw'].attachments[0].query.query
    statement_id = response['raw'].query_result.statement_id
    status = response['raw'].status


    # Use Metadata to create get prompt results
    url = f"{host}/api/2.0/genie/spaces/{space_id}/conversations/{conversation_id}/messages/{message_id}/attachments/{attachment_id}/query-result"
 
    headers = {
        "Authorization": f"Bearer {genie_token}"
        }
    
    results = requests.get(url, headers=headers)
     

    # Parse the data into a dataframe
    row_count = results.json()['statement_response']['manifest']['total_row_count']
    data = results.json()['statement_response']['result']['data_array']
    data_df = pd.DataFrame(data)
    if row_count > 30:
        data_df = data_df.head(10)
    
    # Parse the columns into a list
    col_count = results.json()['statement_response']['manifest']['schema']['column_count']
    if col_count > 0 :
        col_list_of_dict = results.json()['statement_response']['manifest']['schema']['columns']
        feature_list = []
        for element in col_list_of_dict:
            a = [element[key] for key in element if key=='name']
            feature_list.extend(a)

        data_df.columns =feature_list

    output = (query_description + """:\n\n """ + 
          data_df.to_markdown() + 
          """ \n\n """ + sql_query)


    return output





@tool
def python_repl_tool(
    code: Annotated[str, "The python code to execute code to generate plots, charts and visualizations. Use only plotly express to generate charts."],
):
    """Use this to execute python code. If you want to see the output of a value,
    you should print it out with `print(...)`. This is visible to the user.
    To generate charts, you must use ONLY plotly express. 
    Follow the instructions in the code output:
    1. The figure sizes should by 5 by 3. Select different colours and styles.
    2. import all necessary packages in the code.
    """
    try:
        result = repl.run(code)
    except BaseException as e:
        return f"Failed to execute. Error: {repr(e)}"
    result_str = f"Successfully executed:\n```python\n{code}\n```\nCODE OUTPUT:\n {result}"
    return result_str
    

# COMMAND ----------

AGENT_SYS_PROMP = """Role: You are biomarker assistant tasked with providing up-to-date information about the clinical trial data. 

Objective: Assist data-driven researchers by giving accurate information about the clinical trial data solely from GenieClient.

Capabilities: You have been given a tool called get_data_from_genie. Please retrieve your data only from this tool. Do not construct any query.

Next Steps: Use the python_repl_tool to generate visualizations and charts. Use plotly express to generate charts. The plotting figure sizes should by 5 by 3. Select different colours and styles.
"""

# COMMAND ----------

class State(TypedDict):
    messages: Annotated[list, add_messages]

graph_builder = StateGraph(State)

tools = [get_data_from_genie, python_repl_tool]


LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

llm_with_tools = llm.bind_tools(tools)

SYS_MSG = SystemMessage(content=AGENT_SYS_PROMP)

def chatbot(state: State):
    #messages = trim_messages(state["messages"], 
    #                         strategy='last', 
    #                         max_tokens=1000,
    #                         #token_counter=ChatDatabricks(model="gpt-4"),
    #                         token_counter=llm,
    #                         include_system=True,
    #                         allow_partial=True)
    #return {"messages": [llm_with_tools.invoke([SYS_MSG] + messages)]}
    return {"messages": [llm_with_tools.invoke([SYS_MSG] + state["messages"])]}
 
graph_builder.add_node("chatbot", chatbot)

tool_node = ToolNode(tools = tools)
graph_builder.add_node('tools', tool_node)

graph_builder.add_conditional_edges('chatbot', 
                                    tools_condition, 
                                    ['tools', END]
                                    )
graph_builder.add_edge('tools', 'chatbot')
graph_builder.set_entry_point('chatbot')

memory = MemorySaver()

compiled_graph = graph_builder.compile(checkpointer=memory)

# COMMAND ----------

from IPython.display import Markdown, display, Image


# COMMAND ----------

def call_conversational_agent(agent, prompt, user_session_id, verbose=False):
    events = agent.stream(
        {"messages":[{"role": "user", "content": prompt}]},
        {"configurable": {"thread_id": user_session_id}},
        stream_mode = "values",
    )
    print('Running Agent. Please wait...')
    for event in events:
        if verbose:
            event["messages"][-1].pretty_print()
            #yield event["messages"][-1]
    
    

# COMMAND ----------




# COMMAND ----------

uid = 'frank005'
query = 'Aggregate the average Age by DoseSeqp only, then visualize the data'
#query = 'Please visualize the data'
call_conversational_agent(compiled_graph, 
                          prompt=query, 
                          user_session_id=uid, 
                          verbose=True)

# COMMAND ----------

# MAGIC %md
# MAGIC **Deploy Script**

# COMMAND ----------

# MAGIC %%writefile genie_agent.py
# MAGIC
# MAGIC import json
# MAGIC import requests
# MAGIC import functools
# MAGIC import pandas as pd
# MAGIC import numpy as np
# MAGIC import os
# MAGIC from typing import Any, Generator, Literal, Optional
# MAGIC from typing_extensions import TypedDict
# MAGIC
# MAGIC import mlflow
# MAGIC from databricks.sdk import WorkspaceClient
# MAGIC from databricks_langchain import (
# MAGIC     ChatDatabricks,
# MAGIC     UCFunctionToolkit,
# MAGIC )
# MAGIC from databricks_langchain.genie import GenieAgent
# MAGIC from langchain_core.runnables import RunnableLambda
# MAGIC from langgraph.graph import END, StateGraph
# MAGIC from langgraph.graph.message import add_messages
# MAGIC from langgraph.graph.state import CompiledStateGraph
# MAGIC from langgraph.prebuilt import create_react_agent, ToolNode, tools_condition
# MAGIC from mlflow.langchain.chat_agent_langgraph import ChatAgentState
# MAGIC from mlflow.pyfunc import ChatAgent
# MAGIC from mlflow.types.agent import (
# MAGIC     ChatAgentChunk,
# MAGIC     ChatAgentMessage,
# MAGIC     ChatAgentResponse,
# MAGIC     ChatContext,
# MAGIC )
# MAGIC from pydantic import BaseModel
# MAGIC
# MAGIC from langchain_experimental.utilities import PythonREPL
# MAGIC from langchain_core.tools import tool
# MAGIC from langchain_core.messages import trim_messages, SystemMessage
# MAGIC from langgraph.checkpoint.memory import MemorySaver
# MAGIC from typing import Annotated
# MAGIC import plotly.graph_objects as go #To uPse the Plotly library to create the graph
# MAGIC import plotly.express as px #To use the Plotly Express library to create the graph
# MAGIC
# MAGIC
# MAGIC
# MAGIC GENIE_SPACE_ID = '01f009af5a301a0683d008356f8f3289'
# MAGIC  
# MAGIC DATABRICKS_GENIE_PAT = "dapif3bc3b1e718c335b48f4c410b07c9c12"
# MAGIC DATABRICKS_HOST  ="https://amgen-ai-dev.cloud.databricks.com"
# MAGIC client = WorkspaceClient(
# MAGIC     host=DATABRICKS_HOST ,
# MAGIC     token=DATABRICKS_GENIE_PAT
# MAGIC )
# MAGIC  
# MAGIC repl = PythonREPL()
# MAGIC
# MAGIC @tool
# MAGIC def get_data_from_genie(prompt: str):
# MAGIC     """Retrieve data from Genie based on the prompt request"""
# MAGIC
# MAGIC     def get_conversation_metadata_from_genie(prompt: str):
# MAGIC         raw_response = client.genie.start_conversation(
# MAGIC             space_id=GENIE_SPACE_ID,
# MAGIC             content=prompt
# MAGIC         ).result()
# MAGIC     
# MAGIC         return {
# MAGIC             "raw": raw_response
# MAGIC         }
# MAGIC
# MAGIC
# MAGIC     genie_token = 'dapif3bc3b1e718c335b48f4c410b07c9c12'
# MAGIC     host  ="https://amgen-ai-dev.cloud.databricks.com"
# MAGIC
# MAGIC     response = get_conversation_metadata_from_genie(prompt)
# MAGIC
# MAGIC     message_id  = response['raw'].id
# MAGIC     space_id = response['raw'].space_id
# MAGIC     conversation_id = response['raw'].conversation_id
# MAGIC     question_content = response['raw'].content
# MAGIC     attachment_id = response['raw'].attachments[0].attachment_id
# MAGIC     query_description = response['raw'].attachments[0].query.description
# MAGIC     sql_query= response['raw'].attachments[0].query.query
# MAGIC     statement_id = response['raw'].query_result.statement_id
# MAGIC     status = response['raw'].status
# MAGIC
# MAGIC
# MAGIC     # Use Metadata to create get prompt results
# MAGIC     url = f"{host}/api/2.0/genie/spaces/{space_id}/conversations/{conversation_id}/messages/{message_id}/attachments/{attachment_id}/query-result"
# MAGIC  
# MAGIC     headers = {
# MAGIC         "Authorization": f"Bearer {genie_token}"
# MAGIC         }
# MAGIC     
# MAGIC     results = requests.get(url, headers=headers)
# MAGIC      
# MAGIC
# MAGIC     # Parse the data into a dataframe
# MAGIC     row_count = results.json()['statement_response']['manifest']['total_row_count']
# MAGIC     data = results.json()['statement_response']['result']['data_array']
# MAGIC     data_df = pd.DataFrame(data)
# MAGIC     if row_count > 30:
# MAGIC         data_df = data_df.head(10)
# MAGIC     
# MAGIC     # Parse the columns into a list
# MAGIC     col_count = results.json()['statement_response']['manifest']['schema']['column_count']
# MAGIC     if col_count > 0 :
# MAGIC         col_list_of_dict = results.json()['statement_response']['manifest']['schema']['columns']
# MAGIC         feature_list = []
# MAGIC         for element in col_list_of_dict:
# MAGIC             a = [element[key] for key in element if key=='name']
# MAGIC             feature_list.extend(a)
# MAGIC
# MAGIC         data_df.columns =feature_list
# MAGIC
# MAGIC     output = (query_description + """:\n\n """ + 
# MAGIC           data_df.to_markdown() + 
# MAGIC           """ \n\n """ + sql_query)
# MAGIC
# MAGIC
# MAGIC     return output
# MAGIC   
# MAGIC @tool
# MAGIC def python_repl_tool(
# MAGIC     code: Annotated[str, "The python code to execute code to generate plots, charts and visualizations. Use only plotly express to generate charts."],
# MAGIC ):
# MAGIC     """Use this to execute python code. If you want to see the output of a value,
# MAGIC     you should print it out with `print(...)`. This is visible to the user.
# MAGIC     To generate charts, you must use ONLY plotly express. 
# MAGIC     Follow the instructions in the code output:
# MAGIC     1. The figure sizes should by 5 by 3. Select different colours and styles.
# MAGIC     2. import all necessary packages in the code.
# MAGIC     """
# MAGIC     try:
# MAGIC         result = repl.run(code)
# MAGIC     except BaseException as e:
# MAGIC         return f"Failed to execute. Error: {repr(e)}"
# MAGIC     result_str = f"Successfully executed:\n```python\n{code}\n```\nCODE OUTPUT:\n {result}"
# MAGIC     return result_str
# MAGIC   
# MAGIC
# MAGIC AGENT_SYS_PROMP = """Role: You are biomarker assistant tasked with providing up-to-date information about the clinical trial data. 
# MAGIC
# MAGIC Objective: Assist data-driven researchers by giving accurate information about the clinical trial data solely from GenieClient.
# MAGIC
# MAGIC Capabilities: You have been given a tool called get_data_from_genie. Please retrieve your data only from this tool. Do not construct any query.
# MAGIC
# MAGIC Next Steps: Use the python_repl_tool to generate visualizations and charts. Use plotly express to generate charts. The plotting figure sizes should by 5 by 3. Select different colours and styles.
# MAGIC """
# MAGIC
# MAGIC class State(TypedDict):
# MAGIC     messages: Annotated[list, add_messages]
# MAGIC
# MAGIC graph_builder = StateGraph(State)
# MAGIC
# MAGIC tools = [get_data_from_genie, python_repl_tool]
# MAGIC
# MAGIC
# MAGIC LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
# MAGIC llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)
# MAGIC
# MAGIC llm_with_tools = llm.bind_tools(tools)
# MAGIC
# MAGIC SYS_MSG = SystemMessage(content=AGENT_SYS_PROMP)
# MAGIC
# MAGIC def chatbot(state: State):
# MAGIC     
# MAGIC     return {"messages": [llm_with_tools.invoke([SYS_MSG] + state["messages"])]}
# MAGIC  
# MAGIC graph_builder.add_node("chatbot", chatbot)
# MAGIC
# MAGIC tool_node = ToolNode(tools = tools)
# MAGIC graph_builder.add_node('tools', tool_node)
# MAGIC graph_builder.add_conditional_edges('chatbot', 
# MAGIC                                     tools_condition, 
# MAGIC                                     ['tools', END]
# MAGIC                                     )
# MAGIC graph_builder.add_edge('tools', 'chatbot')
# MAGIC graph_builder.set_entry_point('chatbot')
# MAGIC
# MAGIC memory = MemorySaver()
# MAGIC
# MAGIC compiled_graph = graph_builder.compile(checkpointer=memory)
# MAGIC

# COMMAND ----------



# COMMAND ----------

# MAGIC %%writefile app.py
# MAGIC
# MAGIC import genie_agent
# MAGIC import gradio as gr
# MAGIC import pandas as pd
# MAGIC import numpy as np
# MAGIC import random
# MAGIC
# MAGIC def call_conversational_agent(agent, prompt, user_session_id, verbose=False):
# MAGIC     events = agent.stream(
# MAGIC         {"messages":[{"role": "user", "content": prompt}]},
# MAGIC         {"configurable": {"thread_id": user_session_id}},
# MAGIC         stream_mode = "values",
# MAGIC     )
# MAGIC     print('Running Agent. Please wait...')
# MAGIC     for event in events:
# MAGIC         if verbose:
# MAGIC             event["messages"][-1].pretty_print()
# MAGIC
# MAGIC
# MAGIC
# MAGIC compiled_flow = genie_agent.compiled_graph
# MAGIC
# MAGIC uid = 'frank008'
# MAGIC query = 'Aggregate the average Age by DoseSeqp only, then visualize the data'
# MAGIC #query = 'Please visualize the data'
# MAGIC call_conversational_agent(compiled_flow, 
# MAGIC                           prompt=query, 
# MAGIC                           user_session_id=uid, 
# MAGIC                           verbose=True)
# MAGIC
# MAGIC
# MAGIC df = pd.DataFrame({
# MAGIC     'height': np.random.randint(50, 70, 25),
# MAGIC     'weight': np.random.randint(120, 320, 25),
# MAGIC     'age': np.random.randint(18, 65, 25),
# MAGIC     'ethnicity': [random.choice(["white", "black", "asian"]) for _ in range(25)]
# MAGIC })
# MAGIC
# MAGIC
# MAGIC with gr.Blocks() as demo:
# MAGIC     gr.LinePlot(df, x="weight", y="height")
# MAGIC
# MAGIC demo.launch()

# COMMAND ----------






# COMMAND ----------

uid = 'frank008'
query = 'Aggregate the average Age by DoseSeqp only, then visualize the data'
#query = 'Please visualize the data'
call_conversational_agent(compiled_flow, 
                          prompt=query, 
                          user_session_id=uid, 
                          verbose=True)


