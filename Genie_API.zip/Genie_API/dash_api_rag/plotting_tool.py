import pandas as pd
import numpy as np
import os
from dotenv import load_dotenv
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.io as pio
from lifelines import KaplanMeierFitter, NelsonAalenFitter, BreslowFlemingHarringtonFitter, CoxPHFitter,  WeibullFitter
from lifelines.statistics import logrank_test
#from langchain.chat_models import ChatOpenAI
import json
from langchain.prompts import ChatPromptTemplate
from langchain.schema import SystemMessage, HumanMessage
from databricks.sdk import WorkspaceClient
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
import re
from sklearn.preprocessing import LabelEncoder
from requests.exceptions import Timeout, RequestException
import requests

load_dotenv()

# Load environment variables

LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")

# LLM for plotting graph
LLM = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

def general_plotting_agent(df, context_description, user_input):
    def get_fig_from_code(code):
        local_variables = {}
        exec(code, {}, local_variables)
        return local_variables['fig']
    
    CHART_PROMPT = '''
    Role: You are biomarker assistant tasked with providing up-to-date information about the clinical trial data.

    Objective: Your job is to write pandas code to visualize and plot charts based on the given data and column names, context and task.

    Capabilities: You have been given a dataframe as data. The data columns are provided. The context of the task is presented as context.

    Next Steps: When asked to visualize data, provide only python code using Plotly Express to generate charts. 
    The plotting figure sizes should be 5 by 3. Font size for the title and axes and legend should be 8px. Select different colours and styles.
    Include all necessary imports in your code snippets.
    If the task request specific graph use it otherwise use appropriate chart

    columns: {columns}

    data: {data}

    context: {context}

    prompt: {task}

    '''

    chart_prompt = ChatPromptTemplate.from_template(CHART_PROMPT)
    graph_agent_chain = chart_prompt | LLM

    df = df.replace({None: np.nan})
    # Fill NaN values with 0
    df = df.fillna(0)

    try:
        graph_agent_response = graph_agent_chain.invoke({
                    "columns": df.columns.tolist(),
                    "data": df.to_dict(orient="records"),
                    "context": context_description,
                    "task": user_input
                })
        graph_result_output = graph_agent_response.content.strip() or ""
        code_block_match = re.search(r'```(?:[Pp]ython)?(.*?)```', graph_result_output, re.DOTALL)

        if code_block_match:
            code_block = code_block_match.group(1).strip()
            cleaned_code = re.sub(r'(?m)^\s*fig\.show\(\)\s*$', '', code_block)
            try:
                fig = get_fig_from_code(cleaned_code)
                fig_summary = go.Figure()
                return fig, fig_summary,  graph_result_output
            except Exception as e:
                fig = go.Figure()
                fig_summary = go.Figure()
                return fig, fig_summary, str(e)
                pass
        else:
            fig = go.Figure()
            fig_summary = go.Figure()
            return fig, fig_summary, "LLM cannot generate plotting code for this data"
    except:
        fig = go.Figure()
        fig_summary = go.Figure()
        return fig, fig_summary, "LLM cannot generate plotting code for this data structure"

    



       
    
def survival_plotting_agent(df: pd.DataFrame):
    def identify_survival_columns(df: pd.DataFrame) -> dict:
        prompt = f"""
        I have a dataset with the following columns: {', '.join(df.columns)}.
        I want to generate survival curves.
        Which columns should be used for duration and event?
        Return result in the form of json, Don't add explanation: {{"duration": "col1", "event": "col2"}}
        if no column is found then please return {{"duration": "", "event": ""}}
        """
        messages = [
            SystemMessage(content="You are a helpful assistant that identifies survival analysis columns."),
            HumanMessage(content=prompt)
        ]
        response = LLM.invoke(messages)
        return json.loads(response.content)
    
    def get_fig_from_code(code):
        local_variables = {}
        exec(code, {}, local_variables)
        return local_variables['fig']

    CHART_PROMPT = '''
        Role: You are biomarker assistant tasked with providing technical analysis and explanation of Cox Proportional Hazard Models.
        Objective: Your job is to explain Cox Fitting summary
        Capabilities: You have been given a dataframe as data. 
        The data columns are provided. 
        The Cox Fitting summary is also provided as cox_fitting_summary.
        Next Steps: Explain the already Cox fitted results summary
    
        columns: {columns}
        data: {data}
        cox_fitting_summary: {cox_fitting_summary}
        prompt: {task}

        '''
    CHART_PROMPT2 = '''
        Role: You are biomarker assistant tasked with generating Cox Fitting 
        and providing technical analysis and explanation of Cox Proportional Hazard Models.
        Objective: Your job is to explain Cox Fitting summary, provide publication ready visual plots.
        Capabilities: You have been given a dataframe as data. 
        The data columns are provided. 
        The Cox Fitting summary is also provided as cox_fitting_summary.
        Next Steps: Explain the already Cox fitted results summary, 
        provide publication ready visual plots, with p-values annotated at the right-end
        
        For the plotting code use plotly express and capture the plotting object as fig.
        The plotting figure sizes should be 5 by 3. Font size for the title and axes and legend should be 9px. Select different colours and styles.
    
        columns: {columns}
        data: {data}
        cox_fitting_summary: {cox_fitting_summary}
        prompt: {task}

        '''

    chart_prompt = ChatPromptTemplate.from_template(CHART_PROMPT2)
    graph_agent_chain = chart_prompt | LLM

    # Get the event and status columns 
    # Process the dataset
    inferred_duration_event_dict = identify_survival_columns(df)
    
    # Check if duration and event are in the dict
    if not all(value for value in inferred_duration_event_dict.values()):
        fig = go.Figure()
        fig_cph = go.Figure()
        message = "LLM needs EVENT and STATUS column to plot survival curves/Cox Fitting Forest plot"
        return fig, fig_cph, message
    else:
   
        inferred_column_dict = {v: k for k, v in inferred_duration_event_dict.items()}
        df = df.rename(columns=inferred_column_dict)

        if 'SUBJID' in df.columns:
            df = df.drop('SUBJID', axis = 1)
        
        df = df.apply(LabelEncoder().fit_transform)
        df.columns = df.columns.str.lower()
        df = df.replace("None", np.nan).fillna(0)
        df['duration'] = df['duration'].astype(float)
        df['event'] = df['event'].astype(float)
        df['event'] = df['event'].astype(int)
        
        
        

        kmf = KaplanMeierFitter()
        fig = px.line()
        '''
        kmf.fit(df["duration"], df["event"], label="Survival")
        survival_df = kmf.survival_function_.reset_index()
        fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name="Survival")
        fig.update_layout(title='Kaplan-Meier Survival Curves')
        fig.update_layout(width=500,
                          height=300,
                        #title="Kaplan-Meier Survival Curves",
                        xaxis_title="Time",
                        yaxis_title="Survival Probability")
        '''
        if 'group' in df.columns:
            for name, grouped_df in df.groupby("group"):
                kmf.fit(grouped_df["duration"], grouped_df["event"], label=name)
                survival_df = kmf.survival_function_.reset_index()
                survival_df["group"] = name
                fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name=name)
            kmf.fit(df["duration"], df["event"], label="Mean Survival")
            survival_df = kmf.survival_function_.reset_index()
            fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name="Mean Survival")

            groups = df['group'].unique()
            if len(groups) == 2:
                g1 = df[df['group'] == groups[0]]
                g2 = df[df['group'] == groups[1]]
                result = logrank_test(g1['duration'], g2['duration'], g1['event'], g2['event'])
                fig.update_layout(title=f'Kaplan-Meier Survival Curves Log-Rank Test p-value: {result.p_value:.4f}')
            else:
                fig.update_layout(title='Kaplan-Meier Survival Curves Log-Rank Plot')

        elif 'strata' in df.columns:
            for name, grouped_df in df.groupby("strata"):
                kmf.fit(grouped_df["duration"], grouped_df["event"], label=name)
                survival_df = kmf.survival_function_.reset_index()
                survival_df["strata"] = name
                fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name=name)
            kmf.fit(df["duration"], df["event"], label="Mean Survival")
            survival_df = kmf.survival_function_.reset_index()
            fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name="Mean Survival")
            
            groups = df['strata'].unique()
            if len(groups) == 2:
                g1 = df[df['strata'] == groups[0]]
                g2 = df[df['strata'] == groups[1]]
                result = logrank_test(g1['duration'], g2['duration'], g1['event'], g2['event'])
                fig.update_layout(title=f'Kaplan-Meier Survival Curves Log-Rank Test p-value: {result.p_value:.4f}')
            else:
                fig.update_layout(title='Kaplan-Meier Survival Curves Log-Rank Plot')

        elif 'stratification' in df.columns:
            for name, grouped_df in df.groupby("stratification"):
                kmf.fit(grouped_df["duration"], grouped_df["event"], label=name)
                survival_df = kmf.survival_function_.reset_index()
                survival_df["stratification"] = name
                fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name=name)
            kmf.fit(df["duration"], df["event"], label="Mean Survival")
            survival_df = kmf.survival_function_.reset_index()
            fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name="Mean Survival")

            groups = df['stratification'].unique()
            if len(groups) == 2:
                g1 = df[df['stratification'] == groups[0]]
                g2 = df[df['stratification'] == groups[1]]
                result = logrank_test(g1['duration'], g2['duration'], g1['event'], g2['event'])
                fig.update_layout(title=f'Kaplan-Meier Survival Curves Log-Rank Test p-value: {result.p_value:.4f}')
            else:
                fig.update_layout(title='Kaplan-Meier Survival Curves Log-Rank Plot')
        else:
            kmf.fit(df["duration"], df["event"], label="Survival")
            survival_df = kmf.survival_function_.reset_index()
            fig.add_scatter(x=survival_df["timeline"], y=survival_df[kmf._label], name="Survival")
            fig.update_layout(title='Kaplan-Meier Survival Curves')

        fig.update_layout(height=300,
                          width=500,
                        #title="Kaplan-Meier Survival Curves",
                        xaxis_title="Time",
                        yaxis_title="Survival Probability")
        
        try:
            cph = CoxPHFitter()
            cph.fit(df, duration_col='duration', event_col='event')
        except:
            cph = None
            pass


        if cph is not None and not cph.summary.empty:
            summary_df = cph.summary.reset_index().round(3)

            graph_agent_response = graph_agent_chain.invoke({
                        "columns": df.columns.tolist(),
                        "data": df.to_dict(orient="records"),
                        "cox_fitting_summary": summary_df.to_dict(orient="records"),
                        "task": """provide technical explanation of the Cox Fitting summary 
                                and please generate a provide publication-ready 
                                visual plots of hazard ratios with confidence intervals, 
                                with p-values annotated at the right-end
                                """
                    })
        
            agent_output = graph_agent_response.content.strip() or ""
            code_block_match = re.search(r'```(?:[Pp]ython)?(.*?)```', agent_output, re.DOTALL)
            explanation = re.sub(r'```(?:[Pp]ython)?(.*?)```', '', agent_output)

            if code_block_match:
                code_block = code_block_match.group(1).strip()
                cleaned_code = re.sub(r'(?m)^\s*fig\.show\(\)\s*$', '', code_block)
                try:
                    fig_cph = get_fig_from_code(cleaned_code)
                    return fig, fig_cph, explanation
                except Exception as e:
                    message = str(e)
                    fig_cph = go.Figure()
                    return fig, fig_cph, message
            else:
                fig_cph = go.Figure()
                return fig, fig_cph, explanation
            
        else:
            fig_cph = go.Figure()
            return fig, fig_cph, "The CoxPHFitter object has not been fitted, or the summary is not available."
                
    
        

    
# Multi-agent decision routing
def get_plotting_agent(df,  context_description,user_query):
    def route_query(user_query: str) -> str:
        messages = [
            SystemMessage(content="You are a routing assistant. Decide if the query is about survival analysis or general plotting. Return 'survival' or 'general' only."),
            HumanMessage(content=f"Query: {user_query}")
        ]
        response = LLM.invoke(messages)
        return response.content.strip().lower()
    
    task = route_query(user_query)
    
    
    if task == "survival":
        fig, fig_cph, plot_code = survival_plotting_agent(df)
        
    elif task == "general":
        fig, fig_cph, plot_code = general_plotting_agent(df, context_description,user_query)
        
    else:
        fig = go.Figure()
        fig_cph = go.Figure()
        plot_code = ""
    
    return fig, fig_cph, plot_code


