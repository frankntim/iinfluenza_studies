#from langchain.chat_models import ChatOpenAI
from langchain.llms import HuggingFaceEndpoint
from langchain.chains import LLMChain
from langchain_community.vectorstores import DatabricksVectorSearch
from langgraph.graph import StateGraph, END
from typing import TypedDict, Annotated, List, Union, Optional
from langchain.schema.runnable import RunnableLambda
from databricks_langchain import DatabricksVectorSearch
import os
from langchain.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI
#from langchain_openai import ChatOpenAI

from langchain.embeddings import OpenAIEmbeddings
from openai import OpenAI
import os
import json
import re
from pyspark.sql import SparkSession
import pandas as pd
#from openai import OpenAI

# Replace OpenAI with ChatOpenAI
# Pleace call the invoke NOT chat.completions

class AgentState(TypedDict):
    input: str
    retrieved_docs: Optional[List[str]]
    prompt: Optional[str]
    sql_query: Optional[str]
    query_results: Optional[str]
    biomarker_insight: Optional[str]
    is_valid:bool
    validation_issues:Optional[str]
    inference:Optional[str]
    model_name: str
    base_url: str
    api_key: str



def supervisor_router(state: AgentState) -> str:
  print(f"task_name: Supervisor_router")
  if not state.get("retrieved_docs"): #Vector Search Agent
    return {"next": "vector_search"}
  if not state.get("prompt"): #Prompt Engineering Construction Agent
    return {"next":"prompt_engineering"}
  if not state.get("sql_query"): #Text2SQL Generation Agent
    return {"next":"text2sql"}
  if not state.get("query_results"): #SQL Execution and Validation Agent
    return {"next":"sql_validation"}
  return  {"next":"biomarker_expert"}  #Final Interpretation & Summary

SupervisorNode = RunnableLambda(supervisor_router)


# Vector Search Agent
def vector_search_agent(state: AgentState) -> AgentState:
    print(f"task_name: Vector_search")

    vectorstore = DatabricksVectorSearch(
        index_name="edl_dev.cbd_sandbox.pmed_prod_ddm_vector_index"
    )
    docs = vectorstore.similarity_search(state["input"], k=400)
    return {**state, "retrieved_docs": [doc.page_content for doc in docs]}
  
# Prompt Engineering Agent
def prompt_engineering_agent(state: AgentState) -> AgentState:
    print(f"task_name: Prompt_engneering")
    joined_docs = "\n".join(state["retrieved_docs"])
    prompt = f"""Based on the following retrieved content, generate a SQL query:\n\n{joined_docs}\n\nUser Query: {state['input']}"""
    return  {**state, "prompt": prompt}
  


class Text2SQLAgent:
    def __init__(self, model_name: str, base_url: str, api_key: str):
        self.model_name = model_name
        self.base_url = base_url
        self.api_key = api_key

        os.environ["OPENAI_API_KEY"] = api_key

        self.llm = ChatOpenAI(
            model=model_name,
            base_url=base_url,
            openai_api_key=api_key
        )

        self.prompt = PromptTemplate.from_template("{prompt}")
        self.chain = self.prompt | self.llm | StrOutputParser()

    def run(self, state: dict) -> dict:
        print(f"task_name: Generating_SQL with {self.model_name}")
        sql = self.chain.invoke({"prompt": state["prompt"]})
        return {**state, "sql_query": sql}
      

'''
class SQLValidatorAgent:
    def __init__(self, model_name: str, base_url: str, api_key: str):
        # Please change this line to ChatOpenAI
        # The calling may change down stream and I have put a mark over there
        self.client = OpenAI(api_key=api_key, base_url=base_url)
        #self.client = ChatOpenAI(api_key=api_key, base_url=base_url)
        self.model_name = model_name

    def run(self, state: dict) -> dict:
        schema_info = "\n".join(state.get("retrieved_docs", []))
        sql_query = state.get("sql_query", "")

        prompt = (
            f"Schema info:\n{schema_info}\n\n"
            f"Given SQL:\n{sql_query}\n\n"
            "Respond ONLY in JSON format. Do not explain. Reply with:\n"
            '{"valid": true/false, "issues": "...", "inference": "..."}'
        )

        message = [
            {"role": "system", "content": "You are SQL schema checker."},
            {"role": "user", "content": prompt}
        ]
        #####################################################
        # This is where the calling takes place
        # Please change to langchain ChatOpenAI
        response = self.client.chat.completions.create(
            model=self.model_name,
            messages=message
        )
        

        raw_response = response.choices[0].message.content.strip()
        print("[Validation Raw Response]:", raw_response)
        #####################################################

        try:
            # Extract JSON block if wrapped in markdown or explanation
            match = re.search(r'\{.*\}', raw_response, re.DOTALL)
            if match:
                parsed = json.loads(match.group())
            else:
                parsed = json.loads(raw_response)

            return {
                **state,
                "is_valid": parsed.get("valid", False),
                "validation_issues": parsed.get("issues", ""),
                "inference": parsed.get("inference", "")
            }

        except Exception as e:
            print(f"[Validation Error] JSON parsing failed: {e}")
            return {
                **state,
                "is_valid": False,
                "validation_issues": f"Error parsing: {e}",
                "inference": ""
            }

'''

class SQLValidatorAgent:
    def __init__(self, model_name: str, base_url: str, api_key: str):
        self.client = ChatOpenAI(model=model_name,api_key=api_key, base_url=base_url)
        self.model_name = model_name
 
    def run(self, state: dict) -> dict:
        schema_info = "\n".join(state.get("retrieved_docs", []))
        sql_query = state.get("sql_query", "")
 
        prompt = (
            f"Schema info:\n{schema_info}\n\n"
            f"Given SQL:\n{sql_query}\n\n"
            "Respond ONLY in JSON format. Do not explain. Reply with:\n"
            '{"valid": true/false, "issues": "...", "inference": "..."}'
        )
 
        message = [
            {"role": "system", "content": "You are SQL schema checker."},
            {"role": "user", "content": prompt}
        ]
 
        response = self.client.invoke(message)
 
        raw_response = response.content.strip()
        print("[Validation Raw Response]:", raw_response)
 
        try:
            # Extract JSON block if wrapped in markdown or explanation
            match = re.search(r'\{.*\}', raw_response, re.DOTALL)
            if match:
                parsed = json.loads(match.group())
            else:
                parsed = json.loads(raw_response)
 
            return {
                **state,
                "is_valid": parsed.get("valid", False),
                "validation_issues": parsed.get("issues", ""),
                "inference": parsed.get("inference", "")
            }
 
        except Exception as e:
            print(f"[Validation Error] JSON parsing failed: {e}")
            return {
                **state,
                "is_valid": False,
                "validation_issues": f"Error parsing: {e}",
                "inference": ""
            }



spark = SparkSession.builder.appName("LangGraphSQLAgent").getOrCreate()

def sql_executor(state: AgentState) -> AgentState:
    print(f"task_name: SQL_execution")
    try:
        raw_sql = state["sql_query"]
        print(f"[SQL Executor] Raw input:\n{raw_sql}\n")

        # Extract SQL from markdown-style block
        match = re.search(r"```sql\s*(.*?)```", raw_sql, re.DOTALL | re.IGNORECASE)
        if match:
            sql_query = match.group(1).strip()
        else:
            # Fallback: try to find the first SELECT statement
            match = re.search(r"(SELECT .*?;)", raw_sql, re.DOTALL | re.IGNORECASE)
            if match:
                sql_query = match.group(1).strip()
            else:
                raise ValueError("No valid SQL query found in input.")

        # print(f"[SQL Executor] Extracted SQL:\n{sql_query}\n")

        # Execute the SQL
        result_df = spark.sql(sql_query)
        # pandas_df = result_df.toPandas()
        # Show the result in notebook or console
        # result_df.show()

        # print("[SQL Executor] Query Results:")
        # print(pandas_df.to_string(index=False))

        return {**state, "query_results": result_df}

    except Exception as e:
        print(f"[SQL Executor] Error executing query: {e}")
        return {**state, "query_results": f"Error: {e}"}


      

def text2sql_node(state: AgentState) -> AgentState:
  print("DEBUG: text2sql_node received state keys:", list(state.keys()))
  agent = Text2SQLAgent(
      model_name=state["model_name"],
      base_url=state["base_url"],
      api_key=state["api_key"]
  )
  return agent.run(state)


def validate_sql_node(state: AgentState) -> AgentState:
    agent = SQLValidatorAgent(
        model_name=state["model_name"],
        base_url=state["base_url"],
        api_key=state["api_key"]
    )
    return agent.run(state)





graph_builder = StateGraph(AgentState)
graph_builder.add_node("supervisor", SupervisorNode)
graph_builder.add_node("vector_search", vector_search_agent)
graph_builder.add_node("prompt_engineering", prompt_engineering_agent)

# Register the function as a node
graph_builder.add_node("text2sql", text2sql_node)
graph_builder.add_node("Validate_sql", validate_sql_node)
graph_builder.add_node("sql_executor",sql_executor)
graph_builder.set_entry_point("supervisor")

graph_builder.add_edge("supervisor", "vector_search")
graph_builder.add_edge("vector_search", "prompt_engineering")
graph_builder.add_edge("prompt_engineering", "text2sql")
graph_builder.add_edge("text2sql", "Validate_sql")
graph_builder.add_edge( "Validate_sql","sql_executor")
graph_builder.add_edge("sql_executor",END)


workflow = graph_builder.compile()


def summarize_final_output(state: AgentState):
    import re

    # Extract SQL
    sql_raw = state.get("sql_query", "")
    match = re.search(r"```sql\n(.*?)```", sql_raw, re.DOTALL | re.IGNORECASE)
    sql_query = match.group(1).strip() if match else sql_raw.strip()

    # Extract inference
    inference = state.get("inference", "").strip()
    if not inference:
        inference = " No inference found. Check validation agent output."

    # Extract execution result
    result_df = state.get("query_results", None)
    if result_df:
        result_df = result_df.toPandas()
    #result_df.show()

    
    return inference,result_df,sql_query


def call_rag_agent(input_prompt):
    initial_state = {
    "input": input_prompt,
    "model_name": "project-115-Precision_Medicine_AI_Agent-2",
    "base_url": "https://amgen-ai-dev.cloud.databricks.com/serving-endpoints",
    "api_key": "dapi0945608621f87ae408fc84b3f011a0bd"
    }
    final_state = workflow.invoke(initial_state)

    inference,result_df,sql_query = summarize_final_output(final_state)

    return inference,result_df,sql_query
