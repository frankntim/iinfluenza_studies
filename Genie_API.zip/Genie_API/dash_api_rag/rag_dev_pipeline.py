# Databricks notebook source


# COMMAND ----------

!pip install OpenAI
%restart_python
dbutils.library.restartPython()

%pip install databricks-vectorsearch
#dbutils.library.restartPython()
#%restart_python##

# COMMAND ----------

# Install the necessary packages
%pip install --upgrade databricks-langchain langchain-community langchain databricks-sql-connector
%restart_python dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %pip install langgraph

# COMMAND ----------

# MAGIC %restart_python dbutils.library.restartPython()
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %pip install --upgrade databricks-langchain langchain-community langchain databricks-sql-connector

# COMMAND ----------

pip install databricks-langchain

# COMMAND ----------

# MAGIC %md
# MAGIC %restart_python
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# Install the required pydantic version
%pip install pydantic==1.10.2

# COMMAND ----------

#Library Requirements
# from langchain.agents import Tool
from langchain.chat_models import ChatOpenAI
from langchain.llms import HuggingFaceEndpoint
from langchain.chains import LLMChain
from langchain_community.vectorstores import DatabricksVectorSearch
from langgraph.graph import StateGraph, END
from typing import TypedDict, Annotated, List, Union, Optional
from langchain.schema.runnable import RunnableLambda
from databricks_langchain import DatabricksVectorSearch

from langchain.embeddings import OpenAIEmbeddings
from openai import OpenAI
import os
import json


# COMMAND ----------

# MAGIC %md
# MAGIC ### Agent State

# COMMAND ----------

class AgentState(TypedDict):
    input: str
    retrieved_docs: Optional[List[str]]
    prompt: Optional[str]
    sql_query: Optional[str]
    query_results: Optional[str]
    biomarker_insight: Optional[str]
    is_valid:bool
    validation_issues:Optional[str]
    inference:Optional[str]
    model_name: str
    base_url: str
    api_key: str



# COMMAND ----------

# MAGIC %md
# MAGIC ### Supervisor Agent

# COMMAND ----------

def supervisor_router(state: AgentState) -> str:
  print(f"task_name: Supervisor_router")
  if not state.get("retrieved_docs"): #Vector Search Agent
    return {"next": "vector_search"}
  if not state.get("prompt"): #Prompt Engineering Construction Agent
    return {"next":"prompt_engineering"}
  if not state.get("sql_query"): #Text2SQL Generation Agent
    return {"next":"text2sql"}
  if not state.get("query_results"): #SQL Execution and Validation Agent
    return {"next":"sql_validation"}
  return  {"next":"biomarker_expert"}  #Final Interpretation & Summary

SupervisorNode = RunnableLambda(supervisor_router)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Vector Search Agent

# COMMAND ----------


def vector_search_agent(state: AgentState) -> AgentState:
    print(f"task_name: Vector_search")

    vectorstore = DatabricksVectorSearch(
        index_name="edl_dev.cbd_sandbox.pmed_prod_ddm_vector_index"
    )
    docs = vectorstore.similarity_search(state["input"], k=400)
    return {**state, "retrieved_docs": [doc.page_content for doc in docs]}

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prompt Engineering Agent

# COMMAND ----------

def prompt_engineering_agent(state: AgentState) -> AgentState:
    print(f"task_name: Prompt_engneering")
    joined_docs = "\n".join(state["retrieved_docs"])
    prompt = f"""Based on the following retrieved content, generate a SQL query:\n\n{joined_docs}\n\nUser Query: {state['input']}"""
    return  {**state, "prompt": prompt}

# COMMAND ----------

import os
from langchain.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain.chat_models import ChatOpenAI

class Text2SQLAgent:
    def __init__(self, model_name: str, base_url: str, api_key: str):
        self.model_name = model_name
        self.base_url = base_url
        self.api_key = api_key

        os.environ["OPENAI_API_KEY"] = api_key

        self.llm = ChatOpenAI(
            model=model_name,
            base_url=base_url,
            openai_api_key=api_key
        )

        self.prompt = PromptTemplate.from_template("{prompt}")
        self.chain = self.prompt | self.llm | StrOutputParser()

    def run(self, state: dict) -> dict:
        print(f"task_name: Generating_SQL with {self.model_name}")
        sql = self.chain.invoke({"prompt": state["prompt"]})
        return {**state, "sql_query": sql}


# COMMAND ----------

# MAGIC %md
# MAGIC ### Text2SQL GPT4 Agent 

# COMMAND ----------

def text2sql_node(state: AgentState) -> AgentState:
    print("DEBUG: text2sql_node received state keys:", list(state.keys()))
    agent = Text2SQLAgent(
        model_name=state["model_name"],
        base_url=state["base_url"],
        api_key=state["api_key"]
    )
    return agent.run(state)

# COMMAND ----------

# import os
# from langchain.prompts import PromptTemplate
# from langchain_core.output_parsers import StrOutputParser


# # Set the OPENAI_API_KEY environment variable
# os.environ["OPENAI_API_KEY"] = "dapi0945608621f87ae408fc84b3f011a0bd"

# llm_gpt4 = ChatOpenAI(
#     model="project-115-Precision_Medicine_AI_Agent-2",
#     # model_kwargs={"index": "edl_dev.cbd_sandbox.pmed_prod_ddm_vector_index"},
#     openai_api_key=os.environ["OPENAI_API_KEY"],
#     base_url="https://amgen-ai-dev.cloud.databricks.com/serving-endpoints"
# )
# # Define the prompt template
# prompt = PromptTemplate.from_template("{prompt}")

# # Build the chain using LangChain Expression Language (LCEL)
# text2sql_chain_gpt = prompt | llm_gpt4 | StrOutputParser()

# def text2sql_agent_gpt(state: AgentState) -> AgentState:
#     print(f"task_name: Generating_SQL")
#     sql = text2sql_chain_gpt.invoke({"prompt": state["prompt"]})
#     return {**state, "sql_query": sql}

# COMMAND ----------

import json
import re
from openai import OpenAI

class SQLValidatorAgent:
    def __init__(self, model_name: str, base_url: str, api_key: str):
        self.client = OpenAI(api_key=api_key, base_url=base_url)
        self.model_name = model_name

    def run(self, state: dict) -> dict:
        schema_info = "\n".join(state.get("retrieved_docs", []))
        sql_query = state.get("sql_query", "")

        prompt = (
            f"Schema info:\n{schema_info}\n\n"
            f"Given SQL:\n{sql_query}\n\n"
            "Respond ONLY in JSON format. Do not explain. Reply with:\n"
            '{"valid": true/false, "issues": "...", "inference": "..."}'
        )

        message = [
            {"role": "system", "content": "You are SQL schema checker."},
            {"role": "user", "content": prompt}
        ]

        response = self.client.chat.completions.create(
            model=self.model_name,
            messages=message
        )

        raw_response = response.choices[0].message.content.strip()
        print("[Validation Raw Response]:", raw_response)

        try:
            # Extract JSON block if wrapped in markdown or explanation
            match = re.search(r'\{.*\}', raw_response, re.DOTALL)
            if match:
                parsed = json.loads(match.group())
            else:
                parsed = json.loads(raw_response)

            return {
                **state,
                "is_valid": parsed.get("valid", False),
                "validation_issues": parsed.get("issues", ""),
                "inference": parsed.get("inference", "")
            }

        except Exception as e:
            print(f"[Validation Error] JSON parsing failed: {e}")
            return {
                **state,
                "is_valid": False,
                "validation_issues": f"Error parsing: {e}",
                "inference": ""
            }


# COMMAND ----------

# MAGIC %md
# MAGIC ##SQL Validation Agent

# COMMAND ----------

def validate_sql_node(state: AgentState) -> AgentState:
    agent = SQLValidatorAgent(
        model_name=state["model_name"],
        base_url=state["base_url"],
        api_key=state["api_key"]
    )
    return agent.run(state)


# COMMAND ----------

# from openai import OpenAI
# def Validate_sql(state: AgentState) -> AgentState:
#     print(f"task_name: Validate_SQL & Adding_description")
#     # Known schema(it could be fetched dynamically)
#     Schema_Info = "\n".join(state["retrieved_docs"])
#     Sql_query = state["sql_query"]
#     prompt = (f"Schema info:\n{Schema_Info}\n\n"
#               f"Given SQL:\n{Sql_query}\n\n"
#               f"1) Is the SQL valid for the schema?\n"
#               f"2) Are the missing columns, wrong table names?\n"
#               f"3) Is the logic correct in sql query generated like primary key, joins, aggregation and ordering result?\n"
#               f"4) Add a short inference: what does the query return ?\n\n"
#               f"Reply in JSON: {{\"valid\": true/false, \"issues\": \"...\", \"inference\": \"...\"}}")
#     client=OpenAI(api_key = os.environ["OPENAI_API_KEY"],base_url="https://amgen-ai-dev.cloud.databricks.com/serving-endpoints")

#     message=[
#             {"role": "system", "content": "You are SQL schema checker."},
#             {"role": "user", "content": prompt}
#         ]

#     responce = client.chat.completions.create(
#         model="project-115-Precision_Medicine_AI_Agent-2",
#         messages=message
#     )

#     validation = responce.choices[0].message.content.strip()
#     print(f"[ValidationSQL] LLM validation:\n{validation}\n")

#     import json
#     print("DEBUG 01")
#     try:
#         print("DEBUG 02")
#         parsed = json.loads(validation)
#         valid = parsed.get("valid", False)
#         issues = parsed.get("issues", "")
#         inference = parsed.get("inference", "")
        
#     except Exception as e:
#         valid, issues, inference = False, f"Error parsing: {e}", ""

#     return {**state,"is_valid": valid, "validation_issues": issues, "inference": inference}

# COMMAND ----------

import requests
from flask import request

user_email = request.headers.get("X-Forwarded-Email")
user_token = request.headers.get("X-Forwarded-Access-Token")

headers = {
    "X-Forwarded-Email": user_email,
    "X-Forwarded-Access-Token": user_token
}

response = requests.get(
    "https://biolojinn-test-2249790853314266.aws.databricksapps.com/",
    headers=headers
)

# COMMAND ----------

# MAGIC %md
# MAGIC Text2SQL LLAMA4 Agent (ToDO)

# COMMAND ----------

# MAGIC %md
# MAGIC ### SQL Execution Agent 

# COMMAND ----------

import re
from pyspark.sql import SparkSession
import pandas as pd

spark = SparkSession.builder.appName("LangGraphSQLAgent").getOrCreate()

def sql_executor(state: AgentState) -> AgentState:
    print(f"task_name: SQL_execution")
    try:
        raw_sql = state["sql_query"]
        print(f"[SQL Executor] Raw input:\n{raw_sql}\n")

        # Extract SQL from markdown-style block
        match = re.search(r"```sql\s*(.*?)```", raw_sql, re.DOTALL | re.IGNORECASE)
        if match:
            sql_query = match.group(1).strip()
        else:
            # Fallback: try to find the first SELECT statement
            match = re.search(r"(SELECT .*?;)", raw_sql, re.DOTALL | re.IGNORECASE)
            if match:
                sql_query = match.group(1).strip()
            else:
                raise ValueError("No valid SQL query found in input.")

        # print(f"[SQL Executor] Extracted SQL:\n{sql_query}\n")

        # Execute the SQL
        result_df = spark.sql(sql_query)
        # pandas_df = result_df.toPandas()
        # Show the result in notebook or console
        # result_df.show()

        # print("[SQL Executor] Query Results:")
        # print(pandas_df.to_string(index=False))

        return {**state, "query_results": result_df}

    except Exception as e:
        print(f"[SQL Executor] Error executing query: {e}")
        return {**state, "query_results": f"Error: {e}"}


# COMMAND ----------

# MAGIC %md
# MAGIC ### LangGraph Assembly

# COMMAND ----------

print('stay alive')

# COMMAND ----------

#from databricks_langchain import DatabricksVectorSearch


graph_builder = StateGraph(AgentState)
graph_builder.add_node("supervisor", SupervisorNode)
graph_builder.add_node("vector_search", vector_search_agent)
graph_builder.add_node("prompt_engineering", prompt_engineering_agent)

# Register the function as a node
graph_builder.add_node("text2sql", text2sql_node)
graph_builder.add_node("Validate_sql", validate_sql_node)
graph_builder.add_node("sql_executor",sql_executor)
graph_builder.set_entry_point("supervisor")

graph_builder.add_edge("supervisor", "vector_search")
graph_builder.add_edge("vector_search", "prompt_engineering")
graph_builder.add_edge("prompt_engineering", "text2sql")
graph_builder.add_edge("text2sql", "Validate_sql")
graph_builder.add_edge( "Validate_sql","sql_executor")
graph_builder.add_edge("sql_executor",END)


workflow = graph_builder.compile()

# COMMAND ----------

def summarize_final_output(state: AgentState):
    import re

    # Extract SQL
    sql_raw = state.get("sql_query", "")
    match = re.search(r"```sql\n(.*?)```", sql_raw, re.DOTALL | re.IGNORECASE)
    sql_query = match.group(1).strip() if match else sql_raw.strip()

    # Extract inference
    inference = state.get("inference", "").strip()
    if not inference:
        inference = " No inference found. Check validation agent output."

    # Extract execution result
    result_df = state.get("query_results", None)
    result_df.show()

    # print("\n SQL Query:\n", sql_query)
    # print("\n Inference:\n", inference)

    # if result_df is not None and hasattr(result_df, "show"):
        # print("\n Query Execution Result:")
        # result_df.show()
    # else:
    #     print("\n No execution result available.")
    return inference,result_df,sql_query


# COMMAND ----------

initial_state = {
    #"input": "How many cohorts are there and for each how many subjects in study AMG160",
    "input": "Provide the distribution of subjects with adverse event flags indicating Y in AMG160?",
    "model_name": "project-115-Precision_Medicine_AI_Agent-2",
    "base_url": "https://amgen-ai-dev.cloud.databricks.com/serving-endpoints",
    "api_key": "dapi0945608621f87ae408fc84b3f011a0bd"}
final_state = workflow.invoke(initial_state)
inference,result_df,sql_query = summarize_final_output(final_state)
print(f"Inference:{inference}")
print(f"Results:{result_df}")
result_df.show()
print(f"sql_query:{sql_query}")



# COMMAND ----------

sql_query

# COMMAND ----------

initial_state = {
    "input": "How many cohorts are there and for each how many subjects in study AMG160",
    "model_name": "databricks-llama-4-maverick",
    "base_url": "https://amgen-ai-dev.cloud.databricks.com/serving-endpoints",
    "api_key": "dapi0945608621f87ae408fc84b3f011a0bd"}
final_state = workflow.invoke(initial_state)

sql_query = final_state["sql_query"]
inference = final_state.get("inference", "")
query_results = final_state["query_results"]


print("\n SQL Query:\n", sql_query)
print(" Inference:", inference)
query_results.show()

# if isinstance(query_results, str):
#     print(" Execution Error:", query_results)
# else:
#     print(" Execution Result:")
#     query_results.show()


# COMMAND ----------

# MAGIC %md
# MAGIC # How many cohorts are there and for each how many subjects in study AMG160?

# COMMAND ----------

try:
    initial_state = {
    "input": "How many cohorts are there and for each how many subjects in study AMG160",
    "model_name": "databricks-llama-4-maverick",
    "base_url": "https://amgen-ai-dev.cloud.databricks.com/serving-endpoints",
    "api_key": "dapi0945608621f87ae408fc84b3f011a0bd"
}
    result = workflow.invoke(initial_state)
    for step in workflow.stream(result):
        print(f"Step output:\n{step}\n")
except Exception as e:
    print(f"Error occurred: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Provide the distribution of subjects with adverse event flags indicating Y in AMG160?

# COMMAND ----------

try:
    result = workflow.invoke({"input":"Provide the distribution of subjects with adverse event flags indicating Y in AMG160?"})
    for step in workflow.stream(result):
        print(f"Step output:\n{step}\n")
except Exception as e:
    print(f"Error occurred: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC #Calculate survival probability for the cohort arm Part 1 Cohort 1(3day eIV): 0.03mg (d1-d4), 0.09mg (d8/d22) for study AMG160

# COMMAND ----------

try:
    result = workflow.invoke({"input":"Calculate survival probability for the cohort arm Part 1 Cohort 1(3day eIV): 0.03mg (d1-d4), 0.09mg (d8/d22) for study AMG160"})
    for step in workflow.stream(result):
        print(f"Step output:\n{step}\n")
except Exception as e:
    print(f"Error occurred: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC #provide median survival values for the different cohort arms of AMG160

# COMMAND ----------

try:
    result = workflow.invoke({"input":"provide median survival values for the different cohort arms of AMG160"})
    for step in workflow.stream(result):
        print(f"Step output:\n{step}\n")
except Exception as e:
    print(f"Error occurred: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

try:
    result = workflow.invoke({"input":"provide median survival values for the different cohort arms of AMG160"})
    for step in workflow.stream(result):
        print(f"Step output:\n{step}\n")
except Exception as e:
    print(f"Error occurred: {e}")

# COMMAND ----------

try:
    questions=["How many cohorts are there and for each how many subjects in study AMG160?","Provide the distribution of subjects with adverse event flags indicating Y in AMG160?","Calculate survival probability for the cohort arm Part 1 Cohort 1(3day eIV): 0.03mg (d1-d4), 0.09mg (d8/d22) for study AMG160","Provide the distribution of subjects with Anemia on the basis of HIF1A mutation effect for study AMG160"]
    for i in questions:
        result = workflow.invoke({"input": i})
        for step in workflow.stream(result):
            print(f"Questions:{i}")
            print(f"Step output:\n{step}\n")
except Exception as e:
    print(f"Error occurred: {e}")


# COMMAND ----------

try:
    result = workflow.invoke({"input": "What are the min and max range of trial subjects ages for AMG160?"})
    for step in workflow.stream(result):
        print(f"Step output:\n{step}\n")
except Exception as e:
    print(f"Error occurred: {e}")

# COMMAND ----------

try:
    result = workflow.invoke({"input": "What are the min and max range of trial subjects ages for AMG160?"})
    for step in workflow.stream(result):
        print(f"Step output:\n{step}\n")
except Exception as e:
    print(f"Error occurred: {e}")

# COMMAND ----------

try:
    initial_state = {
    "prompt": "Show count of patients grouped by diagnosis",
    "model_name": "project-115-Precision_Medicine_AI_Agent-2",
    "base_url": "https://amgen-ai-dev.cloud.databricks.com/serving-endpoints",
    "api_key": "dapi0945608621f87ae408fc84b3f011a0bd"
}
    result = workflow.invoke(initial_state)
    for step in workflow.stream(result):
        print(f"Step output:\n{step}\n")
except Exception as e:
    print(f"Error occurred: {e}")

# COMMAND ----------



# COMMAND ----------

result = workflow.invoke({"input": "how many subjects are in the Amg160 study?", "num_results": 100})

for step in workflow.stream(result):
    print(f"Step output:\n{step}\n")
    if "biomarker_insight" in step:
        print(step.get("biomarker_insight"))
    elif "retrieved_docs" in step:
        # Handle the vector_search result
        print("Received a vector_search result. Processing...")
        # Example: Extract relevant information from the vector_search result
        vector_search_result = step.get("retrieved_docs")
        print(vector_search_result)
    else:
        print("Unexpected result format. Please check the workflow.invoke method.")

# COMMAND ----------

result = workflow.invoke({"input": "how many subjects are in the Amg160 study?","num_results": 10000})

for step in workflow.stream(result):
    print(f"Step output:\n{step}\n")
    if "biomarker_insight" in step:
        print(step.get("biomarker_insight"))
    elif "retrieved_docs" in step:
        # Handle the vector_search result
        print("Received a vector_search result. Processing...")
        # Example: Extract relevant information from the vector_search result
        vector_search_result = step.get("retrieved_docs")
        print(vector_search_result)
    else:
        print("Unexpected result format. Please check the workflow.invoke method.")
#     if "biomarker_insight" in result:
#         print(result.get("biomarker_insight"))
#     elif "retrieved_docs" in result:
#         # Handle the vector_search result
#         print("Received a vector_search result. Processing...")
#         # Example: Extract relevant information from the vector_search result
#         vector_search_result = result.get("retrieved_docs")
#         print(vector_search_result)
#     else:
#         print("Unexpected result format. Please check the workflow.invoke method.")
# elif isinstance(result, str) and result == "vector_search":
#     print("Received a vector_search result. Processing...")
#     # Handle the vector_search result here
# else:
#     print("Unexpected result format. Please check the workflow.invoke method.")

# COMMAND ----------

print("Initial state:", initial_state)

# COMMAND ----------

from langgraph.graph import StateGraph, END
from typing import TypedDict, Optional, List, Dict
import os
import json
from openai import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chat_models import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser
# from databricks.vector_search import DatabricksVectorSearch

# -----------------------------
# AgentState Definition
# -----------------------------
class AgentState(TypedDict):
    input: str
    retrieved_docs: Optional[List[str]]
    prompt: Optional[str]
    sql_query: Optional[str]
    query_results: Optional[str]
    biomarker_insight: Optional[str]
    is_valid: bool
    validation_issues: Optional[str]
    inference: Optional[str]
    model_name: str
    base_url: str
    api_key: str

# -----------------------------
# Agent Nodes
# -----------------------------

def vector_search_agent(state: AgentState) -> AgentState:
    print("task_name: Vector_search")
    print("Vector Search received keys:", list(state.keys()))

    vectorstore = DatabricksVectorSearch(index_name="edl_dev.cbd_sandbox.pmed_prod_ddm_vector_index")
    docs = vectorstore.similarity_search(state["input"], k=400)
    new_state = {**state, "retrieved_docs": [doc.page_content for doc in docs]}
    print("Vector Search returning keys:", list(new_state.keys()))
    return new_state

def prompt_engineering_agent(state: AgentState) -> AgentState:
    print("task_name: Prompt_engneering")
    print("Prompt Engineering received keys:", list(state.keys()))

    joined_docs = "\n".join(state["retrieved_docs"])
    prompt = f"""Based on the following retrieved content, generate a SQL query:\n\n{joined_docs}\n\nUser Query: {state['input']}"""
    new_state = {**state, "prompt": prompt}
    print("Prompt Engineering returning keys:", list(new_state.keys()))
    return new_state

def text2sql_agent(state: AgentState) -> AgentState:
    print("task_name: Text2SQL")
    print("Text2SQL received keys:", list(state.keys()))

    llm = ChatOpenAI(
        model=state["model_name"],
        base_url=state["base_url"],
        openai_api_key=state["api_key"]
    )
    prompt = PromptTemplate.from_template("{prompt}")
    chain = prompt | llm | StrOutputParser()
    sql = chain.invoke({"prompt": state["prompt"]})
    new_state = {**state, "sql_query": sql}
    print("Text2SQL returning keys:", list(new_state.keys()))
    return new_state

def validate_sql_agent(state: AgentState) -> AgentState:
    print("task_name: Validate_SQL & Adding_description")
    print("Validation received keys:", list(state.keys()))

    schema_info = "\n".join(state.get("retrieved_docs", []))
    sql_query = state.get("sql_query", "")
    prompt = (
        f"Schema info:\n{schema_info}\n\n"
        f"Given SQL:\n{sql_query}\n\n"
        "1) Is the SQL valid for the schema?\n"
        "2) Are there missing columns or wrong table names?\n"
        "3) Is the logic correct — primary keys, joins, aggregations?\n"
        "4) Add a short inference: what does the query return?\n\n"
        'Reply in JSON: {"valid": true/false, "issues": "...", "inference": "..."}'
    )

    client = OpenAI(api_key=state["api_key"], base_url=state["base_url"])
    message = [
        {"role": "system", "content": "You are SQL schema checker."},
        {"role": "user", "content": prompt}
    ]

    response = client.chat.completions.create(
        model=state["model_name"],
        messages=message
    )

    try:
        parsed = json.loads(response.choices[0].message.content.strip())
        valid = parsed.get("valid", False)
        issues = parsed.get("issues", "")
        inference = parsed.get("inference", "")
    except Exception as e:
        valid, issues, inference = False, f"Error parsing: {e}", ""

    new_state = {**state, "is_valid": valid, "validation_issues": issues, "inference": inference}
    print("Validation returning keys:", list(new_state.keys()))
    return new_state

def execute_sql_agent(state: AgentState) -> AgentState:
    print("task_name: Execute_SQL")
    print("Execute SQL received keys:", list(state.keys()))

    sql = state.get("sql_query", "")
    result = f"-- simulated execution of: {sql}"
    new_state = {**state, "query_results": result}
    print("Execute SQL returning keys:", list(new_state.keys()))
    return new_state

# -----------------------------
# LangGraph Workflow
# -----------------------------
workflow = StateGraph(AgentState)

workflow.add_node("vector_search", vector_search_agent)
workflow.add_node("prompt_engineering", prompt_engineering_agent)
workflow.add_node("text2sql", text2sql_agent)
workflow.add_node("validate_sql", validate_sql_agent)
workflow.add_node("execute_sql", execute_sql_agent)

workflow.set_entry_point("vector_search")
workflow.add_edge("vector_search", "prompt_engineering")
workflow.add_edge("prompt_engineering", "text2sql")
workflow.add_edge("text2sql", "validate_sql")
workflow.add_edge("validate_sql", "execute_sql")
workflow.add_edge("execute_sql", END)

graph = workflow.compile()


# COMMAND ----------

initial_state: AgentState = {
    "input": "Find patient counts by cohort",
    "model_name": "project-115-Precision_Medicine_AI_Agent-2",
    "base_url": "https://amgen-ai-dev.cloud.databricks.com/serving-endpoints",
    "api_key": "dapi0945608621f87ae408fc84b3f011a0bd"
}

final_state = graph.invoke(initial_state)
print("Final Output:", final_state)


# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

