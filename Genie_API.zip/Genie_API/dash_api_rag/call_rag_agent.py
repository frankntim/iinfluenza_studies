# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------

# MAGIC %pip install --upgrade databricks-langchain langchain-community langchain databricks-sql-connector databricks-vectorsearch pydantic langgraph langchain_openai openai
# MAGIC #pydantic==1.10.2 langgraph 
# MAGIC %restart_python dbutils.library.restartPython()
# MAGIC

# COMMAND ----------

from rag_agent import call_rag_agent #workflow, summarize_final_output

# COMMAND ----------

prompt_input =  "How many cohorts are there and for each how many subjects in study AMG160"
model_name = "project-115-Precision_Medicine_AI_Agent-2"
inference,result_df,sql_query = call_rag_agent(prompt_input,model_name)

# COMMAND ----------

inference

# COMMAND ----------

print(sql_query)

# COMMAND ----------

result_df

# COMMAND ----------

