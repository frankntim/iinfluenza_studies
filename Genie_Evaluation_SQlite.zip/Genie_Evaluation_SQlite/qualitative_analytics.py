# =============================
# qualitative_analytics.py
# =============================
from typing import List
import json
from db import now_iso
from langchain_openai import ChatOpenAI
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from langchain_core.messages import HumanMessage, SystemMessage


NEGATIVE_OPTIONS = [
    "Information was inaccurate",
    "Response was incomplete",
    "Response was unclear",
    "Response was not relevant",
    "Other",
]


def insert_qualitative(conn, *, quant_id: int, custom_feedback: str, reasons: List[str],
                       severity: float, actionability: float,
                       model: str, software_version: str,
                       user_id: str, vectorization_version: str):
    reason_set = set(reasons or [])
    with conn:
        conn.execute(
            """
            INSERT INTO qualitative_data (
                quant_id, timestamp, custom_feedback,
                flags_inaccurate, flags_incomplete, flags_unclear, flags_irrelevant, flags_other,
                severity, actionability,
                model, software_version, user_id, vectorization_version
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                quant_id, now_iso(), custom_feedback or "",
                1 if "Information was inaccurate" in reason_set else 0,
                1 if "Response was incomplete" in reason_set else 0,
                1 if "Response was unclear" in reason_set else 0,
                1 if "Response was not relevant" in reason_set else 0,
                1 if "Other" in reason_set else 0,
                float(severity), float(actionability),
                model, software_version, user_id or "", vectorization_version or "",
            ),
        )


def update_qualitative_analytics(conn, *, judge_model: str):
    row = conn.execute(
        """
        SELECT COUNT(*) as n,
               COALESCE(SUM(flags_inaccurate),0) as inaccurate,
               COALESCE(SUM(flags_incomplete),0) as incomplete,
               COALESCE(SUM(flags_unclear),0) as unclear,
               COALESCE(SUM(flags_irrelevant),0) as irrelevant,
               COALESCE(SUM(flags_other),0) as other
        FROM qualitative_data
        """
    ).fetchone()

    n = row["n"] or 0
    inaccurate = row["inaccurate"] or 0
    incomplete = row["incomplete"] or 0
    unclear = row["unclear"] or 0
    irrelevant = row["irrelevant"] or 0
    other = row["other"] or 0

    recents = conn.execute(
        """
        SELECT custom_feedback,
               flags_inaccurate, flags_incomplete, flags_unclear, flags_irrelevant, flags_other,
               timestamp
        FROM qualitative_data
        ORDER BY id DESC
        LIMIT 50
        """
    ).fetchall()

    bullets = []
    for r in recents:
        tags = []
        if r["flags_inaccurate"]: tags.append("inaccurate")
        if r["flags_incomplete"]: tags.append("incomplete")
        if r["flags_unclear"]: tags.append("unclear")
        if r["flags_irrelevant"]: tags.append("irrelevant")
        if r["flags_other"]: tags.append("other")
        bullets.append({"timestamp": r["timestamp"], "tags": tags, "note": (r["custom_feedback"] or "").strip()[:500]})

    summary_prompt = (
        "You are an analyst. Given a JSON list of recent negative feedback items from an LLM app, "
        "find the top 3 recurring issues and propose 2 actionable suggestions. Return concise markdown bullets."
    )

    try:
        judge = ChatDatabricks(model=judge_model, temperature=0)#Frank
        summary_resp = judge.invoke([SystemMessage(content=summary_prompt), HumanMessage(content=json.dumps(bullets, ensure_ascii=False))])
        summary_text = getattr(summary_resp, "content", "")
    except Exception:
        summary_text = "(no LLM summary available)"

    with conn:
        conn.execute(
            """
            INSERT INTO qualitative_analytics (
                timestamp, n_negative, counts_inaccurate, counts_incomplete, counts_unclear,
                counts_irrelevant, counts_other, top_themes, judge_model
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (now_iso(), n, inaccurate, incomplete, unclear, irrelevant, other, summary_text, judge_model),
        )
