# =============================
# quantitative_analytics.py
# =============================
from typing import Dict, Optional
import json
from db import now_iso
from langchain_openai import ChatOpenAI
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from langchain_core.messages import HumanMessage, SystemMessage


def extract_token_usage(ai_message) -> Dict[str, Optional[int]]:
    usage = {"input_tokens": None, "output_tokens": None, "total_tokens": None}
    try:
        meta = getattr(ai_message, "usage_metadata", None) or {}
        if meta:
            usage["input_tokens"] = meta.get("input_tokens")
            usage["output_tokens"] = meta.get("output_tokens")
            usage["total_tokens"] = meta.get("total_tokens")
        if not usage["total_tokens"]:
            rmeta = getattr(ai_message, "response_metadata", {})
            tu = rmeta.get("token_usage") or rmeta.get("usage") or {}
            usage["input_tokens"] = usage["input_tokens"] or tu.get("prompt_tokens") or tu.get("input_tokens")
            usage["output_tokens"] = usage["output_tokens"] or tu.get("completion_tokens") or tu.get("output_tokens")
            if tu.get("total_tokens"):
                usage["total_tokens"] = tu.get("total_tokens")
            elif usage["input_tokens"] is not None and usage["output_tokens"] is not None:
                usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]
    except Exception:
        pass
    return usage


def insert_quantitative(conn, *, thumbs: str, user_query: str, llm_response: str,
                        expected_response: str, model: str, software_version: str,
                        usage: Dict[str, Optional[int]], user_id: str, vectorization_version: str) -> int:
    with conn:
        cur = conn.execute(
            """
            INSERT INTO quantitative_data (
                timestamp, thumbs, user_query, llm_response, expected_response,
                model, software_version, input_tokens, output_tokens, total_tokens,
                user_id, vectorization_version
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                now_iso(), thumbs, user_query, llm_response, expected_response,
                model, software_version,
                usage.get("input_tokens"), usage.get("output_tokens"), usage.get("total_tokens"),
                user_id or "", vectorization_version or "",
            ),
        )
        return int(cur.lastrowid)


def insert_quantitative_analytics(conn, *, quant_id: int, judge_model: str, label: str,
                                  rationale: str, overall: Optional[float],
                                  metrics: Dict[str, Optional[float]]):
    with conn:
        conn.execute(
            """
            INSERT INTO quantitative_analytics (
                quant_id, timestamp, judge_score, judge_label, judge_rationale, judge_model,
                correctness, relevance, faithfulness, completeness, conciseness
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                quant_id, now_iso(), overall, label, rationale, judge_model,
                metrics.get("correctness"), metrics.get("relevance"), metrics.get("faithfulness"),
                metrics.get("completeness"), metrics.get("conciseness"),
            ),
        )


def run_judge(conn, *, quant_id: int, judge_model: str, user_query: str,
              llm_response: str, expected_response: Optional[str]):
    system = (
        "You are a strict but fair evaluator. Score the ASSISTANT response on a 0-5 scale."
        "If an expected answer is provided, judge against it primarily (accuracy, completeness, clarity)."
        "If no expected answer, judge usefulness and correctness for the USER query."
        "Return ONLY valid JSON with keys exactly:"
        "{"
        "  \"overall\": number (0-5),"
        "  \"label\": \"Excellent|Good|Fair|Poor|Fail\","
        "  \"rationale\": string,"
        "  \"metrics\": {"
        "    \"correctness\": number (0-5),"
        "    \"relevance\": number (0-5),"
        "    \"faithfulness\": number (0-5),"
        "    \"completeness\": number (0-5),"
        "    \"conciseness\": number (0-5)"
        "  }"
        "}"
    )

    user_blob = {
        "user_query": user_query,
        "assistant_response": llm_response,
        "expected_response": expected_response or "",
    }

    judge = ChatDatabricks(model=judge_model, temperature=0) #Frank
    resp = judge.invoke([SystemMessage(content=system), HumanMessage(content=json.dumps(user_blob, ensure_ascii=False))])
    content = getattr(resp, "content", "{}").strip()

    overall = None
    label = ""
    rationale = ""
    metrics = {k: None for k in ["correctness","relevance","faithfulness","completeness","conciseness"]}

    try:
        data = json.loads(content)
        overall = float(data.get("overall", data.get("score", 0)))
        label = str(data.get("label", "")).strip()
        rationale = str(data.get("rationale", "")).strip()
        m = data.get("metrics", {}) or {}
        for k in metrics.keys():
            v = m.get(k)
            metrics[k] = float(v) if v is not None else None
    except Exception:
        rationale = content[:1000]

    insert_quantitative_analytics(
        conn,
        quant_id=quant_id,
        judge_model=judge_model,
        label=label,
        rationale=rationale,
        overall=(overall if overall is not None else 0.0),
        metrics=metrics,
    )
