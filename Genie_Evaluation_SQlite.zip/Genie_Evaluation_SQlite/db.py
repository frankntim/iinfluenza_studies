# =============================
# db.py
# =============================
import sqlite3
from datetime import datetime


def now_iso() -> str:
    return datetime.utcnow().isoformat()


def get_conn(db_path: str = "feedback.db") -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def create_tables(conn: sqlite3.Connection) -> None:
    with conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS quantitative_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                thumbs TEXT CHECK(thumbs IN ('up','down')),
                user_query TEXT,
                llm_response TEXT,
                expected_response TEXT,
                model TEXT,
                software_version TEXT,
                input_tokens INTEGER,
                output_tokens INTEGER,
                total_tokens INTEGER,
                user_id TEXT,
                vectorization_version TEXT
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS quantitative_analytics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                quant_id INTEGER,
                timestamp TEXT,
                judge_score REAL,
                judge_label TEXT,
                judge_rationale TEXT,
                judge_model TEXT,
                correctness REAL,
                relevance REAL,
                faithfulness REAL,
                completeness REAL,
                conciseness REAL,
                FOREIGN KEY(quant_id) REFERENCES quantitative_data(id) ON DELETE CASCADE
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS qualitative_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                quant_id INTEGER,
                timestamp TEXT,
                custom_feedback TEXT,
                flags_inaccurate INTEGER DEFAULT 0,
                flags_incomplete INTEGER DEFAULT 0,
                flags_unclear INTEGER DEFAULT 0,
                flags_irrelevant INTEGER DEFAULT 0,
                flags_other INTEGER DEFAULT 0,
                severity REAL,
                actionability REAL,
                model TEXT,
                software_version TEXT,
                user_id TEXT,
                vectorization_version TEXT,
                FOREIGN KEY(quant_id) REFERENCES quantitative_data(id) ON DELETE CASCADE
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS qualitative_analytics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                n_negative INTEGER,
                counts_inaccurate INTEGER,
                counts_incomplete INTEGER,
                counts_unclear INTEGER,
                counts_irrelevant INTEGER,
                counts_other INTEGER,
                top_themes TEXT,
                judge_model TEXT
            )
            """
        )


def ensure_judge_metric_columns(conn: sqlite3.Connection) -> None:
    # Adds metric columns if missing
    try:
        info = conn.execute("PRAGMA table_info(quantitative_analytics)").fetchall()
        existing = {row[1] if isinstance(row, tuple) else row["name"] for row in info}
        for col in ["correctness","relevance","faithfulness","completeness","conciseness"]:
            if col not in existing:
                conn.execute(f"ALTER TABLE quantitative_analytics ADD COLUMN {col} REAL")
    except Exception:
        pass


def ensure_qualitative_sa_columns(conn: sqlite3.Connection) -> None:
    # Adds severity/actionability columns if missing
    try:
        info = conn.execute("PRAGMA table_info(qualitative_data)").fetchall()
        existing = {row[1] if isinstance(row, tuple) else row["name"] for row in info}
        if "severity" not in existing:
            conn.execute("ALTER TABLE qualitative_data ADD COLUMN severity REAL")
        if "actionability" not in existing:
            conn.execute("ALTER TABLE qualitative_data ADD COLUMN actionability REAL")
    except Exception:
        pass


def ensure_user_vect_columns(conn: sqlite3.Connection) -> None:
    """Add user_id and vectorization_version to quantitative/qualitative tables if missing."""
    try:
        for table, cols in {
            "quantitative_data": ["user_id", "vectorization_version"],
            "qualitative_data": ["user_id", "vectorization_version"],
        }.items():
            info = conn.execute(f"PRAGMA table_info({table})").fetchall()
            existing = {row[1] if isinstance(row, tuple) else row["name"] for row in info}
            for col in cols:
                if col not in existing:
                    conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} TEXT")
    except Exception:
        pass
