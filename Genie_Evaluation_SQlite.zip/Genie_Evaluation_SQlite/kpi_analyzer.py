# =============================
# kpi_analyzer.py
# =============================
"""KPI Analyzer for qualitative feedback.

Computes two scores in [0.0, 1.0]:
- severity: how harmful/impactful the failure is
- actionability: how directly fixable and specific the feedback is

Strategy:
1) If an OpenAI model name is provided and OPENAI_API_KEY is set, use an
   LLM (via langchain_openai.ChatOpenAI) to produce structured JSON.
2) If the LLM call fails for any reason, fall back to a deterministic
   heuristic based on selected reasons and text features.

Public API:
    analyze_kpis(bundle: dict, model_name: str | None) -> dict

`bundle` should include at least:
    {
      "reasons": list[str],
      "custom_feedback": str,
      "expected": str,
      "user_query": str,
      "assistant_response": str,
      "model": str,
      "version": str
    }

Returns dict like:
    {"severity": float, "actionability": float, "explanation": str}
"""
from __future__ import annotations

import json
import math
import os
import re
from typing import Dict, Any, Optional, List
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)

# Optional LLM dependency
try:
    from langchain_openai import ChatOpenAI
    from langchain_core.messages import HumanMessage, SystemMessage
except Exception:  # pragma: no cover
    ChatOpenAI = None  # type: ignore
    HumanMessage = None  # type: ignore
    SystemMessage = None  # type: ignore

# --------------------------- Heuristic helpers ---------------------------
REASON_SEVERITY = {
    "Information was inaccurate": 0.95,
    "Response was incomplete": 0.65,
    "Response was unclear": 0.55,
    "Response was not relevant": 0.75,
    "Other": 0.45,
}

REASON_ACTIONABILITY = {
    # Inaccurate is often actionable if specifics are given
    "Information was inaccurate": 0.70,
    # Incomplete tends to be easy to fix by adding missing bits
    "Response was incomplete": 0.80,
    # Unclear is usually quite actionable
    "Response was unclear": 0.85,
    # Irrelevant feedback may be less actionable unless details provided
    "Response was not relevant": 0.55,
    "Other": 0.60,
}

NEGATIVE_KEYWORDS = [
    "wrong", "incorrect", "false", "hallucinate", "unsafe", "harmful",
    "misleading", "dangerous", "nonsense", "fabricated"
]

ACTION_HINTS = [
    "should", "expected", "instead", "please", "add", "include",
    "provide", "fix", "correct", "clarify", "step", "reproduce"
]

CODE_HINTS = ["```", "traceback", "error:", "stack", "curl", "json", "sql", "python"]


def _clip01(x: float) -> float:
    return max(0.0, min(1.0, x))


def _heuristic_scores(reasons: List[str], text: str, expected: str) -> Dict[str, float]:
    # Base from reasons (use a softmax-like mean with emphasis on max)
    if not reasons:
        reasons = []
    base_sev = [REASON_SEVERITY.get(r, 0.5) for r in reasons] or [0.5]
    base_act = [REASON_ACTIONABILITY.get(r, 0.5) for r in reasons] or [0.5]

    # Weighted mean towards the max selected reason
    sev = 0.6 * max(base_sev) + 0.4 * (sum(base_sev) / len(base_sev))
    act = 0.6 * max(base_act) + 0.4 * (sum(base_act) / len(base_act))

    text_lc = (text or "").lower()
    expected_lc = (expected or "").lower()

    # Keyword penalties/boosts for severity
    sev += 0.1 * sum(1 for kw in NEGATIVE_KEYWORDS if kw in text_lc)
    sev += 0.05 * text_lc.count("!")

    # Long expected answer means mismatch might be severe
    if len(expected_lc) > 200:
        sev += 0.05

    # Actionability boosts: presence of concrete verbs, steps, or code
    act += 0.08 * sum(1 for kw in ACTION_HINTS if kw in text_lc)
    act += 0.10 if any(h in text for h in CODE_HINTS) else 0.0

    # Normalize to [0,1]
    return {
        "severity": _clip01(sev),
        "actionability": _clip01(act),
    }


LLM_SYSTEM = (
    "You are a rigorous QA analyst. Given a JSON bundle about a negative user feedback, "
    "estimate two KPIs in [0,1]:\n"
    "- severity: overall harm/impact if the assistant's failure were left unaddressed\n"
    "- actionability: how directly fixable and specific the feedback is (higher = more actionable)\n"
    "Consider selected reasons, concrete details, presence of repro steps, and clarity.\n"
    "Respond with ONLY JSON of the form {\"severity\": <float>, \"actionability\": <float>, \"explanation\": <short string>}\n"
)


def _llm_scores(bundle: Dict[str, any], model_name: Optional[str]):
    if not model_name or not os.environ.get("OPENAI_API_KEY") or ChatOpenAI is None:
        return None
    llm = ChatDatabricks(model=model_name, temperature=0)#Frank
    resp = llm.invoke([
        SystemMessage(content=LLM_SYSTEM),
        HumanMessage(content=json.dumps(bundle, ensure_ascii=False)),
    ])
    content = getattr(resp, "content", "{}")
    try:
        data = json.loads(content)
        sev = float(data.get("severity"))
        act = float(data.get("actionability"))
        exp = str(data.get("explanation", "")).strip()
        return {"severity": _clip01(sev), "actionability": _clip01(act), "explanation": exp}
    except Exception:
        return None


def analyze_kpis(bundle: Dict[str, any], model_name: Optional[str] = None) -> Dict[str, any]:
    reasons = bundle.get("reasons") or []
    text = (bundle.get("custom_feedback") or "").strip()
    expected = (bundle.get("expected") or "").strip()
    base = _heuristic_scores(reasons, text, expected)

    try:
        rich = _llm_scores(bundle, model_name)
    except Exception:
        rich = None

    if rich and isinstance(rich.get("severity"), (int, float)) and isinstance(rich.get("actionability"), (int, float)):
        return {
            "severity": _clip01(float(rich["severity"])),
            "actionability": _clip01(float(rich["actionability"])),
            "explanation": rich.get("explanation", ""),
        }

    return {"severity": base["severity"], "actionability": base["actionability"], "explanation": "heuristic"}
