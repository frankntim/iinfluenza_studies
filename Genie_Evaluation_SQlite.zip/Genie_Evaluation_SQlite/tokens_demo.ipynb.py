# Databricks notebook source
# MAGIC %pip install langgraph==0.3.4 langchain-openai==0.3.0 langchain-experimental==0.3.4 databricks-langchain databricks-agents databricks-sql-connector sqlalchemy

# COMMAND ----------

# =============================
# quantitative_analytics.py
# =============================
from typing import Dict, Optional
import json
import os
from db import now_iso
from langchain_openai import ChatOpenAI
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from langchain_core.messages import HumanMessage, SystemMessage

LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
#BASE_URL_SERVING_ENDPOINT = os.environ.get("DATABRICKS_HOST_ENDPOINT")
DATABRICKS_API_KEY = "dapi09f0df7c995c9e37c8a40f7b681a26d4"


os.environ['OPENAI_API_KEY'] = DATABRICKS_API_KEY
MODEL_NAME = LLM_ENDPOINT_NAME
TEMPERATURE = 0

def extract_token_usage(ai_message) -> Dict[str, Optional[int]]:
    usage = {"input_tokens": None, "output_tokens": None, "total_tokens": None}
    try:
        meta = getattr(ai_message, "usage_metadata", None) or {}
        if meta:
            usage["input_tokens"] = meta.get("input_tokens")
            usage["output_tokens"] = meta.get("output_tokens")
            usage["total_tokens"] = meta.get("total_tokens")
        if not usage["total_tokens"]:
            rmeta = getattr(ai_message, "response_metadata", {})
            tu = rmeta.get("token_usage") or rmeta.get("usage") or {}
            usage["input_tokens"] = usage["input_tokens"] or tu.get("prompt_tokens") or tu.get("input_tokens")
            usage["output_tokens"] = usage["output_tokens"] or tu.get("completion_tokens") or tu.get("output_tokens")
            if tu.get("total_tokens"):
                usage["total_tokens"] = tu.get("total_tokens")
            elif usage["input_tokens"] is not None and usage["output_tokens"] is not None:
                usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]
    except Exception:
        pass
    return usage

# COMMAND ----------

user_input = "What is the capital of India"
   

llm = ChatDatabricks(model=MODEL_NAME, temperature=TEMPERATURE) #Frank
ai = llm.invoke([
    SystemMessage(content="You are a helpful assistant."),
    HumanMessage(content=user_input),
])
ai_text = getattr(ai, "content", "(no content)")
usage = extract_token_usage(ai)
print(usage)