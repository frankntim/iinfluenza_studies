# Databricks notebook source
# MAGIC %pip install langgraph==0.3.4 langchain-openai==0.3.0 langchain-experimental==0.3.4 databricks-langchain databricks-agents databricks-sql-connector sqlalchemy