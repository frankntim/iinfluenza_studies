# =============================
# seed_demo_data.py
# =============================
"""Seed the feedback SQLite DB with realistic sample data (focused window).

This version populates data for a SPECIFIC date range — e.g. **July 1 → Sept 9** —
so the approval-rate charts are less cluttered while still showing useful trends.

It inserts rows across *every combination* of (model × software_version) with
both 👍 and 👎 examples each month in the window, including:
- quantitative_data (interactions)
- quantitative_analytics (judge scores: overall + 5 metrics)
- qualitative_data (👎-only; reasons, free-text, severity, actionability)
- a qualitative_analytics snapshot at the end

CLI Example (matches your request):
    python seed_demo_data.py \
      --db feedback.db \
      --models gpt-4o-mini,gpt-4o,gpt-4.1-mini \
      --versions v1.0.0,v1.1.0,v1.2.0 \
      --vec-versions vec-1,vec-2 \
      --users user-001,user-002,user-003 \
      --from 2025-07-01 --to 2025-09-09 \
      --per-combo-month 10 --seed 42

You can also import and call seed_period(...).
"""
from __future__ import annotations

import argparse
import random
from dataclasses import dataclass
from datetime import datetime, timedelta, date
from typing import List, Tuple, Dict, Optional

import db as dbmod
import quantitative_analytics as qa
import qualitative_analytics as ql
from kpi_analyzer import analyze_kpis

TOPICS = [
    "quarterly revenue",
    "protein folding",
    "SQL window functions",
    "Streamlit dialogs",
    "LangChain ChatOpenAI",
    "SQLite indexing",
    "clinical trial phases",
    "vector search",
    "token usage accounting",
    "error handling best practices",
]
NEUTRAL_RESPONSES = [
    "Here is a brief overview and the key points you asked for.",
    "Summarizing the concept with examples…",
    "Let me break that down step-by-step.",
]
BAD_RESPONSES = [
    "I'm not sure, maybe it's related to weather?",
    "42.",
    "This looks fine. Anyway, have a nice day!",
]
EXPECTED_TEMPLATES = [
    "The expected answer should include a definition, 2-3 bullet points, and a short example.",
    "Please provide a concise explanation and a simple code snippet.",
    "A numbered list of steps would be the best response in this case.",
]
NEG_NOTES = [
    "The answer was wrong about the core concept and missed critical context.",
    "It didn't include the SQL example I expected.",
    "The response was unclear and lacked stepwise instructions!",
    "It talked about an unrelated topic and didn't address the question.",
    "The info seemed fabricated and not backed by the prompt.",
]


def month_spans_between(start_dt: datetime, end_dt: datetime) -> List[Tuple[datetime, datetime]]:
    if end_dt <= start_dt:
        return []
    spans: List[Tuple[datetime, datetime]] = []
    cur = start_dt.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    while cur <= end_dt:
        if cur.month == 12:
            nxt = cur.replace(year=cur.year + 1, month=1)
        else:
            nxt = cur.replace(month=cur.month + 1)
        span_start = max(cur, start_dt)
        span_end = min(nxt, end_dt)
        if span_end > span_start:
            spans.append((span_start, span_end))
        cur = nxt
    return spans


def random_dt_in_range(start: datetime, end: datetime) -> datetime:
    delta = end - start
    seconds = max(1, int(delta.total_seconds()) - 1)
    offs = random.randint(0, seconds)
    return start + timedelta(seconds=offs)


@dataclass
class SeedConfig:
    db_path: str
    models: List[str]
    versions: List[str]
    vec_versions: List[str]
    users: List[str]
    start_date: date
    end_date: date
    per_combo_month: int = 10
    seed: Optional[int] = 42


def _ensure_schema(conn):
    dbmod.create_tables(conn)
    dbmod.ensure_judge_metric_columns(conn)
    dbmod.ensure_qualitative_sa_columns(conn)
    dbmod.ensure_user_vect_columns(conn)


def _insert_one(conn, ts: datetime, model: str, version: str, vec_ver: str, user_id: str,
                thumbs: str, user_query: str, assistant_response: str, expected_response: str):
    in_tok = random.randint(40, 300)
    out_tok = random.randint(60, 500)
    usage = {"input_tokens": in_tok, "output_tokens": out_tok, "total_tokens": in_tok + out_tok}

    qid = qa.insert_quantitative(
        conn,
        thumbs=thumbs,
        user_query=user_query,
        llm_response=assistant_response,
        expected_response=expected_response,
        model=model,
        software_version=version,
        usage=usage,
        user_id=user_id,
        vectorization_version=vec_ver,
    )
    with conn:
        conn.execute("UPDATE quantitative_data SET timestamp=? WHERE id=?", (ts.isoformat(), qid))

    if thumbs == "up":
        metrics = {
            "correctness": random.uniform(0.75, 0.98),
            "relevance": random.uniform(0.75, 0.98),
            "faithfulness": random.uniform(0.75, 0.98),
            "completeness": random.uniform(0.70, 0.95),
            "conciseness": random.uniform(0.65, 0.95),
        }
    else:
        metrics = {
            "correctness": random.uniform(0.15, 0.55),
            "relevance": random.uniform(0.10, 0.60),
            "faithfulness": random.uniform(0.15, 0.60),
            "completeness": random.uniform(0.10, 0.55),
            "conciseness": random.uniform(0.30, 0.85),
        }
    overall = sum(metrics.values()) / len(metrics)

    qa.insert_quantitative_analytics(
        conn,
        quant_id=qid,
        judge_model="synthetic-judge",
        label=("Excellent" if overall > 0.85 else "Good" if overall > 0.7 else "Fair" if overall > 0.5 else "Poor"),
        rationale="Synthetic judge scoring for demo data.",
        overall=overall,
        metrics=metrics,
    )
    with conn:
        conn.execute(
            "UPDATE quantitative_analytics SET timestamp=? WHERE id=(SELECT MAX(id) FROM quantitative_analytics WHERE quant_id=?)",
            (ts.isoformat(), qid),
        )

    if thumbs == "down":
        n_reasons = random.randint(1, 3)
        reasons = random.sample(ql.NEGATIVE_OPTIONS, n_reasons)
        custom = random.choice(NEG_NOTES)
        bundle = {
            "reasons": reasons,
            "custom_feedback": custom,
            "expected": expected_response,
            "user_query": user_query,
            "assistant_response": assistant_response,
            "model": model,
            "version": version,
        }
        res = analyze_kpis(bundle, model_name=None)
        severity = float(res.get("severity", 0.5))
        actionability = float(res.get("actionability", 0.5))

        ql.insert_qualitative(
            conn,
            quant_id=qid,
            custom_feedback=custom,
            reasons=reasons,
            severity=severity,
            actionability=actionability,
            model=model,
            software_version=version,
            user_id=user_id,
            vectorization_version=vec_ver,
        )
        with conn:
            conn.execute(
                "UPDATE qualitative_data SET timestamp=? WHERE id=(SELECT MAX(id) FROM qualitative_data WHERE quant_id=?)",
                (ts.isoformat(), qid),
            )

    return qid


def seed_period(db_path: str, models: List[str], versions: List[str], vec_versions: List[str], users: List[str],
                start_date: date, end_date: date, per_combo_month: int = 10, seed: Optional[int] = 42) -> int:
    if seed is not None:
        random.seed(seed)
    conn = dbmod.get_conn(db_path)
    _ensure_schema(conn)

    start_dt = datetime.combine(start_date, datetime.min.time())
    end_dt = datetime.combine(end_date + timedelta(days=1), datetime.min.time())
    month_spans = month_spans_between(start_dt, end_dt)
    total = 0

    for model in models:
        for version in versions:
            for m_start, m_end in month_spans:
                rows = max(2, per_combo_month)
                mandatory = ["up", "down"]
                extra = rows - 2
                thumb_list = mandatory + [random.choice(["up","down"]) for _ in range(extra)]
                random.shuffle(thumb_list)
                for thumbs in thumb_list:
                    ts = random_dt_in_range(m_start, m_end)
                    topic = random.choice(TOPICS)
                    user_q = f"Explain {topic} with an example."
                    if thumbs == "up":
                        llm_resp = random.choice(NEUTRAL_RESPONSES) + f" (re: {topic})"
                        expected = ""
                    else:
                        llm_resp = random.choice(BAD_RESPONSES)
                        expected = random.choice(EXPECTED_TEMPLATES)
                    vec_ver = random.choice(vec_versions)
                    user_id = random.choice(users)
                    _insert_one(conn, ts, model, version, vec_ver, user_id, thumbs, user_q, llm_resp, expected)
                    total += 1

    try:
        ql.update_qualitative_analytics(conn, judge_model="synthetic-judge")
    except Exception:
        pass
    return total


def parse_args():
    p = argparse.ArgumentParser(description="Seed the feedback DB for a specific date window")
    p.add_argument("--db", dest="db_path", default="feedback.db")
    p.add_argument("--models", default="gpt-4o-mini,gpt-4o,gpt-4.1-mini")
    p.add_argument("--versions", default="v1.0.0,v1.1.0,v1.2.0")
    p.add_argument("--vec-versions", default="vec-1,vec-2")
    p.add_argument("--users", default="user-001,user-002,user-003")
    p.add_argument("--from", dest="from_date", default="2025-07-01")
    p.add_argument("--to", dest="to_date", default="2025-09-09")
    p.add_argument("--per-combo-month", type=int, default=10)
    p.add_argument("--seed", type=int, default=42)
    return p.parse_args()


def _parse_date(s: str) -> date:
    return datetime.strptime(s, "%Y-%m-%d").date()


def _split_csv(val: str) -> List[str]:
    return [x.strip() for x in val.split(",") if x.strip()]


if __name__ == "__main__":
    args = parse_args()
    models = _split_csv(args.models)
    versions = _split_csv(args.versions)
    vec_versions = _split_csv(args.vec_versions)
    users = _split_csv(args.users)
    start_date = _parse_date(args.from_date)
    end_date = _parse_date(args.to_date)

    inserted = seed_period(
        db_path=args.db_path,
        models=models,
        versions=versions,
        vec_versions=vec_versions,
        users=users,
        start_date=start_date,
        end_date=end_date,
        per_combo_month=args.per_combo_month,
        seed=args.seed,
    )
    print(f"Inserted {inserted} interactions into {args.db_path} from {start_date} to {end_date}")
