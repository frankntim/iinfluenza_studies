# Databricks notebook source
!pip install langchain==0.3.10
!pip install langchain-openai
!pip install langchain-community
!pip install langchain-chroma
!pip install --upgrade pydantic
#!pip install ag2[openai]
!pip install pysqlite3
!pip install langgraph==0.2.66
!pip install streamlit
#!apt-get install sqlite3 -y
!pip install faiss-cpu
!pip install aiohttp
!pip install langchain_experimental

%restart_python

# COMMAND ----------

from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain.schema import StrOutputParser
from IPython.display import Markdown, display

from typing import Literal
from typing_extensions import TypedDict
from langgraph.graph import MessagesState, END
from langgraph.types import Command
from langgraph.graph.message import add_messages

import os
from typing import Dict, Any
import sqlite3
import re

from typing_extensions import TypedDict
from typing import Annotated, Optional
from langchain_community.agent_toolkits import SQLDatabaseToolkit
from langchain_community.utilities import SQLDatabase
from sqlalchemy import create_engine
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import ToolNode, tools_condition, create_react_agent
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import SystemMessage, HumanMessage

from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver
from langchain_experimental.utilities import PythonREPL

import os
from typing import Dict, Any
import sqlite3
import re



from typing_extensions import TypedDict
from typing import Annotated, Optional
from langchain_community.agent_toolkits import SQLDatabaseToolkit
from langchain_community.utilities import SQLDatabase
from sqlalchemy import create_engine
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import ToolNode, tools_condition
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver

import streamlit as st
from langchain.agents import create_sql_agent
from langchain_community.vectorstores import FAISS
from langchain_core.example_selectors import SemanticSimilarityExampleSelector
from langchain_core.messages import AIMessage
from langchain_core.prompts import (
    SystemMessagePromptTemplate,
    PromptTemplate,
    FewShotPromptTemplate,
)
from langchain_core.prompts.chat import (
    ChatPromptTemplate,
    HumanMessagePromptTemplate,
    MessagesPlaceholder,
)
from langchain_experimental.utilities import PythonREPL
from langchain.memory import ConversationBufferMemory
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain.sql_database import SQLDatabase
from langchain.tools import Tool

# COMMAND ----------

#base_url="https://ai-gateway.dswb.amgen.com/api/v1/project/115"
base_url="https://amgen-ai-dev.cloud.databricks.com/serving-endpoints"
api_key = "dapif3bc3b1e718c335b48f4c410b07c9c12"
model_name = "project-115-Precision_Medicine_AI_Agent-2"

# COMMAND ----------


from langchain_openai import ChatOpenAI
llm = ChatOpenAI(model=model_name,    
                streaming=False,    
                base_url=base_url,    
                api_key=api_key,    
                max_tokens=3000
                )
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

# COMMAND ----------


prompt = ChatPromptTemplate.from_messages(
          [
            (
                "system",            
                "You are a helpful assistant.",        
            ),       
            ("human", "{input}"),    
          ])
#from langchain.schema import StrOutputParser
chain = prompt | llm | StrOutputParser()
response = chain.invoke({"input": "Compare JSP and ASP.NET Blazor in 5 bullet points"})
#response = chain.invoke({"input": "Plot a sine wave from 0 to 2π"})

display(Markdown(response))

# COMMAND ----------

# MAGIC %md
# MAGIC **Text2SQL** 

# COMMAND ----------

def create_and_populate_db():
    # Connect to SQLite database (or create it if it doesn't exist)
    conn = sqlite3.connect("./artist_album.db")
    cursor = conn.cursor()

    # Create tables
    cursor.executescript('''
    CREATE TABLE IF NOT EXISTS Artist (
        ArtistId INTEGER PRIMARY KEY AUTOINCREMENT,
        Name TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS Album (
        AlbumId INTEGER PRIMARY KEY AUTOINCREMENT,
        Title TEXT NOT NULL,
        ArtistId INTEGER NOT NULL,
        FOREIGN KEY (ArtistId) REFERENCES Artist(ArtistId) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS Invoice (
        InvoiceId INTEGER PRIMARY KEY AUTOINCREMENT,
        CustomerId INTEGER NOT NULL,
        Total REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS InvoiceLine (
        InvoiceLineId INTEGER PRIMARY KEY AUTOINCREMENT,
        InvoiceId INTEGER NOT NULL,
        TrackId INTEGER NOT NULL,
        UnitPrice REAL NOT NULL,
        Quantity INTEGER NOT NULL,
        FOREIGN KEY (InvoiceId) REFERENCES Invoice(InvoiceId) ON DELETE CASCADE
    );
    ''')

    # Insert data into Artist table
    cursor.executemany("""
    INSERT INTO Artist (Name) VALUES (?)
    """, [
        ('The Beatles',),
        ('Pink Floyd',),
        ('Led Zeppelin',),
        ('Queen',)
    ])

    # Insert data into Album table
    cursor.executemany("""
    INSERT INTO Album (Title, ArtistId) VALUES (?, ?)
    """, [
        ('Abbey Road', 1),
        ('The Dark Side of the Moon', 2),
        ('Led Zeppelin IV', 3),
        ('A Night at the Opera', 4)
    ])

    # Insert data into Invoice table
    cursor.executemany("""
    INSERT INTO Invoice (CustomerId, Total) VALUES (?, ?)
    """, [
        (1, 29.99),
        (2, 19.99),
        (3, 39.99)
    ])

    # Insert data into InvoiceLine table
    cursor.executemany("""
    INSERT INTO InvoiceLine (InvoiceId, TrackId, UnitPrice, Quantity) VALUES (?, ?, ?, ?)
    """, [
        (1, 101, 9.99, 1),
        (1, 102, 4.99, 2),
        (2, 103, 9.99, 1),
        (3, 104, 19.99, 2)
    ])

    # Commit changes and close connection
    conn.commit()
    conn.close()
    print("Database 'artist_album.db' created and populated successfully.")

if __name__ == "__main__":
    create_and_populate_db()


# COMMAND ----------

artist_db = SQLDatabase.from_uri("sqlite:///artist_album.db")
sql_toolkit = SQLDatabaseToolkit(llm=llm, db=artist_db)
sql_tools = sql_toolkit.get_tools()
#sql_tools

# COMMAND ----------



SQL_PREFIX = """You are an agent designed to interact with a SQL database in SQLite.
Given an input question, create a syntactically correct SQLite query to run, then look at the results of the query and return the answer. Unless the user specifies a specific number of examples they wish to obtain, always limit your query to at most 10 results. 
You can order the results by a relevant column to return the most interesting examples in the database.
Never query for all the columns from a specific table, only ask for the columns that you need based on the question.
Make sure you generate a correct SQLite query a plain text without any formatting or code blocks.
Do not include sql or similar markers.
Do not try to explain the query, just provide the query as-is, like this: SELECT ...

You have access to tools for interacting with the database.
Only use the below tools. Only use the information returned by the below tools to construct your final answer.

You MUST double check your query before executing it. If you get an error while executing a query, rewrite the query and try again.
Do NOT make any DML statements (INSERT, UPDATE, DELETE, DROP etc.) to the database even if the user asks.

To start you should ALWAYS look at the tables in the database to see what you can query.
Do NOT skit this step.
Then you should query the schema of the most relevant tables.

When generating the final answer in markdown from the results,
if there are special characters in the text, such as the dollar symbol,
ensure they are escaped properly to correct rendering e.g $25.5 should become \$25.5
 """
SYS_PROMPT = SystemMessage(content=SQL_PREFIX)

# COMMAND ----------

text2sql_agent = create_react_agent(model=llm, 
                                    tools=sql_tools,
                                     state_modifier=SYS_PROMPT)
text2sql_agent

# COMMAND ----------

def call_text2sql_agent(query, verbose=False):
    for event in text2sql_agent.stream(
        {"messages": [HumanMessage(content=query)]}, stream_mode='values'):
        if verbose:
            event['messages'][-1].pretty_print()
    print('\n\nFinal Response:\n')
    display(Markdown(event['messages'][-1].content))
    

# COMMAND ----------

call_text2sql_agent("What is the name of the artist with the most albums?", verbose=True)

# COMMAND ----------

query = "What are the top 5 best-selling tracks by revenue?"
result = text2sql_agent.invoke({"messages": [HumanMessage(content=query)]})
display(Markdown(result['messages'][-1].content))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Text2SQL Part 2

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

from langchain_experimental.utilities import PythonREPL
from langchain_core.tools import tool
from typing import Annotated
from langchain_community.agent_toolkits import SQLDatabaseToolkit
from langchain_openai import ChatOpenAI

repl = PythonREPL()



#chatgpt = ChatOpenAI(model="gpt-4o", temperature=0)
db = SQLDatabase.from_uri("sqlite:///customer_profiles.db")
sql_toolkit = SQLDatabaseToolkit(db=db, llm=llm)
sql_tools = sql_toolkit.get_tools()

@tool
def python_repl_tool(
    code: Annotated[str, "The python code to execute code, generate charts."],
):
    """Use this to execute python code and do math. If you want to see the output of a value,
    you should print it out with `print(...)`. This is visible to the user."""
    try:
        result = repl.run(code)
    except BaseException as e:
        return f"Failed to execute. Error: {repr(e)}"
    result_str = f"Successfully executed:\n```python\n{code}\n```\nCODE OUTPUT:\n {result}"
    return result_str

# COMMAND ----------

from typing import Literal
from typing_extensions import TypedDict
from langgraph.graph import MessagesState, END
from langgraph.types import Command
from langgraph.graph.message import add_messages
#from langchain.chat_models import ChatOpenAI
from langchain_openai import ChatOpenAI


# Our team supervisor is an LLM node. It just picks the next agent to process
# and decides when the work is completed
members = ["researcher", "coder"]

SUPERVISOR_AGENT_PROMPT = f"""You are a supervisor tasked with managing a conversation between the following workers:
                              {members}.

                              Given the following user request, respond with the worker to act next.
                              Each worker will perform a task and respond with their results and status.
                              Analyze the results carefully and decide which worker to call next accordingly.
                              Remember researcher agent can search for information and coder agent can code.
                              When finished, respond with FINISH."""


class Router(TypedDict):
    """Worker to route to next. If no workers needed, route to FINISH."""
    next: Literal["researcher", "coder", "FINISH"]

class State(TypedDict):
    messages: Annotated[list, add_messages]
    next: str

#llm = ChatOpenAI(model="gpt-4o", temperature=0)
#chatgpt = ChatOpenAI(model="gpt-4o", temperature=0)

def supervisor_node(state: State) -> Command[Literal["researcher", "coder", "__end__"]]:
    messages = [{"role": "system", "content": SUPERVISOR_AGENT_PROMPT},] + state["messages"]
    response = llm.with_structured_output(Router).invoke(messages)
    goto = response["next"]
    if goto == "FINISH":
        goto = END

    return Command(goto=goto, update={"next": goto})


# COMMAND ----------

from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, START, END
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import trim_messages


#chatgpt = ChatOpenAI(model="gpt-4o", temperature=0)

text2sql_agent = create_react_agent(model=llm,
                                    tools=sql_tools,
                                    state_modifier=SYS_PROMPT)

# create node function for financial researcher sub-agent
def research_node(state: State) -> Command[Literal["supervisor"]]:
    result = text2sql_agent.invoke(state)
    return Command(
        update={
            "messages": [
                HumanMessage(content=result["messages"][-1].content, name="researcher")
            ]
        },
        goto="supervisor",
    )


# Create Coder Sub-Agent
code_agent = create_react_agent(llm, tools=[python_repl_tool], state_modifier="""You are a coder who can write and run python code and also visualize charts and graphs.
                                                                                 Only extract the most relevant data related to the question before running code or creating graphs.
                                                                                 Once your task is done report back to the supervisor.""")

# create node function for coder sub-agent
def code_node(state: State) -> Command[Literal["supervisor"]]:
    result = code_agent.invoke(state)
    return Command(
        update={
            "messages": [
                HumanMessage(content=result["messages"][-1].content, name="coder")
            ]
        },
        goto="supervisor",
    )

# build the agent graph
builder = StateGraph(State)
builder.add_edge(START, "supervisor")
builder.add_node("supervisor", supervisor_node)
builder.add_node("researcher", research_node)
builder.add_node("coder", code_node)
graph = builder.compile()

# COMMAND ----------

def call_multi_agent_system(agent, prompt):
    events = agent.stream(
        {"messages": [("user", prompt)]},
        {"recursion_limit": 3},
        stream_mode="values",

    )

    for event in events:
        event["messages"][-1].pretty_print()

    display(Markdown(event["messages"][-1].content))


def call_multi_agent_system2(agent, prompt):
    for event in agent.stream(
        {"messages": [("user", prompt)]},
        {"recursion_limit": 30},
        stream_mode="values",

    ):
      event["messages"][-1].pretty_print()


    display(Markdown(event["messages"][-1].content))

# COMMAND ----------

query = """Get the averag age groups vs gender and Visualize the data with pie chart"""
call_multi_agent_system2(graph, query)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Part 3: Text2SQL Databricks

# COMMAND ----------

from langchain_community.agent_toolkits import create_sql_agent
from langchain_community.utilities.sql_database import SQLDatabase
from langchain_openai import AzureChatOpenAI
from langchain_openai import AzureOpenAIEmbeddings
from databricks_langchain import DatabricksEmbeddings

# https://docs.databricks.com/aws/en/generative-ai/agent-framework/multi-agent-genie

# COMMAND ----------



# COMMAND ----------


    llm = AzureChatOpenAI(
                  openai_api_version= "",
                  azure_endpoint= "",
                  deployment_name= "",
                  api_key="",
                  temperature=0,
              )
            
            
    api_token = ""
    host = ""
    http_path = ""
    catalog = ""
    schema = ""
    
    uri = (
        f"databricks://token:{api_token}@{host}?"
        f"http_path={http_path}&catalog={catalog}&schema={schema}"
    )
            
            
    db = SQLDatabase.from_uri(
        database_uri=uri,
        include_tables=[""],
        sample_rows_in_table_info=5,
    )
        
    agent_executor = create_sql_agent(
        llm=llm,
        db=db,
        verbose=False,
        agent_executor_kwargs={
            "handle_parsing_errors": True,
        },
    )

agent_executor.invoke(
    {
        "input": "<quesion>"
    }
)