"""
Streamlit app: Unity Catalog feedback analytics + LLM-as-a-judge → SQLite → Chatbot on Feedback DB
"""
from __future__ import annotations

import os
import ast
import re
import json
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import streamlit as st
from sqlalchemy import create_engine, text
from dotenv import load_dotenv
import plotly.express as px
from datetime import date

from langchain_openai import ChatOpenAI
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from databricks import sql as dbsql
from langchain.schema import SystemMessage, HumanMessage
from kpi_analyzer import analyze_kpis
from utilities2 import fetch_uc_table, get_datafrom_uc,fq_name, _response_stats,_parse_reasons_any,_category_counts,_to_list #, judge_once

st.set_page_config(page_title="PMed Chatbot Feedback Analytics", page_icon="🧱", layout="wide")




load_dotenv()
LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")
BASE_URL_SERVING_ENDPOINT = os.environ.get("DATABRICKS_HOST_ENDPOINT")
DATABRICKS_API_KEY = os.environ.get("DATABRICKS_TOKEN")

DATABRICKS_HOST_BASE = os.environ.get("DATABRICKS_HOST_BASE")
DATABRICKS_HTTP_PATH = os.environ.get("DATABRICKS_WAREHOUSE")
#FULL_TABLE_NAME = "edl_dev.cbd_sandbox.amg_pmed_convai_feedback"
FULL_TABLE_NAME = "edl_dev.cbd_sandbox.amg_pmed_convai_feedback_analytics"
CATALOG = "edl_dev"
SCHEMA = "cbd_sandbox"
TABLE = "amg_pmed_convai_feedback_analytics"

# Create a remote Spark session
os.environ.pop('DATABRICKS_CLIENT_ID', None)
os.environ.pop('DATABRICKS_CLIENT_SECRET', None)
os.environ['OPENAI_API_KEY'] = DATABRICKS_API_KEY

TEMPERATURE = 0
host = DATABRICKS_HOST_BASE 
path = DATABRICKS_HTTP_PATH 
token = DATABRICKS_API_KEY

db_path = "feedback_analytics.db"



# -----------------------------
# LLM judging
# -----------------------------
JUDGE_SYSTEM_PROMPT = (
    "You are evaluating user-written feedback about AI assistant/model outputs. "
    "Classify and rate each feedback snippet for usefulness and map it to a canonical issue category. "
    "Only reply with strict JSON using the provided schema."
)

JUDGE_USER_TMPL = (
    '''\
Task: Judge the following feedback.

Rules:
- Choose category from: {categories}.
- Define useful as: specific, actionable, and relevant to improving the model or the answer.
- Be strict: generic or venting comments are not useful.
- Return ONLY valid JSON with keys exactly as below (no trailing commentary):
  {{
    "category": "inaccurate|irrelevant|incomplete|unclear|other",
    "usefulness": "useful|not_useful",
    "actionability": 1-5,
    "specificity": 1-5,
    "sentiment": -1 to 1,
    "severity": 1-5,
    "confidence": 0-1,
    "summary": "one-sentence rationale",
    "suggested_rewrite": "rewrite the feedback to be more actionable (keep it brief)"
  }}

Feedback:
"""{text}"""
    '''
)

# ---------- Prompt used for every evaluation ----------
SYSTEM_PROMPT = (
    "You are a strict but fair evaluator. Score the ASSISTANT response with respect to the USER query "
    "and, if provided, an EXPECTED response. Use the following 0–5 float metrics:\n"
    "• correctness: factual accuracy vs the expected answer or domain knowledge\n"
    "• relevance: how well the answer addresses the user’s query\n"
    "• completeness: whether key steps/details are covered (not missing important parts)\n"
    "• faithfulness: grounded in the input/expected content; no hallucinations\n"
    "• conciseness: avoids rambling while retaining necessary information\n\n"
    "Rules:\n"
    "- If an expected response is provided, evaluate primarily against it.\n"
    "- Otherwise, evaluate the assistant response directly against the user query.\n"
    "- Return ONLY valid JSON, no Markdown or commentary. Use this exact schema:\n"
    "{\n"
    '  \"correctness\": number (0-5),\n'
    '  \"relevance\": number (0-5),\n'
    '  \"completeness\": number (0-5),\n'
    '  \"faithfulness\": number (0-5),\n'
    '  \"conciseness\": number (0-5)\n'
    "}"
)


# -----------------------------
# Helpers functions
# -----------------------------
CATEGORY_CANON = ["inaccurate", "irrelevant", "incomplete", "unclear", "other"]
METRICS: List[str] = ["correctness", "relevance", "completeness", "faithfulness", "conciseness"]


def llm_judge(raw_dataset_df, required_cols):
    judge_df = raw_dataset_df[required_cols]

    # Prepare output columns
    out_cols = METRICS + ["judge_raw"]
    for c in out_cols:
        if c not in judge_df.columns:
            judge_df[c] = None

    progress = st.progress(0.0, text="Scoring…")
    total = len(judge_df)

    for idx, row in judge_df.iterrows():
        uq = str(row.get("query", "") or "")
        ar = str(row.get("sql_query", "") or "")
        ex = str(row.get("expected_output", "") or "")

        try:
            c, r, comp, f, conc, raw_out = judge_once(LLM_ENDPOINT_NAME, TEMPERATURE, uq, ar, ex)
        except Exception as e:
            c = r = comp = f = conc = 0.0
            raw_out = f"(error) {e}"

        judge_df.at[idx, "correctness"] = c
        judge_df.at[idx, "relevance"] = r
        judge_df.at[idx, "completeness"] = comp
        judge_df.at[idx, "faithfulness"] = f
        judge_df.at[idx, "conciseness"] = conc
        judge_df.at[idx, "judge_raw"] = raw_out

        if total:
                progress.progress((idx + 1) / total, text=f"Scored {idx + 1}/{total}")

    progress.empty()
    st.success("Done! LLM Judge Scoring completed")
    return judge_df

# LLM as A Judge-> Compare Results with Expected
def _clean_and_parse_json(s: str) -> Dict[str, Any]:
    """
    Try to parse JSON; if the model adds extra text, extract the first {...} block.
    """
    s = (s or "").strip()
    try:
        return json.loads(s)
    except Exception:
        pass

    # Try to extract JSON object with a naive brace match
    try:
        start = s.find("{")
        end = s.rfind("}")
        if start != -1 and end != -1 and end > start:
            candidate = s[start : end + 1]
            return json.loads(candidate)
    except Exception:
        pass

    # Try to remove code fencing/backticks if any
    s2 = re.sub(r"^```(?:json)?|```$", "", s.strip(), flags=re.MULTILINE).strip()
    try:
        return json.loads(s2)
    except Exception:
        pass

    # Failed
    return {}

def _clamp_0_5(x: Any) -> float:
    try:
        v = float(x)
    except Exception:
        return 0.0
    return max(0.0, min(5.0, v))

def judge_once(
    judge_model: str,
    temperature: float,
    user_query: str,
    llm_response: str,
    expected_response: str,
) -> Tuple[float, float, float, float, float, str]:
    """
    Run a single LLM-as-judge evaluation and return the five metrics + raw model output.
    Cached by inputs to avoid re-charging on reruns.
    """
    chat = ChatDatabricks(model=judge_model, temperature=temperature)
    payload = {
        "user_query": user_query or "",
        "assistant_response": llm_response or "",
        "expected_response": expected_response or "",
    }
    msg = json.dumps(payload, ensure_ascii=False)
    ai = chat.invoke([SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=msg)])
    content = getattr(ai, "content", "") or ""

    parsed = _clean_and_parse_json(content)
    c = _clamp_0_5(parsed.get("correctness"))
    r = _clamp_0_5(parsed.get("relevance"))
    comp = _clamp_0_5(parsed.get("completeness"))
    f = _clamp_0_5(parsed.get("faithfulness"))
    conc = _clamp_0_5(parsed.get("conciseness"))
    return c, r, comp, f, conc, content
#---------------------------------------------------------------------
# -----------------------------
# SQLite persistence
# -----------------------------
# -----------------------------
# SQLite persistence
# -----------------------------
@st.cache_resource(show_spinner=False)
def get_engine(db_path: str):
    return create_engine(f"sqlite:///{db_path}")


def write_sqlite_tables(
    engine,
    raw_df: pd.DataFrame,
    #quant_df: pd.DataFrame,
    #cat_counts: pd.DataFrame,
    #judged_df: Optional[pd.DataFrame] = None,
):
    raw_df.to_sql("feedback_raw", engine, if_exists="replace", index=False)
    with engine.begin() as conn:
        try:
            conn.execute(text("CREATE INDEX IF NOT EXISTS idx_raw_model_agent ON feedback_raw(model, agent)"))
            conn.execute(text("CREATE INDEX IF NOT EXISTS idx_raw_vote ON feedback_raw(vote)"))
            #conn.execute(text("CREATE INDEX IF NOT EXISTS idx_j_cat ON llm_judgments(category)"))
        except Exception:
            pass

def get_sqlite_schema_text(engine) -> str:
    try:
        with engine.connect() as conn:
            tables = conn.exec_driver_sql("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;").fetchall()
            out_lines = []
            for (tname,) in tables:
                cols = conn.exec_driver_sql(f"PRAGMA table_info({tname});").fetchall()
                colnames = [c[1] for c in cols]
                out_lines.append(f"- {tname} (" + ", ".join(colnames) + ")")
            return "Available tables and columns:" + " ".join(out_lines)
    except Exception as e:
        return f"(Could not introspect schema: {e})"
    
def nl_to_sql(question: str, schema_text: str, model_name: str, temperature: float = 0.0) -> str:
    
    llm = ChatDatabricks(model=model_name, temperature=temperature)
    sys = (
        "You translate user questions into a single SQLite SELECT query. "
        "Use only the provided tables/columns. Prefer aggregations and filters over returning raw rows. "
        "Return ONLY the SQL, no prose."
    )
    user = (
        "Schema (SQLite):" + schema_text + "" +
        "Write ONE SELECT to answer:" + question + "" +
        "Rules: use valid SQLite; timestamps may be TEXT in ISO format; duration is in response_duration_s."
    )
    resp = llm.invoke([SystemMessage(content=sys), HumanMessage(content=user)])
    return extract_sql_from_text(resp.content)


def extract_sql_from_text(s: str) -> str:
    if not isinstance(s, str):
        return ""
    s_lower = s.lower()
    if "```sql" in s_lower:
        start = s_lower.find("```sql") + 6
        rest = s[start:]
        end = rest.find("```")
        if end != -1:
            return rest[:end].strip().strip(";")
    if "```" in s:
        start = s.find("```") + 3
        rest = s[start:]
        end = rest.find("```")
        if end != -1:
            return rest[:end].strip().strip(";")
    return s.strip().strip(";")
#---------------------------------
#query, sql_query, expected_output,agent, model
st.header("Feedback Analytics")

with st.sidebar:
    
    st.header("App Settings")
    #start_dt = st.date_input("Start date", value=date(2025,7,1))
    #end_dt = st.date_input("End date (inclusive)", value=date(2025,9,9))
    now = datetime.now()
    default_from = now - timedelta(days=30)

    # Use the native datetime input if available; otherwise fall back to date+time.
    #dt_from = st.date_input("From", value=default_from)
    #dt_to = st.date_input("To", value=now)
    from_date = st.date_input("From (date)", value=default_from.date())
    to_date = st.date_input("To (date)", value=now.date())

    from_time = default_from.time()
    to_time = value=now.time()

    dt_from = datetime.combine(from_date, from_time)
    dt_to = datetime.combine(to_date, to_time)

    FULLY_QUALIFIED_TABLE_NAME = fq_name(CATALOG.strip(), SCHEMA.strip(), TABLE.strip())
    ts_col = "query_request_time"
    max_rows = 1000
    
 

if st.button("Connect to Unity Catalog", use_container_width=True):

    with st.spinner("Reading table from Unity Catalog…"):
        try:
            #df = fetch_uc_table(FULL_TABLE_NAME, host, path, token)
            df = get_datafrom_uc(FULLY_QUALIFIED_TABLE_NAME, 
                                 ts_col, 
                                 dt_from, 
                                 dt_to, 
                                 max_rows, 
                                 host, path, 
                                 token)
            
            
        
            st.session_state["raw_df"] = df
            st.success(f"Loaded {len(df):,} rows from {FULL_TABLE_NAME}")
            st.success("LLM as a Judge analytics Done!")
        except Exception as e:
            st.exception(e)

     # Persist base analytics
    #eng = get_engine(db_path)
    #with st.spinner("Writing raw + analytic tables to SQLite…"):
    #    write_sqlite_tables(eng, df)
    #    st.success("Data and Analytic written to DB!")

raw_df: Optional[pd.DataFrame] = st.session_state.get("raw_df")
#judge_result_df = pd.DataFrame()
if raw_df is not None:
    st.subheader("Preview")
    st.dataframe(raw_df.head(50), use_container_width=True)

    



at1, at2, at3, at4, at5, at6 = st.tabs(["Thumbs Up/Down","Approval Rates", "Response Duration", "Response vs Expected Score", "Insight from Negative Feeback", "Chat with Feedback DB"])
with at1:
        st.caption("Thumbs Up/Down.")
        if raw_df is not None:
            counts = raw_df.groupby(["agent","model_type","thumbs"], dropna=False).size().reset_index(name="count")
            if not counts.empty:
                fig1 = px.bar(counts, x="agent", y="count", color="thumbs", barmode="group",
                                facet_row="model_type", title="Count of 👍 vs 👎 by model_type × agent")
                st.plotly_chart(fig1, use_container_width=True)



with at2:
        st.caption("Approval Rate")
        if raw_df is not None:
            daily_model = (
                    raw_df.groupby(["query_request_time","model_type"], dropna=False)
                    .agg(approvals=("approval","sum"), total=("approval","count"))
                    .reset_index()
                )
            if not daily_model.empty:
                st.dataframe(daily_model, use_container_width=True)
                daily_model["approval_rate"] = daily_model["approvals"] / daily_model["total"]
                fig3 = px.line(
                    daily_model, x="query_request_time", y="approval_rate", color="model_type",
                    markers=True, title="Approval rate over time by model_type"
                )
                fig3.update_xaxes(title_font=dict(  weight='bold'),
                    tickfont=dict( weight='bold'))
                fig3.update_yaxes(title_font=dict(  weight='bold'),
                        tickfont=dict(  weight='bold'))
                fig3.update_layout(legend=dict(font=dict( weight='bold')))
                st.plotly_chart(fig3, use_container_width=True)

            daily_agent = (
                    raw_df.groupby(["query_request_time","agent"], dropna=False)
                    .agg(approvals=("approval","sum"), total=("approval","count"))
                    .reset_index()
                )
            if not daily_agent.empty:
                st.dataframe(daily_agent, use_container_width=True)
                daily_agent["approval_rate"] = daily_agent["approvals"] / daily_agent["total"]
                fig4 = px.line(
                    daily_agent, x="query_request_time", y="approval_rate", color="agent",
                    markers=True, title="Approval rate over time by agent"
                )
                fig4.update_xaxes(title_font=dict( weight='bold'),
                    tickfont=dict(weight='bold'))
                fig4.update_yaxes(title_font=dict( weight='bold'),
                        tickfont=dict( weight='bold'))
                fig4.update_layout(legend=dict(font=dict( weight='bold')))
                st.plotly_chart(fig4, use_container_width=True)

with at3:
        st.caption("LLM Duration")

        if raw_df is not None:
           
            response_duration = raw_df.groupby(["agent","model_type"], dropna=False).agg(response_duration=("response_duration_s","mean")).reset_index()
            if not response_duration.empty:
                fig5 = px.bar(response_duration, x="agent", y="response_duration", color="model_type", barmode="group",
                                title="Average response duration by model_type × agent")
                st.plotly_chart(fig5, use_container_width=True)
            st.dataframe(response_duration, use_container_width=True)


with at4:
        st.caption("LLM Response vs Expected Scoring")
        # Summary metrics
        #if judge_result_df is not None:
        if raw_df is not None:
            # Summary metrics
            st.write("### Dataset Averages (0–5)")
            avg = (
                raw_df[METRICS]
                .astype(float)
                .mean()
                .to_frame("average")
                .T
            )
            st.dataframe(avg, use_container_width=True)

            # ---------- Visualizations per model ----------
            st.write("### Visualizations per Model")
            # Filter controls
            models_all = sorted(raw_df["model_type"].dropna().astype(str).unique().tolist())
            selected_models = st.multiselect("Filter models", models_all, default=models_all)

            df_viz = raw_df[raw_df["model_type"].astype(str).isin(selected_models)].copy()
            if df_viz.empty:
                st.info("No rows after filter.")
            else:
                # Long format for plotting
                df_long = df_viz.melt(
                    id_vars=["model_type"], value_vars=METRICS, var_name="metric", value_name="score"
                )
                df_long["score"] = pd.to_numeric(df_long["score"], errors="coerce")
                df_long = df_long.dropna(subset=["score"])

                # 1) Grouped bar — average score per model by metric
                st.markdown("**Average score per model × metric**")
                avg_long = df_long.groupby(["model_type", "metric"], as_index=False)["score"].mean()
                fig1 = px.bar(
                    avg_long,
                    x="model_type",
                    y="score",
                    color="metric",
                    barmode="group",
                    category_orders={"metric": METRICS},
                    range_y=[0, 5],
                    title="Average judge scores per model",
                )
                st.plotly_chart(fig1, use_container_width=True)

                # 2) Boxplot — distribution per model, faceted by metric
                st.markdown("**Score distributions (boxplot) by model, faceted by metric**")
                fig2 = px.box(
                    df_long,
                    x="model_type",
                    y="score",
                    color="model_type",
                    facet_col="metric",
                    category_orders={"metric": METRICS, "model_type": models_all},
                    range_y=[0, 5],
                    title="Distributions of scores by model and metric",
                )
                st.plotly_chart(fig2, use_container_width=True)

                # 3) Heatmap — average score (metric × model)
                st.markdown("**Heatmap of average scores (metric × model)**")
                pivot = df_long.pivot_table(index="metric", columns="model_type", values="score", aggfunc="mean")
                # Ensure metric order
                pivot = pivot.reindex(METRICS)
                fig3 = px.imshow(
                    pivot,
                    text_auto=True,
                    aspect="auto",
                    origin="upper",
                    color_continuous_scale="Blues",
                    range_color=[0, 5],
                    labels=dict(color="avg score"),
                    title="Average scores heatmap",
                )
                st.plotly_chart(fig3, use_container_width=True)

                # 4) Count of evaluated rows per model
                st.markdown("**Count of evaluated rows per model**")
                counts = (
                    df_viz.groupby("model_type", as_index=False)
                    .size()
                    .rename(columns={"size": "count"})
                )
                fig4 = px.bar(
                    counts,
                    x="model_type",
                    y="count",
                    text="count",
                    title="Evaluated rows per model",
                )
                fig4.update_traces(textposition="outside")
                st.plotly_chart(fig4, use_container_width=True)

            #st.write("### Scored Rows")
            #st.dataframe(judge_df, use_container_width=True)

with at5:
        st.caption("Aggregated insights from negative feedback.")
        
        
       
        if raw_df is not None:
            key_columns = ['user_id','session_id','user_query',
                           'assistant_sql_response',
                           'response_text',
                           'feedback_text',
                           'feedback_types_text',
                           'expected_sql_response',
                           'model_type',
                           'agent',
                           'severity',
                           'actionability']
            # KPIs
            total_feedback = len(raw_df)
            avg_severity = float(raw_df["severity"].mean()) if total_feedback else 0.0
            avg_actionability = float(raw_df["actionability"].mean()) if total_feedback else 0.0
            
            top_model = raw_df['model_type'].mode(dropna=True).iloc[0]
           

            k1, k2, k3 = st.columns(3)
            k1.metric("total_feedback", total_feedback)
            k2.metric("avg_severity", f"{avg_severity:.2f}")
            k3.metric("avg_actionability", f"{avg_actionability:.2f}")
            st.metric("top_model", top_model)

            st.write("### Results")
            st.dataframe(raw_df[key_columns], use_container_width=True)

            # Quantitative Metrics

            cat_counts, counts_model, counts_agent, counts_all = _category_counts(raw_df)
            #st.dataframe(exploded, use_container_width=True)
            #st.dataframe(counts_all, use_container_width=True)
            #st.dataframe(counts_model, use_container_width=True)
            #st.dataframe(counts_agent, use_container_width=True)
            st.markdown("**Summary Negative Feedback**")
            st.bar_chart(cat_counts.set_index("category"))
            #st.markdown("**Feedback by Model**")
            #st.bar_chart(counts_model.set_index("category"))
            #st.markdown("**Feedback by Agent**")
            #st.bar_chart(counts_agent.set_index("category"))

            count_a_m = counts_all.groupby(["agent","model_type","_ft"], dropna=False).size().reset_index(name="count")
            if not counts.empty:
                fig8 = px.bar(count_a_m, x="agent", y="count", color="_ft", barmode="group",
                                facet_row="model_type", title="Count of Negative Feedback Selection by model_type × agent")
                st.plotly_chart(fig8, use_container_width=True)

with at6:
        st.caption("Chat with Feedback DB")
        eng = get_engine(db_path)
        with eng.connect() as conn:
                try:
                    tables = conn.exec_driver_sql(
                    "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"
                    ).fetchall()
                    table_names = [t[0] for t in tables]
                    pick = st.selectbox("Select a table to view", table_names)
                    if pick:
                        db_df = pd.read_sql(f"SELECT * FROM {pick} LIMIT 200", conn)
                        st.dataframe(db_df, use_container_width=True)
                except Exception as e:
                    st.warning(f"Could not list tables: {e}")

        schema_text = get_sqlite_schema_text(eng)
        with st.expander("Schema", expanded=False):
            st.code(schema_text)
        
       
        if "chat_messages" not in st.session_state:
            st.session_state["chat_messages"] = []
        for m in st.session_state["chat_messages"]:
            st.chat_message(m["role"]).write(m["content"])
        q = st.chat_input("Ask a question about the data…")
        if q:
            st.chat_message("user").write(q)
            st.session_state["chat_messages"].append({"role": "user", "content": q})
            with st.spinner("Thinking in SQL…"):
                sql = nl_to_sql(q, 
                                schema_text, 
                                model_name=LLM_ENDPOINT_NAME, 
                                temperature=TEMPERATURE)
                ans = pd.read_sql_query(sql, eng)
                #st.chat_message("assistant").write("**SQL**:" + sql)
                st.dataframe(ans, use_container_width=True)
                try:
                    expl = explain_answer(q, ans, model_name=LLM_ENDPOINT_NAME, temperature=TEMPERATURE)
                except Exception as _e:
                    expl = ""
                if expl:
                    st.chat_message("assistant").write(expl)
                st.session_state["chat_messages"].append({"role": "assistant", "content": "SQL run:" + sql + ("" + expl if expl else "")})
            

    
            
                