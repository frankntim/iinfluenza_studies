# Databricks notebook source
%pip install databricks-vectorsearch
%pip install --upgrade langchain
%pip install langchain_community langchain_openai

#%restart_python

# COMMAND ----------

%pip install numpy==1.23.5 pandas==1.5.3

dbutils.library.restartPython()

# COMMAND ----------

from databricks.vector_search.client import VectorSearchClient
from langchain.schema import Document
from typing import List

# COMMAND ----------

def convert_vector_search_to_documents(results) -> List[Document]:
  column_names = []
  for column in results["manifest"]["columns"]:
      column_names.append(column)

  langchain_docs = []
  for item in results["result"]["data_array"]:
      metadata = {}
      score = item[-1]
      # print(score)
      i = 1
      for field in item[1:-1]:
          # print(field + "--")
          metadata[column_names[i]["name"]] = field
          i = i + 1
      doc = Document(page_content=item[0], metadata=metadata)  # , 9)
      langchain_docs.append(doc)
  return langchain_docs

# COMMAND ----------

vsc = VectorSearchClient()

vs_index = "amg427_20170528_ne_cb_clone_index"
catalog_name = "ai_dev"
schema_name = "aiwb_115_cbd_sandbox"
embedding_model_endpoint = "databricks-bge-large-en"
vector_search_endpoint_name = "cbd_pmed_ai_agent_test"

vs_index_fullname = f"{catalog_name}.{schema_name}.{vs_index}"

index = vsc.get_index(endpoint_name=vector_search_endpoint_name, index_name=vs_index_fullname)


# COMMAND ----------

index_description = index.describe()
source_table_fullname = index_description['delta_sync_index_spec']['source_table']
all_columns = spark.table(source_table_fullname).columns

# COMMAND ----------

index_description = index.describe()
source_table_fullname = index_description['delta_sync_index_spec']['source_table']

all_columns = spark.table(source_table_fullname).columns

# Get the columns present in the index
#index_columns = index_description['delta_sync_index_spec']['columns']

# Filter out columns that are not present in the index
#valid_columns = [col for col in all_columns if col in index_columns]

valid_columns = ['PRODUCT','STUDYID','SUBJID','ANALYTE','ASSAY','VISITCD']

results = index.similarity_search(
  query_text='Urine Blood',
  columns=valid_columns,
  num_results=2)
display(results)




# COMMAND ----------

langchain_docs = convert_vector_search_to_documents(results)
langchain_docs

# COMMAND ----------

# DBTITLE 1,Define Environment Variables
import os
catalog = "ai_dev"
workspaceUrl = spark.conf.get('spark.databricks.workspaceUrl')
workspaceUrl = f"https://{workspaceUrl}"
os.environ['DATABRICKS_HOST'] = workspaceUrl
#os.environ['DATABRICKS_TOKEN'] = dbutils.secrets.get("ai_dev", "databricks_token")
os.environ['DATABRICKS_TOKEN'] = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()

# COMMAND ----------

vector_search_endpoint = "cbd_pmed_ai_agent_test"

# COMMAND ----------

from databricks.vector_search.client import VectorSearchClient
from langchain_community.vectorstores import DatabricksVectorSearch
from langchain_community.embeddings import DatabricksEmbeddings


# COMMAND ----------

vsc = VectorSearchClient(workspace_url=os.environ["DATABRICKS_HOST"], personal_access_token=os.environ["DATABRICKS_TOKEN"])

# COMMAND ----------

vsc = VectorSearchClient(workspace_url=os.environ["DATABRICKS_HOST"], personal_access_token=os.environ["DATABRICKS_TOKEN"])
#vs_index = vsc.get_index(
#    endpoint_name=vector_search_endpoint,
#    index_name=f"{catalog}.text_to_sql.query_history_vs_index"
#)

vs_index = "amg427_20170528_ne_cb_clone_index"
catalog_name = "ai_dev"
schema_name = "aiwb_115_cbd_sandbox"
embedding_model_endpoint = "databricks-bge-large-en"
vector_search_endpoint_name = "cbd_pmed_ai_agent_test"

vs_index_fullname = f"{catalog_name}.{schema_name}.{vs_index}"

vs_index = vsc.get_index(endpoint_name=vector_search_endpoint_name, index_name=vs_index_fullname)
# Create the retriever
#vectorstore = DatabricksVectorSearch(
#    vs_index, text_column="generated_question", columns=["generated_question", "statement_text", #"manual_summarization", "table_list", "statement_id"]
#)

# COMMAND ----------

#vs_index
vectorstore = DatabricksVectorSearch(
    vs_index, text_column="ASSAY", columns=['PRODUCT','STUDYID','SUBJID','ANALYTE','ASSAY','VISITCD']
)

# COMMAND ----------

def get_retriever(persist_dir: str = None):
    #Get the vector search index
    vs_index = "amg427_20170528_ne_cb_clone_index"
    catalog_name = "ai_dev"
    schema_name = "aiwb_115_cbd_sandbox"
    embedding_model_endpoint = "databricks-bge-large-en"
    vector_search_endpoint_name = "cbd_pmed_ai_agent_test"

    vs_index_fullname = f"{catalog_name}.{schema_name}.{vs_index}"

    
    vsc = VectorSearchClient(workspace_url=os.environ["DATABRICKS_HOST"], personal_access_token=os.environ["DATABRICKS_TOKEN"])
    vs_index = vsc.get_index(endpoint_name=vector_search_endpoint_name, index_name=vs_index_fullname)

    # Create the retriever
    vectorstore = DatabricksVectorSearch(vs_index, text_column="ASSAY", columns=['PRODUCT','STUDYID','SUBJID','ANALYTE','ASSAY','VISITCD'])
    return vectorstore.as_retriever()

# COMMAND ----------

# test our retriever
retriever = get_retriever()

# COMMAND ----------

similar_documents = retriever.get_relevant_documents("Count unique subjects")

# COMMAND ----------

print(f"Relevant documents: {similar_documents[0]}")

# COMMAND ----------

import json, requests
import pandas as pd

#Define function for Endpoint Call
def call_endpoint(input_dict, endpoint_name, ):
  workspaceUrl = os.environ['DATABRICKS_HOST']
  token = os.environ['DATABRICKS_TOKEN']

  df = pd.DataFrame(input_dict)
  data = {'dataframe_split': df.to_dict(orient='split')}
  data_json = json.dumps(data, allow_nan=True)

  url = f"{workspaceUrl}/serving-endpoints/{endpoint_name}/invocations"
  headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}

  response = requests.request(method='POST', headers=headers, url=url, data=data_json)
  if response.status_code != 200:
      raise Exception(f'Request failed with status {response.status_code}, {response.text}')
  return response.json()


# COMMAND ----------

from langchain_community.vectorstores import DocArrayInMemorySearch
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableParallel, RunnablePassthrough
import json, requests
import pandas as pd

from langchain_community.chat_models import ChatDatabricks

# COMMAND ----------

dbrx_model = ChatDatabricks(endpoint="databricks-dbrx-instruct")

# COMMAND ----------

# Work on this one:
def mine_queries(queries):
    return {'sample_queries':[{'question':q.page_content, 'sql':q.metadata['ANALYTE']} for q in queries], 'tables':list(set([table for q in queries for table in q.metadata['table_list']]))}


# COMMAND ----------

def table_definitions(input):
    tables = list(set(input["tables"]))
    data = {'full_table': tables}
    resp = call_endpoint(data, "t2s_table_definition")

    input["table_response"] = resp['outputs']
    return input

# COMMAND ----------

def build_prompt(input):
    enriched = input["enriched_data"]
    question = input["prompt"]
    tables = enriched["table_response"]
    definitions = [t["table_definition"] for t in tables]
    samples = enriched["sample_queries"]

    data = {'question': [question], 'table_definitions': [definitions], 'sample_queries': [samples]}
    resp = call_endpoint(data, "t2s_build_prompt")

    input["full_prompt"] = resp['outputs'][0]['prompt']
    #print(input)
    return input

# COMMAND ----------

chat_prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "you are a Text-To-SQL generator. When prompted with a question, table structures and sample queries, only reply with SQL. No explanations. Avoid CTEs just to abstract the table name."),
        ("human", "{full_prompt}"),
    ]
)

# COMMAND ----------

output_parser = StrOutputParser()

# COMMAND ----------

setup_and_retrieval = RunnableParallel(
    {"enriched_data": retriever | mine_queries | table_definitions, "prompt": RunnablePassthrough()}
)
chain = setup_and_retrieval | build_prompt | chat_prompt | dbrx_model | output_parser

# COMMAND ----------

question = "urine blood"
answer = chain.invoke(question)
print(answer)