import os, json
import pandas as pd
import plotly.express as px
import streamlit as st
from datetime import date
from dotenv import load_dotenv

from langchain_openai import ChatOpenAI
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from langchain_core.messages import HumanMessage, SystemMessage

from db_uc import UCConfig, get_conn, create_tables, ensure_columns, fq
import quantitative_analytics_uc as qa_uc
import qualitative_analytics_uc as ql_uc
from kpi_analyzer import analyze_kpis
from seed_demo_data_uc import seed_period, SeedCfg

st.set_page_config(page_title="LLM Feedback Collector (Databricks UC)", page_icon="🧱", layout="wide")

load_dotenv()
LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")
BASE_URL_SERVING_ENDPOINT = os.environ.get("DATABRICKS_HOST_ENDPOINT")
DATABRICKS_API_KEY = os.environ.get("DATABRICKS_TOKEN")

DATABRICKS_HOST_BASE = os.environ.get("DATABRICKS_HOST_BASE")
DATABRICKS_HTTP_PATH = os.environ.get("DATABRICKS_WAREHOUSE")



os.environ['OPENAI_API_KEY'] = DATABRICKS_API_KEY

@st.cache_resource(show_spinner=False)
def _conn(cfg: UCConfig):
    c = get_conn(cfg)
    create_tables(c, cfg.catalog, cfg.schema)
    ensure_columns(c, cfg.catalog, cfg.schema)
    return c
#edl_prd.cdh_bite_prd_publish
with st.sidebar:
    st.header("Databricks Connection")
    server_hostname = st.text_input("Server Hostname", value=DATABRICKS_HOST_BASE)
    http_path = st.text_input("HTTP Path", value=DATABRICKS_HTTP_PATH)
    access_token = st.text_input("Personal Access Token", type="password", value=DATABRICKS_API_KEY)
    catalog = st.text_input("Catalog", value=os.environ.get("DATABRICKS_CATALOG","edl_dev"))
    schema = st.text_input("Schema", value=os.environ.get("DATABRICKS_SCHEMA","cbd_sandbox"))

    st.header("App Settings")
    model_name = st.text_input("Model", value=LLM_ENDPOINT_NAME)
    judge_model = st.text_input("Judge Model", value=LLM_ENDPOINT_NAME)
    analysis_model = st.text_input("KPI Analysis Model", value=judge_model)
    temperature = st.slider("Temperature", 0.0, 1.0, 0.0, 0.1)
    software_version = st.text_input("Software version", value="v1.0.0")
    user_id = st.text_input("User ID (optional)", value="")
    vectorization_version = st.text_input("Vectorization version", value="vec-1")

    with st.expander("🧪 Demo data (seed)"):
        st.caption("Populate synthetic data for a focused date window (July → Sept 9).")
        models_csv = st.text_input("Models (CSV)", value="gpt-4o-mini,gpt-4o,gpt-4.1-mini")
        versions_csv = st.text_input("Versions (CSV)", value="v1.0.0,v1.1.0,v1.2.0")
        vec_csv = st.text_input("Vectorization versions (CSV)", value="vec-1,vec-2")
        users_csv = st.text_input("User IDs (CSV)", value="user-001,user-002,user-003")
        start_dt = st.date_input("Start date", value=date(2025,7,1))
        end_dt = st.date_input("End date (inclusive)", value=date(2025,9,9))
        per_combo_month = st.number_input("Rows per (model×version×month)", min_value=2, max_value=200, value=10)
        seed_val = st.number_input("Random seed", min_value=0, max_value=10000, value=42)

        def _split_csv(s): return [x.strip() for x in (s or "").split(",") if x.strip()]

        if st.button("Generate demo data", use_container_width=True):
            try:
                cfg = UCConfig(server_hostname, http_path, access_token, catalog, schema)
                inserted = seed_period(SeedCfg(
                    uc=cfg,
                    models=_split_csv(models_csv),
                    versions=_split_csv(versions_csv),
                    vec_versions=_split_csv(vec_csv),
                    users=_split_csv(users_csv),
                    start_date=start_dt, end_date=end_dt,
                    per_combo_month=int(per_combo_month),
                    seed=int(seed_val),
                ))
                st.success(f"Inserted {inserted} interactions into {catalog}.{schema}")
                st.toast("Demo data generated. Head to Analytics → Refresh!", icon="✅")
            except Exception as e:
                st.error(f"Seeding failed: {e}")

cfg = UCConfig(server_hostname, http_path, access_token, catalog, schema)
conn = _conn(cfg)

st.title("🧱 LLM Feedback Collector — Databricks UC")

# Session state
st.session_state.setdefault("history", [])
st.session_state.setdefault("assistant_last", "")
st.session_state.setdefault("last_usage", {"input_tokens": None, "output_tokens": None, "total_tokens": None})
st.session_state.setdefault("show_positive_modal", False)
st.session_state.setdefault("show_negative_modal", False)

HAS_DIALOG = hasattr(st, "dialog") and callable(getattr(st, "dialog", None))

tab_collect, tab_analytics = st.tabs(["Data Collection", "Analytics"])

# -------------- Data Collection --------------
with tab_collect:
    st.subheader("Chat")
    for role, content in st.session_state.history:
        with st.chat_message(role):
            st.markdown(content)

    user_input = st.chat_input("Ask something…")
    if user_input:
        with st.chat_message("user"): st.markdown(user_input)
        st.session_state.history.append(("user", user_input))
        llm = ChatDatabricks(model=model_name, temperature=temperature)
        ai = llm.invoke([SystemMessage(content="You are a helpful assistant."), HumanMessage(content=user_input)])
        ai_text = getattr(ai, "content", "(no content)")
        usage = qa_uc.extract_token_usage(ai)
        with st.chat_message("assistant"): st.markdown(ai_text)
        st.session_state.history.append(("assistant", ai_text))
        st.session_state.assistant_last = ai_text
        st.session_state.last_usage = usage

    if st.session_state.assistant_last:
        st.divider(); st.subheader("Feedback")
        c1, c2 = st.columns(2)
        with c1:
            if st.button("👍 Thumbs up", use_container_width=True):
                st.session_state.show_positive_modal = True; st.session_state.show_negative_modal = False
        with c2:
            if st.button("👎 Thumbs down", use_container_width=True):
                st.session_state.show_negative_modal = True; st.session_state.show_positive_modal = False

    def _save_positive(expected_pos: str):
        try:
            q = next((txt for role, txt in reversed(st.session_state.history) if role == "user"), "")
            quant_id = qa_uc.insert_quantitative(
                conn, catalog=catalog, schema=schema,
                thumbs="up", user_query=q, llm_response=st.session_state.assistant_last,
                expected_response=expected_pos or "", model=model_name, software_version=software_version,
                usage=st.session_state.last_usage, user_id=user_id, vectorization_version=vectorization_version
            )
            qa_uc.run_judge(conn, catalog=catalog, schema=schema, quant_id=quant_id, judge_model=judge_model,
                            user_query=q, llm_response=st.session_state.assistant_last, expected_response=expected_pos or "")
            st.success("Saved! 🎉")
        except Exception as e:
            st.error(f"Failed to save feedback: {e}")

    def _save_negative(expected_neg: str, reasons, custom):
        try:
            q = next((txt for role, txt in reversed(st.session_state.history) if role == "user"), "")
            bundle = {
                "reasons": reasons or [], "custom_feedback": custom or "", "expected": expected_neg or "",
                "user_query": q, "assistant_response": st.session_state.assistant_last,
                "model": model_name, "version": software_version,
            }
            try:
                res = analyze_kpis(bundle, analysis_model)
                severity_score = float(res.get("severity", 0.5)); actionability_score = float(res.get("actionability", 0.5))
            except Exception:
                severity_score, actionability_score = 0.5, 0.5

            quant_id = qa_uc.insert_quantitative(
                conn, catalog=catalog, schema=schema,
                thumbs="down", user_query=q, llm_response=st.session_state.assistant_last,
                expected_response=expected_neg or "", model=model_name, software_version=software_version,
                usage=st.session_state.last_usage, user_id=user_id, vectorization_version=vectorization_version
            )
            try:
                qa_uc.run_judge(conn, catalog=catalog, schema=schema, quant_id=quant_id, judge_model=judge_model,
                                user_query=q, llm_response=st.session_state.assistant_last, expected_response=expected_neg or "")
            except Exception as je:
                st.info(f"Judge step skipped: {je}")

            ql_uc.insert_qualitative(
                conn, catalog=catalog, schema=schema, quant_id=quant_id, custom_feedback=custom or "",
                reasons=reasons, severity=severity_score, actionability=actionability_score,
                model=model_name, software_version=software_version, user_id=user_id, vectorization_version=vectorization_version
            )
            try:
                ql_uc.update_qualitative_analytics(conn, catalog=catalog, schema=schema, judge_model=judge_model)
            except Exception as qe:
                st.info(f"Qual analytics update skipped: {qe}")
            st.success("Saved! Thank you for the detailed feedback.")
        except Exception as e:
            st.error(f"Failed to save negative feedback: {e}")

    if HAS_DIALOG:
        @st.dialog("Thanks for the positive feedback!")
        def _positive_dialog():
            st.write("Optionally provide an *expected response* for reference.")
            expected_pos = st.text_area("Expected response (optional)", height=150, key="expected_pos")
            colp1, colp2 = st.columns([1,1])
            with colp1:
                if st.button("Submit ✅", key="submit_positive"):
                    _save_positive(expected_pos)
                    st.session_state.show_positive_modal = False; st.rerun()
            with colp2:
                if st.button("Cancel", key="cancel_positive"):
                    st.session_state.show_positive_modal = False; st.rerun()

        @st.dialog("Sorry it missed the mark — help us improve")
        def _negative_dialog():
            st.write("Please share what you expected and what went wrong.")
            expected_neg = st.text_area("Expected response (optional)", height=150, key="expected_neg")
            reasons = st.multiselect("What issues did you notice? (choose one or more)", ql_uc.NEGATIVE_OPTIONS)
            custom = st.text_area("Custom feedback (optional)", placeholder="Tell us more…", height=120)
            coln1, coln2 = st.columns([1,1])
            with coln1:
                if st.button("Submit 🚫", key="submit_negative"):
                    _save_negative(expected_neg, reasons, custom)
                    st.session_state.show_negative_modal = False; st.rerun()
            with coln2:
                if st.button("Cancel", key="cancel_negative"):
                    st.session_state.show_negative_modal = False; st.rerun()
    else:
        def _positive_dialog():
            with st.expander("Thanks for the positive feedback!", expanded=True):
                st.warning("Your Streamlit build has no dialogs; showing inline fallback.")
                expected_pos = st.text_area("Expected response (optional)", height=150, key="expected_pos")
                colp1, colp2 = st.columns([1,1])
                with colp1:
                    if st.button("Submit ✅", key="submit_positive"):
                        _save_positive(expected_pos)
                        st.session_state.show_positive_modal = False; st.rerun()
                with colp2:
                    if st.button("Cancel", key="cancel_positive"):
                        st.session_state.show_positive_modal = False; st.rerun()
        def _negative_dialog():
            with st.expander("Sorry it missed the mark — help us improve", expanded=True):
                st.warning("Your Streamlit build has no dialogs; showing inline fallback.")
                expected_neg = st.text_area("Expected response (optional)", height=150, key="expected_neg")
                reasons = st.multiselect("What issues did you notice? (choose one or more)", ql_uc.NEGATIVE_OPTIONS)
                custom = st.text_area("Custom feedback (optional)", placeholder="Tell us more…", height=120)
                coln1, coln2 = st.columns([1,1])
                with coln1:
                    if st.button("Submit 🚫", key="submit_negative"):
                        _save_negative(expected_neg, reasons, custom)
                        st.session_state.show_negative_modal = False; st.rerun()
                with coln2:
                    if st.button("Cancel", key="cancel_negative"):
                        st.session_state.show_negative_modal = False; st.rerun()

    if st.session_state.get("show_positive_modal"): _positive_dialog()
    elif st.session_state.get("show_negative_modal"): _negative_dialog()

# -------------- Analytics --------------
with tab_analytics:
    st.subheader("Analytics")
    if st.button("🔄 Refresh data"): st.rerun()

    at1, at2 = st.tabs(["Quantitative", "Qualitative (negative)"])

    with at1:
        st.caption("LLM-as-judge (expanded metrics) and quantitative visuals.")
        Q = fq("quantitative_data", catalog, schema); QA = fq("quantitative_analytics", catalog, schema)
        qdf = pd.read_sql_query(f"""                SELECT q.id as interaction_id, q.timestamp, q.thumbs, q.user_query, q.llm_response,
                   q.expected_response, q.model, q.software_version, q.input_tokens, q.output_tokens, q.total_tokens,
                   q.user_id, q.vectorization_version,
                   qa.judge_score, qa.judge_label, qa.judge_rationale, qa.judge_model,
                   qa.correctness, qa.relevance, qa.faithfulness, qa.completeness, qa.conciseness
            FROM {Q} q
            LEFT JOIN (
                SELECT quant_id, max(id) AS max_id FROM {QA} GROUP BY quant_id
            ) last ON last.quant_id = q.id
            LEFT JOIN {QA} qa ON qa.id = last.max_id
            ORDER BY q.id DESC
        """, conn)
        if qdf.empty:
            st.info("No interactions yet. Submit feedback from the Data Collection tab or use the seeder.")
        else:
            st.dataframe(qdf, use_container_width=True, height=360)
            qdf["date"] = pd.to_datetime(qdf["timestamp"], errors="coerce").dt.date
            qdf["approval"] = (qdf["thumbs"] == "up").astype(int)
            qdf["total_tokens"] = qdf["total_tokens"].fillna(0)

            st.markdown("#### Visualizations")

            counts = qdf.groupby(["model","software_version","thumbs"], dropna=False).size().reset_index(name="count")
            if not counts.empty:
                fig1 = px.bar(counts, x="software_version", y="count", color="thumbs", barmode="group",
                              facet_row="model", title="Count of 👍 vs 👎 by model × version")
                st.plotly_chart(fig1, use_container_width=True)

            avg_scores = qdf.groupby(["model","software_version"], dropna=False)["judge_score"].mean().reset_index()
            if not avg_scores.empty:
                fig2 = px.bar(avg_scores, x="software_version", y="judge_score", color="model", barmode="group",
                              title="Average overall judge score by model × version")
                st.plotly_chart(fig2, use_container_width=True)

            daily_model = qdf.groupby(["date","model"], dropna=False).agg(approvals=("approval","sum"), total=("approval","count")).reset_index()
            if not daily_model.empty:
                daily_model["approval_rate"] = daily_model["approvals"] / daily_model["total"]
                fig3 = px.line(daily_model, x="date", y="approval_rate", color="model", markers=True, title="Approval rate over time by model")
                st.plotly_chart(fig3, use_container_width=True)

            daily_ver = qdf.groupby(["date","software_version"], dropna=False).agg(approvals=("approval","sum"), total=("approval","count")).reset_index()
            if not daily_ver.empty:
                daily_ver["approval_rate"] = daily_ver["approvals"] / daily_ver["total"]
                fig4 = px.line(daily_ver, x="date", y="approval_rate", color="software_version", markers=True, title="Approval rate over time by version")
                st.plotly_chart(fig4, use_container_width=True)

            tok = qdf.groupby(["model","software_version"], dropna=False)["total_tokens"].sum().reset_index()
            if not tok.empty:
                fig5 = px.bar(tok, x="software_version", y="total_tokens", color="model", barmode="group",
                              title="Total tokens by model × version")
                st.plotly_chart(fig5, use_container_width=True)

    with at2:
        st.caption("Aggregated insights from negative feedback.")
        QL = fq("qualitative_data", catalog, schema); QA = fq("qualitative_analytics", catalog, schema)
        try:
            qd = pd.read_sql_query(f"""                    SELECT model, software_version, severity, actionability,
                       flags_inaccurate, flags_incomplete, flags_unclear, flags_irrelevant, flags_other
                FROM {QL}
            """, conn)
        except Exception:
            qd = pd.DataFrame(columns=["model","software_version","severity","actionability","flags_inaccurate","flags_incomplete","flags_unclear","flags_irrelevant","flags_other"])

        total_feedback = int(len(qd))
        avg_sev = float(qd["severity"].mean()) if not qd.empty else 0.0
        avg_act = float(qd["actionability"].mean()) if not qd.empty else 0.0
        top_model = (qd["model"].value_counts().idxmax() if not qd.empty and qd["model"].notna().any() else "—")
        top_version = (qd["software_version"].value_counts().idxmax() if not qd.empty and qd["software_version"].notna().any() else "—")

        k1,k2,k3,k4,k5 = st.columns(5)
        k1.metric("total_feedback", total_feedback)
        k2.metric("avg_severity", f"{avg_sev:.2f}")
        k3.metric("avg_actionability", f"{avg_act:.2f}")
        k4.metric("top_response_model", top_model)
        k5.metric("top_software_version", top_version)

        ql_counts = pd.read_sql_query(f"""                SELECT COUNT(*) as n_negative,
                   COALESCE(SUM(flags_inaccurate),0) as inaccurate,
                   COALESCE(SUM(flags_incomplete),0) as incomplete,
                   COALESCE(SUM(flags_unclear),0) as unclear,
                   COALESCE(SUM(flags_irrelevant),0) as irrelevant,
                   COALESCE(SUM(flags_other),0) as other
            FROM {QL}
        """, conn)
        st.metric("Total negatives", int(ql_counts.loc[0,"n_negative"] if not ql_counts.empty else 0))
        if not ql_counts.empty:
            bar_df = ql_counts.iloc[0][["inaccurate","incomplete","unclear","irrelevant","other"]].to_frame(name="count")
            st.bar_chart(bar_df)

        qa_df = pd.read_sql_query(f"""                SELECT timestamp, n_negative, counts_inaccurate, counts_incomplete, counts_unclear,
                   counts_irrelevant, counts_other, top_themes, judge_model
            FROM {QA}
            ORDER BY id DESC LIMIT 5
        """, conn)
        if not qa_df.empty:
            st.write("**Recent theme snapshots**")
            for _, row in qa_df.iterrows():
                st.markdown(f"- _{row['timestamp']}_ — **n={row['n_negative']}** | model: `{row['judge_model']}`")
                st.markdown(row["top_themes"] or "(no themes)")
        else:
            st.info("No qualitative analytics yet. Submit at least one negative feedback.")
