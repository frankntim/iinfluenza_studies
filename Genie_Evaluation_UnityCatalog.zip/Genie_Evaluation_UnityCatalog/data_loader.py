import io
from datetime import datetime, timedelta
from typing import List, Tuple, Optional

import pandas as pd
import streamlit as st
from databricks import sql as dbsql
from dotenv import load_dotenv
import os


# ---------------- UI CONFIG ----------------
st.set_page_config(page_title="Databricks UC Timestamp Loader", page_icon="🧱", layout="wide")
st.title("🧱 Databricks UC — Load Table by Timestamp Range")

load_dotenv()
LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")
BASE_URL_SERVING_ENDPOINT = os.environ.get("DATABRICKS_HOST_ENDPOINT")
DATABRICKS_API_KEY = os.environ.get("DATABRICKS_TOKEN")

DATABRICKS_HOST_BASE = os.environ.get("DATABRICKS_HOST_BASE")
DATABRICKS_HTTP_PATH = os.environ.get("DATABRICKS_WAREHOUSE")
FULL_TABLE_NAME = "edl_dev.cbd_sandbox.amg_pmed_convai_feedback"

# Create a remote Spark session
os.environ.pop('DATABRICKS_CLIENT_ID', None)
os.environ.pop('DATABRICKS_CLIENT_SECRET', None)
os.environ['OPENAI_API_KEY'] = DATABRICKS_API_KEY

TEMPERATURE = 0
host = DATABRICKS_HOST_BASE 
path = DATABRICKS_HTTP_PATH 
token = DATABRICKS_API_KEY
# ---------------- SIDEBAR ----------------
with st.sidebar:
    st.header("Databricks Connection")
    server_hostname = st.text_input(
        "Server Hostname",
        value=DATABRICKS_HOST_BASE,
    )
    http_path = st.text_input(
        "HTTP Path",
        value=DATABRICKS_HTTP_PATH,
    )
    access_token = st.text_input(
        "Personal Access Token",
        type="password",
        value=DATABRICKS_API_KEY,
    )

    st.header("Unity Catalog Target")
    catalog = st.text_input("Catalog", value="edl_dev")
    schema = st.text_input("Schema", value="cbd_sandbox")
    table = st.text_input("Table", value="amg_pmed_convai_feedback")

    # Fixed timestamp column per your requirement
    ts_col = "query_request_time"
    st.text_input("Timestamp column (fixed)", value=ts_col, disabled=True)

    #st.header("Filters (optional)")
    #session_id_raw = st.text_input("session_id (single or CSV)", value="")
    #user_id_raw = st.text_input("user_id (single or CSV)", value="")

    st.header("Timestamp Range (inclusive)")
    now = datetime.now()
    default_from = now - timedelta(days=7)

    # Use the native datetime input if available; otherwise fall back to date+time.
    #dt_from = st.date_input("From", value=default_from)
    #dt_to = st.date_input("To", value=now)
    from_date = st.date_input("From (date)", value=default_from.date())
    to_date = st.date_input("To (date)", value=now.date())

    from_time = default_from.time()
    to_time = value=now.time()

    dt_from = datetime.combine(from_date, from_time)
    dt_to = datetime.combine(to_date, to_time)


    max_rows = st.number_input("Max rows to fetch", min_value=1, max_value=1_000_000, value=50_000, step=1_000)

    st.caption(
        "Tip: save creds in `.streamlit/secrets.toml`: "
        "DATABRICKS_HOST, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN, "
        "DATABRICKS_CATALOG, DATABRICKS_SCHEMA, DATABRICKS_TABLE"
    )


# ---------------- HELPERS ----------------
def fq_name(catalog: str, schema: str, table: str) -> str:
    """Fully-qualified table name with backticks."""
    return f"`{catalog}`.`{schema}`.`{table}`"


def _fetch_df(cur) -> pd.DataFrame:
    """Fetch all rows from a DB-API cursor into a pandas DataFrame."""
    rows = cur.fetchall()
    cols = [d[0] for d in cur.description] if cur.description else []
    return pd.DataFrame.from_records(rows, columns=cols)


def _parse_csv_filter(raw: str) -> Optional[List[str]]:
    """Turn a CSV string into a list of trimmed, non-empty values; return None if blank."""
    if not raw or not raw.strip():
        return None
    items = [x.strip() for x in raw.split(",") if x.strip()]
    return items or None


def _build_query_and_params(
    fqn: str,
    ts_col: str,
    start_dt: datetime,
    end_dt: datetime,
    limit: int,
) -> Tuple[str, List]:
    """
    Build parameterized SQL:
      SELECT * FROM fqn
      WHERE ts_col >= ? AND ts_col <= ?
      ORDER BY ts_col
      LIMIT <int>
    """
    start_s = start_dt.strftime("%Y-%m-%d %H:%M:%S")
    end_s = end_dt.strftime("%Y-%m-%d %H:%M:%S")

    where = [f"{ts_col} >= ?", f"{ts_col} <= ?"]
    params: List = [start_s, end_s]

    where_sql = " AND ".join(where)

    sql = (
        f"SELECT * FROM {fqn} "
        f"WHERE {where_sql} "
        f"ORDER BY {ts_col} "
        f"LIMIT {int(limit)}"
    )
    return sql, params


def _validate_inputs(start_dt: datetime, end_dt: datetime) -> bool:
    if end_dt < start_dt:
        st.error("Invalid range: 'To' timestamp is before 'From' timestamp.")
        return False
    return True


# ---------------- MAIN BUTTON ----------------
load = st.button("Load data", type="primary", use_container_width=True)

if load:
    if not _validate_inputs(dt_from, dt_to):
        st.stop()

    if not server_hostname or not http_path or not access_token:
        st.error("Please provide Databricks connection details (hostname, HTTP path, and access token).")
        st.stop()

    fqn = fq_name(catalog.strip(), schema.strip(), table.strip())

    #session_ids = _parse_csv_filter(session_id_raw)
    #user_ids = _parse_csv_filter(user_id_raw)

    try:
        query, params = _build_query_and_params(
            fqn=fqn,
            ts_col=ts_col,
            start_dt=dt_from,
            end_dt=dt_to,
            limit=int(max_rows),
            #session_ids=session_ids,
            #user_ids=user_ids,
        )

        with st.spinner("Querying Databricks…"):
            with dbsql.connect(
                server_hostname=server_hostname.strip(),
                http_path=http_path.strip(),
                access_token=access_token.strip(),
            ) as conn:
                with conn.cursor() as cur:
                    cur.execute(query, params)
                    df = _fetch_df(cur)

        with st.expander("Executed SQL (read-only)", expanded=False):
            st.code(f"-- Parameters: {params}\n{query}", language="sql")

        if df.empty:
            st.info("No rows matched the selected filters.")
        else:
            st.success(f"Loaded {len(df):,} row(s).")
            st.dataframe(df, use_container_width=True, height=420)

            # Download button
            csv = df.to_csv(index=False).encode("utf-8")
            fname = f"{table}_{dt_from.strftime('%Y%m%dT%H%M%S')}_to_{dt_to.strftime('%Y%m%dT%H%M%S')}.csv"
            st.download_button(
                "Download CSV",
                data=csv,
                file_name=fname,
                mime="text/csv",
                use_container_width=True,
            )

    except Exception as e:
        st.error(f"Query failed: {e}")
