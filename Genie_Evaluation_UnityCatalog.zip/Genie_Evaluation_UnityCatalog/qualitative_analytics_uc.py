
from __future__ import annotations
import json
from typing import List
from databricks import sql
from langchain_openai import ChatOpenAI
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from langchain_core.messages import HumanMessage, SystemMessage
from db_uc import fq

NEGATIVE_OPTIONS = [
    "Information was inaccurate",
    "Response was incomplete",
    "Response was unclear",
    "Response was not relevant",
    "Other",
]

def insert_qualitative(conn, *, catalog: str, schema: str,
                       quant_id: int, custom_feedback: str, reasons: List[str],
                       severity: float, actionability: float,
                       model: str, software_version: str,
                       user_id: str, vectorization_version: str):
    reason_set = set(reasons or [])
    tbl = fq("qualitative_data", catalog, schema)
    with conn.cursor() as cur:
        cur.execute(f"""                INSERT INTO {tbl} (
                quant_id, timestamp, custom_feedback,
                flags_inaccurate, flags_incomplete, flags_unclear, flags_irrelevant, flags_other,
                severity, actionability, model, software_version, user_id, vectorization_version
            ) VALUES (?, current_timestamp(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            quant_id, custom_feedback or "",
            1 if "Information was inaccurate" in reason_set else 0,
            1 if "Response was incomplete" in reason_set else 0,
            1 if "Response was unclear" in reason_set else 0,
            1 if "Response was not relevant" in reason_set else 0,
            1 if "Other" in reason_set else 0,
            float(severity), float(actionability),
            model, software_version, user_id or "", vectorization_version or ""
        ])

def update_qualitative_analytics(conn, *, catalog: str, schema: str, judge_model: str):
    qtbl = fq("qualitative_data", catalog, schema)
    atbl = fq("qualitative_analytics", catalog, schema)
    # Aggregate counts
    with conn.cursor() as cur:
        cur.execute(f"""                SELECT COUNT(*) as n,
                   COALESCE(SUM(flags_inaccurate),0) as inaccurate,
                   COALESCE(SUM(flags_incomplete),0) as incomplete,
                   COALESCE(SUM(flags_unclear),0) as unclear,
                   COALESCE(SUM(flags_irrelevant),0) as irrelevant,
                   COALESCE(SUM(flags_other),0) as other
            FROM {qtbl}
        """ )
        row = cur.fetchall()[0]
        n, inaccurate, incomplete, unclear, irrelevant, other = row

        cur.execute(f"""                SELECT custom_feedback, flags_inaccurate, flags_incomplete, flags_unclear, flags_irrelevant, flags_other, timestamp
            FROM {qtbl}
            ORDER BY id DESC LIMIT 50
        """ )
        recents = cur.fetchall()

    bullets = []
    for r in recents:
        # r indexing by position
        note = (r[0] or "")[:500]
        tags = []
        if r[1]: tags.append("inaccurate")
        if r[2]: tags.append("incomplete")
        if r[3]: tags.append("unclear")
        if r[4]: tags.append("irrelevant")
        if r[5]: tags.append("other")
        bullets.append({"timestamp": str(r[6]), "tags": tags, "note": note})

    summary_prompt = (
        "You are an analyst. Given a JSON list of recent negative feedback items from an LLM app, "
        "find the top 3 recurring issues and propose 2 actionable suggestions. Return concise markdown bullets."
    )
    try:
        judge = ChatDatabricks(model=judge_model, temperature=0)
        resp = judge.invoke([SystemMessage(content=summary_prompt), HumanMessage(content=json.dumps(bullets))])
        summary_text = getattr(resp, "content", "")
    except Exception:
        summary_text = "(no LLM summary available)"

    with conn.cursor() as cur:
        cur.execute(f"""                INSERT INTO {atbl} (
                timestamp, n_negative, counts_inaccurate, counts_incomplete, counts_unclear,
                counts_irrelevant, counts_other, top_themes, judge_model
            ) VALUES (current_timestamp(), ?, ?, ?, ?, ?, ?, ?, ?)
        """, [int(n or 0), int(inaccurate or 0), int(incomplete or 0), int(unclear or 0),
               int(irrelevant or 0), int(other or 0), summary_text, judge_model])
