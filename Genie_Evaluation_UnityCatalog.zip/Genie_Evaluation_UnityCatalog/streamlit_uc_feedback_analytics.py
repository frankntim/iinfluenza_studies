"""
Streamlit app: Unity Catalog feedback analytics + LLM-as-a-judge → SQLite

Features
- Reads a Unity Catalog table (Databricks SQL) with columns: vote, feedback_type, feedback_text, agent, model
- Quant analytics: up/down counts per model×agent; counts of inaccurate/irrelevant/incomplete/unclear/other
- Qual analytics: uses ChatOpenAI (LangChain) to judge feedback_text; stores judgments in SQLite
- Persists raw + analytics tables to SQLite for downstream BI

Run
  pip install streamlit pandas numpy sqlalchemy databricks-sql-connector langchain-openai pydantic
  export OPENAI_API_KEY=...   # required for LLM judging
  export DATABRICKS_HOST=...  # your workspace hostname, e.g. adb-12345.99.azuredatabricks.net
  export DATABRICKS_HTTP_PATH=/sql/1.0/warehouses/XXXX
  export DATABRICKS_TOKEN=... # a PAT with SQL access

  streamlit run streamlit_uc_feedback_analytics.py

Notes
- feedback_type can be an ARRAY<STRING> in UC or a string like "['inaccurate','irrelevant']". Both are handled.
- SQLite DB defaults to ./feedback_analytics.db; change in sidebar if desired.
"""
from __future__ import annotations

import os
import ast
import re
import json
import time
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import streamlit as st
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

from langchain_openai import ChatOpenAI
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)

# Optional import (only needed if connecting to Databricks SQL)
try:
    from databricks import sql as dbsql
except Exception:  # pragma: no cover
    dbsql = None

# LLM (LangChain)
try:
    from langchain_openai import ChatOpenAI
    from langchain.schema import SystemMessage, HumanMessage
except Exception as e:  # pragma: no cover
    ChatOpenAI = None

load_dotenv()
LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")
BASE_URL_SERVING_ENDPOINT = os.environ.get("DATABRICKS_HOST_ENDPOINT")
DATABRICKS_API_KEY = os.environ.get("DATABRICKS_TOKEN")

DATABRICKS_HOST_BASE = os.environ.get("DATABRICKS_HOST_BASE")
DATABRICKS_HTTP_PATH = os.environ.get("DATABRICKS_WAREHOUSE")

# Create a remote Spark session
os.environ.pop('DATABRICKS_CLIENT_ID', None)
os.environ.pop('DATABRICKS_CLIENT_SECRET', None)



os.environ['OPENAI_API_KEY'] = DATABRICKS_API_KEY
# -----------------------------
# Helpers
# -----------------------------
CATEGORY_CANON = ["inaccurate", "irrelevant", "incomplete", "unclear", "other"]


def _to_list(v: Any) -> List[str]:
    """Normalize feedback_type to a list of lowercased strings.
    Accepts list/tuple, JSON string, Python list repr string, CSV string, or None.
    """
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return []
    if isinstance(v, (list, tuple, set)):
        raw = list(v)
    elif isinstance(v, str):
        s = v.strip()
        if s.startswith("[") and s.endswith("]"):
            try:
                raw = ast.literal_eval(s)
                if not isinstance(raw, list):
                    raw = [str(raw)]
            except Exception:
                # Try JSON
                try:
                    raw = json.loads(s)
                    if not isinstance(raw, list):
                        raw = [str(raw)]
                except Exception:
                    # Fallback: comma-separated
                    raw = [p.strip() for p in s.split(",") if p.strip()]
        else:
            raw = [p.strip() for p in s.split(",") if p.strip()]
    else:
        raw = [str(v)]
    # Canonicalize + map unknowns to 'other'
    out: List[str] = []
    for x in raw:
        xlow = str(x).strip().lower()
        if xlow in CATEGORY_CANON:
            out.append(xlow)
        else:
            # attempt light normalization
            if "inaccur" in xlow:
                out.append("inaccurate")
            elif "irrel" in xlow:
                out.append("irrelevant")
            elif "incompl" in xlow:
                out.append("incomplete")
            elif "unclear" in xlow or "confus" in xlow or "ambig" in xlow:
                out.append("unclear")
            else:
                out.append("other")
    return out


def _pivot_updown(df: pd.DataFrame) -> pd.DataFrame:
    # ensure vote normalized to {'up','down'}
    vmap = {
        "up": "up",
        "down": "down",
        "thumbs_up": "up",
        "thumbs_down": "down",
        "1": "up",
        "0": "down",
        "true": "up",
        "false": "down",
        "dummy": "up"
    }
    vote_norm = (
        df["vote"].astype(str).str.strip().str.lower().map(lambda x: vmap.get(x, x))
    )
    tmp = df.assign(vote_norm=vote_norm)
    # Only keep up/down values, drop others
    tmp = tmp[tmp["vote_norm"].isin(["up", "down"])].copy()
    pt = (
        pd.pivot_table(
            tmp,
            index=["model", "agent"],
            columns="vote_norm",
            values="feedback_text",
            aggfunc="count",
            fill_value=0,
        )
        .reset_index()
        .rename_axis(None, axis=1)
    )
    if "up" not in pt.columns:
        pt["up"] = 0
    if "down" not in pt.columns:
        pt["down"] = 0
    pt["total"] = pt["up"] + pt["down"]
    pt["up_rate"] = pt["up"] / pt["total"].replace({0: np.nan})
    return pt.sort_values(["up_rate", "total"], ascending=[False, False])


def _category_counts(df: pd.DataFrame) -> pd.DataFrame:
    exploded = df.assign(_ft=df["feedback_types"].apply(_to_list)).explode("_ft")
    exploded = exploded[~exploded["_ft"].isna()]
    counts = (
        exploded.groupby("_ft").size().reindex(CATEGORY_CANON, fill_value=0).reset_index()
    )
    counts.columns = ["category", "count"]
    return counts


def _connect_uc() -> Optional[Any]:
    if dbsql is None:
        return None
    host = DATABRICKS_HOST_BASE #os.getenv("DATABRICKS_HOST")
    path = DATABRICKS_HTTP_PATH #os.getenv("DATABRICKS_HTTP_PATH")
    token = DATABRICKS_API_KEY #os.getenv("DATABRICKS_TOKEN")
    if not (host and path and token):
        return None
    try:
        return dbsql.connect(server_hostname=host, http_path=path, access_token=token)
    except Exception:  # pragma: no cover
        return None


def fetch_uc_table(fully_qualified_table: str, limit: Optional[int] = None) -> pd.DataFrame:
    """Read Unity Catalog table via Databricks SQL connector.
    Expected columns: vote, feedback_type, feedback_text, agent, model
    """
    conn = _connect_uc()
    if conn is None:
        raise RuntimeError(
            "Could not connect to Databricks SQL. Ensure DATABRICKS_HOST, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN are set and 'databricks-sql-connector' installed."
        )
    q = f"SELECT vote, feedback_types, feedback_text, agent, model FROM {fully_qualified_table}"
    if limit:
        q += f" LIMIT {int(limit)}"
    with conn:
        cur = conn.cursor()
        cur.execute(q)
        rows = cur.fetchall()
        cols = [c[0] for c in cur.description]
    df = pd.DataFrame(rows, columns=cols)
    return df


# -----------------------------
# LLM judging
# -----------------------------
JUDGE_SYSTEM_PROMPT = (
"You are evaluating user-written feedback about AI assistant/model outputs. "
"Classify and rate each feedback snippet for usefulness and map it to a canonical issue category. "
"Only reply with strict JSON using the provided schema."
)


JUDGE_USER_TMPL = (
'''\
    Task: Judge the following feedback.


    Rules:
    - Choose category from: {categories}.
    - Define useful as: specific, actionable, and relevant to improving the model or the answer.
    - Be strict: generic or venting comments are not useful.
    - Return ONLY valid JSON with keys exactly as below (no trailing commentary):
    {{
    "category": "inaccurate|irrelevant|incomplete|unclear|other",
    "usefulness": "useful|not_useful",
    "actionability": 1-5,
    "specificity": 1-5,
    "sentiment": -1 to 1,
    "severity": 1-5,
    "confidence": 0-1,
    "summary": "one-sentence rationale",
    "suggested_rewrite": "rewrite the feedback to be more actionable (keep it brief)"
    }}


    Feedback:
    """{text}"""
'''

)


def _extract_json(s: str) -> Optional[Dict[str, Any]]:
    """Strip to the first JSON object in a text; return dict or None."""
    try:
        # quick path
        return json.loads(s)
    except Exception:
        pass
    try:
        m = re.search(r"\{[\s\S]*\}", s)
        if m:
            return json.loads(m.group(0))
    except Exception:
        return None
    return None


def judge_feedback_batch(
    df: pd.DataFrame,
    model_name: str = LLM_ENDPOINT_NAME,
    temperature: float = 0.0,
    max_rows: Optional[int] = None,
    sleep_s: float = 0.0,
) -> pd.DataFrame:
    if ChatOpenAI is None:
        raise RuntimeError("langchain-openai is not installed. `pip install langchain-openai`. ")
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is not set.")

    use_df = df.copy()
    if max_rows is not None:
        use_df = use_df.head(int(max_rows)).copy()

    llm = ChatDatabricks(model=model_name, temperature=temperature)

    out_records: List[Dict[str, Any]] = []
    progress = st.progress(0, text="Judging feedback with LLM…")
    total = len(use_df)
    for i, row in enumerate(use_df.itertuples(index=False), start=1):
        fb_text = str(getattr(row, "feedback_text", "")).strip()
        if not fb_text:
            out_records.append(
                {
                    "usefulness": "not_useful",
                    "category": "other",
                    "actionability": 1,
                    "specificity": 1,
                    "sentiment": 0,
                    "severity": 1,
                    "confidence": 0,
                    "summary": "Empty feedback",
                    "suggested_rewrite": "",
                }
            )
            progress.progress(i / total)
            continue
        user_prompt = JUDGE_USER_TMPL.format(categories=", ".join(CATEGORY_CANON), text=fb_text)
        msgs = [SystemMessage(content=JUDGE_SYSTEM_PROMPT), HumanMessage(content=user_prompt)]
        try:
            resp = llm.invoke(msgs)
            payload = _extract_json(resp.content)
            if not payload:
                payload = {
                    "usefulness": "not_useful",
                    "category": "other",
                    "actionability": 1,
                    "specificity": 1,
                    "sentiment": 0,
                    "severity": 1,
                    "confidence": 0,
                    "summary": "Could not parse model output",
                    "suggested_rewrite": "",
                }
        except Exception as e:
            payload = {
                "usefulness": "not_useful",
                "category": "other",
                "actionability": 1,
                "specificity": 1,
                "sentiment": 0,
                "severity": 1,
                "confidence": 0,
                "summary": f"LLM error: {e}",
                "suggested_rewrite": "",
            }
        out_records.append(payload)
        progress.progress(i / total)
        if sleep_s > 0:
            time.sleep(sleep_s)

    judged = pd.DataFrame(out_records)
    # Canonicalize columns & types
    judged["category"] = judged["category"].map(lambda x: str(x).lower() if pd.notna(x) else "other").map(
        lambda x: x if x in CATEGORY_CANON else "other"
    )
    for col in ["actionability", "specificity", "severity"]:
        judged[col] = pd.to_numeric(judged[col], errors="coerce").clip(1, 5)
    judged["sentiment"] = pd.to_numeric(judged["sentiment"], errors="coerce").clip(-1, 1)
    judged["confidence"] = pd.to_numeric(judged["confidence"], errors="coerce").clip(0, 1)
    judged["usefulness"] = judged["usefulness"].map(lambda x: "useful" if str(x).lower().startswith("useful") else "not_useful")
    return judged


# -----------------------------
# SQLite persistence
# -----------------------------
@st.cache_resource(show_spinner=False)
def get_engine(db_path: str):
    return create_engine(f"sqlite:///{db_path}")


def write_sqlite_tables(
    engine,
    raw_df: pd.DataFrame,
    quant_df: pd.DataFrame,
    cat_counts: pd.DataFrame,
    judged_df: Optional[pd.DataFrame] = None,
):
    raw_df.to_sql("feedback_raw", engine, if_exists="replace", index=False)
    quant_df.to_sql("quant_counts_model_agent", engine, if_exists="replace", index=False)
    cat_counts.to_sql("category_counts", engine, if_exists="replace", index=False)
    if judged_df is not None:
        judged_df.to_sql("llm_judgments", engine, if_exists="replace", index=False)
        # Derived table: disagreement between human vs LLM category
        try:
            merged = pd.concat([raw_df.reset_index(drop=True), judged_df.reset_index(drop=True)], axis=1)
            # explode human categories
            human_exploded = merged.assign(human_cat=merged["feedback_type"].apply(_to_list)).explode("human_cat")
            human_exploded = human_exploded[human_exploded["human_cat"].notna()].copy()
            human_exploded["agreement"] = (human_exploded["human_cat"] == human_exploded["category"]).astype(int)
            out = (
                human_exploded.groupby(["model", "agent"])  # per slice
                .agg(
                    n=("agreement", "size"),
                    agree=("agreement", "sum"),
                )
                .reset_index()
            )
            out["agree_rate"] = out["agree"] / out["n"].replace({0: np.nan})
            out.to_sql("llm_human_agreement", engine, if_exists="replace", index=False)
        except Exception:
            pass

    with engine.begin() as conn:
        try:
            conn.execute(text("CREATE INDEX IF NOT EXISTS idx_raw_model_agent ON feedback_raw(model, agent)"))
            conn.execute(text("CREATE INDEX IF NOT EXISTS idx_raw_vote ON feedback_raw(vote)"))
            conn.execute(text("CREATE INDEX IF NOT EXISTS idx_j_cat ON llm_judgments(category)"))
        except Exception:
            pass


# -----------------------------
# Streamlit UI
# -----------------------------
st.set_page_config(page_title="UC Feedback Analytics", page_icon="📊", layout="wide")

st.title("📊 Unity Catalog Feedback Analytics")
st.caption("Quantitative KPIs + LLM-as-a-judge on feedback text. Persists to SQLite for BI.")

with st.sidebar:
    st.header("Data sources")
    fqt = st.text_input("Full table name (catalog.schema.table)", placeholder="edl_dev.cbd_sandbox.amg_pmed_convoai_feedback")
    limit = st.number_input("Row limit (0 = all)", min_value=0, value=0, step=1000)
    st.caption("Set Databricks env vars for UC connection: DATABRICKS_HOST, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN")

    st.divider()
    st.header("SQLite output")
    db_path = st.text_input("SQLite DB path", value="feedback_analytics.db")

    st.divider()
    st.header("LLM judge (ChatOpenAI)")
    st.caption("Requires OPENAI_API_KEY. Uses LangChain ChatOpenAI.")
    model_name = st.text_input("Model", value="gpt-4o-mini")
    temperature = st.slider("Temperature", 0.0, 1.0, 0.0, 0.1)
    max_rows = st.number_input("Max rows to judge (0=all)", min_value=0, value=200, step=50)
    throttle = st.slider("Per-row sleep (s)", 0.0, 1.0, 0.0, 0.05)

    st.divider()
    load_btn = st.button("📥 Load from Unity Catalog")

# Session state storage
if "raw_df" not in st.session_state:
    st.session_state["raw_df"] = None

# Load data
if load_btn:
    if not fqt:
        st.error("Please provide a fully qualified Unity Catalog table name.")
    else:
        with st.spinner("Reading table from Unity Catalog…"):
            try:
                df = fetch_uc_table(fqt, limit=None if limit == 0 else limit)
                # normalize feedback_type column to text + preserve original raw for display
                if "feedback_types" not in df.columns:
                    st.warning("Column 'feedback_type' not found; creating empty list.")
                    df["feedback_types"] = [[] for _ in range(len(df))]
                # Keep a text version for SQLite friendliness
                df["feedback_types"] = df["feedback_types"].apply(_to_list)
                df["feedback_type_text"] = df["feedback_types"].apply(lambda xs: json.dumps(xs))
                st.session_state["raw_df"] = df
                st.success(f"Loaded {len(df):,} rows from {fqt}")
            except Exception as e:
                st.exception(e)

raw_df: Optional[pd.DataFrame] = st.session_state.get("raw_df")

# If no data loaded, allow CSV upload as fallback
if raw_df is None:
    st.info("No UC data loaded yet. Upload a CSV with columns vote, feedback_type, feedback_text, agent, model.")
    up = st.file_uploader("Upload CSV", type=["csv"])
    if up is not None:
        df = pd.read_csv(up)
        if "feedback_type" not in df.columns:
            df["feedback_type"] = [[] for _ in range(len(df))]
        df["feedback_type"] = df["feedback_type"].apply(_to_list)
        df["feedback_type_text"] = df["feedback_type"].apply(lambda xs: json.dumps(xs))
        raw_df = df
        st.session_state["raw_df"] = raw_df

if raw_df is not None:
    st.subheader("Preview")
    st.dataframe(raw_df.head(50), use_container_width=True)

    # Quant analytics
    with st.spinner("Computing quantitative analytics…"):
        pivot = _pivot_updown(raw_df)
        cat_counts = _category_counts(raw_df)
    c1, c2 = st.columns([2, 1])
    #with c1:
    #    st.subheader("👍👎 Up/Down by model × agent")
    #    st.dataframe(pivot, use_container_width=True)
    #    st.bar_chart(pivot.set_index(["model", "agent"])[["up", "down"]])
    with c1:
        st.subheader("👍👎 Up/Down by model × agent")
        st.dataframe(pivot, use_container_width=True)
        _chart_df = pivot.copy(); _chart_df["slice"] = _chart_df["model"].astype(str) + " · " + _chart_df["agent"].astype(str)
        st.bar_chart(_chart_df.set_index("slice")[ ["up", "down"] ])
    with c2:
        st.subheader("Issue type counts")
        st.dataframe(cat_counts, use_container_width=True)
        st.bar_chart(cat_counts.set_index("category"))

    # Persist base analytics
    eng = get_engine(db_path)
    with st.spinner("Writing raw + quant tables to SQLite…"):
        #write_sqlite_tables(eng, raw_df, pivot, cat_counts) #F
        st.success(f"Saved to {db_path}")

    st.divider()
    st.subheader("LLM as a Judge")
    run_llm = st.button("🤖 Run judging on current dataset")
    if run_llm:
        with st.spinner("Scoring feedback with ChatOpenAI…"):
            judged = judge_feedback_batch(
                raw_df,
                model_name=LLM_ENDPOINT_NAME,
                temperature=temperature,
                max_rows=None if max_rows == 0 else max_rows,
                sleep_s=throttle,
            )
            # Show a quick peek
            st.dataframe(judged.head(50), use_container_width=True)

            # Join + analyze agreement
            merged = pd.concat([raw_df.reset_index(drop=True), judged.reset_index(drop=True)], axis=1)

            # Useful rate by model×agent
            useful_pivot = (
                merged.assign(useful=(merged["usefulness"] == "useful").astype(int))
                .groupby(["model", "agent"])
                .agg(n=("useful", "size"), useful=("useful", "sum"))
                .reset_index()
            )
            useful_pivot["useful_rate"] = useful_pivot["useful"] / useful_pivot["n"].replace({0: np.nan})

            st.markdown("**LLM Useful-rate by model × agent**")
            st.dataframe(useful_pivot.sort_values("useful_rate", ascending=False), use_container_width=True)
            st.bar_chart(useful_pivot.set_index(["model", "agent"])[["useful"]])

            # Save all to SQLite (adds llm_judgments + agreement)
            with st.spinner("Persisting LLM judgments to SQLite…"):
                #write_sqlite_tables(eng, raw_df, pivot, cat_counts, judged_df=judged) #F
                st.success("Judgments saved (llm_judgments, llm_human_agreement)")
    '''
    st.divider()
    st.subheader("SQLite Tables (quick peek)")
    with eng.connect() as conn:
        try:
            tables = conn.exec_driver_sql(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"
            ).fetchall()
            table_names = [t[0] for t in tables]
            pick = st.selectbox("Select a table to view", table_names)
            if pick:
                df = pd.read_sql(f"SELECT * FROM {pick} LIMIT 200", conn)
                st.dataframe(df, use_container_width=True)
        except Exception as e:
            st.warning(f"Could not list tables: {e}")

    st.caption("Tables written: feedback_raw, quant_counts_model_agent, category_counts, llm_judgments (if run), llm_human_agreement (if run)")
    '''