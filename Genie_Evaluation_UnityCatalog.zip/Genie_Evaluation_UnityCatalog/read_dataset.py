# Databricks notebook source
# MAGIC %pip install langgraph==0.3.4 langchain-openai==0.3.0 langchain-experimental==0.3.4 databricks-langchain databricks-agents databricks-sql-connector sqlalchemy

# COMMAND ----------

# MAGIC %load_ext autoreload
# MAGIC %autoreload 2

# COMMAND ----------

"""Databricks Unity Catalog DB helpers (Delta tables).
Requires: pip install databricks-sql-connector
"""
from __future__ import annotations
import os
from dataclasses import dataclass
from typing import Optional
from databricks import sql

@dataclass
class UCConfig:
    server_hostname: str
    http_path: str
    access_token: str
    catalog: str
    schema: str

def get_conn(cfg: UCConfig):
    return sql.connect(
        server_hostname=cfg.server_hostname,
        http_path=cfg.http_path,
        access_token=cfg.access_token,
    )

def fq(table: str, catalog: str, schema: str) -> str:
    return f"`{catalog}`.`{schema}`.`{table}`"




# COMMAND ----------

from __future__ import annotations

import os
import ast
import re
import json
import time
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
#import streamlit as st
from sqlalchemy import create_engine, text
from dotenv import load_dotenv
import plotly.express as px
from datetime import date

from langchain_openai import ChatOpenAI
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from databricks import sql as dbsql
from langchain.schema import SystemMessage, HumanMessage
from kpi_analyzer2 import analyze_kpis

# COMMAND ----------

#env:
#- name: "SPACE_ID"
#  value: "01f04550b7ca15c39c0d4ba83777f668"
#- name: "LLM_ENDPOINT_NAME" 
#  value : "project-115-Precision_Medicine_AI_Agent-2"
#- name: "DATABRICKS_HOST_ENDPOINT"
#  value : "https://amgen-ai-dev.cloud.databricks.com/serving-endpoints"
#- name: "DATABRICKS_HOST"
#  value: "https://amgen-ai-dev.cloud.databricks.com"
#- name: "DATABRICKS_HOST_BASE"
#  value: "amgen-ai-dev.cloud.databricks.com"
#- name: "DATABRICKS_TOKEN"
#  value: "dapi09f0df7c995c9e37c8a40f7b681a26d4"
#- name: "DATABRICKS_WAREHOUSE"
#  value: "/sql/1.0/warehouses/37c05da246f2f4bd"

DATABRICKS_HOST_BASE= "https://amgen-ai-dev.cloud.databricks.com"
DATABRICKS_HTTP_PATH = "/sql/1.0/warehouses/37c05da246f2f4bd"
DATABRICKS_API_KEY ="dapi09f0df7c995c9e37c8a40f7b681a26d4"
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"

def _connect_uc() -> Optional[Any]:
    if dbsql is None:
        return None
    host = DATABRICKS_HOST_BASE #os.getenv("DATABRICKS_HOST")
    path = DATABRICKS_HTTP_PATH #os.getenv("DATABRICKS_HTTP_PATH")
    token = DATABRICKS_API_KEY #os.getenv("DATABRICKS_TOKEN")
    if not (host and path and token):
        return None
    try:
        return dbsql.connect(server_hostname=host, http_path=path, access_token=token)
    except Exception:  # pragma: no cover
        return None
    
def fetch_uc_table(fully_qualified_table: str, limit: Optional[int] = None) -> pd.DataFrame:
    """Read Unity Catalog table via Databricks SQL connector.
    Expected columns: vote, feedback_type, feedback_text, agent, model
    """
    conn_obj = _connect_uc()
    if conn_obj is None:
        raise RuntimeError(
            "Could not connect to Databricks SQL. Ensure DATABRICKS_HOST, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN are set and 'databricks-sql-connector' installed."
        )
    q = f"SELECT vote, feedback_types, feedback_text, expected_output,agent, model, query_request_time, response_time FROM {fully_qualified_table}"
    if limit:
        q += f" LIMIT {int(limit)}"
    with conn_obj:
        cur = conn_obj.cursor()
        cur.execute(q)
        rows = cur.fetchall()
        cols = [c[0] for c in cur.description]
    df = pd.DataFrame(rows, columns=cols)
    return df

def _find_col(df: pd.DataFrame, candidates: List[str]) -> Optional[str]:
    """Return the first matching (case-insensitive) column name in the dataframe, or None."""
    lower_map = {c.lower(): c for c in df.columns}
    for name in candidates:
        if name in lower_map:
            return lower_map[name]
    return None


# Map short flags to canonical reason strings the analyzer expects
_CANON = {
    "inaccurate": "Information was inaccurate",
    "incomplete": "Response was incomplete",
    "unclear": "Response was unclear",
    "irrelevant": "Response was not relevant",
    "other": "Other",
}


def _dedup_keep_order(items: List[str]) -> List[str]:
    seen = set()
    out = []
    for x in items:
        if x not in seen:
            out.append(x)
            seen.add(x)
    return out


def _normalize_token(tok: str) -> Optional[str]:
    """Map any token to one of the canonical short keys if possible."""
    t = (tok or "").strip().lower()
    for short in _CANON.keys():
        if t == short or short in t:
            return short
    return None


def _parse_reasons_from_string(s: str) -> List[str]:
    """Parse reasons from a delimited string into canonical labels."""
    if not isinstance(s, str) or not s.strip():
        return []
    raw = [tok.strip() for tok in re.split(r"[;,|]", s) if tok.strip()]
    shorts = []
    for tok in raw:
        norm = _normalize_token(tok)
        if norm:
            shorts.append(norm)
    return [_CANON[x] for x in _dedup_keep_order(shorts)]


def _parse_reasons_any(val: Any) -> List[str]:
    """
    Accepts:
      - Python list (already parsed)
      - JSON list string (preferred)
      - Delimited string
    Returns canonical reason strings.
    """
    # Case 1: already a Python list
    if isinstance(val, list):
        shorts = []
        for tok in val:
            norm = _normalize_token(str(tok))
            if norm:
                shorts.append(norm)
        return [_CANON[x] for x in _dedup_keep_order(shorts)]

    # Case 2: JSON list in a string
    if isinstance(val, str):
        s = val.strip()
        if s.startswith("[") and s.endswith("]"):
            # Be forgiving: convert single quotes to double quotes if present
            s_norm = s.replace("'", '"')
            try:
                arr = json.loads(s_norm)
                if isinstance(arr, list):
                    shorts = []
                    for tok in arr:
                        norm = _normalize_token(str(tok))
                        if norm:
                            shorts.append(norm)
                    return [_CANON[x] for x in _dedup_keep_order(shorts)]
            except Exception:
                # fall back to delimited
                pass
        # Case 3: delimited string
        return _parse_reasons_from_string(s)

    # Unknown -> empty
    return []

# COMMAND ----------

FULL_TABLE_NAME = "edl_dev.cbd_sandbox.amg_pmed_convai_feedback"
df = fetch_uc_table(FULL_TABLE_NAME)

# COMMAND ----------

dff = df[['feedback_text','feedback_types','expected_output','model']]
dff = dff.rename(columns={'feedback_text':'custom_feedback',
                          'feedback_types':'reason',
                          'expected_output':'expected',
                          'model':'model'})
dff.head()

# COMMAND ----------

parsed_reasons = dff['reason'].apply(_parse_reasons_any)

# COMMAND ----------

parsed_reasons

# COMMAND ----------

# Pull columns safely
txt = dff['custom_feedback'].astype(str)
exp = dff['expected'].astype(str) if ('expected' != "(none)") else pd.Series([""] * len(dff))
mdl = dff['model'].astype(str) if ('model' != "(none)") else pd.Series([""] * len(dff))


# COMMAND ----------

out_sev, out_act = [], []
for i in range(len(df)):
    bundle = {
        "reasons": parsed_reasons.iloc[i] or [],
        "custom_feedback": txt.iloc[i] or "",
        "expected": exp.iloc[i] or "",
        "model": mdl.iloc[i] or "",
    }
    res = analyze_kpis(bundle, LLM_ENDPOINT_NAME if LLM_ENDPOINT_NAME.strip() else None)
    out_sev.append(float(res.get("severity", 0.5)))
    out_act.append(float(res.get("actionability", 0.5)))

# COMMAND ----------

df_out = dff.copy()
df_out["severity"] = out_sev
df_out["actionability"] = out_act

# COMMAND ----------

df_out.head()

# COMMAND ----------


# KPIs
total_feedback = len(df_out)
avg_severity = float(df_out["severity"].mean()) if total_feedback else 0.0
avg_actionability = float(df_out["actionability"].mean()) if total_feedback else 0.0

top_model = df_out['model'].mode(dropna=True).iloc[0]


# COMMAND ----------

print(top_model)

# COMMAND ----------

# MAGIC %md
# MAGIC Judge Batch

# COMMAND ----------

import io
import json
import re
from typing import Dict, Any, Tuple

import pandas as pd
import streamlit as st

# LangChain OpenAI chat model
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

st.set_page_config(page_title="LLM-as-a-Judge (Batch)", page_icon="⚖️", layout="wide")
st.title("⚖️ LLM-as-a-Judge — Batch Scoring")

with st.sidebar:
    st.header("Judge Settings")
    judge_model = st.text_input("Judge model", value="gpt-4o-mini")
    temperature = st.slider("Temperature", 0.0, 1.0, value=0.0, step=0.1)
    st.caption(
        "Set `OPENAI_API_KEY` in your environment or Streamlit secrets.\n"
        "This app expects CSV columns: user_query, llm_response, expected_response, model."
    )

# ---------- Prompt used for every evaluation ----------
SYSTEM_PROMPT = (
    "You are a strict but fair evaluator. Score the ASSISTANT response with respect to the USER query "
    "and, if provided, an EXPECTED response. Use the following 0–5 float metrics:\n"
    "• correctness: factual accuracy vs the expected answer or domain knowledge\n"
    "• relevance: how well the answer addresses the user’s query\n"
    "• completeness: whether key steps/details are covered (not missing important parts)\n"
    "• faithfulness: grounded in the input/expected content; no hallucinations\n"
    "• conciseness: avoids rambling while retaining necessary information\n\n"
    "Rules:\n"
    "- If an expected response is provided, evaluate primarily against it.\n"
    "- Otherwise, evaluate the assistant response directly against the user query.\n"
    "- Return ONLY valid JSON, no Markdown or commentary. Use this exact schema:\n"
    "{\n"
    '  "correctness": number (0-5),\n'
    '  "relevance": number (0-5),\n'
    '  "completeness": number (0-5),\n'
    '  "faithfulness": number (0-5),\n'
    '  "conciseness": number (0-5)\n'
    "}"
)

def _clean_and_parse_json(s: str) -> Dict[str, Any]:
    """
    Try to parse JSON; if the model adds extra text, extract the first {...} block.
    """
    s = (s or "").strip()
    try:
        return json.loads(s)
    except Exception:
        pass

    # Try to extract JSON object with a naive brace match
    try:
        start = s.find("{")
        end = s.rfind("}")
        if start != -1 and end != -1 and end > start:
            candidate = s[start : end + 1]
            return json.loads(candidate)
    except Exception:
        pass

    # Try to remove code fencing/backticks if any
    s2 = re.sub(r"^```(?:json)?|```$", "", s.strip(), flags=re.MULTILINE).strip()
    try:
        return json.loads(s2)
    except Exception:
        pass

    # Failed
    return {}

def _clamp_0_5(x: Any) -> float:
    try:
        v = float(x)
    except Exception:
        return 0.0
    return max(0.0, min(5.0, v))

@st.cache_data(show_spinner=False)
def judge_once(
    judge_model: str,
    temperature: float,
    user_query: str,
    llm_response: str,
    expected_response: str,
) -> Tuple[float, float, float, float, float, str]:
    """
    Run a single LLM-as-judge evaluation and return the five metrics + raw model output.
    Cached by inputs to avoid re-charging on reruns.
    """
    chat = ChatOpenAI(model=judge_model, temperature=temperature)
    payload = {
        "user_query": user_query or "",
        "assistant_response": llm_response or "",
        "expected_response": expected_response or "",
    }
    msg = json.dumps(payload, ensure_ascii=False)
    ai = chat.invoke([SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=msg)])
    content = getattr(ai, "content", "") or ""

    parsed = _clean_and_parse_json(content)
    c = _clamp_0_5(parsed.get("correctness"))
    r = _clamp_0_5(parsed.get("relevance"))
    comp = _clamp_0_5(parsed.get("completeness"))
    f = _clamp_0_5(parsed.get("faithfulness"))
    conc = _clamp_0_5(parsed.get("conciseness"))
    return c, r, comp, f, conc, content

uploaded = st.file_uploader("Upload CSV", type=["csv"])
run = st.button("Run LLM-as-a-Judge")

if uploaded is None:
    st.info("Upload a CSV to begin.")
    st.stop()

# Read required input CSV
raw = uploaded.read()
df = pd.read_csv(io.BytesIO(raw))

required_cols = ["user_query", "llm_response", "expected_response", "model"]
missing = [c for c in required_cols if c not in df.columns]
if missing:
    st.error(f"Missing required columns: {missing}. Found: {list(df.columns)}")
    st.stop()

st.write("### Preview")
st.dataframe(df.head(10), use_container_width=True)

if run:
    if not (st.secrets.get("OPENAI_API_KEY") or st.session_state.get("OPENAI_API_KEY") or st.get_option("theme.base")):
        # We can't reliably detect env vars in all Streamlit deployments; let errors surface if key truly missing.
        pass

    # Prepare output columns
    out_cols = ["correctness", "relevance", "completeness", "faithfulness", "conciseness", "judge_raw"]
    for c in out_cols:
        if c not in df.columns:
            df[c] = None

    progress = st.progress(0.0, text="Scoring…")
    total = len(df)

    for idx, row in df.iterrows():
        uq = str(row.get("user_query", "") or "")
        ar = str(row.get("llm_response", "") or "")
        ex = str(row.get("expected_response", "") or "")

        try:
            correctness, relevance, completeness, faithfulness, conciseness, raw_out = judge_once(
                judge_model, temperature, uq, ar, ex
            )
        except Exception as e:
            correctness = relevance = completeness = faithfulness = conciseness = 0.0
            raw_out = f"(error) {e}"

        df.at[idx, "correctness"] = correctness
        df.at[idx, "relevance"] = relevance
        df.at[idx, "completeness"] = completeness
        df.at[idx, "faithfulness"] = faithfulness
        df.at[idx, "conciseness"] = conciseness
        df.at[idx, "judge_raw"] = raw_out

        if total:
            progress.progress((idx + 1) / total, text=f"Scored {idx + 1}/{total}")

    progress.empty()

    st.success("Done! See results below.")

    # Summary metrics
    st.write("### Dataset Averages (0–5)")
    avg = (
        df[["correctness", "relevance", "completeness", "faithfulness", "conciseness"]]
        .astype(float)
        .mean()
        .to_frame("average")
        .T
    )
    st.dataframe(avg, use_container_width=True)

    st.write("### Scored Rows")
    st.dataframe(df, use_container_width=True)

    # Download
    out_csv = df.to_csv(index=False).encode("utf-8")
    st.download_button(
        "Download scored CSV",
        data=out_csv,
        file_name="judged_results.csv",
        mime="text/csv",
    )


# COMMAND ----------

from databricks.vector_search.client import VectorSearchClient

client = VectorSearchClient(workspace_url="https://amgen-ai-dev.cloud.databricks.com", 
                            personal_access_token="dapi09f0df7c995c9e37c8a40f7b681a26d4")

index = client.get_index("edl_dev", "cbd_sandbox", "pmed_prod_ddm_vector_index")

results = index.similarity_search(
    query_text="oncology biomarker resistance mechanisms",
    num_results=10
)

for r in results['data_array']:
    print(r)