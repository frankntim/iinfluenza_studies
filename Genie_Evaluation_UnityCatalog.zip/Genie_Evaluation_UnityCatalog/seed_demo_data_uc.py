
from __future__ import annotations
import random
from dataclasses import dataclass
from datetime import datetime, timedelta, date
from typing import List, Tuple, Optional
from db_uc import UCConfig, get_conn, create_tables, ensure_columns, fq
import quantitative_analytics_uc as qa
import qualitative_analytics_uc as ql
from kpi_analyzer import analyze_kpis

TOPICS = ["quarterly revenue","protein folding","SQL window functions","Streamlit dialogs","LangChain ChatOpenAI","SQLite indexing","clinical trial phases","vector search","token usage accounting","error handling best practices"]
NEUTRAL_RESPONSES = ["Here is a brief overview and the key points you asked for.","Summarizing the concept with examples…","Let me break that down step-by-step."]
BAD_RESPONSES = ["I'm not sure, maybe it's related to weather?","42.","This looks fine. Anyway, have a nice day!"]
EXPECTED_TEMPLATES = ["The expected answer should include a definition, 2-3 bullet points, and a short example.","Please provide a concise explanation and a simple code snippet.","A numbered list of steps would be the best response in this case."]
NEG_NOTES = ["The answer was wrong about the core concept and missed critical context.","It didn't include the SQL example I expected.","The response was unclear and lacked stepwise instructions!","It talked about an unrelated topic and didn't address the question.","The info seemed fabricated and not backed by the prompt."]

def month_spans_between(start_dt: datetime, end_dt: datetime):
    spans = []
    cur = start_dt.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    while cur <= end_dt:
        nxt = cur.replace(year=cur.year+1, month=1) if cur.month == 12 else cur.replace(month=cur.month+1)
        span_start = max(cur, start_dt); span_end = min(nxt, end_dt)
        if span_end > span_start: spans.append((span_start, span_end))
        cur = nxt
    return spans

def random_dt_in_range(start: datetime, end: datetime) -> datetime:
    delta = end - start; seconds = max(1, int(delta.total_seconds()) - 1)
    return start + timedelta(seconds=random.randint(0, seconds))

@dataclass
class SeedCfg:
    uc: UCConfig
    models: List[str]
    versions: List[str]
    vec_versions: List[str]
    users: List[str]
    start_date: date
    end_date: date
    per_combo_month: int = 10
    seed: Optional[int] = 42

def _insert_one(conn, catalog, schema, ts, model, version, vec_ver, user_id, thumbs, user_query, assistant_response, expected_response):
    usage = {"input_tokens": random.randint(40,300), "output_tokens": random.randint(60,500)}
    usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]
    qid = qa.insert_quantitative(conn, catalog=catalog, schema=schema,
                                 thumbs=thumbs, user_query=user_query, llm_response=assistant_response,
                                 expected_response=expected_response, model=model, software_version=version,
                                 usage=usage, user_id=user_id, vectorization_version=vec_ver)
    # Force timestamp
    with conn.cursor() as cur:
        cur.execute(f"UPDATE {fq('quantitative_data', catalog, schema)} SET timestamp = ? WHERE id = ?", [ts.strftime('%Y-%m-%d %H:%M:%S'), qid])

    metrics = ({
        "correctness": random.uniform(0.75,0.98),
        "relevance": random.uniform(0.75,0.98),
        "faithfulness": random.uniform(0.75,0.98),
        "completeness": random.uniform(0.70,0.95),
        "conciseness": random.uniform(0.65,0.95),
    } if thumbs == "up" else {
        "correctness": random.uniform(0.15,0.55),
        "relevance": random.uniform(0.10,0.60),
        "faithfulness": random.uniform(0.15,0.60),
        "completeness": random.uniform(0.10,0.55),
        "conciseness": random.uniform(0.30,0.85),
    })
    overall = sum(metrics.values())/len(metrics)
    qa.insert_quantitative_analytics(conn, catalog=catalog, schema=schema, quant_id=qid, judge_model="synthetic-judge",
                                     label=("Excellent" if overall>0.85 else "Good" if overall>0.7 else "Fair" if overall>0.5 else "Poor"),
                                     rationale="Synthetic judge scoring for demo data.", overall=overall, metrics=metrics)
    with conn.cursor() as cur:
        cur.execute(f"""                UPDATE {fq('quantitative_analytics', catalog, schema)}
            SET timestamp = ? WHERE id = (SELECT max(id) FROM {fq('quantitative_analytics', catalog, schema)} WHERE quant_id = ?)
        """, [ts.strftime('%Y-%m-%d %H:%M:%S'), qid])

    if thumbs == "down":
        reasons = random.sample(["Information was inaccurate","Response was incomplete","Response was unclear","Response was not relevant","Other"], random.randint(1,3))
        custom = random.choice(NEG_NOTES)
        bundle = {"reasons": reasons, "custom_feedback": custom, "expected": expected_response,
                  "user_query": user_query, "assistant_response": assistant_response, "model": model, "version": version}
        res = analyze_kpis(bundle, model_name=None)
        with conn.cursor() as cur:
            ql.insert_qualitative(conn, catalog=catalog, schema=schema,
                                  quant_id=qid, custom_feedback=custom, reasons=reasons,
                                  severity=float(res.get("severity",0.5)), actionability=float(res.get("actionability",0.5)),
                                  model=model, software_version=version, user_id=user_id, vectorization_version=vec_ver)
        with conn.cursor() as cur:
            cur.execute(f"""                    UPDATE {fq('qualitative_data', catalog, schema)}
                SET timestamp = ? WHERE id = (SELECT max(id) FROM {fq('qualitative_data', catalog, schema)} WHERE quant_id = ?)
            """, [ts.strftime('%Y-%m-%d %H:%M:%S'), qid])

def seed_period(cfg: SeedCfg) -> int:
    if cfg.seed is not None: random.seed(cfg.seed)
    conn = get_conn(cfg.uc)
    create_tables(conn, cfg.uc.catalog, cfg.uc.schema)
    ensure_columns(conn, cfg.uc.catalog, cfg.uc.schema)
    start_dt = datetime.combine(cfg.start_date, datetime.min.time())
    end_dt = datetime.combine(cfg.end_date, datetime.min.time()) + timedelta(days=1)
    spans = month_spans_between(start_dt, end_dt)
    total = 0
    for model in cfg.models:
        for version in cfg.versions:
            for m_start, m_end in spans:
                rows = max(2, cfg.per_combo_month)
                thumbs_list = ["up","down"] + [random.choice(["up","down"]) for _ in range(rows-2)]
                random.shuffle(thumbs_list)
                for thumbs in thumbs_list:
                    ts = random_dt_in_range(m_start, m_end)
                    topic = random.choice(TOPICS)
                    user_q = f"Explain {topic} with an example."
                    if thumbs == "up":
                        llm_resp, expected = random.choice(NEUTRAL_RESPONSES) + f" (re: {topic})", ""
                    else:
                        llm_resp, expected = random.choice(BAD_RESPONSES), random.choice(EXPECTED_TEMPLATES)
                    vec_ver = random.choice(cfg.vec_versions); user_id = random.choice(cfg.users)
                    _insert_one(conn, cfg.uc.catalog, cfg.uc.schema, ts, model, version, vec_ver, user_id, thumbs, user_q, llm_resp, expected)
                    total += 1
    try:
        ql.update_qualitative_analytics(conn, catalog=cfg.uc.catalog, schema=cfg.uc.schema, judge_model="synthetic-judge")
    except Exception:
        pass
    conn.close()
    return total
