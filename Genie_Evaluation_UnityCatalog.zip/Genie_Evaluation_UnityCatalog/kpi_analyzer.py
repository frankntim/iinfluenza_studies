
from __future__ import annotations
import json, math, os, re
from typing import Dict, Any, Optional, List
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
try:
    from langchain_openai import ChatOpenAI
    from langchain_core.messages import HumanMessage, SystemMessage
except Exception:
    ChatOpenAI = None  # type: ignore
    HumanMessage = None  # type: ignore
    SystemMessage = None  # type: ignore

REASON_SEVERITY = {
    "Information was inaccurate": 0.95,
    "Response was incomplete": 0.65,
    "Response was unclear": 0.55,
    "Response was not relevant": 0.75,
    "Other": 0.45,
}
REASON_ACTIONABILITY = {
    "Information was inaccurate": 0.70,
    "Response was incomplete": 0.80,
    "Response was unclear": 0.85,
    "Response was not relevant": 0.55,
    "Other": 0.60,
}
NEGATIVE_KEYWORDS = ["wrong","incorrect","false","hallucinate","unsafe","harmful","misleading","dangerous","nonsense","fabricated"]
ACTION_HINTS = ["should","expected","instead","please","add","include","provide","fix","correct","clarify","step","reproduce"]
CODE_HINTS = ["```","traceback","error:","stack","curl","json","sql","python"]

def _clip01(x: float) -> float: return max(0.0, min(1.0, x))

def _heuristic_scores(reasons: List[str], text: str, expected: str) -> Dict[str, float]:
    reasons = reasons or []
    base_sev = [REASON_SEVERITY.get(r, 0.5) for r in reasons] or [0.5]
    base_act = [REASON_ACTIONABILITY.get(r, 0.5) for r in reasons] or [0.5]
    sev = 0.6 * max(base_sev) + 0.4 * (sum(base_sev)/len(base_sev))
    act = 0.6 * max(base_act) + 0.4 * (sum(base_act)/len(base_act))
    tl = (text or "").lower(); el = (expected or "").lower()
    sev += 0.1 * sum(1 for kw in NEGATIVE_KEYWORDS if kw in tl)
    sev += 0.05 * tl.count("!")
    if len(el) > 200: sev += 0.05
    act += 0.08 * sum(1 for kw in ACTION_HINTS if kw in tl)
    act += 0.10 if any(h in text for h in CODE_HINTS) else 0.0
    return {"severity": _clip01(sev), "actionability": _clip01(act)}

LLM_SYSTEM = (
    "You are a rigorous QA analyst. Given a JSON bundle about a negative user feedback, "
    "estimate two KPIs in [0,1]:\n"
    "- severity: overall harm/impact if the assistant's failure were left unaddressed\n"
    "- actionability: how directly fixable and specific the feedback is (higher = more actionable)\n"
    "Respond ONLY with JSON: {\"severity\": <float>, \"actionability\": <float>, \"explanation\": <string>}"
)

def _llm_scores(bundle: Dict[str, Any], model_name: Optional[str]):
    if not model_name or not os.environ.get("OPENAI_API_KEY") or ChatOpenAI is None:
        return None
    llm = ChatDatabricks(model=model_name, temperature=0)
    resp = llm.invoke([SystemMessage(content=LLM_SYSTEM), HumanMessage(content=json.dumps(bundle, ensure_ascii=False))])
    try:
        data = json.loads(getattr(resp, "content", "{}"))
        return {"severity": _clip01(float(data.get("severity"))),
                "actionability": _clip01(float(data.get("actionability"))),
                "explanation": str(data.get("explanation","")).strip()}
    except Exception:
        return None

def analyze_kpis(bundle: Dict[str, Any], model_name: Optional[str] = None) -> Dict[str, Any]:
    base = _heuristic_scores(bundle.get("reasons") or [], bundle.get("custom_feedback") or "", bundle.get("expected") or "")
    rich = None
    try: rich = _llm_scores(bundle, model_name)
    except Exception: pass
    if rich and isinstance(rich.get("severity"), (int,float)) and isinstance(rich.get("actionability"), (int,float)):
        return {"severity": _clip01(float(rich["severity"])), "actionability": _clip01(float(rich["actionability"])), "explanation": rich.get("explanation","")}
    return {"severity": base["severity"], "actionability": base["actionability"], "explanation": "heuristic"}
