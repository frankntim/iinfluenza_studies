"""
Streamlit app: Unity Catalog feedback analytics + LLM-as-a-judge → SQLite

Features
- Reads a Unity Catalog table (Databricks SQL) with columns: vote, feedback_type, feedback_text, agent, model
- Quant analytics: up/down counts per model×agent; counts of inaccurate/irrelevant/incomplete/unclear/other
- Qual analytics: uses ChatOpenAI (LangChain) to judge feedback_text; stores judgments in SQLite
- Persists raw + analytics tables to SQLite for downstream BI

Run
  pip install streamlit pandas numpy sqlalchemy databricks-sql-connector langchain-openai pydantic
  export OPENAI_API_KEY=...   # required for LLM judging
  export DATABRICKS_HOST=...  # your workspace hostname, e.g. adb-12345.99.azuredatabricks.net
  export DATABRICKS_HTTP_PATH=/sql/1.0/warehouses/XXXX
  export DATABRICKS_TOKEN=... # a PAT with SQL access

  streamlit run streamlit_uc_feedback_analytics.py

Notes
- feedback_type can be an ARRAY<STRING> in UC or a string like "['inaccurate','irrelevant']". Both are handled.
- SQLite DB defaults to ./feedback_analytics.db; change in sidebar if desired.
"""
from __future__ import annotations

import os
import ast
import re
import json
import time
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import streamlit as st
from sqlalchemy import create_engine, text
from dotenv import load_dotenv
import plotly.express as px
from datetime import date

from langchain_openai import ChatOpenAI
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from databricks import sql as dbsql
from langchain.schema import SystemMessage, HumanMessage
from kpi_analyzer import analyze_kpis

st.set_page_config(page_title="PMed Chatbot Feedback Analytics", page_icon="🧱", layout="wide")
#st.set_page_config(page_title="LLM Feedback Collector", page_icon="💬", layout="wide")

# Optional import (only needed if connecting to Databricks SQL)
#try:
#    from databricks import sql as dbsql
#except Exception:  # pragma: no cover
#    dbsql = None

# LLM (LangChain)
#try:
    #from langchain_openai import ChatOpenAI
   #from langchain.schema import SystemMessage, HumanMessage
#except Exception as e:  # pragma: no cover
#    ChatOpenAI = None



load_dotenv()
LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")
BASE_URL_SERVING_ENDPOINT = os.environ.get("DATABRICKS_HOST_ENDPOINT")
DATABRICKS_API_KEY = os.environ.get("DATABRICKS_TOKEN")

DATABRICKS_HOST_BASE = os.environ.get("DATABRICKS_HOST_BASE")
DATABRICKS_HTTP_PATH = os.environ.get("DATABRICKS_WAREHOUSE")
FULL_TABLE_NAME = "edl_dev.cbd_sandbox.amg_pmed_convai_feedback"
#FULL_TABLE_NAME = "edl_dev.cbd_sandbox.amg_pmed_convai_feedback"

TEMPERATURE = 0
# Create a remote Spark session
os.environ.pop('DATABRICKS_CLIENT_ID', None)
os.environ.pop('DATABRICKS_CLIENT_SECRET', None)

os.environ['OPENAI_API_KEY'] = DATABRICKS_API_KEY


# -----------------------------
# LLM judging
# -----------------------------
JUDGE_SYSTEM_PROMPT = (
    "You are evaluating user-written feedback about AI assistant/model outputs. "
    "Classify and rate each feedback snippet for usefulness and map it to a canonical issue category. "
    "Only reply with strict JSON using the provided schema."
)

JUDGE_USER_TMPL = (
    '''\
Task: Judge the following feedback.

Rules:
- Choose category from: {categories}.
- Define useful as: specific, actionable, and relevant to improving the model or the answer.
- Be strict: generic or venting comments are not useful.
- Return ONLY valid JSON with keys exactly as below (no trailing commentary):
  {{
    "category": "inaccurate|irrelevant|incomplete|unclear|other",
    "usefulness": "useful|not_useful",
    "actionability": 1-5,
    "specificity": 1-5,
    "sentiment": -1 to 1,
    "severity": 1-5,
    "confidence": 0-1,
    "summary": "one-sentence rationale",
    "suggested_rewrite": "rewrite the feedback to be more actionable (keep it brief)"
  }}

Feedback:
"""{text}"""
    '''
)

# ---------- Prompt used for every evaluation ----------
SYSTEM_PROMPT = (
    "You are a strict but fair evaluator. Score the ASSISTANT response with respect to the USER query "
    "and, if provided, an EXPECTED response. Use the following 0–5 float metrics:\n"
    "• correctness: factual accuracy vs the expected answer or domain knowledge\n"
    "• relevance: how well the answer addresses the user’s query\n"
    "• completeness: whether key steps/details are covered (not missing important parts)\n"
    "• faithfulness: grounded in the input/expected content; no hallucinations\n"
    "• conciseness: avoids rambling while retaining necessary information\n\n"
    "Rules:\n"
    "- If an expected response is provided, evaluate primarily against it.\n"
    "- Otherwise, evaluate the assistant response directly against the user query.\n"
    "- Return ONLY valid JSON, no Markdown or commentary. Use this exact schema:\n"
    "{\n"
    '  \"correctness\": number (0-5),\n'
    '  \"relevance\": number (0-5),\n'
    '  \"completeness\": number (0-5),\n'
    '  \"faithfulness\": number (0-5),\n'
    '  \"conciseness\": number (0-5)\n'
    "}"
)


# -----------------------------
# Helpers functions
# -----------------------------
CATEGORY_CANON = ["inaccurate", "irrelevant", "incomplete", "unclear", "other"]
METRICS: List[str] = ["correctness", "relevance", "completeness", "faithfulness", "conciseness"]


def _to_list(v: Any) -> List[str]:
    """Normalize feedback_type to a list of lowercased strings.
    Accepts list/tuple, JSON string, Python list repr string, CSV string, or None.
    """
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return []
    if isinstance(v, (list, tuple, set)):
        raw = list(v)
    elif isinstance(v, str):
        s = v.strip()
        if s.startswith("[") and s.endswith("]"):
            try:
                raw = ast.literal_eval(s)
                if not isinstance(raw, list):
                    raw = [str(raw)]
            except Exception:
                # Try JSON
                try:
                    raw = json.loads(s)
                    if not isinstance(raw, list):
                        raw = [str(raw)]
                except Exception:
                    # Fallback: comma-separated
                    raw = [p.strip() for p in s.split(",") if p.strip()]
        else:
            raw = [p.strip() for p in s.split(",") if p.strip()]
    else:
        raw = [str(v)]
    # Canonicalize + map unknowns to 'other'
    out: List[str] = []
    for x in raw:
        xlow = str(x).strip().lower()
        if xlow in CATEGORY_CANON:
            out.append(xlow)
        else:
            # attempt light normalization
            if "inaccur" in xlow:
                out.append("inaccurate")
            elif "irrel" in xlow:
                out.append("irrelevant")
            elif "incompl" in xlow:
                out.append("incomplete")
            elif "unclear" in xlow or "confus" in xlow or "ambig" in xlow:
                out.append("unclear")
            else:
                out.append("other")
    return out

def _normalized_updown(df: pd.DataFrame):
    # ensure vote normalized to {'up','down'}
    vmap = {
        "up": "up",
        "down": "down",
        "thumbs_up": "up",
        "thumbs_down": "down",
        "1": "up",
        "0": "down",
        "true": "up",
        "false": "down",
        "dummy": "up"
    }
    vote_norm = (
        df["vote"].astype(str).str.strip().str.lower().map(lambda x: vmap.get(x, x))
    )
    df = df.assign(thumbs=vote_norm)
    return df

def _pivot_updown(df: pd.DataFrame) -> pd.DataFrame:
    # ensure vote normalized to {'up','down'}
    vmap = {
        "up": "up",
        "down": "down",
        "thumbs_up": "up",
        "thumbs_down": "down",
        "1": "up",
        "0": "down",
        "true": "up",
        "false": "down",
        "dummy": "up"
    }
    vote_norm = (
        df["vote"].astype(str).str.strip().str.lower().map(lambda x: vmap.get(x, x))
    )
    tmp = df.assign(vote_norm=vote_norm)
    # Only keep up/down values, drop others
    tmp = tmp[tmp["vote_norm"].isin(["up", "down"])].copy()
    pt = (
        pd.pivot_table(
            tmp,
            index=["model", "agent"],
            columns="vote_norm",
            values="feedback_text",
            aggfunc="count",
            fill_value=0,
        )
        .reset_index()
        .rename_axis(None, axis=1)
    )
    if "up" not in pt.columns:
        pt["up"] = 0
    if "down" not in pt.columns:
        pt["down"] = 0
    pt["total"] = pt["up"] + pt["down"]
    pt["up_rate"] = pt["up"] / pt["total"].replace({0: np.nan})
    return pt.sort_values(["up_rate", "total"], ascending=[False, False])


def _category_counts(df: pd.DataFrame) -> pd.DataFrame:
    exploded = df.assign(_ft=df["feedback_types"].apply(_to_list)).explode("_ft")
    exploded = exploded[~exploded["_ft"].isna()]
    counts = (
        exploded.groupby("_ft").size().reindex(CATEGORY_CANON, fill_value=0).reset_index()
    )
    counts.columns = ["category", "count"]

    counts_model = (
        exploded.groupby(["model","_ft"], as_index=False).agg({'model':len})
    )
    counts_model.columns = ["category", "count"]

    counts_agent = (
        exploded.groupby(["agent","_ft"], as_index=False).agg({'agent':len})
    )
    counts_agent.columns = ["category", "count"]

    return counts, counts_model, counts_agent

#df.groupby(['movie id','movie title','release date','IMDb URL','genre'], as_index=False).agg({'user id':len,'rating':'mean'})

def _connect_uc() -> Optional[Any]:
    if dbsql is None:
        return None
    host = DATABRICKS_HOST_BASE #os.getenv("DATABRICKS_HOST")
    path = DATABRICKS_HTTP_PATH #os.getenv("DATABRICKS_HTTP_PATH")
    token = DATABRICKS_API_KEY #os.getenv("DATABRICKS_TOKEN")
    if not (host and path and token):
        return None
    try:
        return dbsql.connect(server_hostname=host, http_path=path, access_token=token)
    except Exception:  # pragma: no cover
        return None


def fetch_uc_table(fully_qualified_table: str, limit: Optional[int] = None) -> pd.DataFrame:
    """Read Unity Catalog table via Databricks SQL connector.
    Expected columns: vote, feedback_type, feedback_text, agent, model
    """
    conn_obj = _connect_uc()
    if conn_obj is None:
        raise RuntimeError(
            "Could not connect to Databricks SQL. Ensure DATABRICKS_HOST, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN are set and 'databricks-sql-connector' installed."
        )
    q = f"SELECT vote, feedback_types, feedback_text,  query, sql_query, expected_output,agent, model, query_request_time, response_time FROM {fully_qualified_table}"
    if limit:
        q += f" LIMIT {int(limit)}"
    with conn_obj:
        cur = conn_obj.cursor()
        cur.execute(q)
        rows = cur.fetchall()
        cols = [c[0] for c in cur.description]
    df = pd.DataFrame(rows, columns=cols)
    return df

def _response_stats(df: pd.DataFrame, group_col: str) -> pd.DataFrame:
    """Aggregate response duration (in seconds) by a column (model or agent).
    Returns columns: group_col, n, mean_s, median_s, p95_s
    """
    if group_col not in df.columns or "response_duration_s" not in df.columns:
        return pd.DataFrame(columns=[group_col, "n", "mean_s", "median_s", "p95_s"])
    s = df[[group_col, "response_duration_s"]].copy()
    s = s[pd.notna(s["response_duration_s"])].copy()
    if s.empty:
        return pd.DataFrame(columns=[group_col, "n", "mean_s", "median_s", "p95_s"])
    g = s.groupby(group_col)["response_duration_s"]
    out = g.agg(
        n="count",
        mean_s="mean",
        median_s="median",
        p95_s=lambda x: x.quantile(0.95),
    ).reset_index()
    return out.sort_values(["median_s", "n"], ascending=[True, False])


def _find_col(df: pd.DataFrame, candidates: List[str]) -> Optional[str]:
    """Return the first matching (case-insensitive) column name in the dataframe, or None."""
    lower_map = {c.lower(): c for c in df.columns}
    for name in candidates:
        if name in lower_map:
            return lower_map[name]
    return None


# Map short flags to canonical reason strings the analyzer expects
_CANON = {
    "inaccurate": "Information was inaccurate",
    "incomplete": "Response was incomplete",
    "unclear": "Response was unclear",
    "irrelevant": "Response was not relevant",
    "other": "Other",
}


def _dedup_keep_order(items: List[str]) -> List[str]:
    seen = set()
    out = []
    for x in items:
        if x not in seen:
            out.append(x)
            seen.add(x)
    return out


def _normalize_token(tok: str) -> Optional[str]:
    """Map any token to one of the canonical short keys if possible."""
    t = (tok or "").strip().lower()
    for short in _CANON.keys():
        if t == short or short in t:
            return short
    return None


def _parse_reasons_from_string(s: str) -> List[str]:
    """Parse reasons from a delimited string into canonical labels."""
    if not isinstance(s, str) or not s.strip():
        return []
    raw = [tok.strip() for tok in re.split(r"[;,|]", s) if tok.strip()]
    shorts = []
    for tok in raw:
        norm = _normalize_token(tok)
        if norm:
            shorts.append(norm)
    return [_CANON[x] for x in _dedup_keep_order(shorts)]


def _parse_reasons_any(val: Any) -> List[str]:
    """
    Accepts:
      - Python list (already parsed)
      - JSON list string (preferred)
      - Delimited string
    Returns canonical reason strings.
    """
    # Case 1: already a Python list
    if isinstance(val, list):
        shorts = []
        for tok in val:
            norm = _normalize_token(str(tok))
            if norm:
                shorts.append(norm)
        return [_CANON[x] for x in _dedup_keep_order(shorts)]

    # Case 2: JSON list in a string
    if isinstance(val, str):
        s = val.strip()
        if s.startswith("[") and s.endswith("]"):
            # Be forgiving: convert single quotes to double quotes if present
            s_norm = s.replace("'", '"')
            try:
                arr = json.loads(s_norm)
                if isinstance(arr, list):
                    shorts = []
                    for tok in arr:
                        norm = _normalize_token(str(tok))
                        if norm:
                            shorts.append(norm)
                    return [_CANON[x] for x in _dedup_keep_order(shorts)]
            except Exception:
                # fall back to delimited
                pass
        # Case 3: delimited string
        return _parse_reasons_from_string(s)

    # Unknown -> empty
    return []

# LLM as A Judge-> Compare Results with Expected
def _clean_and_parse_json(s: str) -> Dict[str, Any]:
    """
    Try to parse JSON; if the model adds extra text, extract the first {...} block.
    """
    s = (s or "").strip()
    try:
        return json.loads(s)
    except Exception:
        pass

    # Try to extract JSON object with a naive brace match
    try:
        start = s.find("{")
        end = s.rfind("}")
        if start != -1 and end != -1 and end > start:
            candidate = s[start : end + 1]
            return json.loads(candidate)
    except Exception:
        pass

    # Try to remove code fencing/backticks if any
    s2 = re.sub(r"^```(?:json)?|```$", "", s.strip(), flags=re.MULTILINE).strip()
    try:
        return json.loads(s2)
    except Exception:
        pass

    # Failed
    return {}

def _clamp_0_5(x: Any) -> float:
    try:
        v = float(x)
    except Exception:
        return 0.0
    return max(0.0, min(5.0, v))

def judge_once(
    judge_model: str,
    temperature: float,
    user_query: str,
    llm_response: str,
    expected_response: str,
) -> Tuple[float, float, float, float, float, str]:
    """
    Run a single LLM-as-judge evaluation and return the five metrics + raw model output.
    Cached by inputs to avoid re-charging on reruns.
    """
    chat = ChatDatabricks(model=judge_model, temperature=temperature)
    payload = {
        "user_query": user_query or "",
        "assistant_response": llm_response or "",
        "expected_response": expected_response or "",
    }
    msg = json.dumps(payload, ensure_ascii=False)
    ai = chat.invoke([SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=msg)])
    content = getattr(ai, "content", "") or ""

    parsed = _clean_and_parse_json(content)
    c = _clamp_0_5(parsed.get("correctness"))
    r = _clamp_0_5(parsed.get("relevance"))
    comp = _clamp_0_5(parsed.get("completeness"))
    f = _clamp_0_5(parsed.get("faithfulness"))
    conc = _clamp_0_5(parsed.get("conciseness"))
    return c, r, comp, f, conc, content
#---------------------------------------------------------------------
#query, sql_query, expected_output,agent, model
st.header("Feedback Analytics")


if st.button("Connect to Unity Catalog", use_container_width=True):

    with st.spinner("Reading table from Unity Catalog…"):
        try:
            df = fetch_uc_table(FULL_TABLE_NAME)
            # normalize feedback_type column to text + preserve original raw for display
            if "feedback_types" not in df.columns:
                st.warning("Column 'feedback_type' not found; creating empty list.")
                df["feedback_types"] = [[] for _ in range(len(df))]
            # Keep a text version for SQLite friendliness
            df["feedback_types"] = df["feedback_types"].apply(_to_list)
            df["feedback_types_text"] = df["feedback_types"].apply(lambda xs: json.dumps(xs))
            # Normalize the data and create a thumps column
            df = _normalized_updown(df)
            # Generate approval rate column
            df["approval"] = (df["thumbs"] == "up").astype(int)
            # Process the date time columns
            # Parse datetime columns if present and compute response duration in seconds
            for _col in ["query_request_time", "response_time"]:
                if _col in df.columns:
                    df[_col] = pd.to_datetime(df[_col], errors="coerce")
            if "query_request_time" in df.columns and "response_time" in df.columns:
                df["response_duration_s"] = (df["response_time"] - df["query_request_time"]).dt.total_seconds()
            
            
            
            st.session_state["raw_df"] = df
            st.success(f"Loaded {len(df):,} rows from {FULL_TABLE_NAME}")
        except Exception as e:
            st.exception(e)

raw_df: Optional[pd.DataFrame] = st.session_state.get("raw_df")

if raw_df is not None:
    st.subheader("Preview")
    st.dataframe(raw_df.head(50), use_container_width=True)


at1, at2, at3 = st.tabs(["Quantitative", "Qualitative", "LLM_as_a_Judge"])
with at1:
        st.caption("Quantitative Visualizations.")

        if raw_df is not None:
            counts = raw_df.groupby(["agent","model","thumbs"], dropna=False).size().reset_index(name="count")
            if not counts.empty:
                fig1 = px.bar(counts, x="agent", y="count", color="thumbs", barmode="group",
                                facet_row="model", title="Count of 👍 vs 👎 by model × version")
                st.plotly_chart(fig1, use_container_width=True)

            
            rt_by_model, rt_by_agent = None, None
            if "response_duration_s" in raw_df.columns and raw_df["response_duration_s"].notna().any():
                rt_by_model = _response_stats(raw_df, "model")
                rt_by_agent = _response_stats(raw_df, "agent")

                #k1, k2 = st.columns(2)
                #k1.metric("duration_per_model", f"{rt_by_model:.2f}")
                #k2.metric("duration_per_agent", f"{rt_by_agent:.2f}")
                c3, c4 = st.columns(2)
                with c3:
                    st.markdown("**By model — counts**")
                    st.dataframe(rt_by_model, use_container_width=True)
                    #st.bar_chart(rt_by_model.set_index("model")[ ["n"] ])
                    st.markdown("**By model — mean seconds**")
                    st.bar_chart(rt_by_model.set_index("model")[ ["mean_s"] ])
                with c4:
                    st.markdown("**By agent — counts**")
                    st.dataframe(rt_by_agent, use_container_width=True)
                    #st.bar_chart(rt_by_agent.set_index("agent")[ ["n"] ])
                    st.markdown("**By agent — mean seconds**")
                    st.bar_chart(rt_by_agent.set_index("agent")[ ["mean_s"] ])

            daily_model = (
                raw_df.groupby(["query_request_time","model"], dropna=False)
                   .agg(approvals=("approval","sum"), total=("approval","count"))
                   .reset_index()
            )
            if not daily_model.empty:
                st.dataframe(daily_model, use_container_width=True)
                daily_model["approval_rate"] = daily_model["approvals"] / daily_model["total"]
                fig3 = px.line(
                    daily_model, x="query_request_time", y="approval_rate", color="model",
                    markers=True, title="Approval rate over time by model"
                )
                fig3.update_xaxes(title_font=dict(  weight='bold'),
                 tickfont=dict( weight='bold'))
                fig3.update_yaxes(title_font=dict(  weight='bold'),
                     tickfont=dict(  weight='bold'))
                fig3.update_layout(legend=dict(font=dict( weight='bold')))
                st.plotly_chart(fig3, use_container_width=True)

            daily_agent = (
                raw_df.groupby(["query_request_time","agent"], dropna=False)
                   .agg(approvals=("approval","sum"), total=("approval","count"))
                   .reset_index()
            )
            if not daily_agent.empty:
                st.dataframe(daily_agent, use_container_width=True)
                daily_agent["approval_rate"] = daily_agent["approvals"] / daily_agent["total"]
                fig4 = px.line(
                    daily_agent, x="query_request_time", y="approval_rate", color="agent",
                    markers=True, title="Approval rate over time by agent"
                )
                fig4.update_xaxes(title_font=dict( weight='bold'),
                 tickfont=dict(weight='bold'))
                fig4.update_yaxes(title_font=dict( weight='bold'),
                     tickfont=dict( weight='bold'))
                fig4.update_layout(legend=dict(font=dict( weight='bold')))
                st.plotly_chart(fig4, use_container_width=True)
                

with at2:
        st.caption("Aggregated insights from negative feedback.")
        
       
        if raw_df is not None:
            dff = raw_df[['feedback_text','feedback_types','expected_output','model']]
            dff = dff.rename(columns={'feedback_text':'custom_feedback',
                                    'feedback_types':'reason',
                                    'expected_output':'expected',
                                    'model':'model'})
            parsed_reasons = dff['reason'].apply(_parse_reasons_any)
            # Pull columns safely
            txt = dff['custom_feedback'].astype(str)
            exp = dff['expected'].astype(str) if ('expected' != "(none)") else pd.Series([""] * len(dff))
            mdl = dff['model'].astype(str) if ('model' != "(none)") else pd.Series([""] * len(dff))

            out_sev, out_act = [], []
            for i in range(len(dff)):
                bundle = {
                    "reasons": parsed_reasons.iloc[i] or [],
                    "custom_feedback": txt.iloc[i] or "",
                    "expected": exp.iloc[i] or "",
                    "model": mdl.iloc[i] or "",
                }
                res = analyze_kpis(bundle, LLM_ENDPOINT_NAME if LLM_ENDPOINT_NAME.strip() else None)
                out_sev.append(float(res.get("severity", 0.5)))
                out_act.append(float(res.get("actionability", 0.5)))

            df_out = dff.copy()
            df_out["severity"] = out_sev
            df_out["actionability"] = out_act

            # KPIs
            total_feedback = len(df_out)
            avg_severity = float(df_out["severity"].mean()) if total_feedback else 0.0
            avg_actionability = float(df_out["actionability"].mean()) if total_feedback else 0.0
            
            top_model = df_out['model'].mode(dropna=True).iloc[0]
           

            k1, k2, k3 = st.columns(3)
            k1.metric("total_feedback", total_feedback)
            k2.metric("avg_severity", f"{avg_severity:.2f}")
            k3.metric("avg_actionability", f"{avg_actionability:.2f}")
            st.metric("top_model", top_model)

            st.write("### Results")
            st.dataframe(df_out, use_container_width=True)

            # Quantitative Metrics

            cat_counts, counts_model, counts_agent = _category_counts(raw_df)
            #st.dataframe(exploded, use_container_width=True)
            #st.dataframe(cat_counts, use_container_width=True)
            #st.dataframe(counts_model, use_container_width=True)
            #st.dataframe(counts_agent, use_container_width=True)
            st.markdown("**Summary Negative Feedback**")
            st.bar_chart(cat_counts.set_index("category"))
            st.markdown("**Feedback by Model**")
            st.bar_chart(counts_model.set_index("category"))
            st.markdown("**Feedback by Agent**")
            st.bar_chart(counts_agent.set_index("category"))

with at3:
    st.caption("LLM to judge SQL Queries vs Expected Queries")
    if raw_df is not None:
        required_cols = ["query", "sql_query", "expected_output", "model"]
        judge_df = raw_df[required_cols]

        # Prepare output columns
        out_cols = METRICS + ["judge_raw"]
        for c in out_cols:
            if c not in judge_df.columns:
                judge_df[c] = None

        progress = st.progress(0.0, text="Scoring…")
        total = len(judge_df)

        for idx, row in judge_df.iterrows():
            uq = str(row.get("query", "") or "")
            ar = str(row.get("sql_query", "") or "")
            ex = str(row.get("expected_output", "") or "")

            try:
                c, r, comp, f, conc, raw_out = judge_once(LLM_ENDPOINT_NAME, TEMPERATURE, uq, ar, ex)
            except Exception as e:
                c = r = comp = f = conc = 0.0
                raw_out = f"(error) {e}"

            judge_df.at[idx, "correctness"] = c
            judge_df.at[idx, "relevance"] = r
            judge_df.at[idx, "completeness"] = comp
            judge_df.at[idx, "faithfulness"] = f
            judge_df.at[idx, "conciseness"] = conc
            judge_df.at[idx, "judge_raw"] = raw_out

            if total:
                progress.progress((idx + 1) / total, text=f"Scored {idx + 1}/{total}")

        progress.empty()
        st.success("Done! See results and visualizations below.")

        # Summary metrics
        st.write("### Dataset Averages (0–5)")
        avg = (
            judge_df[METRICS]
            .astype(float)
            .mean()
            .to_frame("average")
            .T
        )
        st.dataframe(avg, use_container_width=True)

        # ---------- Visualizations per model ----------
        st.write("### Visualizations per Model")
        # Filter controls
        models_all = sorted(judge_df["model"].dropna().astype(str).unique().tolist())
        selected_models = st.multiselect("Filter models", models_all, default=models_all)

        df_viz = judge_df[judge_df["model"].astype(str).isin(selected_models)].copy()
        if df_viz.empty:
            st.info("No rows after filter.")
        else:
            # Long format for plotting
            df_long = df_viz.melt(
                id_vars=["model"], value_vars=METRICS, var_name="metric", value_name="score"
            )
            df_long["score"] = pd.to_numeric(df_long["score"], errors="coerce")
            df_long = df_long.dropna(subset=["score"])

            # 1) Grouped bar — average score per model by metric
            st.markdown("**Average score per model × metric**")
            avg_long = df_long.groupby(["model", "metric"], as_index=False)["score"].mean()
            fig1 = px.bar(
                avg_long,
                x="model",
                y="score",
                color="metric",
                barmode="group",
                category_orders={"metric": METRICS},
                range_y=[0, 5],
                title="Average judge scores per model",
            )
            st.plotly_chart(fig1, use_container_width=True)

            # 2) Boxplot — distribution per model, faceted by metric
            st.markdown("**Score distributions (boxplot) by model, faceted by metric**")
            fig2 = px.box(
                df_long,
                x="model",
                y="score",
                color="model",
                facet_col="metric",
                category_orders={"metric": METRICS, "model": models_all},
                range_y=[0, 5],
                title="Distributions of scores by model and metric",
            )
            st.plotly_chart(fig2, use_container_width=True)

            # 3) Heatmap — average score (metric × model)
            st.markdown("**Heatmap of average scores (metric × model)**")
            pivot = df_long.pivot_table(index="metric", columns="model", values="score", aggfunc="mean")
            # Ensure metric order
            pivot = pivot.reindex(METRICS)
            fig3 = px.imshow(
                pivot,
                text_auto=True,
                aspect="auto",
                origin="upper",
                color_continuous_scale="Blues",
                range_color=[0, 5],
                labels=dict(color="avg score"),
                title="Average scores heatmap",
            )
            st.plotly_chart(fig3, use_container_width=True)

            # 4) Count of evaluated rows per model
            st.markdown("**Count of evaluated rows per model**")
            counts = (
                df_viz.groupby("model", as_index=False)
                .size()
                .rename(columns={"size": "count"})
            )
            fig4 = px.bar(
                counts,
                x="model",
                y="count",
                text="count",
                title="Evaluated rows per model",
            )
            fig4.update_traces(textposition="outside")
            st.plotly_chart(fig4, use_container_width=True)

        st.write("### Scored Rows")
        st.dataframe(judge_df, use_container_width=True)
            
                