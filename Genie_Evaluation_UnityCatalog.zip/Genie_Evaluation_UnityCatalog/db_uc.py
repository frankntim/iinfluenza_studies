
"""Databricks Unity Catalog DB helpers (Delta tables).
Requires: pip install databricks-sql-connector
"""
from __future__ import annotations
import os
from dataclasses import dataclass
from typing import Optional
from databricks import sql

@dataclass
class UCConfig:
    server_hostname: str
    http_path: str
    access_token: str
    catalog: str
    schema: str

def get_conn(cfg: UCConfig):
    return sql.connect(
        server_hostname=cfg.server_hostname,
        http_path=cfg.http_path,
        access_token=cfg.access_token,
    )

def fq(table: str, catalog: str, schema: str) -> str:
    return f"`{catalog}`.`{schema}`.`{table}`"

def execmany(conn, stmts):
    # Execute multiple statements (DDL/DML); Databricks autocommits by default
    with conn.cursor() as cur:
        for s in stmts:
            cur.execute(s)

def create_tables(conn, catalog: str, schema: str):
    # Ensure catalog/schema exist (no-op if already exist)
    stmts = [
        #f"CREATE CATALOG IF NOT EXISTS `{catalog}`",
        #f"CREATE SCHEMA IF NOT EXISTS `{catalog}`.`{schema}`",
        # quantitative_data
        f"""            CREATE TABLE IF NOT EXISTS {fq('quantitative_data', catalog, schema)} (
            id BIGINT GENERATED ALWAYS AS IDENTITY,
            timestamp TIMESTAMP,
            thumbs STRING,
            user_query STRING,
            llm_response STRING,
            expected_response STRING,
            model STRING,
            software_version STRING,
            input_tokens INT,
            output_tokens INT,
            total_tokens INT,
            user_id STRING,
            vectorization_version STRING,
            request_id STRING
        ) USING DELTA
        """.strip(),
        # quantitative_analytics
        f"""            CREATE TABLE IF NOT EXISTS {fq('quantitative_analytics', catalog, schema)} (
            id BIGINT GENERATED ALWAYS AS IDENTITY,
            quant_id BIGINT,
            timestamp TIMESTAMP,
            judge_score DOUBLE,
            judge_label STRING,
            judge_rationale STRING,
            judge_model STRING,
            correctness DOUBLE,
            relevance DOUBLE,
            faithfulness DOUBLE,
            completeness DOUBLE,
            conciseness DOUBLE
        ) USING DELTA
        """.strip(),
        # qualitative_data
        f"""            CREATE TABLE IF NOT EXISTS {fq('qualitative_data', catalog, schema)} (
            id BIGINT GENERATED ALWAYS AS IDENTITY,
            quant_id BIGINT,
            timestamp TIMESTAMP,
            custom_feedback STRING,
            flags_inaccurate INT,
            flags_incomplete INT,
            flags_unclear INT,
            flags_irrelevant INT,
            flags_other INT,
            severity DOUBLE,
            actionability DOUBLE,
            model STRING,
            software_version STRING,
            user_id STRING,
            vectorization_version STRING
        ) USING DELTA
        """.strip(),
        # qualitative_analytics
        f"""            CREATE TABLE IF NOT EXISTS {fq('qualitative_analytics', catalog, schema)} (
            id BIGINT GENERATED ALWAYS AS IDENTITY,
            timestamp TIMESTAMP,
            n_negative INT,
            counts_inaccurate INT,
            counts_incomplete INT,
            counts_unclear INT,
            counts_irrelevant INT,
            counts_other INT,
            top_themes STRING,
            judge_model STRING
        ) USING DELTA
        """.strip(),
    ]
    execmany(conn, stmts)

def ensure_columns(conn, catalog: str, schema: str):
    # Add columns that might be missing on older datasets
    with conn.cursor() as cur:
        # quantitative_analytics metrics (if missing)
        cur.execute(f"DESCRIBE TABLE {fq('quantitative_analytics', catalog, schema)}")
        cols = {row[0] for row in cur.fetchall()}
        for col, typ in [
            ("correctness", "DOUBLE"),
            ("relevance", "DOUBLE"),
            ("faithfulness", "DOUBLE"),
            ("completeness", "DOUBLE"),
            ("conciseness", "DOUBLE"),
        ]:
            if col not in cols:
                cur.execute(f"ALTER TABLE {fq('quantitative_analytics', catalog, schema)} ADD COLUMNS ({col} {typ})")

        # qualitative_data severity/actionability (if missing)
        cur.execute(f"DESCRIBE TABLE {fq('qualitative_data', catalog, schema)}")
        qcols = {row[0] for row in cur.fetchall()}
        for col, typ in [
            ("severity", "DOUBLE"),
            ("actionability", "DOUBLE"),
            ("user_id", "STRING"),
            ("vectorization_version", "STRING"),
        ]:
            if col not in qcols:
                cur.execute(f"ALTER TABLE {fq('qualitative_data', catalog, schema)} ADD COLUMNS ({col} {typ})")

        # quantitative_data user/vectorization/request_id (if missing)
        cur.execute(f"DESCRIBE TABLE {fq('quantitative_data', catalog, schema)}")
        tcols = {row[0] for row in cur.fetchall()}
        for col, typ in [
            ("user_id", "STRING"),
            ("vectorization_version", "STRING"),
            ("request_id", "STRING"),
        ]:
            if col not in tcols:
                cur.execute(f"ALTER TABLE {fq('quantitative_data', catalog, schema)} ADD COLUMNS ({col} {typ})")
