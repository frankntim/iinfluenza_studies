from __future__ import annotations

import os
import ast
import re
import json
import time
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import streamlit as st
from sqlalchemy import create_engine, text
from dotenv import load_dotenv
import plotly.express as px
from datetime import date
from databricks import sql as dbsql


########################################### Definitions
# Map short flags to canonical reason strings the analyzer expects
CATEGORY_CANON = ["inaccurate", "irrelevant", "incomplete", "unclear", "other"]
METRICS: List[str] = ["correctness", "relevance", "completeness", "faithfulness", "conciseness"]

_CANON = {
    "inaccurate": "Information was inaccurate",
    "incomplete": "Response was incomplete",
    "unclear": "Response was unclear",
    "irrelevant": "Response was not relevant",
    "other": "Other",
}

# -----------------------------
# LLM judging
# -----------------------------
JUDGE_SYSTEM_PROMPT = (
    "You are evaluating user-written feedback about AI assistant/model outputs. "
    "Classify and rate each feedback snippet for usefulness and map it to a canonical issue category. "
    "Only reply with strict JSON using the provided schema."
)

JUDGE_USER_TMPL = (
    '''\
Task: Judge the following feedback.

Rules:
- Choose category from: {categories}.
- Define useful as: specific, actionable, and relevant to improving the model or the answer.
- Be strict: generic or venting comments are not useful.
- Return ONLY valid JSON with keys exactly as below (no trailing commentary):
  {{
    "category": "inaccurate|irrelevant|incomplete|unclear|other",
    "usefulness": "useful|not_useful",
    "actionability": 1-5,
    "specificity": 1-5,
    "sentiment": -1 to 1,
    "severity": 1-5,
    "confidence": 0-1,
    "summary": "one-sentence rationale",
    "suggested_rewrite": "rewrite the feedback to be more actionable (keep it brief)"
  }}

Feedback:
"""{text}"""
    '''
)

# ---------- Prompt used for every evaluation ----------
SYSTEM_PROMPT = (
    "You are a strict but fair evaluator. Score the ASSISTANT response with respect to the USER query "
    "and, if provided, an EXPECTED response. Use the following 0–5 float metrics:\n"
    "• correctness: factual accuracy vs the expected answer or domain knowledge\n"
    "• relevance: how well the answer addresses the user’s query\n"
    "• completeness: whether key steps/details are covered (not missing important parts)\n"
    "• faithfulness: grounded in the input/expected content; no hallucinations\n"
    "• conciseness: avoids rambling while retaining necessary information\n\n"
    "Rules:\n"
    "- If an expected response is provided, evaluate primarily against it.\n"
    "- Otherwise, evaluate the assistant response directly against the user query.\n"
    "- Return ONLY valid JSON, no Markdown or commentary. Use this exact schema:\n"
    "{\n"
    '  \"correctness\": number (0-5),\n'
    '  \"relevance\": number (0-5),\n'
    '  \"completeness\": number (0-5),\n'
    '  \"faithfulness\": number (0-5),\n'
    '  \"conciseness\": number (0-5)\n'
    "}"
)


#################################################
# Connection 1
def _connect_uc(host: str, path: str, token: str) -> Optional[Any]:
    if dbsql is None:
        return None
    #host = DATABRICKS_HOST_BASE #os.getenv("DATABRICKS_HOST")
    #path = DATABRICKS_HTTP_PATH #os.getenv("DATABRICKS_HTTP_PATH")
    #token = DATABRICKS_API_KEY #os.getenv("DATABRICKS_TOKEN")
    if not (host and path and token):
        return None
    try:
        return dbsql.connect(server_hostname=host, http_path=path, access_token=token)
    except Exception:  # pragma: no cover
        return None


def fetch_uc_table(fully_qualified_table: str, host: str, path: str, token: str,limit: Optional[int] = None) -> pd.DataFrame:
    """Read Unity Catalog table via Databricks SQL connector.
    Expected columns: vote, feedback_type, feedback_text, agent, model
    """
    conn_obj = _connect_uc(host, path, token)
    if conn_obj is None:
        raise RuntimeError(
            "Could not connect to Databricks SQL. Ensure DATABRICKS_HOST, DATABRICKS_HTTP_PATH, DATABRICKS_TOKEN are set and 'databricks-sql-connector' installed."
        )
    q = f"SELECT vote, feedback_types, feedback_text,  query, sql_query, expected_output,agent, model, query_request_time, response_time FROM {fully_qualified_table}"
    if limit:
        q += f" LIMIT {int(limit)}"
    with conn_obj:
        cur = conn_obj.cursor()
        cur.execute(q)
        rows = cur.fetchall()
        cols = [c[0] for c in cur.description]
    df = pd.DataFrame(rows, columns=cols)

    # Format the returned dataset
    if df is not None:
        # normalize feedback_type column to text + preserve original raw for display
        if "feedback_types" not in df.columns:
            st.warning("Column 'feedback_type' not found; creating empty list.")
            df["feedback_types"] = [[] for _ in range(len(df))]
        # Keep a text version for SQLite friendliness
        df["feedback_types"] = df["feedback_types"].apply(_to_list)
        df["feedback_types_text"] = df["feedback_types"].apply(lambda xs: json.dumps(xs))
        # Normalize the data and create a thumps column
        df = _normalized_updown(df)
        # Generate approval rate column
        df["approval"] = (df["thumbs"] == "up").astype(int)
        # Process the date time columns
        # Parse datetime columns if present and compute response duration in seconds
        for _col in ["query_request_time", "response_time"]:
            if _col in df.columns:
                df[_col] = pd.to_datetime(df[_col], errors="coerce")
        if "query_request_time" in df.columns and "response_time" in df.columns:
            df["response_duration_s"] = (df["response_time"] - df["query_request_time"]).dt.total_seconds()

    return df

# Connection 2
def fq_name(catalog: str, schema: str, table: str) -> str:
    """Fully-qualified table name with backticks."""
    return f"`{catalog}`.`{schema}`.`{table}`"


def _fetch_df(cur) -> pd.DataFrame:
    """Fetch all rows from a DB-API cursor into a pandas DataFrame."""
    rows = cur.fetchall()
    cols = [d[0] for d in cur.description] if cur.description else []
    return pd.DataFrame.from_records(rows, columns=cols)


def _build_query_and_params(
    fqn: str,
    ts_col: str,
    start_dt: datetime,
    end_dt: datetime,
    limit: int,
) -> Tuple[str, List]:
    """
    Build parameterized SQL:
      SELECT * FROM fqn
      WHERE ts_col >= ? AND ts_col <= ?
      ORDER BY ts_col
      LIMIT <int>
    """
    start_s = start_dt.strftime("%Y-%m-%d %H:%M:%S")
    end_s = end_dt.strftime("%Y-%m-%d %H:%M:%S")

    where = [f"{ts_col} >= ?", f"{ts_col} <= ?"]
    params: List = [start_s, end_s]

    where_sql = " AND ".join(where)

    sql = (
        f"SELECT * FROM {fqn} "
        f"WHERE {where_sql} "
        f"ORDER BY {ts_col} "
        f"LIMIT {int(limit)}"
    )
    return sql, params

def get_datafrom_uc(fqn, ts_col, dt_from, dt_to, max_rows, server_hostname, http_path, access_token):

    df = pd.DataFrame()
    query, params = _build_query_and_params(
            fqn=fqn,
            ts_col=ts_col,
            start_dt=dt_from,
            end_dt=dt_to,
            limit=int(max_rows),
        )

    with dbsql.connect(
        server_hostname=server_hostname.strip(),
        http_path=http_path.strip(),
        access_token=access_token.strip(),
    ) as conn:
        with conn.cursor() as cur:
            cur.execute(query, params)
            df = _fetch_df(cur)

            if df is not None:
                # normalize feedback_type column to text + preserve original raw for display
                if "feedback_types" not in df.columns:
                    st.warning("Column 'feedback_type' not found; creating empty list.")
                    df["feedback_types"] = [[] for _ in range(len(df))]
                # Keep a text version for SQLite friendliness
                df["feedback_types"] = df["feedback_types"].apply(_to_list)
                df["feedback_types_text"] = df["feedback_types"].apply(lambda xs: json.dumps(xs))
                # Normalize the data and create a thumps column
                df = _normalized_updown(df)
                # Generate approval rate column
                df["approval"] = (df["thumbs"] == "up").astype(int)
                # Process the date time columns
                # Parse datetime columns if present and compute response duration in seconds
                for _col in ["query_request_time", "response_time"]:
                    if _col in df.columns:
                        df[_col] = pd.to_datetime(df[_col], errors="coerce")
                if "query_request_time" in df.columns and "response_time" in df.columns:
                    df["response_duration_s"] = (df["response_time"] - df["query_request_time"]).dt.total_seconds()

    return df


###

def _to_list(v: Any) -> List[str]:
    """Normalize feedback_type to a list of lowercased strings.
    Accepts list/tuple, JSON string, Python list repr string, CSV string, or None.
    """
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return []
    if isinstance(v, (list, tuple, set)):
        raw = list(v)
    elif isinstance(v, str):
        s = v.strip()
        if s.startswith("[") and s.endswith("]"):
            try:
                raw = ast.literal_eval(s)
                if not isinstance(raw, list):
                    raw = [str(raw)]
            except Exception:
                # Try JSON
                try:
                    raw = json.loads(s)
                    if not isinstance(raw, list):
                        raw = [str(raw)]
                except Exception:
                    # Fallback: comma-separated
                    raw = [p.strip() for p in s.split(",") if p.strip()]
        else:
            raw = [p.strip() for p in s.split(",") if p.strip()]
    else:
        raw = [str(v)]
    # Canonicalize + map unknowns to 'other'
    out: List[str] = []
    for x in raw:
        xlow = str(x).strip().lower()
        if xlow in CATEGORY_CANON:
            out.append(xlow)
        else:
            # attempt light normalization
            if "inaccur" in xlow:
                out.append("inaccurate")
            elif "irrel" in xlow:
                out.append("irrelevant")
            elif "incompl" in xlow:
                out.append("incomplete")
            elif "unclear" in xlow or "confus" in xlow or "ambig" in xlow:
                out.append("unclear")
            else:
                out.append("other")
    return out

def _normalized_updown(df: pd.DataFrame):
    # ensure vote normalized to {'up','down'}
    vmap = {
        "up": "up",
        "down": "down",
        "thumbs_up": "up",
        "thumbs_down": "down",
        "1": "up",
        "0": "down",
        "true": "up",
        "false": "down",
        "dummy": "up"
    }
    vote_norm = (
        df["vote"].astype(str).str.strip().str.lower().map(lambda x: vmap.get(x, x))
    )
    df = df.assign(thumbs=vote_norm)
    return df




def _category_counts(df: pd.DataFrame) -> pd.DataFrame:
    exploded = df.assign(_ft=df["feedback_types_text"].apply(_to_list)).explode("_ft")
    exploded = exploded[~exploded["_ft"].isna()]
    counts = (
        exploded.groupby("_ft").size().reindex(CATEGORY_CANON, fill_value=0).reset_index()
    )
    counts.columns = ["category", "count"]

    counts_model = (
        exploded.groupby(["model","_ft"], as_index=False).agg({'model':len})
    )
    counts_model.columns = ["category", "count"]

    counts_agent = (
        exploded.groupby(["agent","_ft"], as_index=False).agg({'agent':len})
    )
    counts_agent.columns = ["category", "count"]

    counts_all = (
        exploded.groupby(["model","agent","_ft"], as_index=False).agg({'model':len, 'agent':len})
    )

    return counts, counts_model, counts_agent, exploded





def _response_stats(df: pd.DataFrame, group_col: str) -> pd.DataFrame:
    """Aggregate response duration (in seconds) by a column (model or agent).
    Returns columns: group_col, n, mean_s, median_s, p95_s
    """
    if group_col not in df.columns or "response_duration_s" not in df.columns:
        return pd.DataFrame(columns=[group_col, "n", "mean_s", "median_s", "p95_s"])
    s = df[[group_col, "response_duration_s"]].copy()
    s = s[pd.notna(s["response_duration_s"])].copy()
    if s.empty:
        return pd.DataFrame(columns=[group_col, "n", "mean_s", "median_s", "p95_s"])
    g = s.groupby(group_col)["response_duration_s"]
    out = g.agg(
        n="count",
        mean_s="mean",
        median_s="median",
        p95_s=lambda x: x.quantile(0.95),
    ).reset_index()
    return out.sort_values(["median_s", "n"], ascending=[True, False])


def _find_col(df: pd.DataFrame, candidates: List[str]) -> Optional[str]:
    """Return the first matching (case-insensitive) column name in the dataframe, or None."""
    lower_map = {c.lower(): c for c in df.columns}
    for name in candidates:
        if name in lower_map:
            return lower_map[name]
    return None





def _dedup_keep_order(items: List[str]) -> List[str]:
    seen = set()
    out = []
    for x in items:
        if x not in seen:
            out.append(x)
            seen.add(x)
    return out


def _normalize_token(tok: str) -> Optional[str]:
    """Map any token to one of the canonical short keys if possible."""
    t = (tok or "").strip().lower()
    for short in _CANON.keys():
        if t == short or short in t:
            return short
    return None


def _parse_reasons_from_string(s: str) -> List[str]:
    """Parse reasons from a delimited string into canonical labels."""
    if not isinstance(s, str) or not s.strip():
        return []
    raw = [tok.strip() for tok in re.split(r"[;,|]", s) if tok.strip()]
    shorts = []
    for tok in raw:
        norm = _normalize_token(tok)
        if norm:
            shorts.append(norm)
    return [_CANON[x] for x in _dedup_keep_order(shorts)]


def _parse_reasons_any(val: Any) -> List[str]:
    """
    Accepts:
      - Python list (already parsed)
      - JSON list string (preferred)
      - Delimited string
    Returns canonical reason strings.
    """
    # Case 1: already a Python list
    if isinstance(val, list):
        shorts = []
        for tok in val:
            norm = _normalize_token(str(tok))
            if norm:
                shorts.append(norm)
        return [_CANON[x] for x in _dedup_keep_order(shorts)]

    # Case 2: JSON list in a string
    if isinstance(val, str):
        s = val.strip()
        if s.startswith("[") and s.endswith("]"):
            # Be forgiving: convert single quotes to double quotes if present
            s_norm = s.replace("'", '"')
            try:
                arr = json.loads(s_norm)
                if isinstance(arr, list):
                    shorts = []
                    for tok in arr:
                        norm = _normalize_token(str(tok))
                        if norm:
                            shorts.append(norm)
                    return [_CANON[x] for x in _dedup_keep_order(shorts)]
            except Exception:
                # fall back to delimited
                pass
        # Case 3: delimited string
        return _parse_reasons_from_string(s)

    # Unknown -> empty
    return []

# LLM as A Judge-> Compare Results with Expected
def _clean_and_parse_json(s: str) -> Dict[str, Any]:
    """
    Try to parse JSON; if the model adds extra text, extract the first {...} block.
    """
    s = (s or "").strip()
    try:
        return json.loads(s)
    except Exception:
        pass

    # Try to extract JSON object with a naive brace match
    try:
        start = s.find("{")
        end = s.rfind("}")
        if start != -1 and end != -1 and end > start:
            candidate = s[start : end + 1]
            return json.loads(candidate)
    except Exception:
        pass

    # Try to remove code fencing/backticks if any
    s2 = re.sub(r"^```(?:json)?|```$", "", s.strip(), flags=re.MULTILINE).strip()
    try:
        return json.loads(s2)
    except Exception:
        pass

    # Failed
    return {}

def _clamp_0_5(x: Any) -> float:
    try:
        v = float(x)
    except Exception:
        return 0.0
    return max(0.0, min(5.0, v))

def judge_once(
    judge_model: str,
    temperature: float,
    user_query: str,
    llm_response: str,
    expected_response: str,
) -> Tuple[float, float, float, float, float, str]:
    """
    Run a single LLM-as-judge evaluation and return the five metrics + raw model output.
    Cached by inputs to avoid re-charging on reruns.
    """
    chat = ChatDatabricks(model=judge_model, temperature=temperature)
    payload = {
        "user_query": user_query or "",
        "assistant_response": llm_response or "",
        "expected_response": expected_response or "",
    }
    msg = json.dumps(payload, ensure_ascii=False)
    ai = chat.invoke([SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=msg)])
    content = getattr(ai, "content", "") or ""

    parsed = _clean_and_parse_json(content)
    c = _clamp_0_5(parsed.get("correctness"))
    r = _clamp_0_5(parsed.get("relevance"))
    comp = _clamp_0_5(parsed.get("completeness"))
    f = _clamp_0_5(parsed.get("faithfulness"))
    conc = _clamp_0_5(parsed.get("conciseness"))
    return c, r, comp, f, conc, content


