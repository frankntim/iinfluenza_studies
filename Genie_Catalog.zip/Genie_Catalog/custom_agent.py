import requests
import os
import re
import pandas as pd
from langchain_community.agent_toolkits import create_sql_agent
from langchain.chains import create_sql_query_chain
from langchain_community.utilities import SQLDatabase
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)

# Set these with your actual values
DATABRICKS_TOKEN =  "dapi6b0fea77633e3dad824eac87f63d6081"
DATABRICKS_HOST = "https://amgen-ai-dev.cloud.databricks.com"
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
WAREHOUSE_ID = "792838787cf72ed7"


llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)



def call_sql_agent(catalog, schema, table_list, user_query):
    

   

    #user_query = "Aggregate analyte by stresu"

    chain = create_sql_query_chain(llm, db)
    response = chain.invoke({"question": user_query})
    sql_match = re.search(r"```sql\n(.*?)```", str(response), re.DOTALL)
    cleaned_response = re.sub(r"```sql\s*.*?```", "", str(response), flags=re.DOTALL | re.IGNORECASE).strip()
    sql_query = sql_match.group(1).strip() if sql_match else None
    if sql_query is not None:
        result_df = pd.read_sql_query(sql_query, db._engine)
    else:
        result_df = None
    return cleaned_response, sql_query, result_df
    

