# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------

# MAGIC %pip install -U -qqq mlflow langgraph==0.3.4 langchain-experimental==0.3.4 plotly==5.24.1  langchain_community databricks-langchain databricks-agents matplotlib lifelines langchain-openai plotnine statsmodels databricks-sql-connector  databricks-sqlalchemy
# MAGIC
# MAGIC
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

import requests
import os

# LangChain imports
from langchain_community.utilities import SQLDatabase
from langchain.chains import create_sql_query_chain
#from langchain.agents import create_sql_agent
from langchain_community.agent_toolkits import create_sql_agent
from langchain_openai import ChatOpenAI
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
#from langchain_community.tools.unity_catalog.tool import UnityCatalogTool
from langchain.chains import create_sql_query_chain
from langchain.agents import create_sql_agent
from langchain_openai import ChatOpenAI


# Set these with your actual values
DATABRICKS_TOKEN =  "dapi6b0fea77633e3dad824eac87f63d6081"
DATABRICKS_HOST = "https://amgen-ai-dev.cloud.databricks.com"
#OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

HEADERS = {
    "Authorization": f"Bearer {DATABRICKS_TOKEN}",
    "Content-Type": "application/json"
}

# COMMAND ----------



# COMMAND ----------




# COMMAND ----------

catalog = 'ai_dev'
schema = 'aiwb_115_cbd_sandbox'
response = requests.get(f"{DATABRICKS_HOST}/api/2.1/unity-catalog/tables?catalog_name={catalog}&schema_name={schema}", headers=HEADERS)
tables = response.json().get("tables", [])
#tables
table = 'ai_dev.aiwb_115_cbd_sandbox.amg427_20170528_ne_cb_clone'

# COMMAND ----------



# COMMAND ----------


#db = SQLDatabase.from_uri(db_uri, include_tables=selected_tables, schema=schema)
db = SQLDatabase.from_databricks(catalog=catalog, 
                                         schema=schema, 
                                         include_tables=selected_tables, 
                                         api_token=DATABRICKS_TOKEN,
                                         warehouse_id= "792838787cf72ed7")



# COMMAND ----------

LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)


user_query = "Aggregate analyte by stresu"

chain = create_sql_query_chain(llm, db)
response = chain.invoke({"question": user_query})
import re
sql_match = re.search(r"```sql\n(.*?)```", str(response), re.DOTALL)
sql_query = sql_match.group(1).strip() if sql_match else str(response)

# COMMAND ----------

result = db.run(sql_query)

# COMMAND ----------

print(result)

# COMMAND ----------

import pandas as pd
result_df = pd.read_sql_query(sql_query, db._engine)

# COMMAND ----------

result_df

# COMMAND ----------

def call_sql_agent(catalog, schema, table_list, user_query):
    # Set these with your actual values
    DATABRICKS_TOKEN =  "dapi6b0fea77633e3dad824eac87f63d6081"
    DATABRICKS_HOST = "https://amgen-ai-dev.cloud.databricks.com"
    LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
    WAREHOUSE_ID = "792838787cf72ed7"

    
    llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

    HEADERS = {
        "Authorization": f"Bearer {DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }

    db = SQLDatabase.from_databricks(catalog=catalog, 
                                         schema=schema, 
                                         include_tables=selected_tables, 
                                         api_token=DATABRICKS_TOKEN,
                                         warehouse_id= WAREHOUSE_ID)
    

    
    llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)


    #user_query = "Aggregate analyte by stresu"

    chain = create_sql_query_chain(llm, db)
    response = chain.invoke({"question": user_query})
    sql_match = re.search(r"```sql\n(.*?)```", str(response), re.DOTALL)
    sql_query = sql_match.group(1).strip() if sql_match else None
    if sql_query is not None:
        result_df = pd.read_sql_query(sql_query, db._engine)
    else:
        result_df = None
    return response, sql_query, result_df
    


# COMMAND ----------

import requests
import os
from custom_agent import call_sql_agent
# LangChain imports
from langchain_community.utilities import SQLDatabase
from langchain.chains import create_sql_query_chain
#from langchain.agents import create_sql_agent
from langchain_community.agent_toolkits import create_sql_agent
from langchain_openai import ChatOpenAI
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from langchain.chains import create_sql_query_chain

from langchain_openai import ChatOpenAI


catalog = 'ai_dev'
schema = 'aiwb_115_cbd_sandbox'
selected_tables = ['amg427_20170528_ne_cb_clone']

user_query = "Describe the dataset"
response, sql_query, result_df = call_sql_agent(catalog, 
                                                schema, 
                                                selected_tables, 
                                                user_query)

# COMMAND ----------

print(response)

# COMMAND ----------

import pandas as pd

# COMMAND ----------

m_options = [{'label': 'ChatGPT 4', 'value': 'project-115-Precision_Medicine_AI_Agent-2'}, {'label': 'LLAMA 4', 'value': 'databricks-llama-4-maverick'}]

# COMMAND ----------

def get_label_by_value(models, target_value):
    for model in models:
        if model["value"] == target_value:
            return model["label"]
        
    return models[0]['label']  # Return the first

# COMMAND ----------

displayed = get_label_by_value(m_options, target_value='databricks-llama-4-maverick')

# COMMAND ----------

displayed