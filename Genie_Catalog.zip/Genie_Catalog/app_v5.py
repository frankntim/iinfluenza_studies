import dash
from dash import html, dcc, Input, Output, State, ctx
import dash_bootstrap_components as dbc
import requests
import os
import re
from sqlalchemy.engine import create_engine
#from langchain_community.utilities.sql_database import SQLDatabase
# LangChain imports
from custom_agent import call_sql_agent
from langchain_community.agent_toolkits import create_sql_agent
from langchain.chains import create_sql_query_chain
from langchain_community.utilities import SQLDatabase
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from langchain_openai import ChatOpenAI
from langchain.schema import HumanMessage
# Set these with your actual values
DATABRICKS_TOKEN =  "dapi6b0fea77633e3dad824eac87f63d6081"
DATABRICKS_HOST = "https://amgen-ai-dev.cloud.databricks.com"
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
WAREHOUSE_ID = "792838787cf72ed7"
DATABRICKS_HTTP_PATH = "/sql/1.0/warehouses/37c05da246f2f4bd"
PORT = 443


LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

catalog = 'ai_dev'
schema = 'aiwb_115_cbd_sandbox'
selected_tables = ['amg427_20170528_ne_cb_clone']



db_uri = (
    f"databricks:https//token:{DATABRICKS_TOKEN}@{DATABRICKS_HOST}:{PORT}"
    f"?http_path={DATABRICKS_HTTP_PATH}"
)
print(db_uri)
#db_uri = databricks+https://<token>@abc.cloud.databricks.com:443/sql/1.0/warehouses/9265c8e0?catalog=customer&schema=chatbot
'''
# Optionally specify catalog/schema/table filters here
db = SQLDatabase.from_uri(
    db_uri,
    include_tables=selected_tables,  # optional: limit to specific tables
    engine_args={"connect_args": {"catalog": catalog, "schema": schema}}
)

# Create the SQLAlchemy engine

engine = create_engine(
    url="databricks+connector://token:{}@{}".format(
        DATABRICKS_TOKEN, DATABRICKS_HOST
    ),
    connect_args={
        "http_path": DATABRICKS_HTTP_PATH,
        "catalog": catalog,
        "schema": schema
    }
)

engine = create_engine(
    url="databricks+connector://token:{}@{}".format(
        DATABRICKS_TOKEN, DATABRICKS_HOST
    ),
    connect_args={
        "http_path": DATABRICKS_HTTP_PATH,
        "catalog": catalog,
        "schema": schema
    }
)

engine = create_engine(
    "databricks+connector",
    connect_args={
        "server_hostname": DATABRICKS_HOST,
        "access_token": DATABRICKS_TOKEN,
        "http_path": DATABRICKS_HTTP_PATH,
        "catalog": catalog,
        "schema": schema
    }
)

# Create the SQLDatabase using the engine
db = SQLDatabase(engine=engine, include_tables=selected_tables)
'''
app = dash.Dash(__name__)
server = app.server

app.layout = html.Div([
    html.H1("LLM Query App"),

    dcc.Textarea(
        id='user-query',
        placeholder='Enter your query here...',
        style={'width': '100%', 'height': 100},
    ),

    html.Button('Submit', id='submit-button', n_clicks=0),

    html.Hr(),

    html.Div(id='response-output', style={'whiteSpace': 'pre-line'})
])

@app.callback(
    Output('response-output', 'children'),
    Input('submit-button', 'n_clicks'),
    State('user-query', 'value'),
    prevent_initial_call=True
)
def get_llm_response(n_clicks, query):
    if not query:
        return "Please enter a query."

    try:
        
        

        #db = SQLDatabase.from_databricks(catalog=catalog, 
        #                                 schema=schema, 
        #                                 include_tables=selected_tables, 
        #                                 api_token=DATABRICKS_TOKEN,
        #                                 warehouse_id= WAREHOUSE_ID)


        #user_query = "Describe the dataset"
        #response, sql_query, result_df = call_sql_agent(catalog, 
        #                                                schema, 
        #                                                selected_tables, 
        #                                                query)
        
        #response = llm([HumanMessage(content=query)])
        response = "God is good all the time"

        return response
    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == '__main__':
    app.run_server(debug=True)