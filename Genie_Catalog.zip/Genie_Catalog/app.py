import dash
from dash import html, dcc, Input, Output, State, ctx
import dash_bootstrap_components as dbc
import requests
import os
import re

# LangChain imports
from custom_agent import call_sql_agent
from langchain_community.agent_toolkits import create_sql_agent
from langchain.chains import create_sql_query_chain
from langchain_community.utilities import SQLDatabase
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)

# Set these with your actual values
DATABRICKS_TOKEN =  "dapi6b0fea77633e3dad824eac87f63d6081"
DATABRICKS_HOST = "https://amgen-ai-dev.cloud.databricks.com"


LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

HEADERS = {
    "Authorization": f"Bearer {DATABRICKS_TOKEN}",
    "Content-Type": "application/json"
}

# App setup
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

app.layout = html.Div([
    dbc.Button("Open Unity Catalog Modal", id="open-modal", n_clicks=0),

    html.Br(),
    html.Div(id="selected-tables-summary", children="No tables selected."),

    dcc.Store(id="selected-tables-store"),

    html.Br(),
    html.Label("Comments or Notes:"),
    dcc.Textarea(
        id='notes-textarea',
        placeholder='Enter your comments here...',
        style={'width': '100%', 'height': 100},
    ),
    html.Br(),
    dbc.Button("Submit", id="submit-button", n_clicks=0, color="success"),
    html.Br(), html.Div(id="query-result-output"),

    dbc.Modal([
        dbc.ModalHeader(dbc.ModalTitle("Unity Catalog Browser")),
        dbc.ModalBody([
            html.Label("Catalog"),
            dcc.Dropdown(id='catalog-dropdown', placeholder="Select Catalog"),

            html.Br(),
            html.Label("Schema"),
            dcc.Dropdown(id='schema-dropdown', placeholder="Select Schema"),

            html.Br(),
            html.Label("Tables"),
            dcc.Dropdown(id='table-dropdown', multi=True, placeholder="Select Tables"),

            html.Br(),
            dbc.Button("Preview Metadata", id="preview-btn", n_clicks=0, color="primary"),
            html.Br(), html.Br(),
            html.Div(id="table-preview-output")
        ]),
        dbc.ModalFooter(
            dbc.Button("Close", id="close-modal", className="ms-auto", n_clicks=0)
        ),
    ], id="catalog-modal", is_open=False),
])


# Toggle modal
@app.callback(
    Output("catalog-modal", "is_open"),
    [Input("open-modal", "n_clicks"), Input("close-modal", "n_clicks")],
    [State("catalog-modal", "is_open")]
)
def toggle_modal(n1, n2, is_open):
    if ctx.triggered_id in ["open-modal", "close-modal"]:
        return not is_open
    return is_open


# Fetch catalogs
@app.callback(
    Output("catalog-dropdown", "options"),
    Input("catalog-modal", "is_open")
)
def load_catalogs(is_open):
    if not is_open:
        return []
    response = requests.get(f"{DATABRICKS_HOST}/api/2.1/unity-catalog/catalogs", headers=HEADERS)
    if response.status_code == 200:
        catalogs = response.json().get("catalogs", [])
        return [{'label': cat['name'], 'value': cat['name']} for cat in catalogs]
    return []


# Fetch schemas based on catalog
@app.callback(
    Output("schema-dropdown", "options"),
    Input("catalog-dropdown", "value")
)
def load_schemas(catalog):
    if not catalog:
        return []
    response = requests.get(f"{DATABRICKS_HOST}/api/2.1/unity-catalog/schemas?catalog_name={catalog}", headers=HEADERS)
    if response.status_code == 200:
        schemas = response.json().get("schemas", [])
        return [{'label': sch['name'], 'value': sch['name']} for sch in schemas]
    return []


# Fetch tables based on schema
@app.callback(
    Output("table-dropdown", "options"),
    [Input("catalog-dropdown", "value"),
     Input("schema-dropdown", "value")]
)
def load_tables(catalog, schema):
    if not catalog or not schema:
        return []
    response = requests.get(f"{DATABRICKS_HOST}/api/2.1/unity-catalog/tables?catalog_name={catalog}&schema_name={schema}", headers=HEADERS)
    if response.status_code == 200:
        tables = response.json().get("tables", [])
        return [{'label': tbl['name'], 'value': tbl['name']} for tbl in tables]
    return []


# Store selected tables in dcc.Store
@app.callback(
    Output("selected-tables-store", "data"),
    Input("table-dropdown", "value")
)
def store_selected_tables(selected):
    return selected or []


# Show selected tables and count
@app.callback(
    Output("selected-tables-summary", "children"),
    Input("selected-tables-store", "data")
)
def update_table_summary(tables):
    if not tables:
        return "No tables selected."
    return html.Div([
        html.Strong(f"{len(tables)} table(s) selected:"),
        html.Ul([html.Li(tbl) for tbl in tables])
    ])


# Preview selected table metadata
@app.callback(
    Output("table-preview-output", "children"),
    Input("preview-btn", "n_clicks"),
    State("catalog-dropdown", "value"),
    State("schema-dropdown", "value"),
    State("selected-tables-store", "data")
)
def preview_metadata(n_clicks, catalog, schema, selected):
    if not n_clicks or not catalog or not schema or not selected:
        return "No tables selected for preview."

    output = []
    for tbl in selected:
        r = requests.get(
            f"{DATABRICKS_HOST}/api/2.1/unity-catalog/tables/{catalog}.{schema}.{tbl}",
            headers=HEADERS
        )
        if r.status_code == 200:
            t = r.json()
            output.append(html.Div([
                html.H5(f"\U0001F4C4 {t['name']}"),
                html.P(f"Type: {t.get('table_type', 'N/A')}"),
                html.P(f"Owner: {t.get('owner', 'N/A')}"),
                html.Hr()
            ]))
        else:
            output.append(html.Div([
                html.H5(tbl),
                html.P("Failed to load metadata."),
                html.Hr()
            ]))
    return output


# Execute query on submit using LangChain
@app.callback(
    Output("query-result-output", "children"),
    Input("submit-button", "n_clicks"),
    State("notes-textarea", "value"),
    #State("selected-tables-store", "data"),
    #State("schema-dropdown", "value"),
    #State("catalog-dropdown", "value")
)
#def execute_langchain_query(n_clicks, user_query, selected_tables, schema, catalog):
def execute_langchain_query(n_clicks, user_query):
    #if not n_clicks or not user_query or not selected_tables or not schema or not catalog:
    #    return "Please enter a query and select catalog, schema, and tables."
    if not n_clicks or not user_query:
        return "Please enter a query."

    
    try:
        # Please check the connector. I may not be working correctly
        
        #db = SQLDatabase.from_databricks(catalog=catalog, schema=schema, include_tables=selected_tables, 
        #                                 api_token=DATABRICKS_TOKEN,warehouse_id= "792838787cf72ed7")
        
        #chain = create_sql_query_chain(llm, db)
        #response = chain.invoke({"question": user_query})
        
        #sql_match = re.search(r"```sql\n(.*?)```", str(response), re.DOTALL)
        #sql_query = sql_match.group(1).strip() if sql_match else str(response)
        catalog = 'ai_dev'
        schema = 'aiwb_115_cbd_sandbox'
        selected_tables = ['amg427_20170528_ne_cb_clone']

        #user_query = "Describe the dataset"
        response, sql_query, result_df = call_sql_agent(catalog, 
                                                        schema, 
                                                        selected_tables, 
                                                        user_query)
        
        return html.Div([
            html.H6("Generated Response:"),
            html.Pre(str(response)),
            html.H6("Generated SQL Query:"),
            html.Pre(str(sql_query)),
            html.H6("Query Result (DataFrame Preview):"),
            html.Pre(result_df.head().to_string(index=False))
        ])

        
    except Exception as e:
        return html.Div(["Error: ", str(e)])
    

if __name__ == '__main__':
    app.run_server(debug=True)
