import dash
from dash import html, dcc, Input, Output, State, ctx
import dash_bootstrap_components as dbc
import requests
import os
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
import dash
from dash import html, Input, Output, State, ctx, dcc
import dash_bootstrap_components as dbc
import dash_mantine_components as dmc
import requests
import os
import math

# -------------------------------
# Databricks Configuration
# -------------------------------
DATABRICKS_TOKEN =  "dapi0945608621f87ae408fc84b3f011a0bd"
DATABRICKS_HOST = "https://amgen-ai-dev.cloud.databricks.com"

HEADERS = {
    "Authorization": f"Bearer {DATABRICKS_TOKEN}",
    "Content-Type": "application/json"
}

TABLES_PER_PAGE = 100

# -------------------------------
# Dash App Layout
# -------------------------------
app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
app.layout = dmc.MantineProvider([
    html.Div([

        dcc.Store(id='selected-table-store'),

        dbc.Button("Open Unity Catalog Modal", id="open-modal", n_clicks=0),

        dbc.Modal([
            dbc.ModalHeader(dbc.ModalTitle("Unity Catalog Browser")),
            dbc.ModalBody([

                html.Label("Catalog"),
                dmc.Select(id='catalog-dropdown', placeholder="Select Catalog", searchable=True),
                html.Br(),

                html.Label("Schema"),
                dmc.Select(id='schema-dropdown', placeholder="Select Schema", searchable=True),
                html.Br(),

                html.Label("Tables (Multi-select with checkboxes)"),
                dmc.MultiSelect(
                    id='table-dropdown',
                    placeholder="Select Tables",
                    searchable=True,
                    clearable=True,
                    #nothingFound="No tables found",
                    #maxSelectedValues=100,
                    style={"minHeight": "100px"}
                ),

                html.Br(),

                dmc.Pagination(id='table-pagination', total=1, page=1, siblings=1, boundaries=1, withControls=True),

                html.Br(),
                dbc.Button("Preview Metadata", id="preview-btn", n_clicks=0, color="primary"),
                html.Br(), html.Br(),
                html.Div(id="table-preview-output")

            ]),
            dbc.ModalFooter(
                dbc.Button("Close", id="close-modal", className="ms-auto", n_clicks=0)
            ),
        ], id="catalog-modal", is_open=False),
    ])
])


# -------------------------------
# Modal toggle
# -------------------------------
@app.callback(
    Output("catalog-modal", "is_open"),
    [Input("open-modal", "n_clicks"), Input("close-modal", "n_clicks")],
    [State("catalog-modal", "is_open")]
)
def toggle_modal(n1, n2, is_open):
    if ctx.triggered_id in ["open-modal", "close-modal"]:
        return not is_open
    return is_open


# -------------------------------
# Load catalogs
# -------------------------------
@app.callback(
    Output('catalog-dropdown', 'data'),
    Input('catalog-modal', 'is_open')
)
def fetch_catalogs(is_open):
    if not is_open:
        return []
    r = requests.get(f"{DATABRICKS_HOST}/api/2.1/unity-catalog/catalogs", headers=HEADERS)
    return [{'label': c['name'], 'value': c['name']} for c in r.json().get('catalogs', [])]


# -------------------------------
# Load schemas for selected catalog
# -------------------------------
@app.callback(
    Output('schema-dropdown', 'data'),
    Input('catalog-dropdown', 'value')
)
def fetch_schemas(catalog):
    if not catalog:
        return []
    r = requests.get(f"{DATABRICKS_HOST}/api/2.1/unity-catalog/schemas?catalog_name={catalog}", headers=HEADERS)
    return [{'label': s['name'], 'value': s['name']} for s in r.json().get('schemas', [])]


# -------------------------------
# Load tables and paginate
# -------------------------------
@app.callback(
    Output('table-dropdown', 'data'),
    Output('table-pagination', 'total'),
    Input('catalog-dropdown', 'value'),
    Input('schema-dropdown', 'value'),
    Input('table-pagination', 'page')
)
def fetch_tables(catalog, schema, page):
    if not catalog or not schema:
        return [], 1

    r = requests.get(f"{DATABRICKS_HOST}/api/2.1/unity-catalog/tables?catalog_name={catalog}&schema_name={schema}", headers=HEADERS)
    tables = r.json().get('tables', [])

    total_pages = math.ceil(len(tables) / TABLES_PER_PAGE)
    start = (page - 1) * TABLES_PER_PAGE
    end = start + TABLES_PER_PAGE
    page_tables = tables[start:end]

    return [{'label': t['name'], 'value': t['name']} for t in page_tables], max(total_pages, 1)


# -------------------------------
# Store selected tables
# -------------------------------
@app.callback(
    Output('selected-table-store', 'data'),
    Input('table-dropdown', 'value')
)
def store_selected_tables(selected_tables):
    return selected_tables or []


# -------------------------------
# Preview selected table metadata
# -------------------------------
@app.callback(
    Output('table-preview-output', 'children'),
    Input('preview-btn', 'n_clicks'),
    State('catalog-dropdown', 'value'),
    State('schema-dropdown', 'value'),
    State('selected-table-store', 'data')
)
def preview_table_metadata(n_clicks, catalog, schema, selected_tables):
    if not n_clicks or not catalog or not schema or not selected_tables:
        return "No tables selected for preview."

    table_metadata = []
    for tbl in selected_tables:
        r = requests.get(
            f"{DATABRICKS_HOST}/api/2.1/unity-catalog/tables/{catalog}.{schema}.{tbl}",
            headers=HEADERS
        )
        if r.status_code == 200:
            meta = r.json()
            table_metadata.append(html.Div([
                html.H5(f"📄 {meta['name']}"),
                html.P(f"Type: {meta.get('table_type', 'N/A')}"),
                html.P(f"Owner: {meta.get('owner', 'N/A')}"),
                html.Hr()
            ]))
        else:
            table_metadata.append(html.Div([
                html.H5(f"{tbl}"),
                html.P("Failed to retrieve metadata."),
                html.Hr()
            ]))
    return table_metadata

# -------------------------------
# Run the Dash app
# -------------------------------
if __name__ == '__main__':
    app.run_server(debug=True)
