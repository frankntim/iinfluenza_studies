# Databricks notebook source
# MAGIC %pip install langgraph==0.3.4 langchain-openai==0.3.0 langchain-experimental==0.3.4 databricks-langchain databricks-agents databricks-sql-connector sqlalchemy

# COMMAND ----------

from __future__ import annotations

import os
import ast
import re
import json
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
#import streamlit as st
from sqlalchemy import create_engine, text
from dotenv import load_dotenv
#import plotly.express as px
from datetime import date

from langchain_openai import ChatOpenAI
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from databricks import sql as dbsql
from langchain.schema import SystemMessage, HumanMessage
from kpi_analyzer import analyze_kpis
import warnings
warnings.filterwarnings('ignore', category=UserWarning) # Example for UserWarning

# COMMAND ----------

load_dotenv()
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
BASE_URL_SERVING_ENDPOINT = "https://amgen-ai-dev.cloud.databricks.com/serving-endpoints"
DATABRICKS_API_KEY = "dapi09f0df7c995c9e37c8a40f7b681a26d4"

DATABRICKS_HOST_BASE =  "amgen-ai-dev.cloud.databricks.com"
DATABRICKS_HTTP_PATH = "/sql/1.0/warehouses/37c05da246f2f4bd"
FULL_TABLE_NAME = "edl_dev.cbd_sandbox.amg_pmed_convai_feedback"
CATALOG = "edl_dev"
SCHEMA = "cbd_sandbox"
TABLE = "amg_pmed_convai_feedback"

# Create a remote Spark session
os.environ.pop('DATABRICKS_CLIENT_ID', None)
os.environ.pop('DATABRICKS_CLIENT_SECRET', None)
os.environ['OPENAI_API_KEY'] = DATABRICKS_API_KEY

TEMPERATURE = 0
host = DATABRICKS_HOST_BASE 
path = DATABRICKS_HTTP_PATH 
token = DATABRICKS_API_KEY



# COMMAND ----------


def _to_list(v: Any) -> List[str]:
    """Normalize feedback_type to a list of lowercased strings.
    Accepts list/tuple, JSON string, Python list repr string, CSV string, or None.
    """
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return []
    if isinstance(v, (list, tuple, set)):
        raw = list(v)
    elif isinstance(v, str):
        s = v.strip()
        if s.startswith("[") and s.endswith("]"):
            try:
                raw = ast.literal_eval(s)
                if not isinstance(raw, list):
                    raw = [str(raw)]
            except Exception:
                # Try JSON
                try:
                    raw = json.loads(s)
                    if not isinstance(raw, list):
                        raw = [str(raw)]
                except Exception:
                    # Fallback: comma-separated
                    raw = [p.strip() for p in s.split(",") if p.strip()]
        else:
            raw = [p.strip() for p in s.split(",") if p.strip()]
    else:
        raw = [str(v)]
    # Canonicalize + map unknowns to 'other'
    out: List[str] = []
    for x in raw:
        xlow = str(x).strip().lower()
        if xlow in CATEGORY_CANON:
            out.append(xlow)
        else:
            # attempt light normalization
            if "inaccur" in xlow:
                out.append("inaccurate")
            elif "irrel" in xlow:
                out.append("irrelevant")
            elif "incompl" in xlow:
                out.append("incomplete")
            elif "unclear" in xlow or "confus" in xlow or "ambig" in xlow:
                out.append("unclear")
            else:
                out.append("other")
    return out
    
def _normalized_updown(data_df: pd.DataFrame):
    # ensure vote normalized to {'up','down'}
    vmap = {
        "up": "up",
        "down": "down",
        "thumbs_up": "up",
        "thumbs_down": "down",
        "1": "up",
        "0": "down",
        "true": "up",
        "false": "down",
        "dummy": "up"
    }
    vote_norm = (
        data_df["vote"].astype(str).str.strip().str.lower().map(lambda x: vmap.get(x, x))
    )
    data_df = data_df.assign(thumbs=vote_norm)
    return data_df

# -----------------------------
# LLM judging
# -----------------------------
JUDGE_SYSTEM_PROMPT = (
    "You are evaluating user-written feedback about AI assistant/model outputs. "
    "Classify and rate each feedback snippet for usefulness and map it to a canonical issue category. "
    "Only reply with strict JSON using the provided schema."
)

JUDGE_USER_TMPL = (
    '''\
Task: Judge the following feedback.

Rules:
- Choose category from: {categories}.
- Define useful as: specific, actionable, and relevant to improving the model or the answer.
- Be strict: generic or venting comments are not useful.
- Return ONLY valid JSON with keys exactly as below (no trailing commentary):
  {{
    "category": "inaccurate|irrelevant|incomplete|unclear|other",
    "usefulness": "useful|not_useful",
    "actionability": 1-5,
    "specificity": 1-5,
    "sentiment": -1 to 1,
    "severity": 1-5,
    "confidence": 0-1,
    "summary": "one-sentence rationale",
    "suggested_rewrite": "rewrite the feedback to be more actionable (keep it brief)"
  }}

Feedback:
"""{text}"""
    '''
)

# ---------- Prompt used for every evaluation ----------
SYSTEM_PROMPT = (
    "You are a strict but fair evaluator. Score the ASSISTANT response with respect to the USER query "
    "and, if provided, an EXPECTED response. Use the following 0–5 float metrics:\n"
    "• correctness: factual accuracy vs the expected answer or domain knowledge\n"
    "• relevance: how well the answer addresses the user’s query\n"
    "• completeness: whether key steps/details are covered (not missing important parts)\n"
    "• faithfulness: grounded in the input/expected content; no hallucinations\n"
    "• conciseness: avoids rambling while retaining necessary information\n\n"
    "Rules:\n"
    "- If an expected response is provided, evaluate primarily against it.\n"
    "- Otherwise, evaluate the assistant response directly against the user query.\n"
    "- Return ONLY valid JSON, no Markdown or commentary. Use this exact schema:\n"
    "{\n"
    '  \"correctness\": number (0-5),\n'
    '  \"relevance\": number (0-5),\n'
    '  \"completeness\": number (0-5),\n'
    '  \"faithfulness\": number (0-5),\n'
    '  \"conciseness\": number (0-5)\n'
    "}"
)


# -----------------------------
# Helpers functions
# -----------------------------
CATEGORY_CANON = ["inaccurate", "irrelevant", "incomplete", "unclear", "other"]
METRICS: List[str] = ["correctness", "relevance", "completeness", "faithfulness", "conciseness"]
_CANON = {
    "inaccurate": "Information was inaccurate",
    "incomplete": "Response was incomplete",
    "unclear": "Response was unclear",
    "irrelevant": "Response was not relevant",
    "other": "Other",
}


def _find_col(df: pd.DataFrame, candidates: List[str]) -> Optional[str]:
    """Return the first matching (case-insensitive) column name in the dataframe, or None."""
    lower_map = {c.lower(): c for c in df.columns}
    for name in candidates:
        if name in lower_map:
            return lower_map[name]
    return None





def _dedup_keep_order(items: List[str]) -> List[str]:
    seen = set()
    out = []
    for x in items:
        if x not in seen:
            out.append(x)
            seen.add(x)
    return out


def _normalize_token(tok: str) -> Optional[str]:
    """Map any token to one of the canonical short keys if possible."""
    t = (tok or "").strip().lower()
    for short in _CANON.keys():
        if t == short or short in t:
            return short
    return None


def _parse_reasons_from_string(s: str) -> List[str]:
    """Parse reasons from a delimited string into canonical labels."""
    if not isinstance(s, str) or not s.strip():
        return []
    raw = [tok.strip() for tok in re.split(r"[;,|]", s) if tok.strip()]
    shorts = []
    for tok in raw:
        norm = _normalize_token(tok)
        if norm:
            shorts.append(norm)
    return [_CANON[x] for x in _dedup_keep_order(shorts)]


# LLM as A Judge-> Compare Results with Expected
def _clean_and_parse_json(s: str) -> Dict[str, Any]:
    """
    Try to parse JSON; if the model adds extra text, extract the first {...} block.
    """
    s = (s or "").strip()
    try:
        return json.loads(s)
    except Exception:
        pass

    # Try to extract JSON object with a naive brace match
    try:
        start = s.find("{")
        end = s.rfind("}")
        if start != -1 and end != -1 and end > start:
            candidate = s[start : end + 1]
            return json.loads(candidate)
    except Exception:
        pass

    # Try to remove code fencing/backticks if any
    s2 = re.sub(r"^```(?:json)?|```$", "", s.strip(), flags=re.MULTILINE).strip()
    try:
        return json.loads(s2)
    except Exception:
        pass

    # Failed
    return {}

def _parse_reasons_any(val: Any) -> List[str]:
    """
    Accepts:
      - Python list (already parsed)
      - JSON list string (preferred)
      - Delimited string
    Returns canonical reason strings.
    """
    # Case 1: already a Python list
    if isinstance(val, list):
        shorts = []
        for tok in val:
            norm = _normalize_token(str(tok))
            if norm:
                shorts.append(norm)
        return [_CANON[x] for x in _dedup_keep_order(shorts)]

    # Case 2: JSON list in a string
    if isinstance(val, str):
        s = val.strip()
        if s.startswith("[") and s.endswith("]"):
            # Be forgiving: convert single quotes to double quotes if present
            s_norm = s.replace("'", '"')
            try:
                arr = json.loads(s_norm)
                if isinstance(arr, list):
                    shorts = []
                    for tok in arr:
                        norm = _normalize_token(str(tok))
                        if norm:
                            shorts.append(norm)
                    return [_CANON[x] for x in _dedup_keep_order(shorts)]
            except Exception:
                # fall back to delimited
                pass
        # Case 3: delimited string
        return _parse_reasons_from_string(s)

    # Unknown -> empty
    return []

# LLM as A Judge-> Compare Results with Expected
def _clean_and_parse_json(s: str) -> Dict[str, Any]:
    """
    Try to parse JSON; if the model adds extra text, extract the first {...} block.
    """
    s = (s or "").strip()
    try:
        return json.loads(s)
    except Exception:
        pass

    # Try to extract JSON object with a naive brace match
    try:
        start = s.find("{")
        end = s.rfind("}")
        if start != -1 and end != -1 and end > start:
            candidate = s[start : end + 1]
            return json.loads(candidate)
    except Exception:
        pass

    # Try to remove code fencing/backticks if any
    s2 = re.sub(r"^```(?:json)?|```$", "", s.strip(), flags=re.MULTILINE).strip()
    try:
        return json.loads(s2)
    except Exception:
        pass

    # Failed
    return {}

def _clamp_0_5(x: Any) -> float:
    try:
        v = float(x)
    except Exception:
        return 0.0
    return max(0.0, min(5.0, v))

def _clamp_0_5(x: Any) -> float:
    try:
        v = float(x)
    except Exception:
        return 0.0
    return max(0.0, min(5.0, v))

def judge_once(
    judge_model: str,
    temperature: float,
    user_query: str,
    llm_response: str,
    expected_response: str,
) -> Tuple[float, float, float, float, float, str]:
    """
    Run a single LLM-as-judge evaluation and return the five metrics + raw model output.
    Cached by inputs to avoid re-charging on reruns.
    """
    chat = ChatDatabricks(model=judge_model, temperature=temperature)
    payload = {
        "user_query": user_query or "",
        "assistant_response": llm_response or "",
        "expected_response": expected_response or "",
    }
    msg = json.dumps(payload, ensure_ascii=False)
    ai = chat.invoke([SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=msg)])
    content = getattr(ai, "content", "") or ""

    parsed = _clean_and_parse_json(content)
    c = _clamp_0_5(parsed.get("correctness"))
    r = _clamp_0_5(parsed.get("relevance"))
    comp = _clamp_0_5(parsed.get("completeness"))
    f = _clamp_0_5(parsed.get("faithfulness"))
    conc = _clamp_0_5(parsed.get("conciseness"))
    return c, r, comp, f, conc, content
#---------------------------------------------------------------------


# COMMAND ----------

# MAGIC %md
# MAGIC **Load data from both Raw and Analytic**

# COMMAND ----------

from databricks import sql as dbsql
conn = dbsql.connect(server_hostname=host, 
                     http_path=path, 
                     access_token=token)
            
query = """
SELECT f.*
FROM edl_dev.cbd_sandbox.amg_pmed_convai_feedback AS f
LEFT ANTI JOIN edl_dev.cbd_sandbox.amg_pmed_convai_feedback_analytics AS a
ON f.created_at = a.feedback_created_at
"""

with conn.cursor() as cursor:
    cursor.execute(query)
    #result = cursor.fetchall()
    rows = cursor.fetchall()

    # Convert to DataFrame
    #columns = [col[0] for col in cursor.description]
    #missing_feedback_df = pd.DataFrame(result, columns=columns)
    cols = [d[0] for d in cursor.description] if cursor.description else []
    df = pd.DataFrame.from_records(rows, columns=cols)

conn.close()

# COMMAND ----------

# Drop columns if created_at is None
#df = df.dropna(subset=['created_at'])
df.shape

# COMMAND ----------

# Transform the data
if df is not None:
    # normalize feedback_type column to text + preserve original raw for display
    if "feedback_types" not in df.columns:
        df["feedback_types"] = [[] for _ in range(len(df))]
    # Keep a text version for SQLite friendliness
    df["feedback_types"] = df["feedback_types"].apply(_to_list)
    df["feedback_types_text"] = df["feedback_types"].apply(lambda xs: json.dumps(xs))
    # Normalize the data and create a thumps column
    df = _normalized_updown(df)
    # Generate approval rate column
    df["approval"] = (df["thumbs"] == "up").astype(int)
    # Process the date time columns
    # Parse datetime columns if present and compute response duration in seconds
    for _col in ["query_request_time", "response_time"]:
        if _col in df.columns:
            df[_col] = pd.to_datetime(df[_col], errors="coerce")
    if "query_request_time" in df.columns and "response_time" in df.columns:
        df["response_duration_s"] = (df["response_time"] - df["query_request_time"]).dt.total_seconds()

# COMMAND ----------

# Run the Judge Scores
if df is not None:
    required_cols = ["query", "sql_query", "expected_output", "model"]
    judge_df = df[required_cols]

    # Prepare output columns
    out_cols = METRICS + ["judge_raw"]
    for c in out_cols:
        if c not in judge_df.columns:
            judge_df[c] = None

    #progress = st.progress(0.0, text="LLM Judge Scoring…")
    #total = len(judge_df)

    for idx, row in judge_df.iterrows():
        uq = str(row.get("query", "") or "")
        ar = str(row.get("sql_query", "") or "")
        ex = str(row.get("expected_output", "") or "")

        try:
            c, r, comp, f, conc, raw_out = judge_once(LLM_ENDPOINT_NAME, TEMPERATURE, uq, ar, ex)
        except Exception as e:
            c = r = comp = f = conc = 0.0
            raw_out = f"(error) {e}"

        judge_df.at[idx, "correctness"] = c
        judge_df.at[idx, "relevance"] = r
        judge_df.at[idx, "completeness"] = comp
        judge_df.at[idx, "faithfulness"] = f
        judge_df.at[idx, "conciseness"] = conc
        judge_df.at[idx, "judge_raw"] = raw_out

# COMMAND ----------

judge_df.head(2)

# COMMAND ----------

df.columns

# COMMAND ----------

##### Generate Insight Analytics

if df is not None:
    in_df = df[['feedback_text','feedback_types_text','expected_output','model']]
    in_df = in_df.rename(columns={'feedback_text':'custom_feedback',
                            'feedback_types_text':'reason',
                            'expected_output':'expected',
                            'model':'model'})
    
    #progress = st.progress(0.0, text="Insight Analytics Scoring…")
    #total = len(in_df)
    parsed_reasons = in_df['reason'].apply(_parse_reasons_any)
    # Pull columns safely
    txt = in_df['custom_feedback'].astype(str)
    exp = in_df['expected'].astype(str) if ('expected' != "(none)") else pd.Series([""] * len(in_df))
    mdl = in_df['model'].astype(str) if ('model' != "(none)") else pd.Series([""] * len(in_df))

    out_sev, out_act = [], []
    for i in range(len(in_df)):
        bundle = {
            "reasons": parsed_reasons.iloc[i] or [],
            "custom_feedback": txt.iloc[i] or "",
            "expected": exp.iloc[i] or "",
            "model": mdl.iloc[i] or "",
        }
        res = analyze_kpis(bundle, LLM_ENDPOINT_NAME if LLM_ENDPOINT_NAME.strip() else None)
        out_sev.append(float(res.get("severity", 0.3)))
        out_act.append(float(res.get("actionability", 0.2)))

        #if total:
        #        progress.progress((idx + 1) / total, text=f"Scored {idx + 1}/{total}")
    #progress.empty()

    df["severity"] = out_sev
    df["actionability"] = out_act

# COMMAND ----------

JUDGE_COLUMNS = ['correctness',	
                 'relevance',	
                 'completeness',	
                 'faithfulness',	
                 'conciseness',	
                 'judge_raw']
df = pd.concat([df.reset_index(drop=True), judge_df[JUDGE_COLUMNS].reset_index(drop=True)], axis=1)

# COMMAND ----------

df = df.rename(columns={'query':'user_query',
                        'sql_query':'assistant_sql_response',
                        'expected_output':'expected_sql_response',
                        'created_at': 'feedback_created_at',
                        'model':'model_type'})

# COMMAND ----------

df.head(2)

# COMMAND ----------

df[['response_text','expected_sql_response','assistant_sql_response']].head()

# COMMAND ----------

df['created_at'] = datetime.combine(datetime.now().date(), datetime.now().time())
#df[['created_at']].head()

# COMMAND ----------

COLUMN_ORDER = ['feedback_created_at',
 'created_at',   
 'session_id',
 'user_id',
 'vote',
 'feedback_types',
 'feedback_text',
 'expected_sql_response',
  'user_query',
  'response_text',
  'assistant_sql_response',
 'python_code',
  'query_request_time',
 'response_time',
 'agent',
 'model_type',
 'feedback_types_text',
 'thumbs',
  'approval',
 'response_duration_s',
 'severity',
 'actionability',
  'correctness',
  'relevance',
  'completeness',
  'faithfulness',
  'conciseness',
 'judge_raw']
 
df = df[COLUMN_ORDER]
df.head(2)

# COMMAND ----------

df.shape

# COMMAND ----------

df = df.replace({pd.NaT: None, np.nan: None})
num_like = ["response_duration_s", "severity", "actionability","correctness", "relevance", "completeness", "faithfulness", "conciseness"]
for c in num_like:
    df[c] = pd.to_numeric(df[c], errors="coerce")

# COMMAND ----------

from databricks import sql as dbsql
conn = dbsql.connect(server_hostname=host, 
                     http_path=path, 
                     access_token=token)
                     
insert_query = """
INSERT INTO edl_dev.cbd_sandbox.amg_pmed_convai_feedback_analytics
(feedback_created_at,
 created_at,   
 session_id,
 user_id,
 vote,
 feedback_types,
 feedback_text,
 expected_sql_response,
  user_query,
  response_text,
  assistant_sql_response,
 python_code,
  query_request_time,
 response_time,
 agent,
 model_type,
 feedback_types_text,
 thumbs,
  approval,
 response_duration_s,
 severity,
 actionability,
  correctness,
  relevance,
  completeness,
  faithfulness,
  conciseness,
 judge_raw)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
"""

# COMMAND ----------

def safe_ts(val):
    return None if pd.isna(val) else val

with conn.cursor() as cursor:
    for _, row in df.iterrows():
        cursor.execute(
            insert_query,
            (
                row['feedback_created_at'],
                row['created_at'],
                row['session_id'],
                row['user_id'],
                row['vote'],
                row['feedback_types'],
                row['feedback_text'],
                row['expected_sql_response'],
                row['user_query'],
                row['response_text'],
                row['assistant_sql_response'],
                row['python_code'],
                row['query_request_time'],
                row['response_time'],
                row['agent'],
                row['model_type'],
                row['feedback_types_text'],
                row['thumbs'],
                row['approval'],
                float(row['response_duration_s']),
                float(row['severity']),
                float(row['actionability']),
                float(row['correctness']),
                float(row['relevance']),
                float(row['completeness']),
                float(row['faithfulness']),
                float(row['conciseness']),
                row['judge_raw']
            )
        )
    conn.commit()

conn.close()

# COMMAND ----------

spark.sql("DELETE FROM edl_dev.cbd_sandbox.amg_pmed_convai_feedback_analytics")

# COMMAND ----------

df.shape