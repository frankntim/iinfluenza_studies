import os
import json
from typing import Dict, Any, List, Optional
import re
import requests
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
from databricks import sql
from dotenv import load_dotenv
from langchain_community.chat_models import ChatDatabricks
from langchain.schema import SystemMessage, HumanMessage

# -------------------------------------------------------------------
# 🧠 UNIVERSAL SYSTEM PROMPT
# -------------------------------------------------------------------
SYSTEM_PROMPT = """
You are a clinical data reasoning assistant and expert Databricks SQL generator specializing in
Amgen BiTE (Bispecific T-cell Engager) biomarker datasets. Your task is to produce Databricks SQL
queries that generate datasets for *forest plot visualizations* from Amgen’s BiTE clinical studies.

There are two core use cases:
1. Cytokine fold-change vs baseline (e.g., AMG330)
2. Responder vs Non-responder comparison (e.g., AMG701)

All data are stored in Unity Catalog schema: edl_prd.cdh_bite_prd_publish

- *_adsl → subject-level attributes (e.g., response categories)
- *_cb → biomarker or cytokine concentration data

The generated SQL must always:
- Use LOG2() for fold-change
- Avoid dividing by zero (filter STRESN > 0 and BASELINE_VALUE > 0)
- Replace NULL aggregates with COALESCE(…, 0)
- Group by ANALYTE and either STUDY_TIME_6HR or RESPONSE_GROUP
- Be valid Databricks SQL syntax (no pseudo-code)

Follow the universal logic previously described for the AMG330 (time-course) and AMG701 (response) cases.
Return SQL only.
Return only executable Databricks SQL code with no explanations, markdown fences, or comments.
Do not wrap it in ```sql``` or add text like "Here’s your SQL query".
"""

# -------------------------------------------------------------------
# ⚙️ STREAMLIT CONFIG
# -------------------------------------------------------------------
st.set_page_config(page_title="BiTE Forest Plot Generator", layout="wide")

st.title("🧠 BiTE Biomarker Forest Plot Generator (ChatDatabricks + Unity Catalog)")
st.markdown("""
Paste any **analysis prompt** (e.g., for AMG330 or AMG701 studies) below.
ChatDatabricks will automatically generate Databricks SQL, query Unity Catalog,
and visualize the resulting forest plot.
""")

# -------------------------------------------------------------------
# 🔑 Databricks Configuration
# -------------------------------------------------------------------
#DATABRICKS_HOST = st.secrets["databricks"]["server_host"]
#DATABRICKS_HTTP_PATH = st.secrets["databricks"]["http_path"]
#DATABRICKS_TOKEN = st.secrets["databricks"]["token"]
#ENDPOINT = st.secrets["databricks"]["chat_endpoint"]  # e.g., chatdatabricks-llm


# =====================================================
# LLM helper (ChatDatabricks)
# =====================================================
load_dotenv()

# Load environment variables
#SPACE_ID = os.environ.get("SPACE_ID")
DATABRICKS_HTTP_PATH = os.environ.get("SQL_WAREHOUSE_PATH")
DATABRICKS_HOST = os.environ.get("DATABRICKS_HOST_BASE")
DATABRICKS_TOKEN = os.environ.get("DATABRICKS_TOKEN")
ENDPOINT = os.environ.get("LLM_ENDPOINT_NAME")

# Create a remote Spark session
os.environ.pop('DATABRICKS_CLIENT_ID', None)    # Frank
os.environ.pop('DATABRICKS_CLIENT_SECRET', None) # Frank

# Instantiate ChatDatabricks LLM
llm = ChatDatabricks(
    endpoint=ENDPOINT,
    temperature=0,
    max_tokens=1500
)

# -------------------------------------------------------------------
# 💬 CHAT INPUT
# -------------------------------------------------------------------
user_prompt = st.chat_input("Enter your analysis prompt (e.g., forest plot request for AMG330 or AMG701)...")

def clean_sql_response(text: str) -> str:
    """Remove markdown fences and non-SQL content from LLM response."""
    # Remove markdown code fences like ```sql ... ```
    cleaned = re.sub(r"```sql", "", text, flags=re.IGNORECASE)
    cleaned = re.sub(r"```", "", cleaned)
    # Remove leading phrases like "Here is the SQL..." or explanations
    cleaned = re.sub(r"(?i)^(here( is|'s)|the sql|sql query).*?:", "", cleaned).strip()
    # Remove any non-SQL trailing sentences
    cleaned = re.split(r"(;[\s]*)$", cleaned)[0] + ";"
    return cleaned.strip()

if user_prompt:
    with st.spinner("💬 Generating SQL using ChatDatabricks..."):
        response = llm.invoke([
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(content=user_prompt)
        ])
        #sql_query = response.content.strip()

        sql_query_raw = response.content.strip()
        sql_query = clean_sql_response(sql_query_raw)

        st.subheader("🧾 Generated SQL Query")
        st.code(sql_query, language="sql")

    # -------------------------------------------------------------------
    # 🗄️ EXECUTE SQL AGAINST UNITY CATALOG
    # -------------------------------------------------------------------
    with st.spinner("🔍 Executing SQL query via Unity Catalog..."):
        try:
            with sql.connect(
                server_hostname=DATABRICKS_HOST,
                http_path=DATABRICKS_HTTP_PATH,
                access_token=DATABRICKS_TOKEN
            ) as connection:
                with connection.cursor() as cursor:
                    cursor.execute(sql_query)
                    result = cursor.fetchall()
                    columns = [desc[0] for desc in cursor.description]
                    df = pd.DataFrame(result, columns=columns)

            st.success("✅ Forest plot dataset successfully retrieved.")
            st.dataframe(df.head())

        except Exception as e:
            st.error(f"❌ Databricks SQL execution failed: {e}")
            st.stop()

    # -------------------------------------------------------------------
    # 📊 FOREST PLOT VISUALIZATION
    # -------------------------------------------------------------------
    st.subheader("🌲 Forest Plot Visualization")

    df.columns = [col.upper() for col in df.columns]  # normalize column names

    if "STUDY_TIME_6HR" in df.columns:
        # AMG330 time-course use case
        df["LABEL"] = df["ANALYTE"] + " | " + df["STUDY_TIME_6HR"].astype(str) + "h"
        df = df.sort_values(by=["ANALYTE", "STUDY_TIME_6HR"])
    elif "RESPONSE_GROUP" in df.columns:
        # AMG701 responder vs non-responder use case
        df["LABEL"] = df["ANALYTE"] + " | " + df["RESPONSE_GROUP"]
        df = df.sort_values(by=["ANALYTE", "RESPONSE_GROUP"])
    else:
        st.error("❌ Could not determine dataset type (expected STUDY_TIME_6HR or RESPONSE_GROUP).")
        st.stop()

    df = df.reset_index(drop=True)
    df["Y_POS"] = range(len(df))[::-1]

    sns.set(style="whitegrid", context="talk")
    fig, ax = plt.subplots(figsize=(10, 8))

    ax.errorbar(
        df["MEAN_LOG2_FC"],
        df["Y_POS"],
        xerr=df["SD_LOG2_FC"],
        fmt="o",
        color="tab:blue",
        ecolor="gray",
        elinewidth=1.5,
        capsize=4
    )
    ax.axvline(0, color="gray", linestyle="--", linewidth=1.2)
    ax.set_yticks(df["Y_POS"])
    ax.set_yticklabels(df["LABEL"], fontsize=10)
    ax.set_xlabel("Mean log₂ Fold-Change", fontsize=12)
    ax.set_ylabel("Analyte | Group", fontsize=12)
    ax.set_title("Forest Plot Visualization", fontsize=16, pad=15)
    sns.despine(left=True, bottom=True)

    st.pyplot(fig)
    st.success("🎉 Forest plot successfully generated!")
