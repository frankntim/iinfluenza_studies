import os
import json
from typing import Dict, Any, List, Optional
import re
import requests
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
from databricks import sql
from dotenv import load_dotenv
from langchain_community.chat_models import ChatDatabricks
from langchain.schema import SystemMessage, HumanMessage

# -------------------------------------------------------------------
# 🧠 UNIVERSAL SYSTEM PROMPT
# -------------------------------------------------------------------
system_prompt = """
    You are a clinical data reasoning assistant and expert Databricks SQL generator specializing in
    Amgen BiTE (Bispecific T-cell Engager) biomarker datasets. Your task is to produce Databricks SQL
    queries that generate datasets for *forest plot visualizations* from Amgen’s BiTE clinical studies.

    ----------------------------------------------------------------
    📘 DATABASE CONTEXT
    ----------------------------------------------------------------
    All data are stored in schema:
    edl_prd.cdh_bite_prd_publish

    Each study has its own table family (suffix = _ne_*):
    - *_adsl → subject-level demographics & response data
    - *_cb   → cytokine / biomarker concentration data
    - *_ae   → adverse events
    - *_ex   → exposure (dosing)
    - *_ngs  → sequencing data
    - *_rna  → transcriptomic data

    ----------------------------------------------------------------
    📘 COMMON FIELD DEFINITIONS
    ----------------------------------------------------------------
    Across these tables, typical columns include:
    - SUBJID: unique subject identifier
    - ANALYTE or TARGET: biomarker/cytokine name
    - STRESN: numeric concentration value
    - STUDY_TIME or VISITDY or STUDY_DAY: time since dosing (hours or days)
    - BASEFL: baseline flag (Y/N)
    - BEST_RESPONSE or OVERALL_RESPONSE: best overall clinical outcome (CR, PR, SD, PD)

    ----------------------------------------------------------------
    🎯 PRIMARY TASKS (TWO CORE USE CASES)
    ----------------------------------------------------------------

    ### 🧩 Use Case 1 — Cytokine Fold-Change vs. Time (e.g., AMG330)
    Generate a SQL query that computes log₂ fold-changes in cytokine levels across post-dose
    timepoints compared to pre-dose baseline for a given study (e.g., AMG330).

    Required logic:
    1. Identify baseline as mean(STRESN) where STUDY_TIME < 0 or BASEFL = 'Y' for each (SUBJID, ANALYTE).
    2. Compute log₂ fold-change at each post-dose timepoint:
    log2_fc = LOG2(cb.STRESN / b.BASELINE_VALUE)
    3. Round study_time to nearest 6-hour bin: ROUND(cb.STUDY_TIME / 6) * 6 AS STUDY_TIME_6HR
    4. Aggregate across subjects:
    - mean_log2_fc = AVG(log2_fc)
    - sd_log2_fc   = STDDEV(log2_fc)
    5. Filter to key cytokines (e.g., 'IL-6', 'IL-10', 'IL-8', 'MCP-1', 'TNF-a', 'IFN-Gamma').
    6. Order by ANALYTE and STUDY_TIME_6HR.

    ✅ Expected SQL structure:
    -------------------------------------------------------------
    WITH baseline AS (
        SELECT SUBJID, ANALYTE, AVG(STRESN) AS BASELINE_VALUE
        FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb
        WHERE STRESN > 0 AND (STUDY_TIME < 0 OR BASEFL = 'Y')
        GROUP BY SUBJID, ANALYTE
    ),
    summarized AS (
        SELECT
            cb.ANALYTE,
            ROUND(cb.STUDY_TIME / 6) * 6 AS STUDY_TIME_6HR,
            LOG2(cb.STRESN / b.BASELINE_VALUE) AS log2_fc
        FROM edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb cb
        JOIN baseline b
        ON cb.SUBJID = b.SUBJID AND cb.ANALYTE = b.ANALYTE
        WHERE cb.STRESN > 0 AND b.BASELINE_VALUE > 0
        AND cb.ANALYTE IN ('IL-6','IL-10','IL-8','MCP-1','TNF-a','IFN-Gamma')
    )
    SELECT
        ANALYTE,
        STUDY_TIME_6HR,
        COALESCE(AVG(log2_fc), 0) AS mean_log2_fc,
        COALESCE(STDDEV(log2_fc), 0) AS sd_log2_fc
    FROM summarized
    GROUP BY ANALYTE, STUDY_TIME_6HR
    ORDER BY ANALYTE, STUDY_TIME_6HR;
    -------------------------------------------------------------

    ------------------------------------------------------------
    ### 🧩 Use Case 2 — Responder vs Non-Responder Comparison (e.g., AMG701)
    Generate a SQL query comparing biomarker log₂ fold-changes between
    Responders (CR/PR) and Non-Responders (SD/PD) based on subject clinical outcome.

    Required logic:
    1. Define response groups from ADSL:
    - Responder if BEST_RESPONSE IN ('CR','PR')
    - Non-Responder if BEST_RESPONSE IN ('SD','PD')
    2. Compute subject-level baseline (mean(STRESN) per analyte where STUDY_TIME < 0 or BASEFL = 'Y').
    3. Join biomarker data (CB) with response labels (ADSL).
    4. Compute:
    log2_fc = LOG2(cb.STRESN / b.BASELINE_VALUE)
    5. Aggregate across subjects by (ANALYTE, RESPONSE_GROUP):
    - mean_log2_fc = AVG(log2_fc)
    - sd_log2_fc   = STDDEV(log2_fc)

    ✅ Expected SQL structure:
    -------------------------------------------------------------
    WITH baseline AS (
        SELECT SUBJID, ANALYTE, AVG(STRESN) AS BASELINE_VALUE
        FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb
        WHERE STRESN > 0 AND (STUDY_TIME < 0 OR BASEFL = 'Y')
        GROUP BY SUBJID, ANALYTE
    ),
    response_groups AS (
        SELECT
            SUBJID,
            CASE
                WHEN BEST_RESPONSE IN ('CR','PR') THEN 'Responder'
                WHEN BEST_RESPONSE IN ('SD','PD') THEN 'Non-Responder'
            END AS RESPONSE_GROUP
        FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl
        WHERE BEST_RESPONSE IN ('CR','PR','SD','PD')
    ),
    joined AS (
        SELECT
            cb.ANALYTE,
            r.RESPONSE_GROUP,
            LOG2(cb.STRESN / b.BASELINE_VALUE) AS log2_fc
        FROM edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb cb
        JOIN baseline b
        ON cb.SUBJID = b.SUBJID AND cb.ANALYTE = b.ANALYTE
        JOIN response_groups r
        ON cb.SUBJID = r.SUBJID
        WHERE cb.STRESN > 0 AND b.BASELINE_VALUE > 0 AND r.RESPONSE_GROUP IS NOT NULL
    )
    SELECT
        ANALYTE,
        RESPONSE_GROUP,
        COALESCE(AVG(log2_fc), 0) AS mean_log2_fc,
        COALESCE(STDDEV(log2_fc), 0) AS sd_log2_fc
    FROM joined
    GROUP BY ANALYTE, RESPONSE_GROUP
    ORDER BY ANALYTE, RESPONSE_GROUP;
    -------------------------------------------------------------

    ----------------------------------------------------------------
    ⚙️ GENERAL SQL RULES
    ----------------------------------------------------------------
    - Always use LOG2 for fold-change computation.
    - Exclude rows where STRESN ≤ 0 or BASELINE_VALUE ≤ 0.
    - Replace NULL means/SDs with 0 using COALESCE.
    - Never guess table or column names — use only those in schema.
    - Always order final results by analyte and time (or response group).
    - Return clean, executable Databricks SQL — not pseudo-code.
    - If a user specifies another study (e.g., AMG160), update table names accordingly.

    ----------------------------------------------------------------
    🧠 INTENT HANDLING
    ----------------------------------------------------------------
    If the user asks for:
    "cytokine fold-change vs baseline" → Use Use Case 1 query logic.
    "responder vs non-responder" → Use Use Case 2 query logic.

    If unsure, ask which type of forest plot they want.

    ----------------------------------------------------------------
    💡 OUTPUT FORMAT
    ----------------------------------------------------------------
    Output **only** the Databricks SQL code block. No Python or commentary.
    The SQL should be runnable directly in Databricks SQL editor.
    Do not wrap it in ```sql``` or add text like "Here’s your SQL query"
    """
SYSTEM_PROMPT = open("system_prompt.txt").read()
    


# -------------------------------------------------------------------
# ⚙️ STREAMLIT CONFIG
# -------------------------------------------------------------------
st.set_page_config(page_title="BiTE Forest Plot Generator", layout="wide")

st.title("🧠 BiTE Biomarker Forest Plot Generator (ChatDatabricks + Unity Catalog)")
st.markdown("""
Paste any **analysis prompt** (e.g., for AMG330 or AMG701 studies) below.
ChatDatabricks will automatically generate Databricks SQL, query Unity Catalog,
and visualize the resulting forest plot.
""")

# -------------------------------------------------------------------
# 🔑 Databricks Configuration
# -------------------------------------------------------------------
#DATABRICKS_HOST = st.secrets["databricks"]["server_host"]
#DATABRICKS_HTTP_PATH = st.secrets["databricks"]["http_path"]
#DATABRICKS_TOKEN = st.secrets["databricks"]["token"]
#ENDPOINT = st.secrets["databricks"]["chat_endpoint"]  # e.g., chatdatabricks-llm


# =====================================================
# LLM helper (ChatDatabricks)
# =====================================================
load_dotenv()

# Load environment variables
#SPACE_ID = os.environ.get("SPACE_ID")
DATABRICKS_HTTP_PATH = os.environ.get("SQL_WAREHOUSE_PATH")
DATABRICKS_HOST = os.environ.get("DATABRICKS_HOST_BASE")
DATABRICKS_TOKEN = os.environ.get("DATABRICKS_TOKEN")
ENDPOINT = os.environ.get("LLM_ENDPOINT_NAME")

# Create a remote Spark session
os.environ.pop('DATABRICKS_CLIENT_ID', None)    # Frank
os.environ.pop('DATABRICKS_CLIENT_SECRET', None) # Frank

# Instantiate ChatDatabricks LLM
llm = ChatDatabricks(
    endpoint=ENDPOINT,
    temperature=0,
    max_tokens=1500
)

# -------------------------------------------------------------------
# 💬 CHAT INPUT
# -------------------------------------------------------------------
# ---------------------------------------------------------------------
# 2. Unity Catalog mapping (study → table names)
# ---------------------------------------------------------------------
STUDY_TABLES = {
    "AMG160": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg160_20180101_ne_cb",
    },
    "AMG330": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg330_20120252_ne_cb",
    },
    "AMG427": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg427_20170528_ne_cb",
    },
    "AMG673": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg673_20160377_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg673_20160377_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg673_20160377_ne_cb",
    },
    "AMG701": {
        "adsl": "edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_adsl",
        "ae":   "edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_ae",
        "cb":   "edl_prd.cdh_bite_prd_publish.amg701_20170122_ne_cb",
    },
}


# ---------------------------------------------------------------------
# 3. Extract study name from user query
# ---------------------------------------------------------------------
def extract_study_from_query1(natural_query: str) -> str:
    match = re.search(r"AMG\\s?\\d+", natural_query.upper())
    if match:
        return match.group(0).replace(" ", "")
    raise ValueError("Could not detect study name (e.g., AMG160, AMG330) from query.")

STUDY_ALIASES = {
    "xaluritamig": "AMG509",
    "tarlatamab": "AMG757",
    "amg 509": "AMG509",
    "amg 757": "AMG757",
    "amg160": "AMG160",
    "amg 160": "AMG160",
    "amg330": "AMG330",
    "amg 330": "AMG330",
    "amg427": "AMG427",
    "amg 427": "AMG427",
    "amg673": "AMG673",
    "amg 673": "AMG673",
    "amg701": "AMG701",
    "amg 701": "AMG701",
}

def extract_study_from_query(natural_query: str) -> str:
    """
    Extract study identifier (AMG code) from user query.
    Supports both numeric codes (e.g., AMG160) and aliases (e.g., tarlatamab).
    """
    q_lower = natural_query.lower()

    # 1️⃣ Try to detect AMG### pattern
    match = re.search(r"amg\\s?\\d+", q_lower)
    if match:
        return match.group(0).replace(" ", "").upper()

    # 2️⃣ Try to detect known alias name (e.g., "tarlatamab")
    for alias, amg_code in STUDY_ALIASES.items():
        if alias in q_lower:
            return amg_code

    # 3️⃣ If not found, raise clear, user-friendly error
    raise ValueError(
        f"❌ Could not detect a study name or alias from the query: '{natural_query}'.\n"
        f"Please include a molecule name (e.g., 'AMG160') or known alias "
        f"({', '.join(sorted(set(STUDY_ALIASES.keys()) - set(['amg 160','amg160'])))})"
    )

def clean_sql_response(text: str) -> str:
    """Remove markdown fences and non-SQL content from LLM response."""
    # Remove markdown code fences like ```sql ... ```
    cleaned = re.sub(r"```sql", "", text, flags=re.IGNORECASE)
    cleaned = re.sub(r"```", "", cleaned)
    # Remove leading phrases like "Here is the SQL..." or explanations
    cleaned = re.sub(r"(?i)^(here( is|'s)|the sql|sql query).*?:", "", cleaned).strip()
    # Remove any non-SQL trailing sentences
    cleaned = re.split(r"(;[\s]*)$", cleaned)[0] + ";"
    return cleaned.strip()

def generate_sql_with_chatdatabricks(natural_query: str, study: str) -> str:
    if study not in STUDY_TABLES:
        raise ValueError(f"No table mapping found for study {study}")
    
    tables = STUDY_TABLES[study]

    user_prompt = f"""
    Natural language query:
    \"\"\"{natural_query}\"\"\"
    Generate only the SQL query that can be executed in Databricks.
    """
    response = llm.invoke([
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt)
    ])

    #sql = response.content.strip()

    sql_query_raw = response.content.strip()
    sql_query = clean_sql_response(sql_query_raw)

    return sql_query


user_prompt = st.chat_input("Enter your analysis prompt (e.g., forest plot request for AMG330 or AMG701)...")



if user_prompt:
    with st.spinner("💬 Generating SQL using ChatDatabricks..."):
        #response = llm.invoke([
        #    SystemMessage(content=SYSTEM_PROMPT),
        #    HumanMessage(content=user_prompt)
        #])
        #sql_query = response.content.strip()

        #sql_query_raw = response.content.strip()
        #sql_query = clean_sql_response(sql_query_raw)
        study = extract_study_from_query(user_prompt)
        #print(f"Detected study: {study}")

        # Step 2: Generate SQL using ChatDatabricks
        sql_query = generate_sql_with_chatdatabricks(user_prompt, study)

        st.subheader("🧾 Generated SQL Query")
        st.code(sql_query, language="sql")

    # -------------------------------------------------------------------
    # 🗄️ EXECUTE SQL AGAINST UNITY CATALOG
    # -------------------------------------------------------------------
    with st.spinner("🔍 Executing SQL query via Unity Catalog..."):
        try:
            with sql.connect(
                server_hostname=DATABRICKS_HOST,
                http_path=DATABRICKS_HTTP_PATH,
                access_token=DATABRICKS_TOKEN
            ) as connection:
                with connection.cursor() as cursor:
                    cursor.execute(sql_query)
                    result = cursor.fetchall()
                    columns = [desc[0] for desc in cursor.description]
                    df = pd.DataFrame(result, columns=columns)

            st.success("✅ Forest plot dataset successfully retrieved.")
            st.dataframe(df.head())

        except Exception as e:
            st.error(f"❌ Databricks SQL execution failed: {e}")
            st.stop()

    # -------------------------------------------------------------------
    # 📊 FOREST PLOT VISUALIZATION
    # -------------------------------------------------------------------
    st.subheader("🌲 Forest Plot Visualization")

    df.columns = [col.upper() for col in df.columns]  # normalize column names

    if "STUDY_TIME_6HR" in df.columns:
        # AMG330 time-course use case
        df["LABEL"] = df["ANALYTE"] + " | " + df["STUDY_TIME_6HR"].astype(str) + "h"
        df = df.sort_values(by=["ANALYTE", "STUDY_TIME_6HR"])
    elif "RESPONSE_GROUP" in df.columns:
        # AMG701 responder vs non-responder use case
        df["LABEL"] = df["ANALYTE"] + " | " + df["RESPONSE_GROUP"]
        df = df.sort_values(by=["ANALYTE", "RESPONSE_GROUP"])
    else:
        st.error("❌ Could not determine dataset type (expected STUDY_TIME_6HR or RESPONSE_GROUP).")
        st.stop()

    df = df.reset_index(drop=True)
    df["Y_POS"] = range(len(df))[::-1]

    sns.set(style="whitegrid", context="talk")
    fig, ax = plt.subplots(figsize=(10, 8))

    ax.errorbar(
        df["MEAN_LOG2_FC"],
        df["Y_POS"],
        xerr=df["SD_LOG2_FC"],
        fmt="o",
        color="tab:blue",
        ecolor="gray",
        elinewidth=1.5,
        capsize=4
    )
    ax.axvline(0, color="gray", linestyle="--", linewidth=1.2)
    ax.set_yticks(df["Y_POS"])
    ax.set_yticklabels(df["LABEL"], fontsize=10)
    ax.set_xlabel("Mean log₂ Fold-Change", fontsize=12)
    ax.set_ylabel("Analyte | Group", fontsize=12)
    ax.set_title("Forest Plot Visualization", fontsize=16, pad=15)
    sns.despine(left=True, bottom=True)

    st.pyplot(fig)
    st.success("🎉 Forest plot successfully generated!")
