import os
import math
from typing import Tuple, Dict, Any

import numpy as np
import pandas as pd
import streamlit as st
from scipy import stats
from dotenv import load_dotenv

from langchain_community.chat_models import ChatDatabricks
from langchain.schema import HumanMessage

# ----------------------------------------------------
# Helper: create LLM client (ChatDatabricks)
# ----------------------------------------------------

load_dotenv()
DATABRICKS_HOST = os.environ.get("DATABRICKS_HOST")
DATABRICKS_TOKEN = os.environ.get("DATABRICKS_TOKEN")
LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")

# Create a remote Spark session
os.environ.pop('DATABRICKS_CLIENT_ID', None)    # Frank
os.environ.pop('DATABRICKS_CLIENT_SECRET', None) # Frank

# LLM for plotting graph
LLM = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)

#------------------------------------------------
def get_llm(
    model_name: str = "databricks-dbrx-instruct",
    temperature: float = 0.0,
):
    """
    Build a ChatDatabricks instance.

    You can either:
      - Use 'model' to refer to a built-in model like 'databricks-dbrx-instruct', or
      - Use 'endpoint' to call a custom serving endpoint (set via env var).

    Environment variables typically needed:
      - DATABRICKS_HOST
      - DATABRICKS_TOKEN
      - (OPTIONAL) DATABRICKS_LLM_ENDPOINT for a specific serving endpoint
    """
    endpoint = LLM_ENDPOINT_NAME #os.getenv("DATABRICKS_LLM_ENDPOINT")  # optional override
    return ChatDatabricks(
            endpoint=endpoint,
            temperature=temperature,
        )

    #if endpoint:
        # Call a specific Databricks serving endpoint
    #    return ChatDatabricks(
    #        endpoint=endpoint,
    #        temperature=temperature,
    #    )
    #else:
        # Call a workspace model name (e.g. databricks-dbrx-instruct)
    #    return ChatDatabricks(
    #        model=model_name,
    #        temperature=temperature,
    #    )


# ----------------------------------------------------
# Biostat utilities
# ----------------------------------------------------
def infer_variable_types(df: pd.DataFrame) -> Dict[str, str]:
    """
    Infer variable types as 'numeric' or 'categorical' based on dtype and cardinality.
    """
    var_types = {}
    for col in df.columns:
        s = df[col]
        # drop NA-like values
        s_clean = s.replace(["NA", "na", ""], np.nan)
        # try numeric
        numeric_series = pd.to_numeric(s_clean, errors="coerce")
        numeric_fraction = numeric_series.notna().mean()
        unique_vals = s_clean.dropna().unique()
        if numeric_fraction > 0.8 and len(unique_vals) > 5:
            var_types[col] = "numeric"
        else:
            var_types[col] = "categorical"
    return var_types


def summarize_numeric(series: pd.Series) -> Dict[str, float]:
    s = pd.to_numeric(series, errors="coerce").dropna()
    if len(s) == 0:
        return {}
    return {
        "n": int(s.count()),
        "mean": float(s.mean()),
        "sd": float(s.std(ddof=1)),
        "min": float(s.min()),
        "max": float(s.max()),
    }


def two_sample_ttest(
    y: pd.Series,
    group: pd.Series,
) -> Tuple[Dict[str, Any], str, str]:
    """
    Welch two-sample t-test: numeric outcome y vs binary group.
    Returns stats dict + group labels (g1, g2).
    """
    df = pd.DataFrame({"y": pd.to_numeric(y, errors="coerce"), "g": group})
    df = df.dropna()

    groups = df["g"].unique()
    if len(groups) != 2:
        return {}, "", ""

    g1, g2 = groups[0], groups[1]
    y1 = df.loc[df["g"] == g1, "y"]
    y2 = df.loc[df["g"] == g2, "y"]

    if len(y1) < 2 or len(y2) < 2:
        return {}, "", ""

    t_stat, p_value = stats.ttest_ind(y1, y2, equal_var=False)
    res = {
        "group1": str(g1),
        "group2": str(g2),
        "n1": int(len(y1)),
        "n2": int(len(y2)),
        "mean1": float(y1.mean()),
        "mean2": float(y2.mean()),
        "diff": float(y1.mean() - y2.mean()),
        "t": float(t_stat),
        "p": float(p_value),
    }
    return res, str(g1), str(g2)


def chi_square_2x2(
    var1: pd.Series,
    var2: pd.Series,
) -> Dict[str, Any]:
    """
    Chi-square test for independence for 2x2 table.
    """
    df = pd.DataFrame({"v1": var1, "v2": var2}).dropna()
    tab = pd.crosstab(df["v1"], df["v2"])
    if tab.shape != (2, 2):
        return {}

    chi2, p, dof, expected = stats.chi2_contingency(tab)

    return {
        "table": tab.values.tolist(),
        "index": tab.index.astype(str).tolist(),
        "columns": tab.columns.astype(str).tolist(),
        "chi2": float(chi2),
        "df": int(dof),
        "p": float(p),
        "expected": expected.tolist(),
    }


def simple_linear_regression(
    y: pd.Series,
    x: pd.Series,
) -> Dict[str, Any]:
    """
    Simple linear regression y ~ x.
    """
    df = pd.DataFrame(
        {
            "y": pd.to_numeric(y, errors="coerce"),
            "x": pd.to_numeric(x, errors="coerce"),
        }
    ).dropna()
    if len(df) < 3:
        return {}

    slope, intercept, r_value, p_value, std_err = stats.linregress(df["x"], df["y"])

    return {
        "n": int(len(df)),
        "beta0": float(intercept),
        "beta1": float(slope),
        "se_beta1": float(std_err),
        "t": float(slope / std_err if std_err != 0 else np.nan),
        "p": float(p_value),
        "r2": float(r_value ** 2),
    }


# ----------------------------------------------------
# LLM prompt builder
# ----------------------------------------------------
def build_llm_prompt(
    analysis_type: str,
    outcome: str,
    variable2: str,
    stats_dict: Dict[str, Any],
    extra_instructions: str = "",
) -> str:
    """
    Build a prompt for ChatDatabricks to produce a biostatistical conclusion.
    """
    base_context = (
        "You are a biostatistician. Write a concise, clear biostatistical conclusion "
        "for an analysis, as you would for a clinical/biomedical paper.\n\n"
        "Guidelines:\n"
        "- State whether there is evidence of an effect/association.\n"
        "- Report direction and magnitude (means, differences, odds, etc.) when relevant.\n"
        "- Include p-value and any key metrics (R², chi-square, etc.).\n"
        "- Use one short paragraph, maximum 3 sentences.\n"
        "- Do not explain the methods in detail; focus on interpretation.\n\n"
    )

    # Add stats description
    if analysis_type == "summary":
        s = stats_dict
        stats_text = (
            f"Analysis: Descriptive summary of numeric variable '{outcome}'.\n"
            f"Statistics: n={s['n']}, mean={s['mean']:.3f}, sd={s['sd']:.3f}, "
            f"min={s['min']:.3f}, max={s['max']:.3f}.\n"
        )
    elif analysis_type == "ttest":
        s = stats_dict
        stats_text = (
            f"Analysis: Welch two-sample t-test of numeric outcome '{outcome}' "
            f"between groups '{s['group1']}' and '{s['group2']}'.\n"
            f"Group '{s['group1']}': n={s['n1']}, mean={s['mean1']:.3f}.\n"
            f"Group '{s['group2']}': n={s['n2']}, mean={s['mean2']:.3f}.\n"
            f"Difference (group1 - group2) = {s['diff']:.3f}.\n"
            f"t={s['t']:.3f}, p={s['p']:.4g}.\n"
        )
    elif analysis_type == "chisq":
        s = stats_dict
        stats_text = (
            f"Analysis: Chi-square test of independence between '{outcome}' and '{variable2}'.\n"
            f"Observed 2x2 table (rows={s['index']}, cols={s['columns']}): {s['table']}.\n"
            f"Chi-square={s['chi2']:.3f}, df={s['df']}, p={s['p']:.4g}.\n"
        )
    elif analysis_type == "regression":
        s = stats_dict
        stats_text = (
            f"Analysis: Simple linear regression of numeric outcome '{outcome}' on predictor '{variable2}'.\n"
            f"n={s['n']}, intercept(beta0)={s['beta0']:.3f}, slope(beta1)={s['beta1']:.3f}, "
            f"SE_beta1={s['se_beta1']:.3f}, t={s['t']:.3f}, p={s['p']:.4g}, R²={s['r2']:.3f}.\n"
        )
    else:
        stats_text = "Analysis type not recognized.\n"

    if extra_instructions.strip():
        stats_text += f"\nUser extra instructions: {extra_instructions}\n"

    return base_context + stats_text + "\nNow write the conclusion:"


def get_llm_conclusion(
    llm,
    analysis_type: str,
    outcome: str,
    variable2: str,
    stats_dict: Dict[str, Any],
    extra_instructions: str = "",
) -> str:
    if not stats_dict:
        return "Not enough data to perform the selected analysis."

    prompt = build_llm_prompt(
        analysis_type, outcome, variable2, stats_dict, extra_instructions
    )
    resp = llm([HumanMessage(content=prompt)])
    return resp.content.strip()


# ----------------------------------------------------
# Streamlit app
# ----------------------------------------------------
def main():
    st.set_page_config(page_title="Biostatistical Agent", layout="wide")

    st.title("Biostatistical Streamlit Agent (Databricks LLM)")
    st.write(
        "Upload a dataset, select an analysis, and let a biostatistical agent "
        "run basic tests and generate an LLM-based interpretation via Databricks."
    )
    st.caption("For exploratory use only – not for regulatory or clinical decision-making.")

    # Sidebar: LLM settings
    with st.sidebar:
        st.header("LLM settings (ChatDatabricks)")
        model_name = st.text_input(
            "Model name (ignored if using DATABRICKS_LLM_ENDPOINT)",
            value="databricks-dbrx-instruct",
        )
        temperature = st.slider("Temperature", 0.0, 1.0, 0.2, 0.05)
        extra_instructions = st.text_area(
            "Extra instructions to the LLM (optional)",
            placeholder="e.g., emphasize clinical relevance, or keep extremely concise.",
        )

    # Data upload / input
    st.subheader("1. Upload data")
    uploaded_file = st.file_uploader("Upload CSV file", type=["csv"])
    demo = st.checkbox("Use small demo dataset", value=False)

    df = None
    if uploaded_file is not None:
        df = pd.read_csv(uploaded_file)
    elif demo:
        df = pd.DataFrame(
            {
                "group": ["treatment", "control", "treatment", "control", "treatment", "control"],
                "outcome": [12.3, 10.1, 11.4, 9.7, 13.2, 9.9],
                "sex": ["M", "F", "F", "M", "F", "F"],
            }
        )

    if df is None:
        st.info("Upload a CSV or select the demo dataset to begin.")
        return

    st.write("**Preview of data (first 10 rows):**")
    st.dataframe(df.head(10))

    var_types = infer_variable_types(df)

    # Analysis selection
    st.subheader("2. Choose analysis type")

    analysis_type = st.radio(
        "Analysis",
        options=["summary", "ttest", "chisq", "regression"],
        format_func=lambda x: {
            "summary": "Summary (numeric)",
            "ttest": "Two-sample t-test",
            "chisq": "Chi-square (2x2)",
            "regression": "Linear regression",
        }[x],
        horizontal=True,
    )

    # Variable selection
    st.subheader("3. Select variables")

    numeric_vars = [c for c, t in var_types.items() if t == "numeric"]
    categorical_vars = [c for c, t in var_types.items() if t == "categorical"]

    col1, col2 = st.columns(2)

    with col1:
        if analysis_type in ["summary", "ttest", "regression"]:
            outcome = st.selectbox(
                "Outcome (numeric)",
                options=numeric_vars,
                help="Numeric variable used as outcome.",
            )
        else:
            outcome = st.selectbox(
                "Variable 1",
                options=list(df.columns),
                help="First variable for chi-square.",
            )

    with col2:
        var2 = None
        if analysis_type == "ttest":
            var2 = st.selectbox(
                "Group variable (categorical with 2 levels)",
                options=categorical_vars,
            )
        elif analysis_type == "chisq":
            var2 = st.selectbox(
                "Variable 2 (categorical with 2 levels)",
                options=categorical_vars,
            )
        elif analysis_type == "regression":
            var2 = st.selectbox(
                "Predictor (numeric)",
                options=numeric_vars,
            )

    # Run analysis
    st.subheader("4. Results & LLM-generated biostatistical conclusion")

    if st.button("Run analysis"):
        llm = get_llm(model_name=model_name, temperature=temperature)

        stats_dict: Dict[str, Any] = {}
        analysis_label = ""

        try:
            if analysis_type == "summary":
                stats_dict = summarize_numeric(df[outcome])
                analysis_label = "summary"

                if not stats_dict:
                    st.error("Not enough numeric data for summary.")
                else:
                    st.write("**Summary statistics:**")
                    st.json(stats_dict)

            elif analysis_type == "ttest":
                if not outcome or not var2:
                    st.error("Select both outcome and group variable.")
                else:
                    stats_dict, g1, g2 = two_sample_ttest(df[outcome], df[var2])
                    analysis_label = "ttest"

                    if not stats_dict:
                        st.error(
                            "Unable to run t-test. Ensure outcome is numeric and group has exactly two categories with enough data."
                        )
                    else:
                        st.write("**T-test results (Welch):**")
                        st.json(stats_dict)

            elif analysis_type == "chisq":
                if not outcome or not var2:
                    st.error("Select both categorical variables.")
                else:
                    stats_dict = chi_square_2x2(df[outcome], df[var2])
                    analysis_label = "chisq"

                    if not stats_dict:
                        st.error(
                            "Unable to run chi-square. Both variables must be categorical with exactly two levels."
                        )
                    else:
                        st.write("**Contingency table (2x2):**")
                        tab_df = pd.DataFrame(
                            stats_dict["table"],
                            index=stats_dict["index"],
                            columns=stats_dict["columns"],
                        )
                        st.dataframe(tab_df)
                        st.write(
                            f"Chi-square={stats_dict['chi2']:.3f}, df={stats_dict['df']}, p={stats_dict['p']:.4g}"
                        )

            elif analysis_type == "regression":
                if not outcome or not var2:
                    st.error("Select both outcome and predictor.")
                else:
                    stats_dict = simple_linear_regression(df[outcome], df[var2])
                    analysis_label = "regression"

                    if not stats_dict:
                        st.error(
                            "Unable to run regression. Both variables must be numeric with at least 3 complete observations."
                        )
                    else:
                        st.write("**Regression results:**")
                        st.json(stats_dict)

            # If stats_dict is available, get LLM conclusion
            if stats_dict:
                st.markdown("---")
                st.write("**LLM biostatistical conclusion (ChatDatabricks):**")
                conclusion = get_llm_conclusion(
                    llm,
                    analysis_label,
                    outcome,
                    var2 if var2 is not None else "",
                    stats_dict,
                    extra_instructions=extra_instructions,
                )
                st.success(conclusion)

        except Exception as e:
            st.error(f"An error occurred: {e}")


if __name__ == "__main__":
    main()
