import os
import json
from typing import Dict, Any, List, Optional

import numpy as np
import pandas as pd
import streamlit as st
from scipy import stats
import plotly.express as px
from dotenv import load_dotenv

from langchain_community.chat_models import ChatDatabricks
from langchain.schema import HumanMessage


# =====================================================
# LLM helper
# =====================================================
load_dotenv()
DATABRICKS_HOST = os.environ.get("DATABRICKS_HOST")
DATABRICKS_TOKEN = os.environ.get("DATABRICKS_TOKEN")
LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")

# Create a remote Spark session
os.environ.pop('DATABRICKS_CLIENT_ID', None)    # Frank
os.environ.pop('DATABRICKS_CLIENT_SECRET', None) # Frank

# LLM for plotting graph
LLM = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)



#----------------------------------------------------
def get_llm(
    model_name: str = "databricks-dbrx-instruct",
    temperature: float = 0.1,
):
    """
    Build a ChatDatabricks client.

    If DATABRICKS_LLM_ENDPOINT is set, we call that serving endpoint.
    Otherwise, we call a workspace model by name (e.g. databricks-dbrx-instruct).
    """
    endpoint = LLM_ENDPOINT_NAME #os.getenv("DATABRICKS_LLM_ENDPOINT")

    if endpoint:
        return ChatDatabricks(endpoint=endpoint, temperature=temperature)
    else:
        return ChatDatabricks(model=model_name, temperature=temperature)


# =====================================================
# Data / schema utilities
# =====================================================
def infer_variable_types(df: pd.DataFrame) -> Dict[str, str]:
    """
    Infer variable types as 'numeric' or 'categorical' based on dtype and cardinality.
    """
    var_types: Dict[str, str] = {}
    for col in df.columns:
        s = df[col]
        # drop NA-like values
        s_clean = s.replace(["NA", "na", ""], np.nan)
        # try numeric
        numeric_series = pd.to_numeric(s_clean, errors="coerce")
        numeric_fraction = numeric_series.notna().mean()
        unique_vals = s_clean.dropna().unique()
        if numeric_fraction > 0.8 and len(unique_vals) > 5:
            var_types[col] = "numeric"
        else:
            var_types[col] = "categorical"
    return var_types


def build_schema_description(
    df: pd.DataFrame, var_types: Dict[str, str], max_rows: int = 5
) -> str:
    """
    Create a compact textual description of the dataset for the LLM.
    We only send a small sample and summaries, not the entire dataset.
    """
    lines: List[str] = []

    lines.append(f"Dataset has {df.shape[0]} rows and {df.shape[1]} columns.\n")
    lines.append("Columns:\n")

    for col in df.columns:
        col_type = var_types.get(col, "unknown")
        s = df[col]
        non_na = s.replace(["NA", "na", ""], np.nan).dropna()

        if col_type == "numeric":
            numeric = pd.to_numeric(non_na, errors="coerce").dropna()
            if len(numeric) > 0:
                desc = (
                    f"  - {col} (numeric): n={len(numeric)}, "
                    f"mean={numeric.mean():.3f}, sd={numeric.std(ddof=1):.3f}, "
                    f"min={numeric.min():.3f}, max={numeric.max():.3f}"
                )
            else:
                desc = f"  - {col} (numeric): no non-missing values detected"
        else:
            unique_vals = non_na.astype(str).value_counts().head(6)
            uv_str = ", ".join(
                f"{k} (n={v})" for k, v in unique_vals.items()
            )
            desc = f"  - {col} (categorical): {uv_str}"

        lines.append(desc)

    lines.append("\nExample rows (first few):")
    sample = df.head(max_rows).astype(str)
    lines.append(sample.to_csv(index=False))

    return "\n".join(lines)


# =====================================================
# Statistical analysis helpers
# =====================================================
def run_summary(df: pd.DataFrame, col: str) -> Dict[str, Any]:
    s = pd.to_numeric(df[col], errors="coerce").dropna()
    if len(s) == 0:
        return {}
    return {
        "analysis_type": "summary",
        "variable": col,
        "n": int(s.count()),
        "mean": float(s.mean()),
        "sd": float(s.std(ddof=1)),
        "min": float(s.min()),
        "max": float(s.max()),
    }


def run_ttest(
    df: pd.DataFrame, outcome: str, group: str
) -> Dict[str, Any]:
    d = df[[outcome, group]].copy()
    d[outcome] = pd.to_numeric(d[outcome], errors="coerce")
    d = d.dropna()

    groups = d[group].unique()
    if len(groups) != 2:
        return {}

    g1, g2 = groups[0], groups[1]
    y1 = d.loc[d[group] == g1, outcome]
    y2 = d.loc[d[group] == g2, outcome]

    if len(y1) < 2 or len(y2) < 2:
        return {}

    t_stat, p_value = stats.ttest_ind(y1, y2, equal_var=False)

    return {
        "analysis_type": "ttest",
        "outcome": outcome,
        "group": group,
        "group1": str(g1),
        "group2": str(g2),
        "n1": int(len(y1)),
        "n2": int(len(y2)),
        "mean1": float(y1.mean()),
        "mean2": float(y2.mean()),
        "diff": float(y1.mean() - y2.mean()),
        "t": float(t_stat),
        "p": float(p_value),
    }


def run_chisq(df: pd.DataFrame, var1: str, var2: str) -> Dict[str, Any]:
    d = df[[var1, var2]].dropna()
    tab = pd.crosstab(d[var1], d[var2])
    if tab.shape != (2, 2):
        return {}

    chi2, p, dof, expected = stats.chi2_contingency(tab)

    return {
        "analysis_type": "chisq",
        "var1": var1,
        "var2": var2,
        "table": tab.values.tolist(),
        "index": tab.index.astype(str).tolist(),
        "columns": tab.columns.astype(str).tolist(),
        "chi2": float(chi2),
        "df": int(dof),
        "p": float(p),
        "expected": expected.tolist(),
    }


def run_regression(
    df: pd.DataFrame, outcome: str, predictor: str
) -> Dict[str, Any]:
    d = df[[outcome, predictor]].copy()
    d[outcome] = pd.to_numeric(d[outcome], errors="coerce")
    d[predictor] = pd.to_numeric(d[predictor], errors="coerce")
    d = d.dropna()
    if len(d) < 3:
        return {}

    slope, intercept, r_value, p_value, std_err = stats.linregress(
        d[predictor], d[outcome]
    )

    return {
        "analysis_type": "regression",
        "outcome": outcome,
        "predictor": predictor,
        "n": int(len(d)),
        "beta0": float(intercept),
        "beta1": float(slope),
        "se_beta1": float(std_err),
        "t": float(slope / std_err if std_err != 0 else np.nan),
        "p": float(p_value),
        "r2": float(r_value ** 2),
    }


def run_correlation(
    df: pd.DataFrame, var1: str, var2: str
) -> Dict[str, Any]:
    d = df[[var1, var2]].copy()
    d[var1] = pd.to_numeric(d[var1], errors="coerce")
    d[var2] = pd.to_numeric(d[var2], errors="coerce")
    d = d.dropna()
    if len(d) < 3:
        return {}

    r, p = stats.pearsonr(d[var1], d[var2])
    return {
        "analysis_type": "correlation",
        "var1": var1,
        "var2": var2,
        "n": int(len(d)),
        "r": float(r),
        "p": float(p),
    }


# =====================================================
# LLM reasoning: choose analysis + variables
# =====================================================
ANALYSIS_SPEC = """
You are a biostatistician embedded in a data analysis tool.

You receive:
1. A short user question about the analysis they want.
2. A description of the dataset schema and example rows.

Your task:
- Decide the most appropriate single primary biostatistical analysis to run.
- Choose variables from the dataset.
- Optionally suggest a couple of plots.

You may choose one of these analysis_type values:
- "summary": summarize a single numeric variable.
- "ttest": compare a numeric outcome between two groups (2-level categorical).
- "chisq": test association between two binary/categorical variables (2x2).
- "regression": simple linear regression with numeric outcome and numeric predictor.
- "correlation": correlation between two numeric variables.

Return a STRICT JSON object **only** with the following keys:
{
  "analysis_type": "summary" | "ttest" | "chisq" | "regression" | "correlation",
  "outcome": "<column name or null>",
  "predictor": "<column name or null>",
  "group": "<column name or null>",
  "var1": "<column name or null>",
  "var2": "<column name or null>",
  "plots": ["boxplot" | "histogram" | "scatter" | "bar" | "violin" | "line"],
  "reasoning": "<short explanation of your choice>"
}

Rules:
- For "summary": use 'outcome' (numeric) and set others to null.
- For "ttest": use 'outcome' (numeric) and 'group' (2-level categorical). Others null.
- For "chisq": use 'var1' and 'var2' (both categorical). Others null.
- For "regression": use 'outcome' (numeric) and 'predictor' (numeric). Others null.
- For "correlation": use 'var1' and 'var2' (numeric). Others null.

Be consistent with column names as given in the schema. Do not invent columns.
"""


def plan_analysis_with_llm(
    llm, user_query: str, schema_description: str
) -> Dict[str, Any]:
    """Ask the LLM to choose analysis plan based on schema + user query."""
    prompt = (
        ANALYSIS_SPEC
        + "\n\nUser question:\n"
        + user_query.strip()
        + "\n\nDataset schema and sample:\n"
        + schema_description
        + "\n\nReturn JSON now."
    )

    resp = llm([HumanMessage(content=prompt)]).content.strip()

    # Try to extract JSON robustly
    if "```" in resp:
        try:
            blocks = resp.split("```")
            for block in blocks:
                if "{" in block and "}" in block:
                    json_text = block[block.index("{") : block.rindex("}") + 1]
                    return json.loads(json_text)
        except Exception:
            pass

    try:
        return json.loads(resp)
    except Exception:
        return {}


# =====================================================
# LLM interpretation of results
# =====================================================
def build_interpretation_prompt(plan: Dict[str, Any], stats: Dict[str, Any]) -> str:
    base = (
        "You are a biostatistician. Given an analysis description and results, "
        "write a concise interpretation suitable for a biomedical paper.\n\n"
        "Guidelines:\n"
        "- Briefly state what was analyzed (variables, groups).\n"
        "- State whether there is evidence of an association/difference.\n"
        "- Mention effect direction and strength where possible.\n"
        "- Report key statistics (means, differences, t, r, chi-square, p, R², etc.).\n"
        "- Use at most 3 sentences in a single short paragraph.\n\n"
    )

    context = {
        "plan": plan,
        "stats": stats,
    }
    return base + "Analysis plan and numerical results:\n" + json.dumps(
        context, indent=2
    ) + "\n\nNow write the interpretation:"


def interpret_results_with_llm(
    llm, plan: Dict[str, Any], stats: Dict[str, Any]
) -> str:
    if not stats:
        return "Not enough data to perform the requested analysis."

    prompt = build_interpretation_prompt(plan, stats)
    resp = llm([HumanMessage(content=prompt)]).content.strip()
    return resp


# =====================================================
# Plotting helpers (Plotly Express)
# =====================================================
def make_plots(
    df: pd.DataFrame,
    plan: Dict[str, Any],
    var_types: Dict[str, str],
) -> List[Any]:
    plots: List[Any] = []
    analysis_type = plan.get("analysis_type")
    requested_plots = plan.get("plots") or []

    # Deduplicate
    requested_plots = list(dict.fromkeys(requested_plots))

    def add_histogram(col: str):
        d = df[[col]].copy()
        d[col] = pd.to_numeric(d[col], errors="coerce")
        d = d.dropna()
        if d.empty:
            return
        fig = px.histogram(d, x=col, marginal="rug", nbins=20, title=f"Histogram of {col}")
        plots.append(fig)

    def add_boxplot(outcome: str, group: Optional[str]):
        d_cols = [outcome] + ([group] if group else [])
        d = df[d_cols].copy()
        d[outcome] = pd.to_numeric(d[outcome], errors="coerce")
        d = d.dropna()
        if d.empty:
            return
        if group and group in d.columns:
            fig = px.box(d, x=group, y=outcome, points="all", title=f"{outcome} by {group}")
        else:
            fig = px.box(d, y=outcome, points="all", title=f"Boxplot of {outcome}")
        plots.append(fig)

    def add_scatter(x: str, y: str):
        d = df[[x, y]].copy()
        d[x] = pd.to_numeric(d[x], errors="coerce")
        d[y] = pd.to_numeric(d[y], errors="coerce")
        d = d.dropna()
        if d.empty:
            return
        fig = px.scatter(d, x=x, y=y, trendline="ols", title=f"{y} vs {x}")
        plots.append(fig)

    def add_bar(var1: str, var2: Optional[str]):
        d_cols = [var1] + ([var2] if var2 else [])
        d = df[d_cols].dropna()
        if d.empty:
            return
        if var2:
            fig = px.bar(
                d.groupby([var1, var2]).size().reset_index(name="count"),
                x=var1,
                y="count",
                color=var2,
                barmode="group",
                title=f"{var1} by {var2}",
            )
        else:
            fig = px.bar(
                d[var1].value_counts().reset_index().rename(columns={"index": var1, var1: "count"}),
                x=var1,
                y="count",
                title=f"Counts of {var1}",
            )
        plots.append(fig)

    # Decide which plots to actually create based on analysis type
    if analysis_type == "summary":
        outcome = plan.get("outcome")
        if outcome and outcome in df.columns:
            if "histogram" in requested_plots or not requested_plots:
                add_histogram(outcome)
            if "boxplot" in requested_plots:
                add_boxplot(outcome, None)

    elif analysis_type == "ttest":
        outcome = plan.get("outcome")
        group = plan.get("group")
        if outcome and group and outcome in df.columns and group in df.columns:
            if "boxplot" in requested_plots or not requested_plots:
                add_boxplot(outcome, group)
            if "histogram" in requested_plots:
                add_histogram(outcome)

    elif analysis_type == "chisq":
        var1 = plan.get("var1")
        var2 = plan.get("var2")
        if var1 and var2 and var1 in df.columns and var2 in df.columns:
            if "bar" in requested_plots or not requested_plots:
                add_bar(var1, var2)

    elif analysis_type in ["regression", "correlation"]:
        if analysis_type == "regression":
            x = plan.get("predictor")
            y = plan.get("outcome")
        else:  # correlation
            x = plan.get("var1")
            y = plan.get("var2")
        if x and y and x in df.columns and y in df.columns:
            if "scatter" in requested_plots or not requested_plots:
                add_scatter(x, y)
            if "histogram" in requested_plots:
                add_histogram(y)

    return plots


# =====================================================
# Streamlit app
# =====================================================
def main():
    st.set_page_config(page_title="Biostatistical Agent (Auto LLM Planner)", layout="wide")

    st.title("Biostatistical Streamlit Agent")
    st.write(
        "Upload a CSV, describe your question in natural language, and let the LLM "
        "automatically choose a suitable biostatistical analysis, run it, "
        "and generate Plotly plots plus a written conclusion."
    )
    st.caption("For exploratory use only – not for regulatory or clinical decisions.")

    # Sidebar: LLM settings
    with st.sidebar:
        st.header("LLM settings (ChatDatabricks)")
        model_name = st.text_input(
            "Workspace model name (ignored if DATABRICKS_LLM_ENDPOINT is set)",
            value="databricks-dbrx-instruct",
        )
        temperature = st.slider("Temperature", 0.0, 1.0, 0.1, 0.05)

    # Data upload
    st.subheader("1. Upload data")
    uploaded_file = st.file_uploader("Upload CSV file", type=["csv"])
    demo = st.checkbox("Use small demo dataset", value=False)

    df = None
    if uploaded_file is not None:
        df = pd.read_csv(uploaded_file)
    elif demo:
        df = pd.DataFrame(
            {
                "group": ["treatment", "control", "treatment", "control", "treatment", "control"],
                "outcome": [12.3, 10.1, 11.4, 9.7, 13.2, 9.9],
                "age": [55, 60, 52, 58, 49, 62],
                "sex": ["M", "F", "F", "M", "F", "F"],
            }
        )

    if df is None:
        st.info("Upload a CSV or select the demo dataset to begin.")
        return

    st.write("**Preview of data (first 10 rows):**")
    st.dataframe(df.head(10))

    var_types = infer_variable_types(df)

    # User query
    st.subheader("2. Describe your analysis question")
    user_query = st.text_area(
        "Example: 'Compare the outcome between treatment and control groups', "
        "'Is sex associated with outcome?', 'Is there a relationship between age and outcome?'",
        height=80,
    )

    if not user_query.strip():
        st.info("Enter a question about the analysis you want to perform.")
        return

    # Plan + run
    st.subheader("3. Analysis plan, results, and plots")

    if st.button("Run automatic analysis"):
        llm = get_llm(model_name=model_name, temperature=temperature)

        try:
            schema_desc = build_schema_description(df, var_types)
            plan = plan_analysis_with_llm(llm, user_query, schema_desc)

            if not plan or "analysis_type" not in plan:
                st.error("The LLM could not determine an analysis plan. Try rephrasing your question.")
                st.text("Raw plan response:\n" + json.dumps(plan, indent=2))
                return

            st.write("**LLM-chosen analysis plan:**")
            st.json(plan)

            analysis_type = plan.get("analysis_type")
            stats: Dict[str, Any] = {}

            # Execute the selected analysis
            if analysis_type == "summary":
                col = plan.get("outcome")
                if not col or col not in df.columns:
                    st.error("The plan refers to an invalid outcome variable.")
                else:
                    stats = run_summary(df, col)

            elif analysis_type == "ttest":
                outcome = plan.get("outcome")
                group = plan.get("group")
                if (
                    not outcome
                    or not group
                    or outcome not in df.columns
                    or group not in df.columns
                ):
                    st.error("The plan refers to invalid outcome/group variables.")
                else:
                    stats = run_ttest(df, outcome, group)

            elif analysis_type == "chisq":
                var1 = plan.get("var1")
                var2 = plan.get("var2")
                if (
                    not var1
                    or not var2
                    or var1 not in df.columns
                    or var2 not in df.columns
                ):
                    st.error("The plan refers to invalid categorical variables.")
                else:
                    stats = run_chisq(df, var1, var2)

            elif analysis_type == "regression":
                outcome = plan.get("outcome")
                predictor = plan.get("predictor")
                if (
                    not outcome
                    or not predictor
                    or outcome not in df.columns
                    or predictor not in df.columns
                ):
                    st.error("The plan refers to invalid outcome/predictor variables.")
                else:
                    stats = run_regression(df, outcome, predictor)

            elif analysis_type == "correlation":
                var1 = plan.get("var1")
                var2 = plan.get("var2")
                if (
                    not var1
                    or not var2
                    or var1 not in df.columns
                    or var2 not in df.columns
                ):
                    st.error("The plan refers to invalid numeric variables for correlation.")
                else:
                    stats = run_correlation(df, var1, var2)

            else:
                st.error(f"Unsupported analysis type chosen by LLM: {analysis_type}")

            if stats:
                st.markdown("### Numerical results")
                st.json(stats)
            else:
                st.warning("No numerical results were produced (likely insufficient or incompatible data).")

            # Plots
            st.markdown("### Plots")
            figs = make_plots(df, plan, var_types)
            if not figs:
                st.info("No plots generated (plan may not have suggested any or variables were invalid).")
            else:
                for fig in figs:
                    st.plotly_chart(fig, use_container_width=True)

            # Interpretation
            st.markdown("### LLM biostatistical interpretation")
            interpretation = interpret_results_with_llm(llm, plan, stats)
            st.success(interpretation)

        except Exception as e:
            st.error(f"An error occurred: {e}")


if __name__ == "__main__":
    main()
