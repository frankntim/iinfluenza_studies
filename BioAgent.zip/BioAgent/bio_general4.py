import os
import json
from typing import Dict, Any, List, Optional

import numpy as np
import pandas as pd
import streamlit as st
from scipy import stats
import plotly.express as px
import os
from dotenv import load_dotenv
from databricks.sdk import WorkspaceClient
import sqlparse
import statsmodels.api as sm
import uuid
from langchain_community.chat_models import ChatDatabricks
from langchain.schema import HumanMessage
from genie_room import genie_query, clear_conversation #, CHART_PROMPT,LLM

import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm
from statsmodels.stats.anova import AnovaRM


# =====================================================
# LLM helper (ChatDatabricks)
# =====================================================
load_dotenv()

# Load environment variables
SPACE_ID = os.environ.get("SPACE_ID")
DATABRICKS_HOST = os.environ.get("DATABRICKS_HOST")
DATABRICKS_HOST_BASE = os.environ.get("DATABRICKS_HOST_BASE")
DATABRICKS_TOKEN = os.environ.get("DATABRICKS_TOKEN")
LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")

# Create a remote Spark session
os.environ.pop('DATABRICKS_CLIENT_ID', None)    # Frank
os.environ.pop('DATABRICKS_CLIENT_SECRET', None) # Frank

# LLM for plotting graph
LLM = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)


#==========================================
def get_llm(
    temperature: float = 0.1,
):
    """
    Build a ChatDatabricks client.

    If DATABRICKS_LLM_ENDPOINT is set, we call that serving endpoint.
    Otherwise, we call a workspace model by name (e.g. databricks-dbrx-instruct).
    """
    endpoint = LLM_ENDPOINT_NAME #os.getenv("DATABRICKS_LLM_ENDPOINT")
    
    return ChatDatabricks(endpoint=endpoint, temperature=temperature)


# =====================================================
# Databricks Genie helper (placeholder)
# =====================================================
def query_genie_for_dataframe(user_query: str) -> pd.DataFrame:
    """
    Query Databricks Genie for a dataset and return a pandas DataFrame.

    NOTE: This is a template. You must plug in your actual Genie client here.

    Example (pseudo-code):

        from databricks_genai import GenieClient

        client = GenieClient(space_id=space_id)
        result = client.query(genie_query)
        df = result.to_pandas()

    For now, this function is implemented as a placeholder that raises
    an error unless you replace it.
    """
    
    current_session_id = str(uuid.uuid4())
    response, query_text,result_description = genie_query(user_query, current_session_id)
    if isinstance(response, str):
        #response = response.replace("`", "")
        df = pd.DataFrame()
    else:
        df = response.copy()
    return df


# =====================================================
# Data / schema utilities
# =====================================================
def infer_variable_types(df: pd.DataFrame) -> Dict[str, str]:
    var_types: Dict[str, str] = {}
    for col in df.columns:
        s = df[col]
        s_clean = s.replace(["NA", "na", ""], np.nan)
        numeric_series = pd.to_numeric(s_clean, errors="coerce")
        numeric_fraction = numeric_series.notna().mean()
        unique_vals = s_clean.dropna().unique()
        if numeric_fraction > 0.8 and len(unique_vals) > 5:
            var_types[col] = "numeric"
        else:
            var_types[col] = "categorical"
    return var_types


def build_schema_description(
    df: pd.DataFrame, var_types: Dict[str, str], max_rows: int = 5
) -> str:
    lines: List[str] = []

    lines.append(f"Dataset has {df.shape[0]} rows and {df.shape[1]} columns.\n")
    lines.append("Columns:\n")

    for col in df.columns:
        col_type = var_types.get(col, "unknown")
        s = df[col]
        non_na = s.replace(["NA", "na", ""], np.nan).dropna()

        if col_type == "numeric":
            numeric = pd.to_numeric(non_na, errors="coerce").dropna()
            if len(numeric) > 0:
                desc = (
                    f"  - {col} (numeric): n={len(numeric)}, "
                    f"mean={numeric.mean():.3f}, sd={numeric.std(ddof=1):.3f}, "
                    f"min={numeric.min():.3f}, max={numeric.max():.3f}"
                )
            else:
                desc = f"  - {col} (numeric): no non-missing values detected"
        else:
            unique_vals = non_na.astype(str).value_counts().head(6)
            uv_str = ", ".join(f"{k} (n={v})" for k, v in unique_vals.items())
            desc = f"  - {col} (categorical): {uv_str}"

        lines.append(desc)

    lines.append("\nExample rows (first few):")
    sample = df.head(max_rows).astype(str)
    lines.append(sample.to_csv(index=False))

    return "\n".join(lines)


# =====================================================
# Statistical analysis helpers (basic)
# =====================================================
def run_summary(df: pd.DataFrame, col: str) -> Dict[str, Any]:
    s = pd.to_numeric(df[col], errors="coerce").dropna()
    if len(s) == 0:
        return {}
    return {
        "analysis_type": "summary",
        "variable": col,
        "n": int(s.count()),
        "mean": float(s.mean()),
        "sd": float(s.std(ddof=1)),
        "min": float(s.min()),
        "max": float(s.max()),
    }


def run_ttest(df: pd.DataFrame, outcome: str, group: str) -> Dict[str, Any]:
    d = df[[outcome, group]].copy()
    d[outcome] = pd.to_numeric(d[outcome], errors="coerce")
    d = d.dropna()

    groups = d[group].unique()
    if len(groups) != 2:
        return {}

    g1, g2 = groups[0], groups[1]
    y1 = d.loc[d[group] == g1, outcome]
    y2 = d.loc[d[group] == g2, outcome]

    if len(y1) < 2 or len(y2) < 2:
        return {}

    t_stat, p_value = stats.ttest_ind(y1, y2, equal_var=False)

    return {
        "analysis_type": "ttest",
        "outcome": outcome,
        "group": group,
        "group1": str(g1),
        "group2": str(g2),
        "n1": int(len(y1)),
        "n2": int(len(y2)),
        "mean1": float(y1.mean()),
        "mean2": float(y2.mean()),
        "diff": float(y1.mean() - y2.mean()),
        "t": float(t_stat),
        "p": float(p_value),
    }


def run_chisq(df: pd.DataFrame, var1: str, var2: str) -> Dict[str, Any]:
    d = df[[var1, var2]].dropna()
    tab = pd.crosstab(d[var1], d[var2])
    if tab.shape != (2, 2):
        return {}

    chi2, p, dof, expected = stats.chi2_contingency(tab)

    return {
        "analysis_type": "chisq",
        "var1": var1,
        "var2": var2,
        "table": tab.values.tolist(),
        "index": tab.index.astype(str).tolist(),
        "columns": tab.columns.astype(str).tolist(),
        "chi2": float(chi2),
        "df": int(dof),
        "p": float(p),
        "expected": expected.tolist(),
    }


def run_regression(df: pd.DataFrame, outcome: str, predictor: str) -> Dict[str, Any]:
    d = df[[outcome, predictor]].copy()
    d[outcome] = pd.to_numeric(d[outcome], errors="coerce")
    d[predictor] = pd.to_numeric(d[predictor], errors="coerce")
    d = d.dropna()
    if len(d) < 3:
        return {}

    slope, intercept, r_value, p_value, std_err = stats.linregress(
        d[predictor], d[outcome]
    )

    return {
        "analysis_type": "regression",
        "outcome": outcome,
        "predictor": predictor,
        "n": int(len(d)),
        "beta0": float(intercept),
        "beta1": float(slope),
        "se_beta1": float(std_err),
        "t": float(slope / std_err if std_err != 0 else np.nan),
        "p": float(p_value),
        "r2": float(r_value**2),
    }


def run_correlation(df: pd.DataFrame, var1: str, var2: str) -> Dict[str, Any]:
    d = df[[var1, var2]].copy()
    d[var1] = pd.to_numeric(d[var1], errors="coerce")
    d[var2] = pd.to_numeric(d[var2], errors="coerce")
    d = d.dropna()
    if len(d) < 3:
        return {}

    r, p = stats.pearsonr(d[var1], d[var2])
    return {
        "analysis_type": "correlation",
        "var1": var1,
        "var2": var2,
        "n": int(len(d)),
        "r": float(r),
        "p": float(p),
    }


# =====================================================
# ANOVA & LMM helpers
# =====================================================
def run_anova_oneway(df: pd.DataFrame, outcome: str, factor: str) -> Dict[str, Any]:
    d = df[[outcome, factor]].dropna()
    d[outcome] = pd.to_numeric(d[outcome], errors="coerce")
    d = d.dropna()
    if d.empty or d[factor].nunique() < 2:
        return {}

    model = smf.ols(f"{outcome} ~ C({factor})", data=d).fit()
    aov = anova_lm(model, typ=2)
    aov_dict = aov.reset_index().rename(columns={"index": "source"}).to_dict(orient="records")
    return {
        "analysis_type": "anova_oneway",
        "outcome": outcome,
        "factor": factor,
        "anova_table": aov_dict,
        "model_summary": str(model.summary()),
    }


def run_anova_twoway(df: pd.DataFrame, outcome: str, factor1: str, factor2: str) -> Dict[str, Any]:
    d = df[[outcome, factor1, factor2]].dropna()
    d[outcome] = pd.to_numeric(d[outcome], errors="coerce")
    d = d.dropna()
    if d.empty or d[factor1].nunique() < 2 or d[factor2].nunique() < 2:
        return {}

    model = smf.ols(f"{outcome} ~ C({factor1}) * C({factor2})", data=d).fit()
    aov = anova_lm(model, typ=2)
    aov_dict = aov.reset_index().rename(columns={"index": "source"}).to_dict(orient="records")
    return {
        "analysis_type": "anova_twoway",
        "outcome": outcome,
        "factor1": factor1,
        "factor2": factor2,
        "anova_table": aov_dict,
        "model_summary": str(model.summary()),
    }


def run_anova_rm(
    df: pd.DataFrame, outcome: str, subject: str, within: str
) -> Dict[str, Any]:
    """
    One-way repeated measures ANOVA using statsmodels AnovaRM.
    Assumes long format: multiple rows per subject, each row is a level of 'within'.
    """
    d = df[[outcome, subject, within]].dropna()
    d[outcome] = pd.to_numeric(d[outcome], errors="coerce")
    d = d.dropna()
    if d.empty:
        return {}
    if d[subject].nunique() < 2 or d[within].nunique() < 2:
        return {}

    try:
        aovrm = AnovaRM(d, depvar=outcome, subject=subject, within=[within]).fit()
    except Exception:
        return {}

    table_df = aovrm.anova_table.reset_index().rename(columns={"index": "source"})
    aov_dict = table_df.to_dict(orient="records")

    return {
        "analysis_type": "anova_rm",
        "outcome": outcome,
        "subject": subject,
        "within": within,
        "anova_table": aov_dict,
        "table_str": str(aovrm.anova_table),
    }


def run_lmm(
    df: pd.DataFrame,
    outcome: str,
    subject: str,
    fixed_factors: List[str],
) -> Dict[str, Any]:
    """
    Simple linear mixed model: random intercept for subject, fixed effects for factors.
    """
    cols = [outcome, subject] + fixed_factors
    d = df[cols].dropna()
    d[outcome] = pd.to_numeric(d[outcome], errors="coerce")
    d = d.dropna()
    if d.empty or d[subject].nunique() < 2:
        return {}

    fixed_formula = " + ".join([f"C({f})" for f in fixed_factors]) if fixed_factors else "1"
    formula = f"{outcome} ~ {fixed_formula}"

    try:
        model = smf.mixedlm(formula, data=d, groups=d[subject]).fit()
    except Exception:
        return {}

    summary_str = str(model.summary())
    fe = model.fe_params.to_dict()
    re_var = model.cov_re.iloc[0, 0] if model.cov_re.shape == (1, 1) else None

    return {
        "analysis_type": "lmm",
        "outcome": outcome,
        "subject": subject,
        "fixed_factors": fixed_factors,
        "fixed_effects": fe,
        "random_effect_variance": float(re_var) if re_var is not None else None,
        "model_summary": summary_str,
    }


# =====================================================
# LLM reasoning: choose analysis
# =====================================================
ANALYSIS_SPEC = """
You are a biostatistician embedded in a data analysis tool.

You receive:
1. A single natural-language query from the user (the same query used to retrieve the data from Databricks Genie).
2. A description of the dataset schema and example rows.

Your task:
- Decide the most appropriate single primary biostatistical analysis to run.
- Choose variables from the dataset.
- Optionally suggest a couple of plots.

You may choose one of these analysis_type values:
- "summary": summarize a single numeric variable.
- "ttest": compare a numeric outcome between two groups (2-level categorical).
- "chisq": test association between two binary/categorical variables (2x2).
- "regression": simple linear regression with numeric outcome and numeric predictor.
- "correlation": correlation between two numeric variables.
- "anova_oneway": one-way ANOVA with a numeric outcome and one categorical factor.
- "anova_twoway": two-way ANOVA with a numeric outcome and two categorical factors (including interaction).
- "anova_rm": one-way repeated measures ANOVA with a numeric outcome, a subject ID, and one within-subject factor.
- "lmm": linear mixed model with a numeric outcome, a subject ID as a random intercept, and optional fixed factors.

Return a STRICT JSON object **only** with the following keys:
{
  "analysis_type": "summary" | "ttest" | "chisq" | "regression" | "correlation"
                   | "anova_oneway" | "anova_twoway" | "anova_rm" | "lmm",
  "outcome": "<column name or null>",
  "predictor": "<column name or null>",
  "group": "<column name or null>",
  "var1": "<column name or null>",
  "var2": "<column name or null>",
  "factor1": "<column name or null>",
  "factor2": "<column name or null>",
  "subject": "<column name or null>",          // for repeated measures & LMM
  "within": "<column name or null>",           // within-subject factor for anova_rm
  "fixed_factors": ["<column name>", ...],     // list of fixed-effect factors for LMM (may be empty)
  "plots": ["boxplot" | "histogram" | "scatter" | "bar" | "violin" | "line"],
  "reasoning": "<short explanation of your choice>"
}

Rules:
- For "summary": use 'outcome' (numeric) and set others to null or empty.
- For "ttest": use 'outcome' (numeric) and 'group' (2-level categorical). Others null/empty.
- For "chisq": use 'var1' and 'var2' (both categorical). Others null/empty.
- For "regression": use 'outcome' (numeric) and 'predictor' (numeric). Others null/empty.
- For "correlation": use 'var1' and 'var2' (numeric). Others null/empty.
- For "anova_oneway": use 'outcome' (numeric) and 'factor1' (categorical).
- For "anova_twoway": use 'outcome' (numeric) and 'factor1', 'factor2' (categorical).
- For "anova_rm": use 'outcome' (numeric), 'subject' (ID), and 'within' (within-subject factor).
- For "lmm": use 'outcome' (numeric), 'subject' (ID random effect), and 'fixed_factors' (list of categorical or numeric variables as fixed effects).

Be consistent with column names as given in the schema. Do not invent columns.
"""


def plan_analysis_with_llm(llm, genie_query: str, schema_description: str) -> Dict[str, Any]:
    prompt = (
        ANALYSIS_SPEC
        + "\n\nUser's single query (used for both Genie and analysis intent):\n"
        + genie_query.strip()
        + "\n\nDataset schema and sample:\n"
        + schema_description
        + "\n\nReturn JSON now."
    )

    resp = llm([HumanMessage(content=prompt)]).content.strip()

    if "```" in resp:
        try:
            blocks = resp.split("```")
            for block in blocks:
                if "{" in block and "}" in block:
                    json_text = block[block.index("{") : block.rindex("}") + 1]
                    return json.loads(json_text)
        except Exception:
            pass

    try:
        return json.loads(resp)
    except Exception:
        return {}


# =====================================================
# LLM interpretation of results
# =====================================================
def build_interpretation_prompt(plan: Dict[str, Any], stats: Dict[str, Any]) -> str:
    base = (
        "You are a biostatistician. Given an analysis description and results, "
        "write a concise interpretation suitable for a biomedical paper.\n\n"
        "Guidelines:\n"
        "- Briefly state what was analyzed (variables, groups).\n"
        "- State whether there is evidence of an association/difference.\n"
        "- Mention effect direction and strength where possible.\n"
        "- Report key statistics (means, differences, F-values, t, r, chi-square, p, R², etc.).\n"
        "- Use at most 3 sentences in a single short paragraph.\n\n"
    )

    context = {"plan": plan, "stats": stats}
    return base + "Analysis plan and numerical results:\n" + json.dumps(
        context, indent=2
    ) + "\n\nNow write the interpretation:"


def interpret_results_with_llm(llm, plan: Dict[str, Any], stats: Dict[str, Any]) -> str:
    if not stats:
        return "Not enough data to perform the requested analysis."
    prompt = build_interpretation_prompt(plan, stats)
    resp = llm([HumanMessage(content=prompt)]).content.strip()
    return resp


# =====================================================
# Plotting helpers (Plotly Express)
# =====================================================
def make_plots(
    df: pd.DataFrame,
    plan: Dict[str, Any],
    var_types: Dict[str, str],
) -> List[Any]:
    plots: List[Any] = []
    analysis_type = plan.get("analysis_type")
    requested_plots = plan.get("plots") or []
    requested_plots = list(dict.fromkeys(requested_plots))  # dedupe

    def add_histogram(col: str):
        d = df[[col]].copy()
        d[col] = pd.to_numeric(d[col], errors="coerce")
        d = d.dropna()
        if d.empty:
            return
        fig = px.histogram(d, x=col, marginal="rug", nbins=20, title=f"Histogram of {col}")
        plots.append(fig)

    def add_boxplot(outcome: str, group: Optional[str]):
        d_cols = [outcome] + ([group] if group else [])
        d = df[d_cols].copy()
        d[outcome] = pd.to_numeric(d[outcome], errors="coerce")
        d = d.dropna()
        if d.empty:
            return
        if group and group in d.columns:
            fig = px.box(d, x=group, y=outcome, points="all", title=f"{outcome} by {group}")
        else:
            fig = px.box(d, y=outcome, points="all", title=f"Boxplot of {outcome}")
        plots.append(fig)

    def add_scatter(x: str, y: str):
        d = df[[x, y]].copy()
        d[x] = pd.to_numeric(d[x], errors="coerce")
        d[y] = pd.to_numeric(d[y], errors="coerce")
        d = d.dropna()
        if d.empty:
            return
        fig = px.scatter(d, x=x, y=y, trendline="ols", title=f"{y} vs {x}")
        plots.append(fig)

    def add_bar(var1: str, var2: Optional[str]):
        d_cols = [var1] + ([var2] if var2 else [])
        d = df[d_cols].dropna()
        if d.empty:
            return
        if var2:
            fig = px.bar(
                d.groupby([var1, var2]).size().reset_index(name="count"),
                x=var1,
                y="count",
                color=var2,
                barmode="group",
                title=f"{var1} by {var2}",
            )
        else:
            fig = px.bar(
                d[var1].value_counts().reset_index().rename(columns={"index": var1, var1: "count"}),
                x=var1,
                y="count",
                title=f"Counts of {var1}",
            )
        plots.append(fig)

    # Mapping per analysis type
    if analysis_type == "summary":
        outcome = plan.get("outcome")
        if outcome and outcome in df.columns:
            if "histogram" in requested_plots or not requested_plots:
                add_histogram(outcome)
            if "boxplot" in requested_plots:
                add_boxplot(outcome, None)

    elif analysis_type == "ttest":
        outcome = plan.get("outcome")
        group = plan.get("group")
        if outcome and group and outcome in df.columns and group in df.columns:
            if "boxplot" in requested_plots or not requested_plots:
                add_boxplot(outcome, group)
            if "histogram" in requested_plots:
                add_histogram(outcome)

    elif analysis_type == "chisq":
        var1 = plan.get("var1")
        var2 = plan.get("var2")
        if var1 and var2 and var1 in df.columns and var2 in df.columns:
            if "bar" in requested_plots or not requested_plots:
                add_bar(var1, var2)

    elif analysis_type == "regression":
        outcome = plan.get("outcome")
        predictor = plan.get("predictor")
        if outcome and predictor and outcome in df.columns and predictor in df.columns:
            if "scatter" in requested_plots or not requested_plots:
                add_scatter(predictor, outcome)
            if "histogram" in requested_plots:
                add_histogram(outcome)

    elif analysis_type == "correlation":
        var1 = plan.get("var1")
        var2 = plan.get("var2")
        if var1 and var2 and var1 in df.columns and var2 in df.columns:
            if "scatter" in requested_plots or not requested_plots:
                add_scatter(var1, var2)
            if "histogram" in requested_plots:
                add_histogram(var1)

    elif analysis_type == "anova_oneway":
        outcome = plan.get("outcome")
        factor = plan.get("factor1") or plan.get("factor")
        if outcome and factor and outcome in df.columns and factor in df.columns:
            if "boxplot" in requested_plots or not requested_plots:
                add_boxplot(outcome, factor)
            if "histogram" in requested_plots:
                add_histogram(outcome)

    elif analysis_type == "anova_twoway":
        outcome = plan.get("outcome")
        factor1 = plan.get("factor1")
        factor2 = plan.get("factor2")
        if outcome and factor1 and factor2 and all(
            c in df.columns for c in [outcome, factor1, factor2]
        ):
            if "boxplot" in requested_plots or not requested_plots:
                # Combine factors for interaction boxplot if desired
                combo = df[[factor1, factor2]].astype(str)
                combo_col = "_interaction_tmp_"
                df[combo_col] = combo[factor1] + ":" + combo[factor2]
                add_boxplot(outcome, combo_col)
                df.drop(columns=[combo_col], inplace=True, errors="ignore")
            if "histogram" in requested_plots:
                add_histogram(outcome)

    elif analysis_type == "anova_rm":
        outcome = plan.get("outcome")
        within = plan.get("within")
        if outcome and within and outcome in df.columns and within in df.columns:
            if "boxplot" in requested_plots or not requested_plots:
                add_boxplot(outcome, within)
            if "histogram" in requested_plots:
                add_histogram(outcome)

    elif analysis_type == "lmm":
        outcome = plan.get("outcome")
        fixed_factors = plan.get("fixed_factors") or []
        # simple plots: boxplots across first fixed factor or histogram
        if outcome and outcome in df.columns:
            if fixed_factors:
                ff = fixed_factors[0]
                if ff in df.columns and ("boxplot" in requested_plots or not requested_plots):
                    add_boxplot(outcome, ff)
            if "histogram" in requested_plots:
                add_histogram(outcome)

    return plots


# =====================================================
# Streamlit app
# =====================================================
def main():
    st.set_page_config(
        page_title="Biostatistical Agent with Databricks Genie (ANOVA + LMM)",
        layout="wide",
    )

    st.title("Biostatistical Agent with Genie")
    st.write(
        "Use a **single natural-language query** to:\n"
        "1. Retrieve a dataset from Databricks Genie (via a space ID).\n"
        "2. Let a biostatistical agent automatically decide and run an appropriate analysis "
        "(including ANOVA and linear mixed models) using ChatDatabricks.\n"
        "3. View numerical results, Plotly plots, and an LLM-generated interpretation."
    )
    st.caption("For exploratory use only – not for regulatory or clinical decisions.")

    # Sidebar: LLM settings
    with st.sidebar:
        st.header("LLM settings (ChatDatabricks)")
        #model_name = st.text_input(
        #    "Workspace model name (ignored if DATABRICKS_LLM_ENDPOINT is set)",
        #    value="databricks-dbrx-instruct",
        #)
        temperature = st.slider("Temperature", 0.0, 1.0, 0.1, 0.05)

    # Single query (Genie + analysis intent)
    st.subheader("Single Genie Query")
    #space_id = st.text_input("Genie Space ID", help="ID of the Genie space to query.")
    genie_query = st.text_area(
        "Genie query (used both to retrieve data and to define the analysis intent)",
        placeholder=(
            "Example: 'Return the clinical trial dataset with columns subject_id, treatment_group, "
            "timepoint, outcome, and analyze the longitudinal effect of treatment over time with "
            "a repeated measures design.'\n"
            "Genie should respond with a tabular dataset."
        ),
        height=120,
    )

    #demo = st.checkbox(
    #    "Use small demo dataset instead of Genie (for testing)", value=False
    #)

    if not genie_query.strip(): #and not demo:
        st.info("Enter a Genie query or enable the demo dataset.")
        return

    if st.button("Run Genie + Biostatistical Analysis"):
        llm = get_llm(temperature=temperature)

        # Step 1: Get DataFrame (from Genie or demo)
        df: Optional[pd.DataFrame] = None

        #if demo:
        #    df = pd.DataFrame(
        #        {
        #            "subject_id": [1, 1, 2, 2, 3, 3],
        #            "timepoint": ["baseline", "week4", "baseline", "week4", "baseline", "week4"],
        #            "treatment_group": ["A", "A", "B", "B", "A", "A"],
        #            "outcome": [10.0, 12.0, 9.0, 11.0, 11.0, 13.0],
        #        }
        #    )
        #    st.info("Using demo dataset; Genie was not called.")
        #else:
        #if not space_id.strip():
        #    st.error("Please provide a Genie Space ID.")
        #    return
        try:
            df = query_genie_for_dataframe(genie_query)
        except NotImplementedError as nie:
            st.error(str(nie))
            return
        except Exception as e:
            st.error(f"Error querying Genie: {e}")
            return

        if df is None or df.empty:
            st.error("No data returned.")
            return

        st.write("**Preview of data retrieved (first 10 rows):**")
        st.dataframe(df.head(10))

        var_types = infer_variable_types(df)

        try:
            # Step 2: Build schema description and ask LLM to choose analysis
            schema_desc = build_schema_description(df, var_types)
            plan = plan_analysis_with_llm(llm, genie_query, schema_desc)

            if not plan or "analysis_type" not in plan:
                st.error("The LLM could not determine an analysis plan.")
                st.text("Raw plan response:\n" + json.dumps(plan, indent=2))
                return

            st.subheader("Analysis Plan")
            st.json(plan)

            analysis_type = plan.get("analysis_type")
            stats: Dict[str, Any] = {}

            # Step 3: Execute the selected analysis
            if analysis_type == "summary":
                col = plan.get("outcome")
                if not col or col not in df.columns:
                    st.error("The plan refers to an invalid outcome variable.")
                else:
                    stats = run_summary(df, col)

            elif analysis_type == "ttest":
                outcome = plan.get("outcome")
                group = plan.get("group")
                if not outcome or not group or outcome not in df.columns or group not in df.columns:
                    st.error("The plan refers to invalid outcome/group variables.")
                else:
                    stats = run_ttest(df, outcome, group)

            elif analysis_type == "chisq":
                var1 = plan.get("var1")
                var2 = plan.get("var2")
                if not var1 or not var2 or var1 not in df.columns or var2 not in df.columns:
                    st.error("The plan refers to invalid categorical variables.")
                else:
                    stats = run_chisq(df, var1, var2)

            elif analysis_type == "regression":
                outcome = plan.get("outcome")
                predictor = plan.get("predictor")
                if (
                    not outcome
                    or not predictor
                    or outcome not in df.columns
                    or predictor not in df.columns
                ):
                    st.error("The plan refers to invalid outcome/predictor variables.")
                else:
                    stats = run_regression(df, outcome, predictor)

            elif analysis_type == "correlation":
                var1 = plan.get("var1")
                var2 = plan.get("var2")
                if not var1 or not var2 or var1 not in df.columns or var2 not in df.columns:
                    st.error("The plan refers to invalid numeric variables for correlation.")
                else:
                    stats = run_correlation(df, var1, var2)

            elif analysis_type == "anova_oneway":
                outcome = plan.get("outcome")
                factor = plan.get("factor1") or plan.get("factor")
                if not outcome or not factor or outcome not in df.columns or factor not in df.columns:
                    st.error("The plan refers to invalid outcome/factor variables.")
                else:
                    stats = run_anova_oneway(df, outcome, factor)

            elif analysis_type == "anova_twoway":
                outcome = plan.get("outcome")
                factor1 = plan.get("factor1")
                factor2 = plan.get("factor2")
                if (
                    not outcome
                    or not factor1
                    or not factor2
                    or outcome not in df.columns
                    or factor1 not in df.columns
                    or factor2 not in df.columns
                ):
                    st.error("The plan refers to invalid outcome/factor variables.")
                else:
                    stats = run_anova_twoway(df, outcome, factor1, factor2)

            elif analysis_type == "anova_rm":
                outcome = plan.get("outcome")
                subject = plan.get("subject")
                within = plan.get("within")
                if (
                    not outcome
                    or not subject
                    or not within
                    or outcome not in df.columns
                    or subject not in df.columns
                    or within not in df.columns
                ):
                    st.error("The plan refers to invalid outcome/subject/within variables.")
                else:
                    stats = run_anova_rm(df, outcome, subject, within)

            elif analysis_type == "lmm":
                outcome = plan.get("outcome")
                subject = plan.get("subject")
                fixed_factors = plan.get("fixed_factors") or []
                if not outcome or not subject or outcome not in df.columns or subject not in df.columns:
                    st.error("The plan refers to invalid outcome/subject for LMM.")
                else:
                    valid_fixed = [f for f in fixed_factors if f in df.columns]
                    stats = run_lmm(df, outcome, subject, valid_fixed)

            else:
                st.error(f"Unsupported analysis type chosen by LLM: {analysis_type}")

            st.subheader("Numerical / Model Results")
            if stats:
                st.json(stats)
            else:
                st.warning("No numerical results were produced (likely insufficient or incompatible data).")

            # Step 4: Plots
            st.subheader("Plots")
            figs = make_plots(df, plan, var_types)
            if not figs:
                st.info("No plots generated (plan may not have suggested any or variables were invalid).")
            else:
                for fig in figs:
                    st.plotly_chart(fig, use_container_width=True)

            # Step 5: Interpretation
            st.subheader("LLM Biostatistical Interpretation")
            interpretation = interpret_results_with_llm(llm, plan, stats)
            st.success(interpretation)

        except Exception as e:
            st.error(f"An error occurred: {e}")


if __name__ == "__main__":
    main()
