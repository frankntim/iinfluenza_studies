import pandas as pd
import ipywidgets as widgets
from IPython.display import display, clear_output, Markdown, HTML
import os
import pandas as pd
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from langchain_experimental.agents import create_pandas_dataframe_agent

import plotly.graph_objects as go #To uPse the Plotly library to create the graph
import plotly.express as px #To use the Plotly Express library to create the graph
import seaborn as sns
import statsmodels.api as sm
import statsmodels.formula.api as smf
import io
from types import SimpleNamespace
import os
import base64
from ipywidgets import Button, Layout


LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)


def launch_csv_chat_app():
    # Initialize shared state using SimpleNamespace
    state = SimpleNamespace()
    state.llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)
    state.agent = None
    state.df = None
    background_image_file = "moroccan-flower-dark.png"

    with open(background_image_file, "rb") as f:
        encoded = base64.b64encode(f.read()).decode("utf-8")
    mime = "image/png"
    data_url = f"data:{mime};base64,{encoded}"
    display(HTML(f"""
                 <style>
                 .widget-app-container {{
                     background-image: url('{data_url}');
                     background-repeat: repeat;
                     background-size: auto:
                     padding: 20px;
                     border-radius: 10px
                 }}
                 .widget-app-container textarea {{
                     font-family: monospace;
                 }}
                 </style>
                 """)
            )

    # UI Widgets
    '''
    header_image_file = "moroccan-flower-dark.png"
    with open(header_image_file, "rb") as f:
        header_encoded = base64.b64encode(f.read()).decode("utf-8")
        #header_image = f.read()
    mime = "image/png" if header_image_file.endswith(".png") else "image/jpeg"

    header_image_widget = widgets.Image(
            #value=header_image,
            value=base64.b64decode(header_encoded),
            format=mime.split("/")[-1],
            layout=widgets.Layout(width='90%', height='80px')
        )
    '''
    

    analysis_button = widgets.Button(
        description="Survival - Cox - Linear Mixed Model",
        disabled=True,
        button_style = 'primary',
        layout=widgets.Layout(width='90%', height='80px'),
        style=widgets.ButtonStyle(button_color='blue', text_color = 'black', font_weight='bold')
    )
    #analysis_button.add_class("flat-analysis-button")
   
    # Title styling
    display(HTML("""
        <style>
            .flat-analysis-button button {
                background-color: #ADD8E6 !important;
                color: black !important;
                font-weight: bold;
                font-size: 20px;
                border: none !important;
                box-shadow: none !important;
                cursor: default !important;
            }
            
        </style>
    """))
    




    button_description = widgets.Button(
        description='Survival - Cox Fitting - Linear Mixed', 
        layout = widgets.Layout(width='90%', height='80px')
    )
    upload_widget = widgets.FileUpload(
        accept='.csv', multiple=False, description='Upload CSV', layout = widgets.Layout(width='90%', height='80px')
    )
    chat_box = widgets.Textarea(
        value='',
        placeholder='Ask a question about your dataset...',
        description='Query:',
        layout=widgets.Layout(width='90%', height='100px')
    )
    submit_button = widgets.Button(
        description='Chat', 
        button_style='success', 
        layout = widgets.Layout(width='90%', height='80px')
    )
    output_area = widgets.Output()

    # Upload handler
    def handle_upload(change):
        output_area.clear_output()
        if upload_widget.value:
            uploaded_filename = list(upload_widget.value.keys())[0]
            uploaded_bytes = upload_widget.value[uploaded_filename]['content']
            state.df = pd.read_csv(io.BytesIO(uploaded_bytes))

            with output_area:
                print(f"✅ Successfully loaded: {uploaded_filename}")
                display(state.df.head())

            # Create the agent
            state.agent = create_pandas_dataframe_agent(state.llm, 
                                                        state.df, 
                                                        verbose=True,
                                                        handle_parsing_errors = True,
                                                        allow_dangerous_code=True )

    upload_widget.observe(handle_upload, names='value')

    # Submit handler
    def on_submit_click(b):
        output_area.clear_output()

        if state.agent is None:
            with output_area:
                print("⚠️ Please upload a CSV file first.")
            return
        
        query = chat_box.value.strip()
        if not query:
            with output_area:
                print("⚠️ Please enter a query about the dataset.")
            return

        try:
            with output_area:
                print("🤖 Querying the dataset...\n")
                response = state.agent.invoke(query)
                print(response['output'])
        except Exception as e:
            with output_area:
                print("❌ Error while processing:", str(e))

    submit_button.on_click(on_submit_click)

    # Display app
    container = widgets.VBox([
        #header_image_widget,
        #button_description,
        analysis_button,
        upload_widget,
        chat_box,
        submit_button,
        output_area
    ])

    container.add_class("widget-app-container")
    display(container)