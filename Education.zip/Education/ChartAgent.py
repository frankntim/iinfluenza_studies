# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %pip install -U -qqq mlflow langgraph==0.3.4 langchain-experimental==0.3.4 plotly==5.24.1  langchain_community databricks-langchain databricks-agents matplotlib lifelines langchain-openai plotnine statsmodels
# MAGIC
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# Cell 1: Imports
import pandas as pd
import ipywidgets as widgets
from IPython.display import display, clear_output, Markdown
import os
import pandas as pd
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from langchain_experimental.agents import create_pandas_dataframe_agent

import plotly.graph_objects as go #To uPse the Plotly library to create the graph
import plotly.express as px #To use the Plotly Express library to create the graph
import seaborn as sns
import statsmodels.api as sm
import statsmodels.formula.api as smf
from plotnine import *



from langchain_openai import ChatOpenAI
import os


# Cell 2: Environment setup
# Set your OpenAI API key (you can set this securely in your environment instead)
#os.environ["OPENAI_API_KEY"] = "your-api-key-here"  # replace with your actual key
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)


# Cell 3: File upload + agent integration
upload = widgets.FileUpload(
    accept='.csv',
    multiple=False,
    description="Upload CSV"
)

query_box = widgets.Textarea(
    placeholder='Ask a question about the dataset...',
    description='Query:',
    layout=widgets.Layout(width='80%', height='100px')
)

submit_button = widgets.Button(description="Submit")
output = widgets.Output()

# Global variables
df = None
agent = None

def handle_upload(change):
    global df, agent
    clear_output(wait=True)
    uploaded_file = list(upload.value.values())[0]
    content = uploaded_file['content']
    df = pd.read_csv(pd.io.common.BytesIO(content))
    print("✅ CSV loaded successfully. Shape:", df.shape)

    # Display the first few rows
    display(df.head())

    # Create the LLM agent
    #llm = ChatOpenAI(model="gpt-4", temperature=0)
    #agent = create_pandas_dataframe_agent(llm, df, verbose=False)
    agent = create_pandas_dataframe_agent(
                    llm,
                    df,
                    #prefix=PROMPT,
                    agent_type="tool-calling",  # Use the modern "tool-calling" agent type
                    allow_dangerous_code=True,  # Allow execution of Python code (use with caution)
                    verbose=True,               # Enable verbose logging for debugging
                )

    # Show widgets again
    display(upload, query_box, submit_button, output)

upload.observe(handle_upload, names='value')
display(upload)


# Cell 4: LLM chat with dataset
def on_submit_clicked(b):
    with output:
        clear_output()
        user_query = query_box.value.strip()
        if df is None or agent is None:
            print("⚠️ Please upload a dataset first.")
            return
        if not user_query:
            print("⚠️ Please enter a query.")
            return
        try:
            print(f"📩 You asked: {user_query}\n")
            #response = agent.run(user_query)
            response = agent.invoke(user_query)
            print(f"🤖 Response:\n{response['output']}")
        except Exception as e:
            print("❌ Error:", str(e))

submit_button.on_click(on_submit_clicked)
display(query_box, submit_button, output)

# COMMAND ----------

# DBTITLE 1,Data Analyst Agent
# Step 1: Make sure the .py file is in the same folder
from chat_app2 import launch_csv_chat_app
# Step 2: Call the function to launch the app
launch_csv_chat_app()

# COMMAND ----------

# MAGIC %md
# MAGIC **Backend Connection**

# COMMAND ----------

# Databricks ipywidgets notebook: Data Catalog & Table Explorer

# COMMAND ----------
# MAGIC %md
# # Data Catalog & Table Explorer
# This notebook provides an interactive UI (powered by `ipywidgets`) to browse Unity Catalog catalogs, schemas, and tables, and to run ad‑hoc SQL queries directly from a Databricks notebook.

# COMMAND ----------
# Install ipywidgets if needed (Databricks Runtime 14+ comes with it)
# Uncomment the line below if ipywidgets is missing in your cluster environment
# %pip install --quiet ipywidgets

# COMMAND ----------
import ipywidgets as widgets
from IPython.display import display, clear_output
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# -----------------------------------------------------------------------------
# Helper functions
# -----------------------------------------------------------------------------

def list_catalogs() -> list[str]:
    """Return a list of catalog names visible to the current user."""
    return [row.catalog for row in spark.sql("SHOW CATALOGS").collect()]


def list_schemas(catalog: str) -> list[str]:
    """Return a list of schemas/databases for a given catalog."""
    return [row.databaseName for row in spark.sql(f"SHOW SCHEMAS IN `{catalog}`").collect()]


def list_tables(catalog: str, schema: str) -> list[str]:
    """Return a list of tables for a given catalog & schema."""
    rows = spark.sql(f"SHOW TABLES IN `{catalog}`.`{schema}`").collect()
    return [row.tableName for row in rows]

# -----------------------------------------------------------------------------
# Widgets definitions
# -----------------------------------------------------------------------------

catalog_dropdown = widgets.Dropdown(
    options=list_catalogs(),
    description="Catalog:",
    layout=widgets.Layout(width="300px"),
)

schema_dropdown = widgets.Dropdown(
    options=[],
    description="Schema:",
    layout=widgets.Layout(width="300px"),
)

tables_select = widgets.SelectMultiple(
    options=[],
    description="Tables:",
    rows=8,
    layout=widgets.Layout(width="300px"),
)

limit_int = widgets.BoundedIntText(
    value=20,
    min=1,
    max=10000,
    step=1,
    description="Show rows:",
    layout=widgets.Layout(width="200px"),
)

run_button = widgets.Button(
    description="Run Query",
    button_style="success",
    tooltip="Run the generated query and display the result",
)

custom_sql = widgets.Textarea(
    placeholder="Or write your own SQL here…",
    description="SQL:",
    layout=widgets.Layout(width="600px", height="120px"),
)

output = widgets.Output()

# -----------------------------------------------------------------------------
# Callback functions
# -----------------------------------------------------------------------------

def on_catalog_change(change):
    catalog = change["new"]
    schema_dropdown.options = list_schemas(catalog)
    # Automatically trigger schema update for the first schema in list
    if schema_dropdown.options:
        schema_dropdown.value = schema_dropdown.options[0]


def on_schema_change(change):
    catalog = catalog_dropdown.value
    schema = change["new"]
    tables_select.options = list_tables(catalog, schema)


def run_query(_):
    with output:
        clear_output()
        if custom_sql.value.strip():
            sql = custom_sql.value.strip()
            print("Running custom SQL:")
            print(sql)
        else:
            selected = list(tables_select.value)
            if not selected:
                print("⚠️ Please select at least one table or write custom SQL.")
                return
            catalog = catalog_dropdown.value
            schema = schema_dropdown.value
            table_refs = [f"{catalog}.{schema}.{t}" for t in selected]
            sql = "SELECT * FROM " + ", ".join(table_refs) + f" LIMIT {limit_int.value}"
            print("Running generated SQL:")
            print(sql)
        try:
            df = spark.sql(sql)
            display(df.limit(limit_int.value).toPandas())
        except Exception as e:
            print("Query failed:", e)

# -----------------------------------------------------------------------------
# Widget event bindings
# -----------------------------------------------------------------------------

catalog_dropdown.observe(on_catalog_change, names="value")
schema_dropdown.observe(on_schema_change, names="value")
run_button.on_click(run_query)

# Trigger initial population of schema & table lists
on_catalog_change({"new": catalog_dropdown.value})

# -----------------------------------------------------------------------------
# Layout & display
# -----------------------------------------------------------------------------

ui = widgets.VBox([
    widgets.HBox([catalog_dropdown, schema_dropdown]),
    widgets.HBox([tables_select, widgets.VBox([limit_int, run_button])]),
    custom_sql,
    output,
])

display(ui)


# COMMAND ----------

# MAGIC %md
# MAGIC