# Databricks notebook source
# MAGIC %pip install -U -qqq mlflow langgraph==0.3.4 langchain-experimental==0.3.4 plotly==5.24.1 lifelines langchain_community databricks-langchain databricks-agents matplotlib lifelines langchain-openai plotnine statsmodels
# MAGIC
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC **Using LangChain's Pandas DataFrame Agent**
# MAGIC
# MAGIC **Introduction**
# MAGIC
# MAGIC The create_pandas_dataframe_agent function from the langchain_experimental.agents.agent_toolkits.pandas.base module is a powerful tool designed to enable language models (LLMs) to interact with and analyze data stored in Pandas DataFrames. By combining the capabilities of LLMs with the flexibility of Pandas, this function allows users to perform complex data analysis tasks through natural language queries. The agent can handle a variety of operations, such as filtering, aggregation, and visualization, making it an invaluable tool for data scientists, analysts, and developers who want to streamline their workflows.
# MAGIC
# MAGIC However, it is important to note that this functionality comes with significant security considerations. The agent relies on a Python REPL (Read-Eval-Print Loop) tool, which can execute arbitrary code. This capability, while powerful, introduces potential risks, such as arbitrary code execution vulnerabilities, if not used in a properly sandboxed environment. Users must explicitly opt-in to this functionality by setting the allow_dangerous_code parameter to True, acknowledging the risks and ensuring that appropriate safeguards are in place.

# COMMAND ----------


import os
import pandas as pd
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from langchain_experimental.agents import create_pandas_dataframe_agent
import plotly.graph_objects as go #To uPse the Plotly library to create the graph
import plotly.express as px #To use the Plotly Express library to create the graph
import seaborn as sns
import statsmodels.api as sm
import statsmodels.formula.api as smf
from plotnine import *
LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)


# COMMAND ----------

def pretty_print_response(question, response):
    """
    Formats and prints the agent's response in a structured and readable manner.

    This function takes a question and the agent's response, extracts the 'output' key
    from the response, and prints it with clear separators for improved readability.
    It is useful for debugging, logging, or presenting results in a user-friendly format.

    Args:
        question (str): The question or query posed to the agent.
        response (dict): The agent's response, expected to contain an 'output' key
                         with the result of the query.

    Returns:
        None: This function prints the formatted output directly to the console.
    """
    print(f"Question: {question}")
    print("\n" + "=" * 80 + "\n")
    print(response["output"])  # Extract the 'output' key for pretty printing
    print("\n" + "=" * 80 + "\n")

# COMMAND ----------


LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)


# COMMAND ----------

# MAGIC %md
# MAGIC **Generalized Analysis**

# COMMAND ----------

titanic = pd.read_csv('titanic_2.csv')
titanic.head()

# COMMAND ----------

# Read the dataset
titanic = pd.read_csv('titanic_2.csv')

PROMPT="""
You are a data analyst. You are provided with titanic dataset. Analyze the dataset and respond to the question. Use plotly express for the chart. figure size should be 5 by 4
"""

# Create the agent with default parameters
agent = create_pandas_dataframe_agent(
    llm,
    titanic,
    prefix=PROMPT,
    agent_type="tool-calling",  # Use the modern "tool-calling" agent type
    allow_dangerous_code=True,  # Allow execution of Python code (use with caution)
    verbose=True,               # Enable verbose logging for debugging
)

# Ask the agent a question
response = agent.invoke("Plot sex vs age with bar chart?")
print(response["output"])

# COMMAND ----------

# MAGIC %md
# MAGIC **Example 1: Survival Plots with KM**
# MAGIC
# MAGIC In this section we will use the Agentic AI and Prompts and Input Datasets to plot a specialized plots such as KM Survival Plots

# COMMAND ----------

survival_dataset = pd.read_csv('survival_dataset.csv')
survival_dataset.head()

# COMMAND ----------

# Create the agent with a custom prefix and suffix
survival_dataset = pd.read_csv('survival_dataset.csv')

PROMPT="""
You are a data analyst. You are provided with survival_dataset dataset. Analyze the survival analysis, duration is Overall Survival (Months) and event is Overall Survival Status.
"""
PROMPT2="""
You are a data analyst. You are provided with survival_dataset dataset. Present the answer as {{time: time column, event: event column}}
"""
agent = create_pandas_dataframe_agent(
    llm,
    survival_dataset,
    agent_type="tool-calling",
    prefix= PROMPT2,
    suffix="Provide the final answer in a clear and structured format.",
    allow_dangerous_code=True,
    verbose=True,
)

# Ask the agent a question

#response = agent.invoke("select columns for time and event")
#print(response["output"])
response = agent.invoke("Fit and plot the KM survival curve for this dataset")
print(response["output"])

# COMMAND ----------

#from PIL import Image
#from IPython.display import display

#img = Image.open('survival.png')
#display(img)

# COMMAND ----------

# MAGIC %md
# MAGIC **Example 2: Linear Mixed Model**

# COMMAND ----------

mixed_model_data = pd.read_csv('mixed_model_data.csv')
mixed_model_data.head()

# COMMAND ----------

# Load the data
mixed_model_data = pd.read_csv('mixed_model_data.csv')

# Craft a prompt to give it a sense of direction
PROMPT="""
I have a longitudinal dataset with 50 subjects measured 5  times each called mixed_model_data.csv.
The variables are:
value (response), time (continuous), group (A/B), subject_id (random effect).

Fit a linear mixed model with:
Fixed effects: time + group + time*group
Random intercepts: subject_id
Plot fixed effect trends 
Figure size should be 6 by 4
Please suppress the warnings
"""

PROMPT2="""
I have a longitudinal dataset with 50 subjects measured 5  times each called mixed_model_data.csv.
The variables are: value (response), time (continuous), group (A/B), subject_id (random effect).

Fit a linear mixed model with subject_id as random effect.
"""

# Furnish the agent with the necessary tools: LLM + dataset + Prompts
agent = create_pandas_dataframe_agent(
    llm,
    mixed_model_data,
    agent_type="tool-calling",
    prefix= PROMPT2,
    suffix="Provide the final answer in a clear and structured format.",
    allow_dangerous_code=True,
    verbose=True,
)

# Ask the agent a question
response = agent.invoke("Plot fixed effect trends and model results?")
#print(response["output"])
pretty_print_response("Plot fixed effect trends and model results?", response)

# COMMAND ----------

#from PIL import Image
#from IPython.display import display

#img = Image.open('mixed_model.png')
#display(img)

# COMMAND ----------

# MAGIC %md
# MAGIC **Example 3: Cox Proportional Hazard Fitting**

# COMMAND ----------

df = pd.read_csv('rossi_cox_fitting_dataset.csv')
df.head()

# COMMAND ----------

# Load the data
cox_fitting_data = pd.read_csv('rossi_cox_fitting_dataset.csv')

# Craft a prompt to give it a sense of direction
PROMPT="""
Use this dataset to fit Cox proportional harzard. These are the variables
duration: week, event: arrest

Print a tabular view of coefficients and related stats
Generate the related chart
Figure size should be 6 by 4
Save the figure as cox_fitting_model.png
Please suppress the warnings
"""

# Furnish the agent with the necessary tools: LLM + dataset + Prompts
agent = create_pandas_dataframe_agent(
    llm,
    cox_fitting_data,
    agent_type="tool-calling",
    prefix= PROMPT,
    suffix="Provide the final answer in a clear and structured format.",
    allow_dangerous_code=True,
    verbose=True,
)

# Ask the agent a question
response = agent.invoke("Fit and plot Cox fitting and model results")
#print(response["output"])
#pretty_print_response("Fit and plot Cox fitting and model results", response)

# COMMAND ----------

from PIL import Image
from IPython.display import display

img = Image.open('cox_fitting_model.png')
display(img)

# COMMAND ----------

# MAGIC %md
# MAGIC **LangGraph Agentic AI**

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------




# COMMAND ----------



# COMMAND ----------

pd.read_csv('survival_dataset.csv').shape

# COMMAND ----------

# Create button widget. Click this sample to loada sampled dataframe from UC table
import ipywidgets as widgets
from ipywidgets import interact
import pandas as pd
import pandas as pd
import os
import pandas as pd
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
from langchain_experimental.agents import create_pandas_dataframe_agent
import plotly.graph_objects as go #To uPse the Plotly library to create the graph
import plotly.express as px #To use the Plotly Express library to create the graph
import seaborn as sns
import statsmodels.api as sm
import statsmodels.formula.api as smf
from plotnine import *
from PIL import Image
from IPython.display import display
import plotly.io as pio
from lifelines import KaplanMeierFitter, CoxPHFitter
from lifelines.statistics import logrank_test

button = widgets.Button(description="Load data")
output = widgets.Output()

def load_sample_df(dataset):
    df = pd.read_csv(dataset)
    return df

def on_button_clicked(_):
    with output:
        output.clear_output()
        import plotly.graph_objects as go #To uPse the Plotly library to create the graph
        import plotly.express as px #To use the Plotly Express library to create the grap

        df = load_sample_df("survival_dataset.csv")
        
        LLM_ENDPOINT_NAME = "project-115-Precision_Medicine_AI_Agent-2"
        llm = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)
      


        PROMPT="""
        You are a data analyst. Analyze the dataset and respond to the question. Please suppress warnings. Use all the observations for analysis. 
        """
        PROMPT2="""
        I have a longitudinal dataset with 50 subjects measured 5  times each called mixed_model_data.csv.
        The variables are: value (response), time (continuous), group (A/B), subject_id (random effect).

        """
        PROMPT3="""
        You are a data analyst. You are provided with survival dataset called survival_dataset.csv with 1405 observations. Analyze the survival analysis, duration is Overall Survival (Months) and event is Overall Survival Status.

        """

        # Create the agent with default parameters
        agent = create_pandas_dataframe_agent(
            llm,
            df,
            prefix=PROMPT3,
            agent_type="tool-calling",  # Use the modern "tool-calling" agent type
            allow_dangerous_code=True,  # Allow execution of Python code (use with caution)
            verbose=True,               # Enable verbose logging for debugging
        )

        # Ask the agent a question
        response = agent.invoke("Fit and plot the KM survival curve for this dataset")
        print(response["output"])

button.on_click(on_button_clicked)
display(button, output)

# COMMAND ----------

