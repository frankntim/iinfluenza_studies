import dash
from dash import html, dcc, Input, Output, State, ctx
import dash_bootstrap_components as dbc
import requests
import os
from databricks_langchain import (
    ChatDatabricks,
    UCFunctionToolkit,
)
import dash
from dash import html, Input, Output, State, ctx
import dash_bootstrap_components as dbc
import dash_mantine_components as dmc
import requests
import o


DATABRICKS_TOKEN =  "dapi0945608621f87ae408fc84b3f011a0bd"
DATABRICKS_HOST = "https://amgen-ai-dev.cloud.databricks.com"

# Set these with your actual values
#DATABRICKS_HOST = os.getenv('DATABRICKS_HOST', 'https://<your-instance>.cloud.databricks.com')
#DATABRICKS_TOKEN = os.getenv('DATABRICKS_TOKEN', '<your-token>')

HEADERS = {
    "Authorization": f"Bearer {DATABRICKS_TOKEN}",
    "Content-Type": "application/json"
}

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

app.layout = html.Div([
    dbc.Button("Open Unity Catalog Modal", id="open-modal", n_clicks=0),

    dbc.Modal([
        dbc.ModalHeader(dbc.ModalTitle("Unity Catalog Browser")),
        dbc.ModalBody([

            html.Label("Catalog"),
            dmc.Select(
                id='catalog-dropdown',
                placeholder="Select Catalog",
                searchable=True
            ),
            html.Br(),

            html.Label("Schema"),
            dmc.Select(
                id='schema-dropdown',
                placeholder="Select Schema",
                searchable=True
            ),
            html.Br(),

            html.Label("Tables (Multi-select with checkboxes)"),
            dmc.MultiSelect(
                id='table-dropdown',
                placeholder="Select Tables",
                searchable=True,
                clearable=True,
                nothingFound="No tables found",
                maxSelectedValues=10,
                style={"minHeight": "100px"}
            ),
        ]),
        dbc.ModalFooter(
            dbc.Button("Close", id="close-modal", className="ms-auto", n_clicks=0)
        ),
    ],
        id="catalog-modal",
        is_open=False),
])


# Toggle modal open/close
@app.callback(
    Output("catalog-modal", "is_open"),
    [Input("open-modal", "n_clicks"), Input("close-modal", "n_clicks")],
    [State("catalog-modal", "is_open")],
)
def toggle_modal(n1, n2, is_open):
    if ctx.triggered_id in ["open-modal", "close-modal"]:
        return not is_open
    return is_open


# Populate catalog dropdown
@app.callback(
    Output('catalog-dropdown', 'data'),
    Input('catalog-modal', 'is_open')
)
def fetch_catalogs(is_open):
    if not is_open:
        return []

    response = requests.get(f"{DATABRICKS_HOST}/api/2.1/unity-catalog/catalogs", headers=HEADERS)
    if response.status_code == 200:
        catalogs = response.json().get("catalogs", [])
        return [{"label": cat['name'], "value": cat['name']} for cat in catalogs]
    return []


# Populate schema dropdown
@app.callback(
    Output('schema-dropdown', 'data'),
    Input('catalog-dropdown', 'value')
)
def fetch_schemas(catalog):
    if not catalog:
        return []

    response = requests.get(f"{DATABRICKS_HOST}/api/2.1/unity-catalog/schemas?catalog_name={catalog}", headers=HEADERS)
    if response.status_code == 200:
        schemas = response.json().get("schemas", [])
        return [{"label": sch['name'], "value": sch['name']} for sch in schemas]
    return []


# Populate table dropdown with checkboxes
@app.callback(
    Output('table-dropdown', 'data'),
    [Input('catalog-dropdown', 'value'),
     Input('schema-dropdown', 'value')]
)
def fetch_tables(catalog, schema):
    if not catalog or not schema:
        return []

    response = requests.get(f"{DATABRICKS_HOST}/api/2.1/unity-catalog/tables?catalog_name={catalog}&schema_name={schema}", headers=HEADERS)
    if response.status_code == 200:
        tables = response.json().get("tables", [])
        return [{"label": t['name'], "value": t['name']} for t in tables]
    return []


if __name__ == '__main__':
    app.run_server(debug=True)
