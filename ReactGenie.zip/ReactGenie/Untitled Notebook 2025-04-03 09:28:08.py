# Databricks notebook source
# MAGIC %pip install -U -qqq mlflow langgraph==0.3.4 langchain-experimental==0.3.4 databricks-langchain databricks-agents uv
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

from langchain_community.tools.databricks import UCFunctionToolkit
import pandas as pd
import numpy as np

# COMMAND ----------

def display_tools(tools):
    display(pd.DataFrame([{k: str(v) for k, v in vars(tool).items()} for tool in tools]))


tools = (
    UCFunctionToolkit(
        # SQL warehouse ID is required to execute UC functions
        warehouse_id= "792838787cf72ed7"
    )
    .include(
        # Include functions as tools using their qualified names.
        # You can use "{catalog_name}.{schema_name}.*" to get all functions in a schema.
        "edl_dev.cbd_sandbox.get_doseseqp_age_by_subject"
    )
    .get_tools()
)

# COMMAND ----------

display_tools(tools)

# COMMAND ----------

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate
from langchain_community.chat_models import ChatDatabricks


# Utilize a Foundational Model API via ChatDatabricks 


llm = ChatDatabricks(endpoint="databricks-bge-large-en")
#llm = ChatDatabricks(endpoint="databricks-meta-llama-3-1-70b-instruct")


# Define the prompt for the model, note the description to use the tools
prompt = ChatPromptTemplate.from_messages(
    [(
        "system",
        "You are a helpful assistant for a large biomarker company.Make sure to use tool for information.Refer the tools description and make a decision of the tools to call for each user query.",
        ),
        ("placeholder", "{chat_history}"),
        ("human", "{input}"),
        ("placeholder", "{agent_scratchpad}"),
    ]
)

# COMMAND ----------

from langchain.agents import AgentExecutor, create_tool_calling_agent
agent = create_tool_calling_agent(llm, tools, prompt)
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

# COMMAND ----------

#agent_executor.invoke({"input": "Return subjid, doseseqp, age for subject 5280000036"})



agent_executor.invoke({"input": "Return subjid, doseseqp, age for subject 5280000036"})

