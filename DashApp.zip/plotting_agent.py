import pandas as pd
import os
from dotenv import load_dotenv
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.io as pio
from lifelines import KaplanMeierFitter, NelsonAalenFitter, BreslowFlemingHarringtonFitter, CoxPHFitter,  WeibullFitter
#from langchain.chat_models import ChatOpenAI
import json
from langchain.prompts import ChatPromptTemplate
from langchain.schema import SystemMessage, HumanMessage
from databricks.sdk import WorkspaceClient
#from databricks_langchain import (
#    ChatDatabricks,
#    UCFunctionToolkit,
#)
# LangChain imports
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage, HumanMessage
from sklearn.preprocessing import LabelEncoder
import re
import plotly.tools as tls
import plotly.io as pio


#load_dotenv()

# Load environment variables
OPEN_AI_KEY = "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"
os.environ["OPENAI_API_KEY"] = OPEN_AI_KEY

#LLM_ENDPOINT_NAME = os.environ.get("LLM_ENDPOINT_NAME")
LLM = ChatOpenAI(model="gpt-4o", temperature=0, api_key=OPEN_AI_KEY)

# LLM for plotting graph
#LLM = ChatDatabricks(endpoint=LLM_ENDPOINT_NAME, temperature=0)



def general_plotting_agent(df, context_description, user_input):
    def get_fig_from_code(code):
        local_variables = {}
        exec(code, {}, local_variables)
        return local_variables['fig']
    
    CHART_PROMPT = '''
    Role: You are biomarker assistant tasked with providing up-to-date information about the clinical trial data.

    Objective: Your job is to write pandas code to visualize and plot charts based on the given data and column names, context and task.

    Capabilities: You have been given a dataframe as data. The data columns are provided. The context of the task is presented as context.

    Next Steps: When asked to visualize data, provide only python code using Plotly Express to generate charts. 
    The plotting figure sizes should be 5 by 3. Font size for the title and axes should be 9px. Select different colours and styles.
    Include all necessary imports in your code snippets.
    If the task request specific graph use it otherwise use appropriate chart

    columns: {columns}

    data: {data}

    context: {context}

    prompt: {task}

    '''

    chart_prompt = ChatPromptTemplate.from_template(CHART_PROMPT)
    graph_agent_chain = chart_prompt | LLM

    graph_agent_response = graph_agent_chain.invoke({
                "columns":df.columns.tolist(),
                "data": df.to_dict(orient="records"),
                "context": context_description,
                "task": user_input
            })
    graph_result_output = graph_agent_response.content.strip() or ""
    code_block_match = re.search(r'```(?:[Pp]ython)?(.*?)```', graph_result_output, re.DOTALL)

    if code_block_match:
        code_block = code_block_match.group(1).strip()
        cleaned_code = re.sub(r'(?m)^\s*fig\.show\(\)\s*$', '', code_block)
        try:
            fig = get_fig_from_code(cleaned_code)
            return fig, graph_result_output
        except:
            fig = go.Figure()
            return fig, ""
            pass
    else:
        fig = go.Figure()
        return fig, ""
    


def survival_plotting_agent(df: pd.DataFrame):
    def identify_survival_columns(df: pd.DataFrame) -> dict:
        prompt = f"""
        I have a dataset with the following columns: {', '.join(df.columns)}.
        I want to generate survival curves.
        Which columns should be used for duration and event?
        Return result in the form of json, Don't add explanation: {{"duration": "col1", "event": "col2"}}
        """
        messages = [
            SystemMessage(content="You are a helpful assistant that identifies survival analysis columns."),
            HumanMessage(content=prompt)
        ]
        response = LLM.invoke(messages)
       
        return json.loads(response.content)
    
    def infer_covariates(query, df_columns):
        messages = [
            SystemMessage(content=f"""
                You are a helpful assistant. Given the following columns: {df_columns},
                and the user query, identify covariates for a Cox proportional hazards model (as a Python list of strings).
                Just return the list of covariate column names in Python syntax. Do not include the duration, event, or group column.
            """),
            HumanMessage(content=query)
        ]
        response = LLM.invoke(messages).content.strip()
        try:
            inferred = eval(response)
            if isinstance(inferred, list):
                return inferred
        except:
            pass
        return []
    
    def generate_survival_subplots(df: pd.DataFrame, columns: dict):
        df = df[[columns['duration'], columns['event']] + ([columns['group']] if 'group' in columns else [])]
        df.columns = ['duration', 'event'] + (['group'] if 'group' in columns else [])

        fitters = [
            (KaplanMeierFitter, "Kaplan-Meier"),
            (NelsonAalenFitter, "Nelson-Aalen"),
            (BreslowFlemingHarringtonFitter, "BH")
        ]

        fig = make_subplots(rows=3, cols=1, shared_xaxes=True, vertical_spacing=0.1,
                            subplot_titles=[name for _, name in fitters])

        for i, (fitter_cls, title) in enumerate(fitters, start=1):
            fitter = fitter_cls()
            if 'group' in df.columns:
                for name, grouped_df in df.groupby("group"):
                    fitter.fit(grouped_df["duration"], grouped_df["event"], label=f"{title} - {name}")
                    curve_df = (fitter.survival_function_ if hasattr(fitter, 'survival_function_') else fitter.cumulative_hazard_).reset_index()
                    fig.add_trace(
                        go.Scatter(x=curve_df["timeline"], y=curve_df[fitter._label], mode='lines', name=fitter._label),
                        row=i, col=1
                    )
            else:
                fitter.fit(df["duration"], df["event"], label=f"{title} - Overall")
                curve_df = (fitter.survival_function_ if hasattr(fitter, 'survival_function_') else fitter.cumulative_hazard_).reset_index()
                fig.add_trace(
                    go.Scatter(x=curve_df["timeline"], y=curve_df[fitter._label], mode='lines', name=fitter._label),
                    row=i, col=1
                )

        fig.update_layout(
            height=900,
            title_text="Survival Curves by Method",
            showlegend=True
        )
        return fig
    
    def generate_cox_fitting(df, inferred_time_event_dict):
        
        cph = CoxPHFitter()
        df_cox = df.copy()

        # Switch the variables and Rename the variables
        inferred_column_dict = {v: k for k, v in inferred_time_event_dict.items()}
        df_cox = df_cox.rename(columns=inferred_column_dict)
        #df_cox = df_cox.drop(['Patient ID'], axis = 1)
        
        df_cox = df_cox.apply(LabelEncoder().fit_transform)
        cph.fit(df_cox, duration_col="duration", event_col="event")
        #cox_fitted_fig = cph.plot()
        
        
        
        return 
    
    
    try:
        inferred_duration_event_dict = identify_survival_columns(df)
        print(inferred_duration_event_dict)
        fig = go.Figure()
        fig = generate_survival_subplots(df, inferred_duration_event_dict)
       
        return fig, ""
    except Exception as e:
        fig = go.Figure()
        return fig, str(e)
        
    

    
# Multi-agent decision routing
def get_plotting_agent(df,  context_description,user_query):
    def route_query(user_query: str) -> str:
        messages = [
            SystemMessage(content="You are a routing assistant. Decide if the query is about survival analysis or general plotting. Return 'survival' or 'general' only."),
            HumanMessage(content=f"Query: {user_query}")
        ]
        response = LLM.invoke(messages)
        return response.content.strip().lower()
    
    task = route_query(user_query)
    if task == "survival":
        fig, error_message = survival_plotting_agent(df)
        return fig, error_message
        

        
    elif task == "general":
        fig, plot_code = general_plotting_agent(df, context_description,user_query)
        fig2 = go.Figure()
        return fig, plot_code
        
    else:
        fig = go.Figure()
        plot_code = ""
        return fig, plot_code
